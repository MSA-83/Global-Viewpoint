# Bundle Audit

## Preserved
- Legacy root application files
- SQLite database artifacts
- Legacy deployment files
- Rewritten backend/frontend stack

## Normalized
- Monorepo workspace config
- Frontend/backend separation
- Worker entrypoints
- Infra and migration layout

## Intentional changes
- Old root files moved to `apps/legacy-web/`
- New backend moved to `services/api/`
- New frontend moved to `apps/analyst-ui/`
- Deployment configs moved to `infra/`


## v7 refinement pass
- Added Vite env typings.
- Improved map legend, heading arrows, and jamming visuals.
- Aligned alert scopes with actual filter behavior.
- Added copilot follow-up actions driven by backend responses.
