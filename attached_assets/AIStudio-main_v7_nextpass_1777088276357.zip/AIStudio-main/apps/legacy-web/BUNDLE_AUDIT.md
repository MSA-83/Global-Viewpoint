# Bundle Audit

This archive is a strict superset of the original `AIStudio-main.zip`.

## Verified

- All original file paths are present.
- All original file hashes match exactly.
- The added production rewrite lives alongside the original app instead of replacing it.

## Notes

The original SQLite database files remain included for fidelity with the source archive.
The new backend and frontend stacks are added under `backend/` and `frontend/`.
