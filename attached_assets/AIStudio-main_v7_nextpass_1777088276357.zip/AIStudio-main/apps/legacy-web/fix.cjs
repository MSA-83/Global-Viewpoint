const fs = require('fs');
['newsapi.ts', 'firms.ts', 'cyber.ts', 'orbital.ts'].forEach(f => {
  const p = './services/ingestion/' + f;
  let c = fs.readFileSync(p, 'utf8');
  c = c.replace('db.prepare(\\`', 'db.prepare(`');
  c = c.replace('\\`);', '`);');
  fs.writeFileSync(p, c);
});
