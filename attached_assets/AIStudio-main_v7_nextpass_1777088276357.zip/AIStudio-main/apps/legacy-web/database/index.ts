import Database from 'better-sqlite3';
import path from 'path';

export const db = new Database('sentinel.db', { verbose: undefined }); // Remove verbose in prod
db.pragma('journal_mode = WAL');

export function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS entities (
      id TEXT PRIMARY KEY,
      domain TEXT NOT NULL,
      type TEXT NOT NULL,
      name TEXT,
      callsign TEXT,
      lat REAL,
      lng REAL,
      heading REAL,
      speed REAL,
      altitude REAL,
      severity TEXT,
      confidence REAL,
      metadata TEXT,
      last_updated TEXT
    );

    CREATE TABLE IF NOT EXISTS observations (id INTEGER PRIMARY KEY AUTOINCREMENT,entity_id TEXT NOT NULL,lat REAL,lng REAL,speed REAL,heading REAL,created_at TEXT);

    CREATE TABLE IF NOT EXISTS alerts (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT,
      severity TEXT NOT NULL,
      domain TEXT,
      status TEXT,
      lat REAL,
      lng REAL,
      created_at TEXT
    );

    CREATE TABLE IF NOT EXISTS cases (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      status TEXT,
      assigned_to TEXT,
      created_at TEXT
    );
  `);
  
  console.log('[DB] Sentinel Database Initialized');
}
