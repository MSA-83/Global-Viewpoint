import { processObservation } from '../engine/pol.js';
import { db } from '../../database/index.js';
import type { Server } from 'socket.io';

const SATELLITE_NORAD_IDS = [
  25544, // ISS
  20580, // Hubble Space Telescope
  48274, // Tiangong Space Station
  43013, // NOAA 20
  48209, // Sentinel 6
];

export async function fetchOrbitalData(io: Server) {
  const apiKey = process.env.N2YO_KEY;
  if (!apiKey) {
    console.warn('[ORBITAL] N2YO_KEY not found. Skipping orbital feed.');
    return;
  }

  try {
    console.log('[ORBITAL] Fetching satellite telemetry from N2YO...');
    const records = [];

    // The endpoint requires an observer location, we use 0,0,0
    for (const noradId of SATELLITE_NORAD_IDS) {
      const url = `https://api.n2yo.com/rest/v1/satellite/positions/${noradId}/0/0/0/1/&apiKey=${apiKey}`;
      const res = await fetch(url);
      const data = await res.json();

      if (data.info && data.positions && data.positions.length > 0) {
        const pos = data.positions[0];
        records.push({
          id: `NORAD-${noradId}`,
          name: data.info.satname,
          lat: pos.satlatitude,
          lng: pos.satlongitude,
          altitude: pos.sataltitude, // in km
          heading: pos.azimuth || 0, 
          timestamp: pos.timestamp
        });
      }
    }

    if (records.length === 0) return;

    const insert = db.prepare(`
      INSERT OR REPLACE INTO entities 
      (id, domain, type, name, callsign, lat, lng, heading, speed, altitude, severity, confidence, metadata, last_updated)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const insertMany = db.transaction((data) => {
      for (const req of data) {
        insert.run(
          req.id, 'orbital', 'satellite', req.name, req.id.replace('NORAD-', 'NOR-'),
          req.lat, req.lng, req.heading, 
          27000, // rough orbital speed in km/h
          req.altitude * 3280.84, // convert km to feet
          'normal', 1.0, 
          JSON.stringify({ source: 'N2YO', elevation: req.altitude }), 
          new Date(req.timestamp * 1000).toISOString()
        );
      }
    });

    insertMany(records);
    console.log(`[ORBITAL] Ingested ${records.length} satellite positions.`);

  } catch (error) {
    console.error('[ORBITAL] Failed to fetch data:', error);
  }
}

export function startOrbitalIngestor(io: Server) {
  fetchOrbitalData(io);
  // Poll every 1 minute
  setInterval(() => fetchOrbitalData(io), 60 * 1000);
}
