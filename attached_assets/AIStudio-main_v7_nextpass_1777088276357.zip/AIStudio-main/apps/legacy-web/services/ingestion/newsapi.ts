import { db } from '../../database/index.js';
import type { Server } from 'socket.io';

export async function fetchNewsThreats(io: Server) {
  const apiKey = process.env.NEWSAPI_KEY;
  if (!apiKey) {
    console.warn('[OSINT] NEWSAPI_KEY not found. Skipping News API feed.');
    return;
  }

  try {
    console.log('[OSINT] Fetching global threat keywords from News API...');
    const url = `https://newsapi.org/v2/everything?q=(cyberattack OR missile OR troops OR earthquake OR maritime incident)&language=en&sortBy=publishedAt&pageSize=10&apiKey=${apiKey}`;
    
    const response = await fetch(url);
    const data = await response.json();

    if (data.status === 'ok' && data.articles) {
      const insert = db.prepare(`
        INSERT OR IGNORE INTO alerts (id, title, description, severity, domain, status, lat, lng, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      const newAlerts: any[] = [];
      
      const insertMany = db.transaction((articles) => {
        for (const article of articles) {
          // Generate a deterministic ID based on URL to avoid duplicates
          const id = `OSINT-${Buffer.from(article.url || '').toString('base64').substring(0, 10)}`;
          const title = article.title;
          const description = article.description || 'No description provided';
          const severity = (title.toLowerCase().includes('missile') || title.toLowerCase().includes('cyberattack')) ? 'critical' : 'high';
          const domain = title.toLowerCase().includes('cyber') ? 'cyber' : 'conflict';
          const status = 'Active';
          // Roughly map to null lat/lng since it's global news, or we could NLP it. We'll use 0,0 
          const lat = 0;
          const lng = 0;
          const created_at = article.publishedAt;

          // Note: using insert/ignore handles dups assuming we set ID properly. 
          // SQLite INSERT OR IGNORE works if ID is primary key.
          try {
             insert.run(id, title, description, severity, domain, status, lat, lng, created_at);
             newAlerts.push({id, title, description, severity, domain, status, lat, lng, created_at});
          } catch(e) {}
        }
      });

      insertMany(data.articles);
      
      if (newAlerts.length > 0) {
        console.log(`[OSINT] Ingested ${newAlerts.length} new threat alerts.`);
        // Notify frontend
      }
    }
  } catch (error) {
    console.error('[OSINT] Failed to fetch news API:', error);
  }
}

export function startNewsIngestor(io: Server) {
  // initial fetch
  fetchNewsThreats(io);
  // poll every 15 min
  setInterval(() => fetchNewsThreats(io), 15 * 60 * 1000);
}
