import { processObservation } from '../engine/pol.js';
import { db } from '../../database/index.js';
import type { Server } from 'socket.io';

const generateId = () => Math.random().toString(36).substring(2, 9);

export function startSimulator(io: Server) {
  console.log('[Simulator] Starting global feed ingestion simulation');

  // Seed initial data
  const domains = ['aviation', 'orbital', 'cyber', 'maritime', 'conflict', 'fire', 'seismic', 'disaster', 'weather', 'space_weather', 'air_quality', 'aviation_wx'];
  
  const seedEntities = Array.from({ length: 50 }).map(() => ({
    id: generateId(),
    domain: domains[Math.floor(Math.random() * domains.length)],
    type: 'asset',
    name: `Asset-${Math.floor(Math.random() * 1000)}`,
    callsign: `CS-${Math.floor(Math.random() * 1000)}`,
    lat: (Math.random() * 180) - 90,
    lng: (Math.random() * 360) - 180,
    heading: Math.random() * 360,
    speed: Math.random() * 600,
    altitude: Math.random() * 40000,
    severity: Math.random() > 0.9 ? 'critical' : 'normal',
    confidence: 0.8 + (Math.random() * 0.2),
    metadata: JSON.stringify({ source: 'simfeed', country: 'UNKNOWN' }),
    last_updated: new Date().toISOString()
  }));

  const insert = db.prepare(`
    INSERT OR REPLACE INTO entities 
    (id, domain, type, name, callsign, lat, lng, heading, speed, altitude, severity, confidence, metadata, last_updated)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertMany = db.transaction((entities) => {
    for (const e of entities) {
      insert.run(e.id, e.domain, e.type, e.name, e.callsign, e.lat, e.lng, e.heading, e.speed, e.altitude, e.severity, e.confidence, e.metadata, e.last_updated);
    }
  });

  insertMany(seedEntities);

  io.emit('bulk_sync', seedEntities);

  // Periodic updates to simulate movement
  setInterval(() => {
    const time = new Date().toISOString();
    const toUpdate = seedEntities.slice(0, 10).map(e => {
      // simulate movement
      e.lat += (Math.random() * 0.5 - 0.25);
      e.lng += (Math.random() * 0.5 - 0.25);
      e.heading = (e.heading + (Math.random() * 10 - 5)) % 360;
      e.last_updated = time;
      return e;
    });

    insertMany(toUpdate);
    
    // Broadcast changes format
    io.emit('entity_updates', toUpdate);

  }, 1000);
}
