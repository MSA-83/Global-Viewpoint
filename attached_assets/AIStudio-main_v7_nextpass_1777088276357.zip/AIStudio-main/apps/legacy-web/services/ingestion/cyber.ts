import { db } from '../../database/index.js';
import type { Server } from 'socket.io';
import https from 'https';

export async function fetchCyberThreats(io: Server) {
  // Using Abuse.ch URLHaus or Feodo Tracker for C2/botnet IPs, mapped to Geo
  // We can simulate the geo mapping if we don't do an IP lookup, or just do a few simulated hotspots anchored around reported threat data.
  // We will download recent Feodo Tracker botnet C2s
  
  try {
    console.log('[CYBER] Fetching C2 Botnet threats from Abuse.ch...');
    const url = 'https://feodotracker.abuse.ch/downloads/ipblocklist.csv';
    
    // Quick fetch
    const res = await fetch(url);
    const text = await res.text();
    
    const lines = text.split('\\n');
    const activeThreats = [];
    
    // We'll deterministically hash the IPs into latitude/longitude for visualization
    // since we don't have a free MaxMind geo DB in the container.
    // This gives them fixed map locations.
    const ipToGeo = (ip: string) => {
      const parts = ip.split('.');
      if (parts.length !== 4) return { lat: 0, lng: 0 };
      const lat = (parseInt(parts[0]) / 255) * 180 - 90;
      const lng = (parseInt(parts[1]) / 255) * 360 - 180;
      return { lat, lng };
    };

    for (const line of lines) {
      if (line.startsWith('#') || !line.trim()) continue;
      const cols = line.split(',');
      if (cols.length < 5) continue;
      
      const ip = cols[1].replace(/"/g, '');
      const port = cols[2].replace(/"/g, '');
      const status = cols[3].replace(/"/g, '');
      const malware = cols[4].replace(/"/g, '');
      
      if (status === 'online') {
          activeThreats.push({ ip, port, malware });
      }
    }

    if (activeThreats.length === 0) return;

    // Use a subset to avoid flooding the map
    const topThreats = activeThreats.slice(0, 200);

    const insert = db.prepare(`
      INSERT OR REPLACE INTO entities 
      (id, domain, type, name, callsign, lat, lng, heading, speed, altitude, severity, confidence, metadata, last_updated)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const insertMany = db.transaction((data) => {
      for (const req of data) {
        const geo = ipToGeo(req.ip);
        const id = `C2-${req.ip}`;
        
        insert.run(
          id, 'cyber', 'c2_server', `${req.malware} C2 Node`, req.ip,
          geo.lat, geo.lng, 0, 0, 0, 'critical', 0.99, 
          JSON.stringify({ source: 'Abuse.ch', port: req.port, malware: req.malware }), 
          new Date().toISOString()
        );
      }
    });

    insertMany(topThreats);
    console.log(`[CYBER] Ingested ${topThreats.length} active botnet C2 nodes.`);

  } catch (error) {
    console.error('[CYBER] Failed to fetch cyber data:', error);
  }
}

export function startCyberIngestor(io: Server) {
  fetchCyberThreats(io);
  setInterval(() => fetchCyberThreats(io), 30 * 60 * 1000);
}
