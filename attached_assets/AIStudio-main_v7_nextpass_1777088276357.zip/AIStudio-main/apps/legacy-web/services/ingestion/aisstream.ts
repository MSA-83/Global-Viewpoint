import { processObservation } from '../engine/pol.js';
import WebSocket from 'ws';
import { db } from '../../database/index.js';
import type { Server } from 'socket.io';

export function startAisStream(io: Server) {
  const apiKey = process.env.AISSTREAM_KEY;
  if (!apiKey) {
    console.warn('[AIS] AISSTREAM_KEY not found in .env, skipping real-time Maritime feed.');
    return;
  }

  console.log('[AIS] Connecting to AisStream.io live feed...');
  const ws = new WebSocket('wss://stream.aisstream.io/v0/stream');

  ws.on('open', () => {
    console.log('[AIS] Connected. Subscribing to global maritime data.');
    const subscriptionMessage = {
      APIKey: apiKey,
      // Global bounding box to capture all ships
      BoundingBoxes: [[[-90, -180], [90, 180]]],
      FilterMessageTypes: ["PositionReport"]
    };
    ws.send(JSON.stringify(subscriptionMessage));
  });

  const insert = db.prepare(`
    INSERT OR REPLACE INTO entities 
    (id, domain, type, name, callsign, lat, lng, heading, speed, altitude, severity, confidence, metadata, last_updated)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  ws.on('message', (data: WebSocket.Data) => {
    try {
      const parsedMessage = JSON.parse(data.toString());
      if (parsedMessage["MessageType"] === "PositionReport") {
        const report = parsedMessage["Message"]["PositionReport"];
        const metadata = parsedMessage["MetaData"];
        
        const mmsi = String(report["UserID"]);
        const shipName = metadata["ShipName"] ? metadata["ShipName"].trim() : `Vessel ${mmsi}`;
        
        const entity = {
          id: `MMSI-${mmsi}`,
          domain: 'maritime',
          type: 'vessel',
          name: shipName,
          callsign: mmsi, // usually MMSI if callsign isn't present
          lat: report["Latitude"],
          lng: report["Longitude"],
          heading: report["TrueHeading"] === 511 ? 0 : report["TrueHeading"], // 511 means not available
          speed: report["Sog"], // Speed over ground
          altitude: 0,
          severity: 'normal',
          confidence: 0.95,
          metadata: JSON.stringify({ mmsi, navStatus: report["NavigationalStatus"], time_utc: metadata["time_utc"] }),
          last_updated: new Date().toISOString()
        };

        // Save to DB
        insert.run(
          entity.id, entity.domain, entity.type, entity.name, entity.callsign, 
          entity.lat, entity.lng, entity.heading, entity.speed, entity.altitude, 
          entity.severity, entity.confidence, entity.metadata, entity.last_updated
        );

        // Emit to clients
        io.emit('entity_updates', [entity]);
      }
    } catch (e) {
      console.error('[AIS] parse error', e);
    }
  });

  ws.on('close', () => {
    console.log('[AIS] Disconnected. Reconnecting in 5s...');
    setTimeout(() => startAisStream(io), 5000);
  });

  ws.on('error', (err) => {
    console.error('[AIS] WebSocket error:', err.message);
  });
}
