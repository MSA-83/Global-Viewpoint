import { db } from '../../database/index.js';
import type { Server } from 'socket.io';

export async function fetchNasaFirms(io: Server) {
  const apiKey = process.env.NASA_FIRMS_KEY;
  if (!apiKey) return;

  try {
    console.log('[FIRMS] Fetching global thermal anomalies...');
    // Grab world area (W,S,E,N = -180,-90,180,90) for last 1 day
    // The FIRMS API format: /api/area/csv/[MAP_KEY]/VIIRS_SNPP_NRT/world/1
    const url = `https://firms.modaps.eosdis.nasa.gov/api/area/csv/${apiKey}/VIIRS_SNPP_NRT/world/1`;
    const res = await fetch(url);
    const text = await res.text();
    
    // Simple CSV parser
    const lines = text.split('\\n');
    if (lines.length < 2) return;
    
    // headers: latitude,longitude,bright_ti4,scan,track,acq_date,acq_time,satellite,instrument,confidence,version,bright_ti5,frp,daynight
    const records = [];
    for (let i = 1; i < lines.length; i++) {
      if (!lines[i].trim()) continue;
      const cols = lines[i].split(',');
      if (cols.length < 10) continue;
      
      const lat = parseFloat(cols[0]);
      const lng = parseFloat(cols[1]);
      const confidence = cols[9];
      const frp = parseFloat(cols[12]); // Fire Radiative Power
      
      // Filter for high confidence or high FRP (significant fires only so we don't spam the UI)
      if (confidence === 'h' || frp > 100) {
        records.push({ lat, lng, frp, confidence });
      }
    }

    if (records.length === 0) return;

    const insert = db.prepare(`
      INSERT OR REPLACE INTO entities 
      (id, domain, type, name, callsign, lat, lng, heading, speed, altitude, severity, confidence, metadata, last_updated)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const insertMany = db.transaction((data) => {
      for (const req of data) {
        // A unique deterministic ID based on exact coordinate (since it's a fixed event for that day)
        const id = `THERMAL-${req.lat.toFixed(2)}-${req.lng.toFixed(2)}`;
        const severity = req.frp > 500 ? 'critical' : 'high';
        
        insert.run(
          id, 'infrastructure', 'anomaly', 'Thermal Anomaly / Fire', 'FIRMS',
          req.lat, req.lng, 0, 0, 0, severity, 
          req.confidence === 'h' ? 0.95 : 0.8, 
          JSON.stringify({ source: 'NASA FIRMS', frp: req.frp }), 
          new Date().toISOString()
        );
      }
    });

    insertMany(records);
    console.log(`[FIRMS] Ingested ${records.length} thermal anomalies.`);

  } catch (error) {
    console.error('[FIRMS] Failed to fetch data:', error);
  }
}

export function startFirmsIngestor(io: Server) {
  fetchNasaFirms(io);
  // Real world this updates a few times a day, we'll poll every 1 hour
  setInterval(() => fetchNasaFirms(io), 60 * 60 * 1000);
}
