import { db } from '../../database/index.js';
import type { Server } from 'socket.io';

const DOMAIN_TTLS: Record<string, number> = {
  aviation: 600,       // 10 mins
  maritime: 1800,      // 30 mins
  cyber: 3600 * 24,    // 24 hours
  infrastructure: 3600 * 24,
  orbital: 600,        // 10 mins
  conflict: 86400,     // 24 hours
  default: 3600
};

export function startTtlEngine(io: Server) {
  console.log('[ENGINE] Starting TTL Confidence Decay Engine...');
  
  setInterval(() => {
    const now = Date.now();
    const entities = db.prepare('SELECT id, domain, confidence, last_updated FROM entities').all() as any[];
    
    let expiredCount = 0;
    const updateConf = db.prepare('UPDATE entities SET confidence = ? WHERE id = ?');
    const deleteEntity = db.prepare('DELETE FROM entities WHERE id = ?');
    const deleteObs = db.prepare('DELETE FROM observations WHERE entity_id = ?');

    db.transaction(() => {
      for (const e of entities) {
        const ttl = DOMAIN_TTLS[e.domain] || DOMAIN_TTLS.default;
        const lastUpdatedMs = new Date(e.last_updated).getTime();
        const elapsedS = (now - lastUpdatedMs) / 1000;
        
        let newConf = Math.max(0.0, 1.0 - (elapsedS / ttl));
        
        // Prevent precision issues
        newConf = Math.round(newConf * 1000) / 1000;

        if (newConf !== e.confidence) {
          updateConf.run(newConf, e.id);
          
          // Emit update
          io.emit('entity_update', { id: e.id, confidence: newConf });

          if (newConf === 0) {
            expiredCount++;
            deleteEntity.run(e.id);
            deleteObs.run(e.id);
            io.emit('entity_expired', { id: e.id });
          }
        }
      }
    })();
    
    if (expiredCount > 0) {
      console.log(`[ENGINE] TTL Engine cleared ${expiredCount} expired entities.`);
    }

  }, 10 * 1000); // Run every 10 seconds
}
