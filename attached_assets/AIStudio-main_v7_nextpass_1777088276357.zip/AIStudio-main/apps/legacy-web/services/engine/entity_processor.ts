import { db } from '../../database/index.js';
import type { Server } from 'socket.io';
import { processObservation } from './pol.js';

export function upsetEntity(io: Server, e: any) {
  const insert = db.prepare(`
    INSERT OR REPLACE INTO entities 
    (id, domain, type, name, callsign, lat, lng, heading, speed, altitude, severity, confidence, metadata, last_updated)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  insert.run(
    e.id, 
    e.domain, 
    e.type, 
    e.name || null, 
    e.callsign || null,
    e.lat, 
    e.lng, 
    e.heading || 0, 
    e.speed || 0, 
    e.altitude || 0, 
    e.severity || 'low', 
    e.confidence || 1.0, 
    JSON.stringify(e.metadata || {}), 
    e.last_updated || new Date().toISOString()
  );

  // Send to graph logic & observation history
  processObservation(io, e.id, e.lat, e.lng, e.speed || 0, e.heading || 0, e.domain);
}
