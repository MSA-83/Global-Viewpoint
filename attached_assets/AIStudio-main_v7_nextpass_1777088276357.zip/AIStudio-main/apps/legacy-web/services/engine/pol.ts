import { db } from '../../database/index.js';
import type { Server } from 'socket.io';
import { v4 as uuidv4 } from 'uuid';

// Haversine distance in KM
function getDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371; 
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
}

export function processObservation(io: Server, id: string, lat: number, lng: number, speed: number, heading: number, domain: string) {
  // 1. Insert Observation
  db.prepare('INSERT INTO observations (entity_id, lat, lng, speed, heading, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(id, lat, lng, speed, heading, new Date().toISOString());

  // 2. Fetch history (limit to last 20 for brief analysis)
  const history = db.prepare('SELECT lat, lng, speed, heading, created_at FROM observations WHERE entity_id = ? ORDER BY created_at DESC LIMIT 20')
    .all(id) as any[];

  if (history.length < 3) return;

  // --- ANOMALY 1: COORDINATE JUMP / PHYSICAL LIMIT SANITY ---
  // Detect if the entity "jumped" impossibly fast (Spoofing)
  const newest = history[0];
  const prev = history[1];
  
  const dtHours = (new Date(newest.created_at).getTime() - new Date(prev.created_at).getTime()) / (1000 * 3600);
  const distKm = getDistance(prev.lat, prev.lng, newest.lat, newest.lng);
  
  if (dtHours > 0 && dtHours < 24) {
    const impliedSpeedKt = (distKm / dtHours) * 0.539957; // km/h to knots
    
    let maxSpeed = 999;
    if (domain === 'aviation') maxSpeed = 750; // Mach 1+
    if (domain === 'maritime') maxSpeed = 50;  // crazy fast boat
    
    if (impliedSpeedKt > maxSpeed * 1.5) {
       // Trigger ATLAS Anomaly AML.T0043 (Craft Adversarial Data) / AML.T0088 (Deepfake)
       fireAnomaly(io, id, 'COORDINATE_SPOOF', 'CRITICAL', 
        `Entity reported an impossible physical position jump of ${distKm.toFixed(1)}km in ${(dtHours * 60).toFixed(1)}mins (Implied Speed: ${impliedSpeedKt.toFixed(0)} kt)`,
        'AML.T0043'
       );
    }
  }

  // --- ANOMALY 2: LOITERING DETECTOR ---
  if (history.length >= 10 && (domain === 'aviation' || domain === 'maritime')) {
    // Calculate centroid of last 10 points
    const set = history.slice(0, 10);
    const avgLat = set.reduce((s, h) => s + h.lat, 0) / set.length;
    const avgLng = set.reduce((s, h) => s + h.lng, 0) / set.length;

    // Calculate max radius from centroid
    let maxDist = 0;
    let avgSpeed = 0;
    for (const h of set) {
      maxDist = Math.max(maxDist, getDistance(avgLat, avgLng, h.lat, h.lng));
      avgSpeed += h.speed || 0;
    }
    avgSpeed /= set.length;

    const timeDiffMins = (new Date(set[0].created_at).getTime() - new Date(set[set.length-1].created_at).getTime()) / 60000;

    let isLoitering = false;
    if (domain === 'aviation') {
       if (avgSpeed < 200 && maxDist < 20 && timeDiffMins > 10) isLoitering = true;
    } else if (domain === 'maritime') {
       if (avgSpeed < 3 && maxDist < 2 && timeDiffMins > 20) isLoitering = true;
    }

    if (isLoitering) {
      fireAnomaly(io, id, 'LOITERING', 'HIGH',
        `Entity observed loitering. Kept within a ${maxDist.toFixed(1)}km radius for ${timeDiffMins.toFixed(0)} minutes.`
      );
    }
  }
}

function fireAnomaly(io: Server, entityId: string, alertType: string, severity: string, description: string, atlasId?: string) {
  // Check if we recently fired this exact alert
  const recent = db.prepare('SELECT id FROM alerts WHERE alert_type = ? AND entity_id = ? AND description = ? AND created_at > datetime("now", "-1 hour")').get(alertType, entityId, description);
  
  if (recent) return;

  const alert = {
    id: uuidv4(),
    entity_id: entityId,
    alert_type: alertType,
    severity,
    title: atlasId ? `[ATLAS: ${atlasId}] ${alertType.replace('_', ' ')}` : alertType.replace('_', ' '),
    description,
    atlas_technique: atlasId || null,
    created_at: new Date().toISOString()
  };

  db.prepare('INSERT INTO alerts (id, entity_id, alert_type, severity, title, description, atlas_technique, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(alert.id, alert.entity_id, alert.alert_type, alert.severity, alert.title, alert.description, alert.atlas_technique, alert.created_at);

  io.emit('new_alert', alert);
  console.log(`[POL] Anomaly Detected: ${alert.title} on ${entityId}`);
}
