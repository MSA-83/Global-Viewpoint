const fs = require('fs');

const files = ['simulator.ts', 'aisstream.ts', 'orbital.ts'];
for (const file of files) {
  const p = './services/ingestion/' + file;
  let c = fs.readFileSync(p, 'utf8');
  
  if (!c.includes('processObservation')) {
    c = "import { processObservation } from '../engine/pol.js';\\n" + c;
    
    // Instead of completely rewriting, we'll hook the insert execution manually if needed.
    // Actually, maybe we can run processObservation in the main loop of the file?
    
    // Replace insert.run(...) with an intercepted version or insert just the code for insert.run
    c = c.replace(/insert\\.run\\(([^;]+)\\);/g, (match, args) => {
      // Find the variables or use the generic approach: we know 'req.' or 'e.' or 'entity'
      return `${match} processObservation(io, typeof req !== "undefined" ? req.id : typeof e !== "undefined" ? e.id : entity.id, typeof req !== "undefined" ? req.lat : typeof e !== "undefined" ? e.lat : entity.lat, typeof req !== "undefined" ? req.lng : typeof e !== "undefined" ? e.lng : entity.lng, typeof req !== "undefined" ? req.speed || 0 : typeof e !== "undefined" ? e.speed || 0 : 0, typeof req !== "undefined" ? req.heading || 0 : typeof e !== "undefined" ? e.heading || 0 : 0, typeof req !== "undefined" ? (req.domain || 'unknown') : typeof e !== "undefined" ? e.domain || 'unknown' : entity.domain || 'unknown');`;
    });

    fs.writeFileSync(p, c);
    console.log('patched', p);
  }
}
