import 'dotenv/config';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import cors from 'cors';
import path from 'node:path';
import { v4 as uuidv4 } from 'uuid';
import { db, initDb } from './database/index.js';
import { startSimulator } from './services/ingestion/simulator.js';
import { startAisStream } from './services/ingestion/aisstream.js';
import { startNewsIngestor } from './services/ingestion/newsapi.js';
import { startFirmsIngestor } from './services/ingestion/firms.js';
import { startCyberIngestor } from './services/ingestion/cyber.js';
import { startOrbitalIngestor } from './services/ingestion/orbital.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  const server = http.createServer(app);
  const io = new SocketIOServer(server, {
    cors: { origin: '*' }
  });

  initDb();
  startSimulator(io);
  startAisStream(io);
  startNewsIngestor(io);
  startFirmsIngestor(io);
  startCyberIngestor(io);
  startOrbitalIngestor(io);

  import('./services/engine/ttl.js').then((m) => m.startTtlEngine(io));

  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  app.get('/api/entities', (req, res) => {
    const rawData = db.prepare('SELECT * FROM entities ORDER BY last_updated DESC LIMIT 1000').all();
    const entities = rawData.map((d: any) => ({ ...d, metadata: JSON.parse(d.metadata || '{}') }));
    res.json(entities);
  });

  app.get('/api/entities/:id/history', (req, res) => {
    const data = db.prepare('SELECT lat, lng, speed, heading, created_at FROM observations WHERE entity_id = ? ORDER BY created_at DESC LIMIT 50').all(req.params.id);
    res.json(data);
  });

  app.get('/api/entities/:id/notes', (req, res) => {
    try {
      const data = db.prepare('SELECT * FROM notes WHERE entity_id = ? ORDER BY created_at DESC').all(req.params.id);
      res.json(data);
    } catch {
      res.json([]);
    }
  });

  app.post('/api/entities/:id/notes', (req, res) => {
    try {
      db.prepare('CREATE TABLE IF NOT EXISTS notes (id TEXT PRIMARY KEY, entity_id TEXT NOT NULL, content TEXT, created_at TEXT)').run();
      const id = uuidv4();
      const content = req.body.content || '';
      db.prepare('INSERT INTO notes (id, entity_id, content, created_at) VALUES (?, ?, ?, ?)').run(id, req.params.id, content, new Date().toISOString());
      res.json({ success: true, id });
    } catch (e) {
      res.status(500).json({ error: String(e) });
    }
  });

  app.delete('/api/notes/:id', (req, res) => {
    try {
      db.prepare('DELETE FROM notes WHERE id = ?').run(req.params.id);
      res.json({ success: true });
    } catch {
      res.status(500).json({ error: 'Failed' });
    }
  });

  app.get('/api/alerts', (req, res) => {
    const data = db.prepare('SELECT * FROM alerts ORDER BY created_at DESC LIMIT 500').all();
    res.json(data);
  });

  io.on('connection', (socket) => {
    console.log(`[Socket] User connected: ${socket.id}`);

    socket.on('telemetry_ping', (ack?: () => void) => {
      if (typeof ack === 'function') ack();
      socket.emit('telemetry_pong', { ts: Date.now() });
    });

    socket.on('disconnect', () => {
      console.log(`[Socket] User disconnected: ${socket.id}`);
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  setInterval(() => {
    // Mock simulator heartbeat retained for backward compatibility.
  }, 5000);

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`[SENTINEL-X] Platform Command Core running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server", err);
  process.exit(1);
});
