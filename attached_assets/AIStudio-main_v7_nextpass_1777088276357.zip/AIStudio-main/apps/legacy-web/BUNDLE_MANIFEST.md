# Sentinel-X complete bundle

This archive preserves the original AIStudio-main repo intact and adds a production rewrite beside it.

## Preserved original repo
- AIStudio-main/package.json
- AIStudio-main/server.ts
- AIStudio-main/src/*
- AIStudio-main/services/*
- AIStudio-main/database/index.ts
- AIStudio-main/sentinel.db*
- AIStudio-main/fix.cjs
- AIStudio-main/patch_ingestors.cjs

## Production rewrite
- backend/
- frontend/
- docker-compose.yml
- railway.toml
- railway.json

## Environment files
- AIStudio-main/.env.example (original)
- AIStudio-main/backend/.env.example (production backend)
- AIStudio-main/frontend/.env.example (production frontend)
- AIStudio-main/production/.env.example (combined production template)
