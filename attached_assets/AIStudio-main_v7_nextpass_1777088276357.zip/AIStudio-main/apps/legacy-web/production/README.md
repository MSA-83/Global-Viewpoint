# Sentinel-X

Operational intelligence platform with a FastAPI backend and React/Vite analyst UI.

## Run locally

Backend:
```bash
cd backend
pip install -r requirements.txt
alembic -c alembic.ini upgrade head
gunicorn -c gunicorn.conf.py backend.app.main:app
```

Frontend:
```bash
cd frontend
npm install
npm run dev
```

## Environment

Copy `.env.example` to `.env` and set production secrets before deployment.
