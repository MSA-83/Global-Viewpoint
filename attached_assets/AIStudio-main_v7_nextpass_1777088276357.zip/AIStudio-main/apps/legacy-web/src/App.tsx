/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Shell } from './components/layout/Shell';
import { WatchMap } from './pages/WatchMap';
import { ThreatIntelligence } from './pages/ThreatIntelligence';
import { CaseManagement } from './pages/CaseManagement';
import { Analytics } from './pages/Analytics';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Shell />}>
          <Route index element={<Navigate to="/watch" replace />} />
          <Route path="watch" element={<WatchMap />} />
          <Route path="threats" element={<ThreatIntelligence />} />
          <Route path="cases" element={<CaseManagement />} />
          <Route path="analytics" element={<Analytics />} />
        </Route>
      </Routes>
    </Router>
  );
}
