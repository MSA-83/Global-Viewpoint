import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { Activity, Shield, Crosshair } from 'lucide-react';

const activityData = [
  { time: '00:00', events: 120 },
  { time: '04:00', events: 180 },
  { time: '08:00', events: 450 },
  { time: '12:00', events: 500 },
  { time: '16:00', events: 480 },
  { time: '20:00', events: 320 },
  { time: '24:00', events: 150 },
];

const riskData = [
  { domain: 'Aviation', critical: 4, high: 12 },
  { domain: 'Maritime', critical: 2, high: 24 },
  { domain: 'Orbital', critical: 0, high: 2 },
  { domain: 'Cyber', critical: 8, high: 45 },
];

export function Analytics() {
  return (
    <div className="p-6 h-full flex flex-col font-sans overflow-y-auto">
      <header className="mb-6 shrink-0">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <Activity className="text-brand-400" />
          GLOBAL ANALYTICS DASHBOARD
        </h1>
        <p className="text-sm text-slate-500 mt-1">Cross-domain intelligence metrics</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 h-80 flex flex-col">
          <h2 className="text-xs font-bold text-slate-400 mb-4 font-mono">24H EVENT VOLUME</h2>
          <div className="flex-1 min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={activityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorEvents" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', fontSize: '12px' }}
                  itemStyle={{ color: '#e2e8f0' }}
                />
                <Area type="monotone" dataKey="events" stroke="#818cf8" strokeWidth={2} fillOpacity={1} fill="url(#colorEvents)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 h-80 flex flex-col">
          <h2 className="text-xs font-bold text-slate-400 mb-4 font-mono">RISK DISTRIBUTION BY DOMAIN</h2>
          <div className="flex-1 min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={riskData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="domain" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', fontSize: '12px' }}
                  cursor={{fill: '#1e293b', opacity: 0.4}}
                />
                <Bar dataKey="critical" stackId="a" fill="#ef4444" radius={[0, 0, 0, 0]} />
                <Bar dataKey="high" stackId="a" fill="#f97316" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-6">
             <Shield className="size-6 text-emerald-400 mb-2" />
             <div className="text-xl font-bold text-white tracking-tight mb-1">Source Reliability</div>
             <div className="text-sm text-slate-500">99.99% uptime across all active ingestion pipelines.</div>
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-6">
             <Crosshair className="size-6 text-brand-400 mb-2" />
             <div className="text-xl font-bold text-white tracking-tight mb-1">Target Acquisition</div>
             <div className="text-sm text-slate-500">142 new unknown targets registered in the last hour.</div>
          </div>
          <div className="bg-slate-900 border border-slate-800 rounded-lg p-6">
             <Activity className="size-6 text-blue-400 mb-2" />
             <div className="text-xl font-bold text-white tracking-tight mb-1">System Load</div>
             <div className="text-sm text-slate-500">Processing 4,500 messages/sec with 12ms latency.</div>
          </div>
      </div>
    </div>
  )
}

