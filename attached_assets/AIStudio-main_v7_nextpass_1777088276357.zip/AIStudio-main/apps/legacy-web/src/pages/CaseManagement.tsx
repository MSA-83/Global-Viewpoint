import { FolderKanban, Search, Plus, Clock, User } from 'lucide-react';

const MOCK_CASES = [
  { id: 'CAS-8821', title: 'Anomalous Orbital Drift - Cosmos 148', status: 'Active', assigned: 'OPERATOR_01', updated: '10m ago' },
  { id: 'CAS-8820', title: 'Unregistered Vessel in EEZ - Sector 7', status: 'Escalated', assigned: 'TAC_TEAM_A', updated: '1h ago' },
  { id: 'CAS-8819', title: 'Border Checkpoint Comms Failure', status: 'Closed', assigned: 'SYSTEM', updated: '2d ago' },
];

export function CaseManagement() {
  return (
    <div className="p-6 h-full flex flex-col font-sans">
      <header className="mb-6 shrink-0 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <FolderKanban className="text-brand-400" />
            CASE DISPATCH
          </h1>
          <p className="text-sm text-slate-500 mt-1">Incident tracking and intelligence dossiers</p>
        </div>
        <button className="bg-brand-500 text-white px-4 py-2 rounded text-sm font-bold shadow-lg shadow-brand-500/20 hover:bg-brand-400 transition-colors flex items-center gap-2">
          <Plus className="size-4" />
          NEW DOSSIER
        </button>
      </header>

      <div className="flex gap-4 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-slate-500" />
          <input 
            type="text" 
            placeholder="Search cases by ID, Tag, or Keyword..." 
            className="w-full bg-slate-900 border border-slate-800 rounded pl-10 pr-4 py-2 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-brand-500"
          />
        </div>
        <select className="bg-slate-900 border border-slate-800 rounded px-4 py-2 text-sm text-slate-300 outline-none">
          <option>All Statuses</option>
          <option>Active</option>
          <option>Escalated</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {MOCK_CASES.map(c => (
          <div key={c.id} className="bg-slate-900 border border-slate-800 rounded-lg p-5 hover:border-slate-700 transition-colors cursor-pointer group">
            <div className="flex justify-between items-start mb-4">
              <span className="text-xs font-mono font-bold text-brand-400">{c.id}</span>
              <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                c.status === 'Active' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 
                c.status === 'Escalated' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 
                'bg-slate-800 text-slate-400 border border-slate-700'
              }`}>{c.status}</span>
            </div>
            <h3 className="text-white font-semibold mb-6 group-hover:text-brand-400 transition-colors">{c.title}</h3>
            
            <div className="flex justify-between items-center text-xs text-slate-500 font-mono">
              <span className="flex items-center gap-1.5"><User className="size-3" /> {c.assigned}</span>
              <span className="flex items-center gap-1.5"><Clock className="size-3" /> {c.updated}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

