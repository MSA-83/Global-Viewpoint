import { useEffect, useState, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Tooltip, useMap, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { io } from 'socket.io-client';
import { GoogleGenAI } from '@google/genai';
import type { Entity } from '../types';
import { Target, AlertTriangle, Ship, Plane, Radio, Terminal, Sparkles, Filter, X } from 'lucide-react';

const SVG_ICONS = {
  aviation: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.2-1.1.6L3 8l6 5.5-4 4-2.5-.5L1 18.5l5.5 2 2 5.5 1.5-1.5-.5-2.5 4-4 5.5 6c.4-.2.7-.6.6-1.1z"/></svg>`,
  maritime: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1 .6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4c0 2.9.94 5.34 2.81 7.76"/><path d="M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6"/><path d="M12 10v4"/><path d="M12 2v3"/></svg>`,
  cyber: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 17 10 11 4 5"/><line x1="12" x2="20" y1="19" y2="19"/></svg>`,
  infrastructure: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>`,
  orbital: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="m3 15 2 2 4-4"/></svg>`,
  conflict: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>`,
  fire: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>`,
  seismic: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>`,
  disaster: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" x2="12" y1="9" y2="13"/><line x1="12" x2="12.01" y1="17" y2="17"/></svg>`,
  weather: `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/></svg>`,
};

const DOMAIN_COLORS: Record<string, string> = {
  aviation: 'text-blue-400 bg-blue-500/20 border-blue-400',
  maritime: 'text-teal-400 bg-teal-500/20 border-teal-400',
  cyber: 'text-fuchsia-400 bg-fuchsia-500/20 border-fuchsia-400 shadow-[0_0_8px_rgba(217,70,239,0.5)]',
  infrastructure: 'text-orange-400 bg-orange-500/20 border-orange-400',
  orbital: 'text-zinc-400 bg-zinc-500/20 border-zinc-400',
  conflict: 'text-red-400 bg-red-500/20 border-red-400',
  fire: 'text-orange-500 bg-orange-600/20 border-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.5)]',
  seismic: 'text-yellow-400 bg-yellow-500/20 border-yellow-400',
  disaster: 'text-purple-400 bg-purple-500/20 border-purple-400',
  weather: 'text-sky-400 bg-sky-500/20 border-sky-400',
  aviation_wx: 'text-blue-300 bg-blue-400/20 border-blue-300',
  space_weather: 'text-indigo-400 bg-indigo-500/20 border-indigo-400',
  air_quality: 'text-emerald-400 bg-emerald-500/20 border-emerald-400',
};

const TTL_COLORS = (conf: number) => {
  if (conf > 0.7) return '#10b981'; // green
  if (conf > 0.3) return '#eab308'; // yellow
  return '#ef4444'; // red
};

function createIcon(domain: string, conf: number = 1.0) {
  const svg = SVG_ICONS[domain as keyof typeof SVG_ICONS] || SVG_ICONS.cyber;
  const colorClass = DOMAIN_COLORS[domain] || DOMAIN_COLORS.cyber;
  const ringColor = TTL_COLORS(conf);
  const ringDash = Math.max(0, conf * 100);

  const html = `<div class="relative flex items-center justify-center size-8">
    <svg class="absolute inset-0 size-8 -rotate-90" viewBox="0 0 36 36">
      <circle cx="18" cy="18" r="16" fill="none" stroke="rgba(255,255,255,0.1)" stroke-width="2" />
      <circle cx="18" cy="18" r="16" fill="none" stroke="${ringColor}" stroke-width="2" stroke-dasharray="${ringDash}, 100" />
    </svg>
    <div class="size-6 rounded-full flex items-center justify-center ${colorClass}">
      ${svg}
    </div>
  </div>`;

  return new L.DivIcon({
    className: 'bg-transparent',
    html,
    iconSize: [32, 32]
  });
}

export function WatchMap() {
  const [entities, setEntities] = useState<Record<string, Entity>>({});
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>(null);
  const [activeThreats, setActiveThreats] = useState<number>(0);

  const [visibleDomains, setVisibleDomains] = useState<Record<string, boolean>>({
    aviation: true,
    maritime: true,
    cyber: true,
    infrastructure: true,
    orbital: true,
    military: true,
    seismic: true,
    fire: true,
    disaster: true,
    weather: true,
    space_weather: true,
    air_quality: true,
    aviation_wx: true,
    conflict: true,
    unknown: true
  });

  const [isCopilotOpen, setIsCopilotOpen] = useState(false);
  const [copilotSummary, setCopilotSummary] = useState('');
  const [copilotLoading, setCopilotLoading] = useState(false);

  const [selectedEntityHistory, setSelectedEntityHistory] = useState<{lat: number, lng: number}[]>([]);
  const [selectedEntityNotes, setSelectedEntityNotes] = useState<{id: string, content: string, created_at: string}[]>([]);

  useEffect(() => {
    if (!selectedEntityId) {
      setSelectedEntityHistory([]);
      setSelectedEntityNotes([]);
      return;
    }
    fetch(`/api/entities/${selectedEntityId}/history`)
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) {
          setSelectedEntityHistory(data.map((d: any) => ({ lat: d.lat, lng: d.lng })));
        }
      })
      .catch(e => console.error('Failed to fetch history', e));

    fetch(`/api/entities/${selectedEntityId}/notes`)
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) {
          setSelectedEntityNotes(data);
        }
      })
      .catch(e => console.error('Failed to fetch notes', e));
  }, [selectedEntityId]);

  const handleSummarize = async () => {
    setCopilotLoading(true);
    setCopilotSummary('');
    setIsCopilotOpen(true);
    try {
      const summaryData = (Object.values(entities) as unknown as Entity[])
        .filter(e => visibleDomains[e.domain] || visibleDomains['unknown'])
        .slice(0, 50)
        .map(e => ({ name: e.name, type: e.type, callsign: e.callsign, domain: e.domain, severity: e.severity }));
       
const aiKey = import.meta.env.VITE_GEMINI_API_KEY as string | undefined;
if (!aiKey) {
  setCopilotSummary('Set VITE_GEMINI_API_KEY to enable AI summaries.');
  return;
}
const ai = new GoogleGenAI({ apiKey: aiKey });
      const prompt = `You are an AI Copilot for a Threat Intelligence application named Sentinel-X. 
Please provide a brief, actionable intelligence summary of the current map view based on the following tracked entities. Keep it strictly under 3 sentences and sound professional and analytical. Focus on the main anomalies or significant counts.

Entities:
${JSON.stringify(summaryData, null, 2)}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });

      setCopilotSummary(response.text || 'No summary generated.');
    } catch (err: any) {
      console.error('[COPILOT] Error:', err);
      setCopilotSummary('Failed to summarize view. ' + (err.message || ''));
    } finally {
      setCopilotLoading(false);
    }
  };

  const toggleDomain = (domain: string) => {
    setVisibleDomains(prev => ({ ...prev, [domain]: !prev[domain] }));
  };

  useEffect(() => {
    // Connect to WebSockets
    const socket = io();

    fetch('/api/alerts')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setActiveThreats(data.length);
        }
      })
      .catch(e => console.error(e));

    socket.on('new_alert', () => {
      setActiveThreats(prev => prev + 1);
    });

    socket.on('bulk_sync', (data: Entity[]) => {
      const map: Record<string, Entity> = {};
      data.forEach(e => map[e.id] = e);
      setEntities(map);
    });

    socket.on('entity_updates', (updates: Entity[]) => {
      setEntities(prev => {
        const next = { ...prev };
        updates.forEach(e => next[e.id] = { ...next[e.id], ...e });
        return next;
      });
    });

    socket.on('entity_update', (update: { id: string, confidence: number }) => {
      setEntities(prev => {
        if (!prev[update.id]) return prev;
        const next = { ...prev };
        next[update.id] = { ...next[update.id], confidence: update.confidence };
        return next;
      });
    });

    socket.on('entity_expired', (data: { id: string }) => {
      setEntities(prev => {
        if (!prev[data.id]) return prev;
        const next = { ...prev };
        delete next[data.id];
        return next;
      });
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const selectedEntity = selectedEntityId ? entities[selectedEntityId] : null;

  return (
    <div className="flex w-full h-full relative">
      <div className="flex-1 bg-slate-950 relative z-0">
        <MapContainer 
          center={[20, 0]} 
          zoom={3} 
          className="w-full h-full outline-none"
          zoomControl={false}
        >
          {/* CartoDB Dark Matter */}
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          />

          {Object.values(entities)
            .filter((entity: any) => visibleDomains[entity.domain] !== false)
            .map((entity: any) => (
            <Marker 
              key={entity.id} 
              position={[entity.lat, entity.lng]}
              icon={createIcon(entity.domain, entity.confidence)}
              eventHandlers={{
                click: () => setSelectedEntityId(entity.id)
              }}
            >
              <Tooltip direction="top" offset={[0, -10]} opacity={1} className="bg-slate-900 border-slate-700 text-slate-200" permanent={typeof selectedEntityId === 'string' && selectedEntityId === entity.id}>
                <span className="font-mono text-xs">{entity.callsign || entity.name || entity.id}</span>
              </Tooltip>
              <Popup className="custom-popup">
                <div className="font-mono text-xs max-w-[200px] max-h-[200px] overflow-y-auto">
                   <strong className="text-brand-400">{entity.callsign || entity.name || entity.id}</strong>
                   <div className="text-[10px] text-slate-500 mb-2 uppercase">{entity.domain} - {entity.type}</div>
                   {entity.metadata && Object.keys(entity.metadata).length > 0 && (
                      <div className="flex flex-col gap-0.5 text-[9px] text-slate-300">
                         {Object.entries(entity.metadata).map(([k, v]) => (
                             <div key={k} className="flex justify-between gap-2 border-b border-white/10 pb-0.5 mb-0.5">
                               <span className="text-slate-500 uppercase">{k}:</span> 
                               <span className="text-right break-all">{String(v)}</span>
                             </div>
                         ))}
                      </div>
                   )}
                </div>
              </Popup>
            </Marker>
          ))}

          {selectedEntityId && selectedEntityHistory.length > 0 && (
             <Polyline 
                positions={selectedEntityHistory.map(h => [h.lat, h.lng]) as [number, number][]} 
                color="#06b6d4" 
                weight={2} 
                opacity={0.8} 
                dashArray="5, 10" 
             />
          )}

        </MapContainer>
        
        {/* Overlays */}
        <div className="absolute top-4 left-4 z-[999] pointer-events-auto flex flex-col gap-4">
          <div className="bg-slate-900/80 border border-slate-700 p-2 rounded backdrop-blur max-w-xs font-mono text-xs shadow-lg">
            <div className="text-brand-400 font-bold mb-1">GLOBAL SENSORS ONLINE</div>
            <div className="text-slate-400 flex justify-between"><span>TRACKED TARGETS:</span> <span className="text-slate-200">{Object.keys(entities).length}</span></div>
            <div className="text-slate-400 flex justify-between"><span>ACTIVE THREATS:</span> <span className="text-red-400">{activeThreats}</span></div>
          </div>
          
          <div className="bg-slate-900/80 border border-slate-700 p-2 rounded backdrop-blur max-w-xs font-mono text-xs shadow-lg">
            <div className="text-slate-200 font-bold mb-2 flex items-center gap-2"><Filter className="size-3"/> SIGNAL FILTERS</div>
            <div className="flex flex-col gap-1.5">
              {Object.keys(visibleDomains).map(domain => (
                <label key={domain} className="flex items-center gap-2 cursor-pointer hover:text-white text-slate-400 capitalize">
                  <input type="checkbox" className="accent-brand-500 rounded bg-slate-800 border-slate-600" checked={visibleDomains[domain]} onChange={() => toggleDomain(domain)} />
                  {domain}
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* AI Copilot Button + Panel */}
        <div className="absolute right-4 bottom-4 z-[999] pointer-events-auto flex flex-col items-end gap-2">
          {isCopilotOpen && (
             <div className="bg-slate-900/90 border border-brand-500/50 rounded-lg backdrop-blur-md p-4 w-80 shadow-[0_0_15px_rgba(20,184,166,0.2)] flex flex-col gap-3">
               <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                 <h3 className="text-brand-400 font-bold text-sm flex items-center gap-2">
                   <Sparkles className="size-4" /> AI OSINT COPILOT
                 </h3>
                 <button onClick={() => setIsCopilotOpen(false)} className="text-slate-400 hover:text-white">
                   <X className="size-4" />
                 </button>
               </div>
               <div className="text-sm text-slate-300 font-mono min-h-[60px]">
                 {copilotLoading ? (
                   <div className="animate-pulse flex space-x-2 text-brand-400">
                     <div className="h-2 w-2 bg-brand-400 rounded-full"></div>
                     <div className="h-2 w-2 bg-brand-400 rounded-full"></div>
                     <div className="h-2 w-2 bg-brand-400 rounded-full"></div>
                   </div>
                 ) : (
                   <p>{copilotSummary}</p>
                 )}
               </div>
             </div>
          )}
          
          <button 
            onClick={handleSummarize}
            className="flex items-center gap-2 bg-brand-600 hover:bg-brand-500 text-white px-4 py-2 rounded shadow-lg font-bold text-sm font-mono transition-transform hover:scale-105 active:scale-95"
          >
            <Sparkles className="size-4" />
            ANALYZE VIEW
          </button>
        </div>
      </div>

      {/* Intelligence Panel */}
      {selectedEntity && (
        <aside className="w-80 border-l border-slate-800 bg-slate-950/95 backdrop-blur-md flex flex-col z-[1001] transition-transform shadow-2xl">
          <header className="h-12 border-b border-slate-800 flex items-center px-4 justify-between shrink-0">
            <h2 className="text-xs font-bold text-slate-200 flex items-center gap-2">
              <Target className="size-4 text-brand-400" />
              INTELLIGENCE PROFILE
            </h2>
            <button onClick={() => setSelectedEntityId(null)} className="text-slate-500 hover:text-white transition-colors">✕</button>
          </header>
          
          <div className="p-4 flex flex-col gap-4 overflow-y-auto">
            <div className="border border-slate-800 rounded bg-slate-900/50 p-4">
              <div className="text-2xl font-mono font-bold text-white mb-1">
                {selectedEntity.callsign || selectedEntity.name || 'UNKNOWN'}
              </div>
              <div className="text-xs font-mono text-slate-500 uppercase flex justify-between">
                <span>ID: {selectedEntity.id}</span>
                <span className="text-brand-400">{selectedEntity.domain}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <DataBox label="HEADING" value={Math.floor(selectedEntity.heading) + '°'} />
              <DataBox label="SPEED" value={Math.floor(selectedEntity.speed) + ' kts'} />
              <DataBox label="ALTITUDE" value={Math.floor(selectedEntity.altitude) + ' ft'} />
              <DataBox label="CONFIDENCE" value={(selectedEntity.confidence * 100).toFixed(1) + '%'} highlight={selectedEntity.confidence > 0.8 ? 'text-emerald-400' : 'text-amber-400'} />
            </div>

            <div className="border border-slate-800 rounded flex flex-col">
              <div className="px-3 py-2 bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                Live Telemetry
              </div>
              <div className="p-3 font-mono text-xs text-slate-300 flex flex-col gap-1">
                <div>LAT: {selectedEntity.lat.toFixed(6)}</div>
                <div>LNG: {selectedEntity.lng.toFixed(6)}</div>
                <div className="mt-2 text-slate-500 text-[10px]">LAST UPDATE: {new Date(selectedEntity.last_updated).toLocaleTimeString()}</div>
              </div>
            </div>

            <div className="border border-slate-800 rounded flex flex-col">
              <div className="px-3 py-2 bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                Threat Assessment
              </div>
              <div className="p-3 font-mono text-xs flex items-center justify-between">
                <span className="text-slate-400">SEVERITY</span>
                <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                  selectedEntity.severity === 'critical' ? 'bg-red-500/20 text-red-400' : 
                  selectedEntity.severity === 'high' ? 'bg-orange-500/20 text-orange-400' : 
                  'bg-slate-800 text-slate-300'
                }`}>
                  {selectedEntity.severity || 'Normal'}
                </span>
              </div>
            </div>

            {selectedEntity.metadata && Object.keys(selectedEntity.metadata).length > 0 && (
              <div className="border border-slate-800 rounded flex flex-col">
                <div className="px-3 py-2 bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                  Metadata
                </div>
                <div className="p-3 font-mono text-xs text-slate-300 flex flex-col gap-1 overflow-x-auto break-all">
                  {Object.entries(selectedEntity.metadata).map(([k, v]) => (
                     <div key={k} className="flex justify-between gap-4">
                       <span className="text-slate-500 uppercase">{k}:</span>
                       <span className="text-right">{String(v)}</span>
                     </div>
                  ))}
                </div>
              </div>
            )}

            {/* Analyst Notes */}
            <div className="border border-slate-800 rounded flex flex-col">
              <div className="px-3 py-2 bg-slate-800/50 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                Analyst Notes
              </div>
              <div className="p-3 font-sans text-xs text-slate-300 flex flex-col gap-2">
                <textarea 
                   placeholder="Add observation note..."
                   className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-white placeholder:text-slate-600 focus:outline-none focus:border-brand-500"
                   onKeyDown={(e) => {
                     if (e.key === 'Enter' && !e.shiftKey) {
                       e.preventDefault();
                       const val = e.currentTarget.value;
                       e.currentTarget.value = '';
                       fetch(`/api/entities/${selectedEntity.id}/notes`, {
                         method: 'POST',
                         headers: {'Content-Type': 'application/json'},
                         body: JSON.stringify({ content: val })
                       })
                       .then(r => r.json())
                       .then(res => {
                         if (res.success) {
                           setSelectedEntityNotes(prev => [{
                             id: res.id,
                             content: val,
                             created_at: new Date().toISOString()
                           }, ...prev]);
                         }
                       });
                     }
                   }}
                />
                <div className="text-[9px] text-slate-500 mt-1 italic text-right">Press Enter to save</div>
                {selectedEntityNotes.length > 0 && (
                  <div className="mt-2 flex flex-col gap-2 border-t border-slate-800 pt-2 h-32 overflow-y-auto pr-1">
                    {selectedEntityNotes.map(n => (
                      <div key={n.id} className="bg-slate-800/30 p-2 rounded relative group cursor-default">
                        <div className="text-[10px] text-slate-500 mb-1 flex justify-between">
                          <span>{new Date(n.created_at).toLocaleDateString()}</span>
                          <button 
                            className="hidden group-hover:block text-slate-500 hover:text-red-400"
                            onClick={() => {
                              fetch(`/api/notes/${n.id}`, { method: 'DELETE' }).then(() => {
                                setSelectedEntityNotes(prev => prev.filter(x => x.id !== n.id));
                              });
                            }}
                          >✕</button>
                        </div>
                        <div className="text-xs text-slate-300 break-words whitespace-pre-wrap">{n.content}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <button className="mt-4 w-full py-2 bg-brand-500/10 hover:bg-brand-500/20 text-brand-400 border border-brand-500/30 rounded text-xs font-bold transition-colors">
              OPEN CASE FILE
            </button>
          </div>
        </aside>
      )}
    </div>
  )
}

function DataBox({ label, value, highlight }: { label: string, value: string | number, highlight?: string }) {
  return (
    <div className="border border-slate-800 rounded bg-slate-900/30 p-3 flex flex-col">
      <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-1">{label}</span>
      <span className={`font-mono text-sm ${highlight || 'text-slate-200'}`}>{value}</span>
    </div>
  )
}
