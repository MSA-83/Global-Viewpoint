import { useEffect, useState } from 'react';
import type { Entity } from '../types';
import { Target, ShieldAlert, AlertTriangle, ArrowUpRight, ExternalLink, X, Search } from 'lucide-react';
import { cn } from '../lib/utils';

export function ThreatIntelligence() {
  const [alerts, setAlerts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAlert, setSelectedAlert] = useState<any | null>(null);

  useEffect(() => {
    fetch('/api/alerts')
      .then(res => res.json())
      .then(data => {
        setAlerts(data);
        setLoading(false);
      });

    import('socket.io-client').then(({ io }) => {
      const socket = io();
      socket.on('new_alert', (alert) => {
        setAlerts(prev => [alert, ...prev]);
      });
      return () => socket.disconnect();
    });
  }, []);

  const criticalCount = alerts.filter(a => a.severity === 'critical').length;

  return (
    <div className="p-6 h-full flex flex-col font-sans overflow-hidden">
      <header className="mb-6 shrink-0">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <ShieldAlert className="text-brand-400" />
          THREAT INTELLIGENCE ENGINE & OSINT
        </h1>
        <p className="text-sm text-slate-500 mt-1">Global entity anomaly and real-time OSINT threat alerts</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 shrink-0 font-mono">
        <StatCard title="TOTAL OPEN ALERTS" value={alerts.length.toString()} />
        <StatCard 
          title="CRITICAL THREATS" 
          value={criticalCount.toString()} 
          highlight={criticalCount > 0 ? "text-red-400" : undefined}
          icon={criticalCount > 0 ? AlertTriangle : undefined}
        />
        <StatCard title="SOURCES ONLINE" value="12" />
        <StatCard title="OSINT STATUS" value="LIVE" />
      </div>

      <div className="flex-1 bg-slate-900/50 border border-slate-800 rounded-lg overflow-hidden flex flex-col relative w-full">
        <div className="p-4 border-b border-slate-800 bg-slate-900/80 flex justify-between items-center shrink-0">
          <h2 className="text-sm font-bold text-slate-300">ACTIVE THREAT LEDGER</h2>
          <div className="flex gap-2">
            <button className="px-3 py-1 bg-slate-800 text-xs text-slate-300 rounded border border-slate-700 hover:bg-slate-700 transition-colors">
              FILTER
            </button>
            <button className="px-3 py-1 bg-brand-500/20 text-xs text-brand-400 rounded border border-brand-500/30 hover:bg-brand-500/30 transition-colors">
              EXPORT
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-auto flex relative">
          {loading ? (
            <div className="flex items-center justify-center p-8 text-slate-500 font-mono w-full">LOADING INTELLIGENCE...</div>
          ) : (
            <div className="flex-1 overflow-auto w-full">
              <table className="w-full text-left text-sm whitespace-nowrap">
              <thead className="bg-slate-900 text-slate-500 font-mono text-xs uppercase sticky top-0 border-b border-slate-800 shadow-sm z-10">
                <tr>
                  <th className="px-4 py-3 font-semibold">ISSUE</th>
                  <th className="px-4 py-3 font-semibold">DOMAIN</th>
                  <th className="px-4 py-3 font-semibold">SEVERITY</th>
                  <th className="px-4 py-3 font-semibold">TIMESTAMP</th>
                  <th className="px-4 py-3 font-semibold text-right">ACTION</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50 text-slate-300 font-mono text-xs">
                {alerts.length === 0 ? (
                  <tr>
                     <td colSpan={5} className="px-4 py-8 text-center text-slate-500">No active threats detected.</td>
                  </tr>
                ) : alerts.map(a => (
                  <tr 
                    key={a.id} 
                    className="hover:bg-slate-800/20 transition-colors group cursor-pointer"
                    onClick={() => setSelectedAlert(a)}
                  >
                    <td className="px-4 py-3 border-l-2 border-transparent group-hover:border-brand-500">
                       <div className="font-bold text-white max-w-sm truncate whitespace-normal leading-tight">{a.title}</div>
                       <div className="text-[10px] text-slate-500 truncate max-w-md hidden md:block whitespace-normal leading-tight mt-1">{a.description}</div>
                    </td>
                    <td className="px-4 py-3 text-brand-400">{a.domain}</td>
                    <td className="px-4 py-3">
                      <span className={cn(
                        "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                        a.severity === 'critical' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-orange-500/10 text-orange-400 border border-orange-500/20'
                      )}>
                        {a.severity}
                      </span>
                    </td>
                    <td className="px-4 py-3">{new Date(a.created_at).toLocaleString()}</td>
                    <td className="px-4 py-3 text-right">
                      <button className="text-slate-500 hover:text-brand-400 opacity-0 group-hover:opacity-100 transition-opacity">
                        <ArrowUpRight className="size-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          )}

          {/* Drill-down Panel */}
          {selectedAlert && (
            <aside className="w-96 border-l border-slate-800 bg-slate-950/95 backdrop-blur-md flex flex-col absolute right-0 top-0 bottom-0 z-20 shadow-2xl animate-in slide-in-from-right-10 overflow-hidden">
              <header className="h-12 border-b border-slate-800 flex items-center px-4 justify-between shrink-0 bg-slate-900/50">
                <h2 className="text-xs font-bold text-slate-200 flex items-center gap-2 font-mono">
                  <ShieldAlert className="size-4 text-brand-400" />
                  THREAT DOSSIER
                </h2>
                <button onClick={() => setSelectedAlert(null)} className="text-slate-500 hover:text-white transition-colors">
                  <X className="size-4" />
                </button>
              </header>
              
              <div className="p-4 flex flex-col gap-5 overflow-y-auto w-full">
                <div>
                  <div className="flex justify-between items-start gap-4 mb-2">
                    <span className={cn(
                      "px-2 py-0.5 rounded text-[10px] font-bold uppercase shrink-0 border",
                      selectedAlert.severity === 'critical' ? 'bg-red-500/10 text-red-400 border-red-500/20' : 'bg-orange-500/10 text-orange-400 border-orange-500/20'
                    )}>
                      {selectedAlert.severity}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono border border-slate-800 px-2 py-0.5 rounded">{selectedAlert.domain}</span>
                  </div>
                  <h3 className="text-lg font-bold text-white leading-snug">{selectedAlert.title}</h3>
                  <div className="text-xs text-slate-400 mt-2 font-mono opacity-80">
                    {new Date(selectedAlert.created_at).toLocaleString()}
                  </div>
                </div>

                <div className="border border-slate-800 rounded bg-slate-900/30 overflow-hidden flex flex-col">
                  <div className="px-3 py-2 bg-slate-800/40 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                    Intelligence Description
                  </div>
                  <div className="p-3 text-sm text-slate-300 leading-relaxed font-sans whitespace-normal break-words">
                    {selectedAlert.description}
                  </div>
                </div>

                <div className="border border-slate-800 rounded bg-slate-900/30 overflow-hidden flex flex-col">
                  <div className="px-3 py-2 bg-slate-800/40 text-[10px] font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800">
                    Entity Metadata
                  </div>
                  <div className="p-3 font-mono text-xs flex flex-col gap-2">
                    <div className="flex justify-between items-center text-slate-400 border-b border-slate-800/50 pb-1">
                      <span>INTERNAL_ID</span>
                      <span className="text-slate-300 truncate max-w-[150px]">{selectedAlert.id}</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-400 border-b border-slate-800/50 pb-1">
                      <span>STATUS</span>
                      <span className="text-brand-400">{selectedAlert.status}</span>
                    </div>
                    {selectedAlert.lat !== 0 && (
                      <div className="flex justify-between items-center text-slate-400 border-b border-slate-800/50 pb-1">
                        <span>COORDINATES</span>
                        <span className="text-slate-300">{selectedAlert.lat.toFixed(4)}, {selectedAlert.lng.toFixed(4)}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-col gap-2 mt-2 font-mono">
                  <a 
                    href={`https://news.google.com/search?q=${encodeURIComponent(selectedAlert.title)}`} 
                    target="_blank" 
                    rel="noreferrer"
                    className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 py-2 rounded text-xs transition-colors"
                  >
                    <Search className="size-3" /> Search Open Web OSINT
                  </a>
                  <a 
                    href={`https://twitter.com/search?q=${encodeURIComponent(selectedAlert.title)}`} 
                    target="_blank" 
                    rel="noreferrer"
                    className="flex items-center justify-center gap-2 bg-[#1DA1F2]/10 hover:bg-[#1DA1F2]/20 text-[#1DA1F2] border border-[#1DA1F2]/30 py-2 rounded text-xs transition-colors"
                  >
                    <ExternalLink className="size-3" /> Search Social Media
                  </a>
                </div>
              </div>
            </aside>
          )}

        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, highlight, icon: Icon }: { title: string, value: string, highlight?: string, icon?: any }) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col justify-center relative overflow-hidden">
      <div className="text-xs text-slate-500 mb-2 font-semibold tracking-wider relative z-10">{title}</div>
      <div className={cn("text-2xl font-bold flex items-center gap-2 relative z-10", highlight || "text-slate-200")}>
        {Icon && <Icon className="size-5" />}
        {value}
      </div>
      <div className="absolute -bottom-4 -right-4 size-16 bg-slate-800/50 rounded-full blur-2xl z-0" />
    </div>
  )
}

