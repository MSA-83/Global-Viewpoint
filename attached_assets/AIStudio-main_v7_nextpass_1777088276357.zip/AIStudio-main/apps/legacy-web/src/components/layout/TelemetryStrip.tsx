import { useEffect, useState } from 'react';
import { io } from 'socket.io-client';

export function TelemetryStrip() {
  const [latency, setLatency] = useState(0);
  const [entitiesProcessed, setEntitiesProcessed] = useState(0);

  useEffect(() => {
    const socket = io();
    const pinger = setInterval(() => {
      const start = Date.now();
      socket.emit('telemetry_ping', () => {
        setLatency(Date.now() - start);
      });
    }, 2000);

    socket.on('telemetry_pong', () => {
      // Ack-driven latency updates are enough; event retained for compatibility.
    });

    socket.on('entity_updates', (updates: any) => {
      setEntitiesProcessed(prev => prev + updates.length);
    });

    return () => {
      clearInterval(pinger);
      socket.disconnect();
    };
  }, []);

  return (
    <footer className="h-8 border-t border-slate-800 bg-slate-950 flex items-center justify-between px-4 text-[10px] font-mono text-slate-500 z-50">
      <div className="flex gap-6">
        <span className="flex items-center gap-2">
          <div className="size-1.5 rounded-full bg-emerald-500 animate-pulse" />
          SYSTEM ONLINE
        </span>
        <span>LATENCY: {latency}ms</span>
        <span>ACTIVE NODES: 42</span>
      </div>
      <div className="flex gap-6 text-brand-400/70 text-right">
        <span>SESSION ID: ALFA-78-TX</span>
        <span>ENTITIES SYNCED: {entitiesProcessed.toLocaleString()}</span>
      </div>
    </footer>
  );
}
