import { Outlet, NavLink } from 'react-router-dom';
import { Globe, ShieldAlert, FolderKanban, Activity, Settings, User } from 'lucide-react';
import { cn } from '../../lib/utils';
import { TelemetryStrip } from './TelemetryStrip';

export function Shell() {
  return (
    <div className="flex h-screen w-full flex-col bg-slate-950 text-slate-200 overflow-hidden font-sans">
      {/* Top Banner */}
      <header className="h-12 border-b border-slate-800 bg-slate-950 flex items-center justify-between px-4 z-50 shadow-sm relative">
        <div className="flex items-center gap-3">
          <div className="size-6 bg-brand-500 rounded-sm flex items-center justify-center border border-brand-400/50 shadow-[0_0_15px_rgba(99,102,241,0.5)]">
            <Globe className="size-4 text-white" />
          </div>
          <span className="font-bold tracking-widest text-sm text-slate-100">SENTINEL-X</span>
          <div className="h-4 w-px bg-slate-800 ml-2" />
          <span className="text-xs text-brand-400 uppercase tracking-widest font-mono ml-2 animate-pulse">Live</span>
        </div>
        
        {/* Universal Search */}
        <div className="flex-1 max-w-md mx-6">
          <div className="h-8 bg-slate-900 border border-slate-800 rounded px-3 flex items-center text-xs text-slate-500 font-mono">
            CMD + K to global search...
          </div>
        </div>

        <div className="flex items-center gap-4">
          <button className="text-slate-400 hover:text-white transition-colors">
            <Settings className="size-4" />
          </button>
          <button className="flex items-center gap-2 border border-slate-800 bg-slate-900 px-3 py-1 rounded text-xs hover:bg-slate-800 transition-colors">
            <User className="size-3" />
            <span>OPERATOR_01</span>
          </button>
        </div>
      </header>

      {/* Main Layout Area */}
      <div className="flex flex-1 overflow-hidden relative z-10">
        {/* Left Sidebar Layout */}
        <aside className="w-16 flex flex-col items-center py-4 gap-6 border-r border-slate-800 bg-slate-950 z-50">
          <NavIcon to="/watch" icon={Globe} label="Global Watch" />
          <NavIcon to="/threats" icon={ShieldAlert} label="Threat Intel" />
          <NavIcon to="/cases" icon={FolderKanban} label="Cases" />
          <NavIcon to="/analytics" icon={Activity} label="Analytics" />
        </aside>

        {/* Dynamic Content */}
        <main className="flex-1 relative flex flex-col min-w-0 bg-slate-900">
          <Outlet />
        </main>
      </div>

      {/* Persistence Strip - Telemetry */}
      <TelemetryStrip />
    </div>
  );
}

function NavIcon({ to, icon: Icon, label }: { to: string, icon: any, label: string }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) => cn(
        "group relative size-10 rounded-lg flex items-center justify-center transition-all duration-200",
        isActive 
          ? "bg-brand-500/10 text-brand-400 border border-brand-500/30 shadow-[inset_0_0_10px_rgba(99,102,241,0.2)]" 
          : "text-slate-500 hover:text-slate-300 hover:bg-slate-900"
      )}
      title={label}
    >
      <Icon className="size-5" />
    </NavLink>
  );
}
