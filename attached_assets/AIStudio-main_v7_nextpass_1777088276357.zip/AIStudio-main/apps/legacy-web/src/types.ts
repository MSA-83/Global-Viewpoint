export type Entity = {
  id: string;
  domain: string;
  type: string;
  name: string | null;
  callsign: string | null;
  lat: number;
  lng: number;
  heading: number;
  speed: number;
  altitude: number;
  severity: string;
  confidence: number;
  metadata: any;
  last_updated: string;
};

export type Alert = {
  id: string;
  title: string;
  description: string;
  severity: string;
  domain: string;
  status: string;
  lat: number;
  lng: number;
  created_at: string;
};
