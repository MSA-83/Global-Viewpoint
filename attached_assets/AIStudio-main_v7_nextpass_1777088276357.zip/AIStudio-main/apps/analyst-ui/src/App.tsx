import { BrowserRouter as Router, Navigate, Route, Routes } from "react-router-dom";

import { Shell } from "./components/layout/Shell";
import { Analytics } from "./pages/Analytics";
import { CaseManagement } from "./pages/CaseManagement";
import { ThreatIntelligence } from "./pages/ThreatIntelligence";
import WatchMap from "./pages/WatchMap";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Shell />}>
          <Route index element={<Navigate to="/watch" replace />} />
          <Route path="watch" element={<WatchMap />} />
          <Route path="threats" element={<ThreatIntelligence />} />
          <Route path="cases" element={<CaseManagement />} />
          <Route path="analytics" element={<Analytics />} />
        </Route>
      </Routes>
    </Router>
  );
}
