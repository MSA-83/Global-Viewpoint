import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import L, { type LatLngBoundsExpression, type LatLngExpression } from "leaflet";
import { Circle, MapContainer, Marker, Polyline, Popup, TileLayer, Tooltip, useMap, useMapEvents, Rectangle } from "react-leaflet";
import { ArrowRight, ChevronDown, Globe, Layers3, Loader2, MapPinned, Satellite, Search, Target, Wifi, WifiOff } from "lucide-react";

import { apiFetch } from "../../lib/api";
import { useDashboardSummary } from "../../hooks/useDashboardSummary";
import { useRealtimeIntel } from "../../hooks/useRealtimeIntel";
import type { DashboardSummary, EntityTrackPoint, IntelAlert, IntelEntity, RealtimeFilters } from "@sentinel-x/shared";
import { AlertDrawer } from "../alerts/AlertDrawer";
import { CopilotDrawer } from "../copilot/CopilotDrawer";
import { MapLegend } from "./MapLegend";

function confidenceColor(confidence: number) {
  if (confidence >= 0.8) return "#22c55e";
  if (confidence >= 0.55) return "#f59e0b";
  return "#ef4444";
}

function domainAccent(domain: string) {
  switch (domain) {
    case "aviation":
      return "#60a5fa";
    case "maritime":
      return "#2dd4bf";
    case "orbital":
      return "#a78bfa";
    case "cyber":
      return "#f472b6";
    case "infrastructure":
      return "#fb923c";
    default:
      return "#94a3b8";
  }
}

function entityGlyph(entity: IntelEntity) {
  const hay = `${entity.domain} ${entity.entity_type} ${entity.name ?? ""} ${entity.callsign ?? ""}`.toLowerCase();
  if (hay.includes("air") || hay.includes("flight") || hay.includes("aviation") || hay.includes("plane")) return "plane";
  if (hay.includes("ship") || hay.includes("boat") || hay.includes("maritime") || hay.includes("vessel") || hay.includes("sea")) return "ship";
  if (hay.includes("sat") || hay.includes("orbit")) return "satellite";
  if (hay.includes("cyber") || hay.includes("radio") || hay.includes("signal")) return "radio";
  if (hay.includes("infra") || hay.includes("ground") || hay.includes("tower")) return "tower";
  return "target";
}

function glyphMarkup(glyph: string, color: string) {
  const common = `fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"`;
  switch (glyph) {
    case "plane":
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18"><path ${common} d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.2-1.1.6L3 8l6 5.5-4 4-2.5-.5L1 18.5l5.5 2 2 5.5 1.5-1.5-.5-2.5 4-4 5.5 6c.4-.2.7-.6.6-1.1z"/></svg>`;
    case "ship":
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18"><path ${common} d="M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1 .6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path ${common} d="M19.38 20A11.6 11.6 0 0 0 21 14l-9-4-9 4c0 2.9.94 5.34 2.81 7.76"/><path ${common} d="M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6"/></svg>`;
    case "satellite":
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18"><path ${common} d="M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4"/><path ${common} d="M14 2v4a2 2 0 0 0 2 2h4"/><path ${common} d="m3 15 2 2 4-4"/></svg>`;
    case "radio":
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18"><path ${common} d="M4 7h16"/><path ${common} d="M6 7l7 14 5-9"/><path ${common} d="M17 12h3"/></svg>`;
    case "tower":
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18"><path ${common} d="M12 2 7 22h10L12 2Z"/><path ${common} d="M9 14h6"/><path ${common} d="M8 18h8"/></svg>`;
    default:
      return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18"><path ${common} d="M12 2v4"/><path ${common} d="M12 18v4"/><path ${common} d="M4 12H2"/><path ${common} d="M22 12h-2"/><circle ${common} cx="12" cy="12" r="4"/></svg>`;
  }
}

function entityIcon(entity: IntelEntity, selected: boolean, heading?: number | null) {
  const glyph = entityGlyph(entity);
  const color = domainAccent(entity.domain);
  const ring = selected ? "#38bdf8" : confidenceColor(entity.confidence);
  const rotation = heading == null ? 0 : heading;
  const jam = entity.metadata?.gps_jamming || entity.metadata?.gnss_jamming;
  const jamRadius = Number(entity.metadata?.jamming_radius_m || entity.metadata?.expected_radius_m || 0);
  const ringColor = jam ? "#f97316" : ring;
  const badge = jam ? `<div style="position:absolute;bottom:-4px;right:-4px;width:10px;height:10px;border-radius:9999px;background:#f97316;border:2px solid rgba(15,23,42,0.92)"></div>` : "";
  const direction = heading == null ? "" : `<div style="position:absolute;top:-4px;left:50%;transform:translateX(-50%) rotate(${rotation}deg);font-size:10px;line-height:1;color:${color};text-shadow:0 1px 0 rgba(15,23,42,0.9)">▲</div>`;
  return L.divIcon({
    className: "",
    html: `
      <div style="position:relative;width:46px;height:46px;display:grid;place-items:center;">
        ${direction}
        <div style="position:absolute;inset:0;border-radius:9999px;border:2px solid ${ringColor};opacity:0.75;box-shadow:0 0 0 4px rgba(15,23,42,0.55);${jamRadius ? `background: radial-gradient(circle, rgba(249,115,22,0.08) 0%, rgba(15,23,42,0) 70%);` : ""}"></div>
        <div style="width:26px;height:26px;border-radius:9999px;background:rgba(15,23,42,0.96);border:1px solid ${color};display:grid;place-items:center;transform:rotate(${rotation}deg);box-shadow:0 0 16px rgba(0,0,0,0.25);">
          ${glyphMarkup(glyph, color)}
        </div>
        ${badge}
      </div>
    `,
    iconSize: [46, 46],
    iconAnchor: [23, 23],
  });
}

function clusterIcon(count: number) {
  return L.divIcon({
    className: "",
    html: `<div class="sx-cluster">${count}</div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });
}

function projectHeading(lat: number, lon: number, heading: number, distanceMeters = 2500) {
  const rad = (heading * Math.PI) / 180;
  const dLat = (distanceMeters * Math.cos(rad)) / 111_320;
  const dLon = (distanceMeters * Math.sin(rad)) / (111_320 * Math.cos((lat * Math.PI) / 180));
  return [lat + dLat, lon + dLon] as [number, number];
}

function isEntityJammed(entity: IntelEntity) {
  return Boolean(entity.metadata?.gps_jamming || entity.metadata?.gnss_jamming || entity.metadata?.jammed);
}

function jammingRadius(entity: IntelEntity) {
  const raw = entity.metadata?.jamming_radius_m || entity.metadata?.expected_radius_m || entity.metadata?.interference_radius_m;
  const radius = typeof raw === "number" ? raw : Number(raw || 0);
  return Number.isFinite(radius) && radius > 0 ? radius : 1500;
}

function fmtTime(value?: string | null) {
  if (!value) return "unknown";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}

function useViewport() {
  const [viewport, setViewport] = useState<{ center: [number, number]; zoom: number; bounds: any | null }>({ center: [20, 0], zoom: 2, bounds: null });
  useMapEvents({
    moveend(map) {
      setViewport({ center: [map.getCenter().lat, map.getCenter().lng], zoom: map.getZoom(), bounds: map.getBounds() });
    },
    zoomend(map) {
      setViewport({ center: [map.getCenter().lat, map.getCenter().lng], zoom: map.getZoom(), bounds: map.getBounds() });
    },
    load(map) {
      setViewport({ center: [map.getCenter().lat, map.getCenter().lng], zoom: map.getZoom(), bounds: map.getBounds() });
    },
  });
  return viewport;
}

function FlyToSelection({ selected }: { selected: IntelEntity | null }) {
  const map = useMap();
  useEffect(() => {
    if (selected) map.flyTo([selected.lat, selected.lon], Math.max(map.getZoom(), 6), { duration: 0.6 });
  }, [selected, map]);
  return null;
}

function MainViewportBridge({ onViewport }: { onViewport: (state: { center: [number, number]; zoom: number; bounds: any | null }) => void }) {
  const map = useMap();
  useEffect(() => {
    const update = () => onViewport({ center: [map.getCenter().lat, map.getCenter().lng], zoom: map.getZoom(), bounds: map.getBounds() });
    update();
    map.on("moveend zoomend", update);
    return () => {
      map.off("moveend zoomend", update);
    };
  }, [map, onViewport]);
  return null;
}

function cellKey(entity: IntelEntity, zoom: number) {
  const latStep = zoom < 4 ? 24 : zoom < 6 ? 12 : zoom < 8 ? 4 : 2;
  const lonStep = latStep;
  return `${Math.round(entity.lat / latStep)}:${Math.round(entity.lon / lonStep)}`;
}

function clusterVisibleEntities(entities: IntelEntity[], zoom: number, bounds: any | null) {
  const visible = bounds ? entities.filter((entity) => bounds.contains([entity.lat, entity.lon])) : entities;
  if (zoom >= 8 || visible.length < 24) return visible.map((entity) => ({ kind: "entity" as const, entity }));
  const groups = new Map<string, IntelEntity[]>();
  for (const entity of visible) {
    const key = cellKey(entity, zoom);
    const group = groups.get(key) || [];
    group.push(entity);
    groups.set(key, group);
  }
  return [...groups.values()].map((group) => {
    if (group.length === 1) return { kind: "entity" as const, entity: group[0] };
    const lat = group.reduce((sum, e) => sum + e.lat, 0) / group.length;
    const lon = group.reduce((sum, e) => sum + e.lon, 0) / group.length;
    return { kind: "cluster" as const, center: [lat, lon] as [number, number], entities: group };
  });
}

function mapLayer(kind: string) {
  const today = new Date().toISOString().slice(0, 10);
  switch (kind) {
    case "gibs":
      return {
        label: "NASA GIBS satellite",
        url: `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_CorrectedReflectance_TrueColor/default/${today}/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg`,
        attribution: 'Imagery © NASA GIBS, data courtesy of NASA Earthdata',
        maxNativeZoom: 9,
      };
    case "sentinel": {
      const sentinelUrl = (import.meta.env.VITE_SENTINELMAP_TILE_URL as string | undefined)?.trim();
      if (!sentinelUrl) {
        return {
          label: "NASA GIBS fallback",
          url: `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/MODIS_Terra_CorrectedReflectance_TrueColor/default/${today}/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg`,
          attribution: 'Imagery © NASA GIBS, SentinelMap optional via env',
          maxNativeZoom: 9,
        };
      }
      return {
        label: "SentinelMap / Sentinel-2",
        url: sentinelUrl,
        attribution: 'Imagery © SentinelMap / Sentinel-2 open data',
        maxNativeZoom: 14,
      };
    }
    default:
      return {
        label: "OpenStreetMap",
        url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
        attribution: "&copy; OpenStreetMap contributors",
        maxNativeZoom: 19,
      };
  }
}

function MiniMap({ entities, selectedEntity, viewport }: { entities: IntelEntity[]; selectedEntity: IntelEntity | null; viewport: { center: [number, number]; zoom: number; bounds: any | null } }) {
  const center: [number, number] = selectedEntity ? [selectedEntity.lat, selectedEntity.lon] : viewport.center;
  const miniEntities = entities.slice(0, 80);
  return (
    <div className="absolute bottom-4 right-4 z-[900] hidden h-52 w-52 overflow-hidden rounded-2xl border border-slate-700 bg-slate-950/90 shadow-2xl backdrop-blur md:block">
      <MapContainer center={center} zoom={1} zoomControl={false} attributionControl={false} dragging={false} scrollWheelZoom={false} doubleClickZoom={false} boxZoom={false} keyboard={false} touchZoom={false} className="h-full w-full">
        <TileLayer {...mapLayer("street")} opacity={0.35} />
        {viewport.bounds ? (
          <Rectangle bounds={viewport.bounds as LatLngBoundsExpression} pathOptions={{ color: "#38bdf8", weight: 1, fillOpacity: 0.06 }} />
        ) : null}
        {miniEntities.map((entity) => (
          <Marker key={`mini-${entity.id}`} position={[entity.lat, entity.lon]} icon={entityIcon(entity, selectedEntity?.id === entity.id, entity.heading)} />
        ))}
      </MapContainer>
      <div className="pointer-events-none absolute left-2 top-2 rounded-full border border-slate-700 bg-slate-950/90 px-2 py-1 text-[10px] uppercase tracking-[0.2em] text-slate-400">
        overview
      </div>
    </div>
  );
}

function EntityStats({ entity, track }: { entity: IntelEntity | null; track: EntityTrackPoint[] }) {
  if (!entity) {
    return (
      <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-4 text-sm text-slate-500">
        Select an entity to inspect its track, direction, and confidence decay.
      </div>
    );
  }
  const jammed = isEntityJammed(entity);
  const radius = jammingRadius(entity);
  return (
    <div className="space-y-3 rounded-2xl border border-slate-800 bg-slate-900/50 p-4">
      <div>
        <div className="text-sm font-semibold text-slate-50">{entity.name || entity.external_id}</div>
        <div className="mt-1 text-xs text-slate-500">{entity.domain} · {entity.entity_type}</div>
      </div>
      <div>
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span>Confidence</span>
          <span>{(entity.confidence * 100).toFixed(0)}%</span>
        </div>
        <div className="mt-2 h-2 rounded-full bg-slate-800">
          <div className="h-2 rounded-full" style={{ width: `${Math.max(8, Math.min(100, entity.confidence * 100))}%`, backgroundColor: confidenceColor(entity.confidence) }} />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs text-slate-400">
        <Info label="Last seen" value={fmtTime(entity.last_seen_at)} />
        <Info label="Heading" value={entity.heading == null ? "n/a" : `${Math.round(entity.heading)}°`} />
        <Info label="Speed" value={entity.speed == null ? "n/a" : `${entity.speed.toFixed(1)}`} />
        <Info label="Track points" value={track.length} />
      </div>
      {jammed ? (
        <div className="rounded-2xl border border-orange-500/30 bg-orange-500/10 p-3 text-xs text-orange-100">
          GNSS interference suspected. Expected radius approximately {radius.toLocaleString()} m.
        </div>
      ) : null}
      <div className="rounded-2xl border border-slate-800 bg-slate-950 p-3">
        <div className="text-[10px] uppercase tracking-[0.2em] text-slate-500">Latest track</div>
        <div className="mt-2 space-y-1 text-xs text-slate-400">
          {track.slice(-6).map((point) => (
            <div key={point.id} className="flex items-center justify-between gap-3">
              <span>{fmtTime(point.observed_at)}</span>
              <span>{point.lat.toFixed(3)}, {point.lon.toFixed(3)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2">
      <div className="text-[10px] uppercase tracking-[0.18em] text-slate-500">{label}</div>
      <div className="mt-1 text-slate-100">{value}</div>
    </div>
  );
}

export function WatchMap() {
  const token = localStorage.getItem("access_token");
  const { summary, loading: summaryLoading, error: summaryError, refresh } = useDashboardSummary();
  const { entities, alerts, connectionStatus, filters, setFilters, lastMessageAt } = useRealtimeIntel(token, {});
  const [search, setSearch] = useState("");
  const [basemap, setBasemap] = useState<"street" | "gibs" | "sentinel">("gibs");
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>(null);
  const [track, setTrack] = useState<EntityTrackPoint[]>([]);
  const [trackLoading, setTrackLoading] = useState(false);
  const [viewport, setViewport] = useState<{ center: [number, number]; zoom: number; bounds: any | null }>({ center: [20, 0], zoom: 2, bounds: null });
  const [alertOverrides, setAlertOverrides] = useState<Record<string, Partial<IntelAlert>>>({});
  const [copilotOpen, setCopilotOpen] = useState(true);
  const [alertsOpen, setAlertsOpen] = useState(true);
  const [localDomains, setLocalDomains] = useState<string[]>([]);
  const mapRef = useRef<HTMLDivElement | null>(null);

  const mergedAlerts = useMemo(() => alerts.map((alert) => ({ ...alert, ...(alertOverrides[alert.id] || {}) })), [alerts, alertOverrides]);
  const selectedEntity = useMemo(() => entities.find((entity) => entity.id === selectedEntityId) || summary?.top_entities.find((entity) => entity.id === selectedEntityId) || null, [entities, selectedEntityId, summary]);

  const visibleEntities = useMemo(() => {
    const query = search.trim().toLowerCase();
    const next = entities.filter((entity) => {
      if (localDomains.length && !localDomains.includes(entity.domain)) return false;
      if (query) {
        const hay = `${entity.name ?? ""} ${entity.external_id} ${entity.domain} ${entity.entity_type} ${entity.callsign ?? ""}`.toLowerCase();
        if (!hay.includes(query)) return false;
      }
      return viewport.bounds ? viewport.bounds.contains([entity.lat, entity.lon]) : true;
    });
    return next;
  }, [entities, search, localDomains, viewport.bounds]);

  const visibleAlerts = useMemo(() => {
    const query = search.trim().toLowerCase();
    return mergedAlerts.filter((alert) => {
      if (query) {
        const hay = `${alert.title} ${alert.description} ${alert.alert_type} ${alert.source}`.toLowerCase();
        if (!hay.includes(query)) return false;
      }
      if (selectedEntityId && alert.entity_id && alert.entity_id !== selectedEntityId) return false;
      return true;
    });
  }, [mergedAlerts, search, selectedEntityId]);

  const clusters = useMemo(() => clusterVisibleEntities(visibleEntities, viewport.zoom, viewport.bounds), [visibleEntities, viewport]);

  useEffect(() => {
    const activeDomains = localDomains.length ? localDomains : undefined;
    setFilters((prev: RealtimeFilters) => ({ ...prev, domains: activeDomains }));
  }, [localDomains, setFilters]);

  useEffect(() => {
    let cancelled = false;
    async function loadTrack() {
      if (!selectedEntityId || !token) {
        setTrack([]);
        return;
      }
      setTrackLoading(true);
      try {
        const res = await apiFetch(`/api/entities/${selectedEntityId}/track?limit=120`, { method: "GET" });
        const data = (await res.json()) as EntityTrackPoint[];
        if (!cancelled) setTrack(data);
      } catch {
        if (!cancelled) setTrack([]);
      } finally {
        if (!cancelled) setTrackLoading(false);
      }
    }
    void loadTrack();
    return () => {
      cancelled = true;
    };
  }, [selectedEntityId, token]);

  const topDomains = useMemo(() => summary?.domains.slice(0, 6).map((entry) => entry.domain) || [], [summary]);
  const mapLayerConfig = mapLayer(basemap);
  const labelsOverlay = basemap === "gibs" || basemap === "sentinel";
  const selectedTrackLine: LatLngExpression[] = useMemo(() => track.map((point) => [point.lat, point.lon] as [number, number]), [track]);
  const selectedProjection = useMemo(() => {
    if (!selectedEntity || selectedEntity.heading == null) return null;
    return projectHeading(selectedEntity.lat, selectedEntity.lon, selectedEntity.heading, selectedEntity.speed ? Math.max(2000, selectedEntity.speed * 180) : 2500);
  }, [selectedEntity]);

  return (
    <div className="grid h-full min-h-0 grid-cols-1 xl:grid-cols-[360px_minmax(0,1fr)_420px]">
      <aside className={copilotOpen ? "min-h-0 border-b border-slate-800 xl:border-b-0 xl:border-r" : "hidden xl:block xl:min-h-0 xl:border-r xl:border-slate-800"}>
        <CopilotDrawer
          dashboard={summary}
          selectedEntity={selectedEntity}
          visibleEntities={visibleEntities}
          visibleAlerts={visibleAlerts}
          onSelectEntity={(entityId) => setSelectedEntityId(entityId)}
        />
      </aside>

      <section ref={mapRef} className="relative min-h-[68vh] overflow-hidden bg-slate-900 xl:min-h-0">
        <div className="absolute left-4 top-4 z-[850] flex max-w-[calc(100%-2rem)] flex-col gap-3 rounded-2xl border border-slate-800 bg-slate-950/90 p-3 text-slate-200 shadow-2xl backdrop-blur">
          <div className="flex flex-wrap items-center gap-2">
            <div className="inline-flex items-center gap-2 rounded-full border border-slate-700 bg-slate-900 px-3 py-1 text-xs text-slate-300">
              {connectionStatus === "connected" ? <Wifi className="h-3.5 w-3.5 text-emerald-400" /> : connectionStatus === "error" ? <WifiOff className="h-3.5 w-3.5 text-red-400" /> : <Loader2 className="h-3.5 w-3.5 animate-spin text-amber-400" />}
              {connectionStatus}
            </div>
            <div className="inline-flex items-center gap-2 rounded-full border border-slate-700 bg-slate-900 px-3 py-1 text-xs text-slate-300">
              <MapPinned className="h-3.5 w-3.5 text-cyan-300" />
              {visibleEntities.length} entities
            </div>
            <div className="inline-flex items-center gap-2 rounded-full border border-slate-700 bg-slate-900 px-3 py-1 text-xs text-slate-300">
              <Target className="h-3.5 w-3.5 text-orange-300" />
              {visibleAlerts.length} alerts
            </div>
            <button onClick={() => void refresh()} className="inline-flex items-center gap-2 rounded-full border border-slate-700 bg-slate-900 px-3 py-1 text-xs text-slate-300 hover:bg-slate-800">
              Refresh summary
            </button>
            <span className="text-[10px] uppercase tracking-[0.24em] text-slate-500">{lastMessageAt ? new Date(lastMessageAt).toLocaleTimeString() : "waiting for stream"}</span>
          </div>
          {summaryError ? <div className="rounded-xl border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-200">{summaryError}</div> : null}
          {summaryLoading ? <div className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2 text-xs text-slate-500">Loading dashboard summary…</div> : null}
          <div className="flex flex-wrap items-center gap-2">
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search entities, alerts, callsigns…"
              className="min-w-[240px] rounded-full border border-slate-800 bg-slate-900 px-4 py-2 text-sm text-slate-100 outline-none placeholder:text-slate-600 focus:border-cyan-500/50"
            />
            <div className="flex flex-wrap gap-2">
              {(topDomains.length ? topDomains : ["aviation", "maritime", "cyber", "orbital"]).map((domain) => (
                <button
                  key={domain}
                  onClick={() => setLocalDomains((prev) => prev.includes(domain) ? prev.filter((item) => item !== domain) : [...prev, domain])}
                  className={[
                    "rounded-full border px-3 py-1.5 text-xs transition",
                    localDomains.includes(domain) ? "border-cyan-500/40 bg-cyan-500/10 text-cyan-200" : "border-slate-800 bg-slate-900 text-slate-400 hover:bg-slate-800",
                  ].join(" ")}
                >
                  {domain}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 rounded-full border border-slate-800 bg-slate-900 px-2 py-1 text-xs text-slate-400">
              <Layers3 className="h-3.5 w-3.5" />
              <select value={basemap} onChange={(event) => setBasemap(event.target.value as any)} className="bg-transparent outline-none">
                <option value="gibs">NASA GIBS satellite</option>
                <option value="street">OpenStreetMap</option>
                <option value="sentinel">Sentinel-2 tile service</option>
              </select>
            </div>
            <button onClick={() => setCopilotOpen((prev) => !prev)} className="rounded-full border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-800">
              Copilot {copilotOpen ? "on" : "off"}
            </button>
            <button onClick={() => setAlertsOpen((prev) => !prev)} className="rounded-full border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-slate-300 hover:bg-slate-800">
              Alerts {alertsOpen ? "on" : "off"}
            </button>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-slate-500">
            <span>Satellite imagery source:</span>
            <span className="rounded-full border border-slate-800 bg-slate-900 px-2 py-1">{basemap === "gibs" ? "NASA GIBS" : basemap === "sentinel" ? "SentinelMap / Sentinel-2" : "OpenStreetMap"}</span>
            {isEntityJammed(selectedEntity || ({} as IntelEntity)) ? (
              <span className="rounded-full border border-orange-500/30 bg-orange-500/10 px-2 py-1 text-orange-200">GNSS interference ring enabled</span>
            ) : null}
          </div>
        </div>

        <div className="absolute bottom-4 left-4 z-[850] max-w-[calc(100%-2rem)]">
          <MapLegend basemap={mapLayerConfig.label} />
        </div>

        <MapContainer center={viewport.center} zoom={viewport.zoom} className="h-full w-full" preferCanvas>
          <TileLayer url={mapLayerConfig.url} attribution={mapLayerConfig.attribution} maxNativeZoom={mapLayerConfig.maxNativeZoom} />
          {labelsOverlay ? <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="&copy; OpenStreetMap contributors" opacity={0.22} /> : null}
          <MainViewportBridge onViewport={setViewport} />
          <FlyToSelection selected={selectedEntity} />
          {clusters.map((item) => {
            if (item.kind === "cluster") {
              return (
                <Marker key={item.entities.map((e) => e.id).join("-")} position={item.center} icon={clusterIcon(item.entities.length)} eventHandlers={{ click: () => setViewport((state) => ({ ...state, zoom: Math.min(state.zoom + 1, 12), center: item.center })) }}>
                  <Tooltip direction="top" offset={[0, -10]} opacity={1} permanent={false}>{item.entities.length} entities</Tooltip>
                  <Popup>
                    <div className="min-w-[240px] space-y-2 text-sm">
                      <div className="font-semibold text-slate-900">{item.entities.length} entities</div>
                      <div className="text-xs text-slate-600">Zoom in for individual markers.</div>
                    </div>
                  </Popup>
                </Marker>
              );
            }
            const entity = item.entity;
            const isSelected = selectedEntityId === entity.id;
            const jammed = isEntityJammed(entity);
            const icon = entityIcon(entity, isSelected, entity.heading);
            const headingLine = entity.heading == null ? null : projectHeading(entity.lat, entity.lon, entity.heading, entity.speed ? Math.max(2000, entity.speed * 180) : 2500);
            const jamCircle = jammed ? jammingRadius(entity) : 0;
            return (
              <Fragment key={entity.id}>
                <Marker
                  key={entity.id}
                  position={[entity.lat, entity.lon]}
                  icon={icon}
                  title={entity.name || entity.external_id}
                  eventHandlers={{ click: () => setSelectedEntityId(entity.id) }}
                >
                  <Tooltip direction="top" offset={[0, -12]} opacity={1} sticky>
                    <div className="space-y-1">
                      <div className="font-semibold text-slate-900">{entity.name || entity.external_id}</div>
                      <div className="text-xs text-slate-600">{entity.domain} · {entity.entity_type}</div>
                      <div className="text-xs text-slate-600">Confidence {(entity.confidence * 100).toFixed(0)}%</div>
                    </div>
                  </Tooltip>
                  <Popup>
                    <div className="min-w-[260px] space-y-2 text-sm">
                      <div className="font-semibold text-slate-900">{entity.name || entity.external_id}</div>
                      <div className="text-xs text-slate-600">{entity.domain} · {entity.entity_type}</div>
                      <div className="text-xs text-slate-600">Last seen {fmtTime(entity.last_seen_at)}</div>
                      <button onClick={() => setSelectedEntityId(entity.id)} className="rounded-lg border border-slate-300 px-3 py-2 text-xs text-slate-700 hover:bg-slate-50">Inspect entity</button>
                    </div>
                  </Popup>
                </Marker>
                {headingLine ? <Polyline key={`${entity.id}-heading`} positions={[[entity.lat, entity.lon], headingLine]} pathOptions={{ color: confidenceColor(entity.confidence), weight: 2, opacity: 0.9, dashArray: "6 8" }} /> : null}
                {jammed ? <Circle key={`${entity.id}-jam`} center={[entity.lat, entity.lon]} radius={jamCircle} pathOptions={{ color: "#f97316", weight: 2, fillColor: "#f97316", fillOpacity: 0.08, dashArray: "8 10" }} /> : null}
              </Fragment>
            );
          })}
          {selectedTrackLine.length > 1 ? <Polyline positions={selectedTrackLine} pathOptions={{ color: "#38bdf8", weight: 3, opacity: 0.85 }} /> : null}
          {selectedEntity && selectedProjection ? <Polyline positions={[[selectedEntity.lat, selectedEntity.lon], selectedProjection]} pathOptions={{ color: "#f8fafc", weight: 2, opacity: 0.75, dashArray: "4 6" }} /> : null}
          {selectedEntity ? <Circle center={[selectedEntity.lat, selectedEntity.lon]} radius={Math.max(600, selectedEntity.speed ? selectedEntity.speed * 15 : 1200)} pathOptions={{ color: confidenceColor(selectedEntity.confidence), fillOpacity: 0.04, weight: 1.5 }} /> : null}
          <MiniMap entities={visibleEntities} selectedEntity={selectedEntity} viewport={viewport} />
        </MapContainer>
      </section>

      <aside className={alertsOpen ? "min-h-0 border-t border-slate-800 xl:border-t-0 xl:border-l" : "hidden xl:block xl:min-h-0 xl:border-l xl:border-slate-800"}>
        <AlertDrawer
          open
          alerts={mergedAlerts}
          summary={summary}
          selectedEntity={selectedEntity}
          onClose={() => setAlertsOpen(false)}
          onFocusEntity={(entityId) => setSelectedEntityId(entityId)}
          onAlertStatusChange={(alertId, status) => setAlertOverrides((prev) => ({ ...prev, [alertId]: { status } }))}
        />
        <div className="border-t border-slate-800 p-4">
          <EntityStats entity={selectedEntity} track={track} />
          {trackLoading ? <div className="mt-3 rounded-2xl border border-slate-800 bg-slate-900/50 p-3 text-sm text-slate-500">Loading entity track…</div> : null}
        </div>
      </aside>
    </div>
  );
}

export default WatchMap;
