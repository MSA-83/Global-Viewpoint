import { ArrowRight, Circle, Satellite, TriangleAlert } from "lucide-react";

type Item = { label: string; tone: string; icon: "dot" | "arrow" | "satellite" | "warning" };

const items: Item[] = [
  { label: "Aircraft", tone: "border-blue-400 bg-blue-400/15 text-blue-200", icon: "arrow" },
  { label: "Maritime", tone: "border-teal-400 bg-teal-400/15 text-teal-200", icon: "dot" },
  { label: "Orbital", tone: "border-violet-400 bg-violet-400/15 text-violet-200", icon: "satellite" },
  { label: "Cyber", tone: "border-pink-400 bg-pink-400/15 text-pink-200", icon: "dot" },
  { label: "Infrastructure", tone: "border-orange-400 bg-orange-400/15 text-orange-200", icon: "dot" },
  { label: "GNSS jamming", tone: "border-orange-500 bg-orange-500/15 text-orange-100", icon: "warning" },
];

function Icon({ icon }: { icon: Item["icon"] }) {
  if (icon === "arrow") return <ArrowRight className="h-3.5 w-3.5" />;
  if (icon === "satellite") return <Satellite className="h-3.5 w-3.5" />;
  if (icon === "warning") return <TriangleAlert className="h-3.5 w-3.5" />;
  return <Circle className="h-3.5 w-3.5 fill-current" />;
}

export function MapLegend({ basemap }: { basemap: string }) {
  return (
    <div className="pointer-events-auto rounded-2xl border border-slate-800 bg-slate-950/90 p-3 text-xs text-slate-300 shadow-2xl backdrop-blur">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.24em] text-slate-500">
        <Satellite className="h-3.5 w-3.5" />
        map legend
      </div>
      <div className="mt-2 grid gap-1.5 sm:grid-cols-2">
        {items.map((item) => (
          <div key={item.label} className={`flex items-center gap-2 rounded-lg border px-2 py-1.5 ${item.tone}`}>
            <span className="inline-flex h-5 w-5 items-center justify-center rounded-full border border-current/30 bg-slate-950/70">
              <Icon icon={item.icon} />
            </span>
            <span>{item.label}</span>
          </div>
        ))}
      </div>
      <div className="mt-2 text-[11px] text-slate-500">Basemap: {basemap}</div>
    </div>
  );
}
