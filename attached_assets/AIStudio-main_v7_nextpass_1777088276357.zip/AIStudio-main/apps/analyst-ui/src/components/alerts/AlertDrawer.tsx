import { useMemo, useState } from "react";
import { Download, ExternalLink, Filter, ShieldAlert, TriangleAlert, X } from "lucide-react";

import { apiFetch } from "../../lib/api";
import type { DashboardSummary, IntelAlert, IntelEntity } from "@sentinel-x/shared";

const TRIAGE_FLOW = ["open", "triaged", "suppressed", "resolved"] as const;
const ALERT_SCOPES = ["all", "selected", "open", "triaged", "suppressed", "resolved", "critical"] as const;

function severityRank(severity: string) {
  switch (severity) {
    case "critical":
      return 5;
    case "high":
      return 4;
    case "medium":
      return 3;
    case "low":
      return 2;
    default:
      return 1;
  }
}

function alertToCsv(alerts: IntelAlert[]) {
  const header = ["id", "entity_id", "source", "alert_type", "title", "description", "severity", "status", "observed_at", "created_at"];
  const rows = alerts.map((a) => header.map((key) => JSON.stringify((a as any)[key] ?? "")).join(","));
  return [header.join(","), ...rows].join("\n");
}

export function AlertDrawer({
  open,
  alerts,
  summary,
  selectedEntity,
  onClose,
  onFocusEntity,
  onAlertStatusChange,
}: {
  open: boolean;
  alerts: IntelAlert[];
  summary: DashboardSummary | null;
  selectedEntity: IntelEntity | null;
  onClose: () => void;
  onFocusEntity: (entityId: string) => void;
  onAlertStatusChange: (alertId: string, status: IntelAlert["status"]) => void;
}) {
  const [scope, setScope] = useState<(typeof ALERT_SCOPES)[number]>("all");
  const [busyId, setBusyId] = useState<string | null>(null);

  const scoped = useMemo(() => {
    let next = [...alerts].sort((a, b) => severityRank(b.severity) - severityRank(a.severity) || (b.created_at || "").localeCompare(a.created_at || ""));
    if (selectedEntity && scope === "selected") next = next.filter((a) => a.entity_id === selectedEntity.id);
    if (scope === "open") next = next.filter((a) => a.status === "open");
    if (scope === "triaged") next = next.filter((a) => a.status === "triaged");
    if (scope === "suppressed") next = next.filter((a) => a.status === "suppressed");
    if (scope === "resolved") next = next.filter((a) => a.status === "resolved");
    if (scope === "critical") next = next.filter((a) => a.severity === "critical" || a.severity === "high");
    if (scope === "selected" && !selectedEntity) next = [];
    return next;
  }, [alerts, scope, selectedEntity]);

  async function triage(alert: IntelAlert, status: IntelAlert["status"]) {
    setBusyId(alert.id);
    try {
      await apiFetch(`/api/alerts/${alert.id}`, {
        method: "PATCH",
        body: JSON.stringify({ status }),
      });
      onAlertStatusChange(alert.id, status);
    } finally {
      setBusyId(null);
    }
  }

  async function exportCsv() {
    const blob = new Blob([alertToCsv(scoped)], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `alerts-${scope}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function exportJson() {
    const blob = new Blob([JSON.stringify(scoped, null, 2)], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "alerts.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  if (!open) return null;

  return (
    <section className="flex h-full min-h-0 flex-col bg-slate-950">
      <header className="border-b border-slate-800 p-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-100">
              <ShieldAlert className="h-4 w-4 text-red-400" />
              Alert triage
            </div>
            <p className="mt-1 text-xs text-slate-500">Prioritize, suppress, resolve, and export alert evidence</p>
          </div>
          <button onClick={onClose} className="rounded-lg border border-slate-800 bg-slate-900 p-2 text-slate-300 hover:bg-slate-800" aria-label="Close alert drawer">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2 text-xs text-slate-500">
          <Stat label="Open" value={summary?.open_alerts ?? alerts.filter((a) => a.status === "open").length} />
          <Stat label="Critical" value={summary?.critical_alerts ?? alerts.filter((a) => a.severity === "critical").length} />
          <Stat label="Jamming" value={summary?.jamming_signals ?? 0} />
        </div>
      </header>

      <div className="border-b border-slate-800 p-4">
        <div className="flex flex-wrap items-center gap-2">
          {ALERT_SCOPES.map((item) => (
            <button
              key={item}
              onClick={() => setScope(item)}
              aria-pressed={scope === item}
              className={[
                "rounded-full border px-3 py-1.5 text-xs transition",
                scope === item
                  ? "border-cyan-500/40 bg-cyan-500/10 text-cyan-200"
                  : "border-slate-800 bg-slate-900 text-slate-400 hover:bg-slate-800",
              ].join(" ")}
            >
              {item}
            </button>
          ))}
          <button
            onClick={() => setScope("all")}
            className="rounded-full border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-slate-400 transition hover:bg-slate-800"
          >
            <Filter className="mr-1 inline h-3.5 w-3.5" />
            All alerts
          </button>
        </div>

        <div className="mt-3 flex items-center justify-between gap-3">
          <div className="text-xs text-slate-500">Showing {scoped.length} alerts in the current scope.</div>
          <div className="flex gap-2">
            <button onClick={exportCsv} className="inline-flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs text-slate-200 hover:bg-slate-800">
            <Download className="h-3.5 w-3.5" /> Export CSV
          </button>
            <button onClick={exportJson} className="inline-flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900 px-3 py-2 text-xs text-slate-200 hover:bg-slate-800">
              <Download className="h-3.5 w-3.5" /> Export JSON
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {selectedEntity ? (
          <div className="mb-4 rounded-2xl border border-slate-800 bg-slate-900/50 p-4">
            <div className="text-xs uppercase tracking-[0.2em] text-slate-500">Selected entity</div>
            <div className="mt-2 text-sm font-semibold text-slate-50">{selectedEntity.name || selectedEntity.external_id}</div>
            <div className="mt-1 text-xs text-slate-500">{selectedEntity.domain} · {selectedEntity.entity_type}</div>
            <button
              onClick={() => onFocusEntity(selectedEntity.id)}
              className="mt-3 inline-flex items-center gap-2 rounded-full border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-slate-300 transition hover:border-cyan-500/40 hover:text-white"
            >
              Focus entity <ExternalLink className="h-3.5 w-3.5" />
            </button>
          </div>
        ) : null}

        {scoped.length === 0 ? (
          <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-4 text-sm text-slate-500">
            No alerts in the current scope.
          </div>
        ) : (
          <div className="space-y-3">
            {scoped.map((alert) => {
              const entityMatch = selectedEntity && alert.entity_id === selectedEntity.id;
              return (
                <article key={alert.id} className="rounded-2xl border border-slate-800 bg-slate-900/50 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-sm font-semibold text-slate-50">{alert.title}</div>
                      <div className="mt-1 text-xs text-slate-500">{alert.description}</div>
                    </div>
                    <span className={[
                      "rounded-full border px-2 py-1 text-[10px] uppercase tracking-[0.18em]",
                      alert.severity === "critical" ? "border-red-500/30 bg-red-500/10 text-red-200" : alert.severity === "high" ? "border-orange-500/30 bg-orange-500/10 text-orange-200" : "border-slate-700 bg-slate-950 text-slate-400",
                    ].join(" ")}>
                      {alert.severity}
                    </span>
                  </div>
                  <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-slate-500">
                    <span>{alert.alert_type}</span>
                    <span>•</span>
                    <span>{alert.status}</span>
                    {entityMatch ? <span className="text-cyan-300">• selected entity</span> : null}
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                            {TRIAGE_FLOW.map((status) => (
                      <button
                        key={status}
                        disabled={busyId === alert.id}
                        onClick={() => void triage(alert, status)}
                        className={[
                          "rounded-full border px-3 py-1.5 text-xs transition disabled:opacity-50",
                          alert.status === status
                            ? "border-cyan-500/40 bg-cyan-500/10 text-cyan-200"
                            : "border-slate-800 bg-slate-950 text-slate-400 hover:bg-slate-800",
                        ].join(" ")}
                      >
                        {status}
                      </button>
                    ))}
                    {alert.entity_id ? (
                      <button
                        onClick={() => onFocusEntity(alert.entity_id!)}
                        className="rounded-full border border-slate-800 bg-slate-950 px-3 py-1.5 text-xs text-slate-400 transition hover:border-cyan-500/40 hover:text-white"
                      >
                        Focus entity
                      </button>
                    ) : null}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2">
      <div className="text-[10px] uppercase tracking-[0.2em] text-slate-500">{label}</div>
      <div className="mt-1 text-base font-semibold text-slate-100">{value}</div>
    </div>
  );
}
