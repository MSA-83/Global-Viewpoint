import { useMemo, useState } from "react";
import { Bot, ChevronRight, MessageSquare, RefreshCw, Search, Sparkles } from "lucide-react";

import { copilotChat } from "../../lib/api";
import type { DashboardSummary, IntelAlert, IntelEntity } from "@sentinel-x/shared";
import type { ChatMessage, CopilotChatResponse } from "@sentinel-x/shared";

function truncate(text: string, length = 180) {
  return text.length > length ? `${text.slice(0, length - 1)}…` : text;
}

export function CopilotDrawer({
  dashboard,
  selectedEntity,
  visibleEntities,
  visibleAlerts,
  onSelectEntity,
}: {
  dashboard: DashboardSummary | null;
  selectedEntity: IntelEntity | null;
  visibleEntities: IntelEntity[];
  visibleAlerts: IntelAlert[];
  onSelectEntity: (entityId: string) => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content: "I can summarize the map, explain alert clusters, and drill into entities using live dashboard data.",
    },
  ]);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [provider, setProvider] = useState<string>("local");
  const [suggestedActions, setSuggestedActions] = useState<string[]>(quickPrompts);

  const visibleEntityIds = useMemo(() => visibleEntities.slice(0, 40).map((e) => e.id), [visibleEntities]);
  const visibleAlertIds = useMemo(() => visibleAlerts.slice(0, 30).map((a) => a.id), [visibleAlerts]);

  const quickPrompts = [
    "Summarize the current operational picture.",
    "Which entities look unstable or low confidence?",
    "Show me alerts that need triage first.",
    "Is there a GPS jamming pattern on the map?",
  ];

  async function send(message = draft) {
    const trimmed = message.trim();
    if (!trimmed || busy) return;
    setBusy(true);
    setDraft("");
    const nextMessages = [...messages, { role: "user", content: trimmed } as ChatMessage];
    setMessages(nextMessages);
    try {
      const response = await copilotChat<CopilotChatResponse>({
        messages: nextMessages,
        selected_entity_id: selectedEntity?.id ?? null,
        focus_domain: selectedEntity?.domain ?? null,
        visible_entity_ids: visibleEntityIds,
        visible_alert_ids: visibleAlertIds,
        viewport: {
          entity_count: visibleEntities.length,
          alert_count: visibleAlerts.length,
          selected_entity_id: selectedEntity?.id ?? null,
        },
        filters: {
          domains: Array.from(new Set(visibleEntities.map((e) => e.domain))),
        },
      });
      setProvider(response.provider);
      setSuggestedActions(response.suggested_actions?.length ? response.suggested_actions : quickPrompts);
      setMessages((prev) => [...prev, { role: "assistant", content: response.message }]);
    } catch (err) {
      setMessages((prev) => [...prev, { role: "assistant", content: err instanceof Error ? err.message : "Copilot request failed." }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="flex h-full min-h-0 flex-col border-b border-slate-800 bg-slate-950 xl:border-b-0 xl:border-r">
      <header className="border-b border-slate-800 p-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-100">
              <Bot className="h-4 w-4 text-cyan-400" />
              AI copilot
            </div>
            <p className="mt-1 text-xs text-slate-500">Live dashboard context and conversational analysis</p>
          </div>
          <span className="rounded-full border border-slate-700 bg-slate-900 px-2 py-1 text-[10px] uppercase tracking-[0.2em] text-slate-400">
            {provider}
          </span>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-slate-500">
          <Metric label="Entities" value={dashboard?.active_entities ?? visibleEntities.length} />
          <Metric label="Open alerts" value={dashboard?.open_alerts ?? visibleAlerts.length} />
        </div>
        <div className="mt-3 flex flex-wrap gap-2 text-[10px] uppercase tracking-[0.18em] text-slate-500">
          {selectedEntity ? <span className="rounded-full border border-cyan-500/20 bg-cyan-500/10 px-2 py-1 text-cyan-200">selected entity active</span> : null}
          {dashboard?.jamming_signals ? <span className="rounded-full border border-orange-500/20 bg-orange-500/10 px-2 py-1 text-orange-200">{dashboard.jamming_signals} jamming signals</span> : null}
          {dashboard?.critical_alerts ? <span className="rounded-full border border-red-500/20 bg-red-500/10 px-2 py-1 text-red-200">{dashboard.critical_alerts} critical alerts</span> : null}
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="space-y-2">
          <div className="text-xs font-medium uppercase tracking-[0.2em] text-slate-500">Quick prompts</div>
          <div className="flex flex-wrap gap-2">
            {quickPrompts.map((prompt) => (
              <button
                key={prompt}
                onClick={() => void send(prompt)}
                className="rounded-full border border-slate-800 bg-slate-900 px-3 py-2 text-left text-xs text-slate-300 transition hover:border-cyan-500/40 hover:bg-slate-800"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4 rounded-2xl border border-slate-800 bg-slate-900/50 p-3">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-[0.2em] text-slate-500">
            <Sparkles className="h-3.5 w-3.5" />
            Conversation
          </div>
          <div className="mt-3 flex max-h-[34vh] flex-col gap-3 overflow-y-auto pr-1">
            {messages.map((msg, index) => (
              <div
                key={`${msg.role}-${index}`}
                className={[
                  "rounded-2xl border px-3 py-2 text-sm leading-5",
                  msg.role === "user"
                    ? "border-cyan-500/20 bg-cyan-500/10 text-cyan-50"
                    : "border-slate-800 bg-slate-950 text-slate-200",
                ].join(" ")}
              >
                <div className="mb-1 text-[10px] uppercase tracking-[0.25em] text-slate-500">{msg.role}</div>
                {msg.content}
              </div>
            ))}
            {busy ? (
              <div className="rounded-2xl border border-slate-800 bg-slate-950 px-3 py-2 text-sm text-slate-400">
                <RefreshCw className="mr-2 inline h-3.5 w-3.5 animate-spin" />
                Thinking through the dashboard context…
              </div>
            ) : null}
          </div>
        </div>

        <div className="mt-4 rounded-2xl border border-slate-800 bg-slate-900/50 p-3">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-[0.2em] text-slate-500">
            <Sparkles className="h-3.5 w-3.5" />
            Suggested follow-ups
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {suggestedActions.map((action) => (
              <button
                key={action}
                onClick={() => void send(action)}
                className="rounded-full border border-slate-800 bg-slate-950 px-3 py-2 text-left text-xs text-slate-300 transition hover:border-cyan-500/40 hover:bg-slate-800"
              >
                {truncate(action, 140)}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4 rounded-2xl border border-slate-800 bg-slate-900/50 p-3">
          <label className="text-xs font-medium uppercase tracking-[0.2em] text-slate-500">Ask copilot</label>
          <textarea
            value={draft}
            onChange={(event) => setDraft(event.target.value)}
            rows={4}
            placeholder="Ask about alerts, entity behavior, route anomalies, or jamming indicators."
            className="mt-2 w-full rounded-xl border border-slate-800 bg-slate-950 px-3 py-2 text-sm text-slate-100 outline-none transition placeholder:text-slate-600 focus:border-cyan-500/50"
          />
          <div className="mt-3 flex gap-2">
            <button
              onClick={() => void send()}
              disabled={busy || !draft.trim()}
              className="inline-flex items-center gap-2 rounded-xl bg-cyan-500 px-4 py-2 text-sm font-medium text-slate-950 transition hover:bg-cyan-400 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <MessageSquare className="h-4 w-4" />
              Send
            </button>
            <button
              onClick={() => setDraft("")}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900 px-4 py-2 text-sm text-slate-300 transition hover:bg-slate-800"
            >
              Clear
            </button>
          </div>
        </div>

        <div className="mt-4 rounded-2xl border border-slate-800 bg-slate-900/50 p-3">
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-[0.2em] text-slate-500">
            <Search className="h-3.5 w-3.5" />
            Selected entity
          </div>
          {selectedEntity ? (
            <div className="mt-3 space-y-2 text-sm text-slate-200">
              <div className="font-semibold text-slate-50">{selectedEntity.name || selectedEntity.external_id}</div>
              <div className="text-xs text-slate-500">{selectedEntity.domain} · {selectedEntity.entity_type}</div>
              <div className="text-xs text-slate-500">Confidence {(selectedEntity.confidence * 100).toFixed(0)}%</div>
              <button
                onClick={() => onSelectEntity(selectedEntity.id)}
                className="inline-flex items-center gap-1 rounded-full border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-slate-300 transition hover:border-cyan-500/40 hover:text-white"
              >
                Focus entity
                <ChevronRight className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <p className="mt-3 text-sm text-slate-500">No entity selected. Click a marker or a row from the alert drawer.</p>
          )}
        </div>
      </div>
    </section>
  );
}

function Metric({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-950 px-3 py-2">
      <div className="text-[10px] uppercase tracking-[0.2em] text-slate-500">{label}</div>
      <div className="mt-1 text-lg font-semibold text-slate-100">{value}</div>
    </div>
  );
}
