import { NavLink, Outlet } from "react-router-dom";
import { Activity, Globe, FolderKanban, ShieldAlert } from "lucide-react";

import { TelemetryStrip } from "./TelemetryStrip";

function NavIcon({ to, icon: Icon, label }: { to: string; icon: any; label: string }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        [
          "group relative flex size-10 items-center justify-center rounded-lg transition-all duration-200",
          isActive
            ? "border border-indigo-500/30 bg-indigo-500/10 text-indigo-300"
            : "text-slate-500 hover:bg-slate-900 hover:text-slate-200",
        ].join(" ")
      }
      title={label}
    >
      <Icon className="size-5" />
    </NavLink>
  );
}

export function Shell() {
  return (
    <div className="flex h-screen w-full flex-col overflow-hidden bg-slate-950 text-slate-200">
      <header className="flex h-12 items-center justify-between border-b border-slate-800 bg-slate-950 px-4">
        <div className="flex items-center gap-3">
          <div className="flex size-6 items-center justify-center rounded-sm border border-indigo-500/40 bg-indigo-500 text-white">
            <Globe className="size-4" />
          </div>
          <span className="text-sm font-bold tracking-widest text-slate-100">SENTINEL-X</span>
          <span className="text-xs uppercase tracking-[0.2em] text-indigo-300">Live</span>
        </div>
        <div className="hidden max-w-md flex-1 px-6 md:block">
          <div className="rounded border border-slate-800 bg-slate-900 px-3 py-2 text-xs text-slate-500">
            Analyst search and command palette
          </div>
        </div>
        <div className="text-xs uppercase tracking-widest text-slate-500">OPERATOR_01</div>
      </header>

      <div className="flex min-h-0 flex-1 overflow-hidden">
        <aside className="flex w-16 flex-col items-center gap-6 border-r border-slate-800 bg-slate-950 py-4">
          <NavIcon to="/watch" icon={Globe} label="Global Watch" />
          <NavIcon to="/threats" icon={ShieldAlert} label="Threat Intel" />
          <NavIcon to="/cases" icon={FolderKanban} label="Cases" />
          <NavIcon to="/analytics" icon={Activity} label="Analytics" />
        </aside>

        <main className="min-w-0 flex-1 overflow-hidden bg-slate-900">
          <Outlet />
        </main>
      </div>

      <TelemetryStrip />
    </div>
  );
}
