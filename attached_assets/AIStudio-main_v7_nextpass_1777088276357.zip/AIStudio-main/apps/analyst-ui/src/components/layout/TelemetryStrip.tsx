import { useEffect, useState } from "react";
import { apiFetch } from "../../lib/api";

export function TelemetryStrip() {
  const [ready, setReady] = useState(false);
  const [latency, setLatency] = useState(0);
  const [entitiesProcessed] = useState(0);

  useEffect(() => {
    let mounted = true;
    const tick = async () => {
      const start = performance.now();
      try {
        const res = await apiFetch("/api/health/ready", { method: "GET" });
        if (!mounted) return;
        setReady(res.ok);
        setLatency(Math.round(performance.now() - start));
      } catch {
        if (!mounted) return;
        setReady(false);
      }
    };
    tick();
    const id = window.setInterval(tick, 5000);
    return () => {
      mounted = false;
      window.clearInterval(id);
    };
  }, []);

  return (
    <footer className="h-8 border-t border-slate-800 bg-slate-950 flex items-center justify-between px-4 text-[10px] font-mono text-slate-500 z-50">
      <div className="flex gap-6">
        <span className="flex items-center gap-2">
          <div className={`size-1.5 rounded-full ${ready ? "bg-emerald-500" : "bg-amber-500"} animate-pulse`} />
          {ready ? "SYSTEM ONLINE" : "SYSTEM DEGRADED"}
        </span>
        <span>LATENCY: {latency}ms</span>
        <span>ACTIVE NODES: 3</span>
      </div>
      <div className="flex gap-6 text-brand-400/70 text-right">
        <span>SESSION ID: SX-01</span>
        <span>ENTITIES SYNCED: {entitiesProcessed.toLocaleString()}</span>
      </div>
    </footer>
  );
}
