import { useEffect, useState } from "react";
import { apiFetch } from "../lib/api";

export function Analytics() {
  const [ready, setReady] = useState(false);
  const [summary, setSummary] = useState<{ entities: number; alerts: number; cases: number }>({ entities: 0, alerts: 0, cases: 0 });

  useEffect(() => {
    let mounted = true;
    Promise.all([
      apiFetch("/api/entities?limit=1").then((r) => r.json()).catch(() => []),
      apiFetch("/api/alerts?limit=1").then((r) => r.json()).catch(() => []),
      apiFetch("/api/cases").then((r) => r.json()).catch(() => []),
    ]).then(([entities, alerts, cases]) => {
      if (!mounted) return;
      setSummary({ entities: entities.length, alerts: alerts.length, cases: cases.length });
      setReady(true);
    });
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div className="h-full overflow-y-auto p-6">
      <h1 className="text-xl font-semibold text-slate-100">Analytics</h1>
      <p className="mt-1 text-sm text-slate-500">Live counts and operational health.</p>
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        <Card title="Entities" value={String(summary.entities)} />
        <Card title="Alerts" value={String(summary.alerts)} />
        <Card title="Cases" value={String(summary.cases)} />
      </div>
      <div className="mt-6 text-sm text-slate-500">{ready ? "Analytics loaded." : "Loading analytics…"}</div>
    </div>
  );
}

function Card({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-950 p-4">
      <div className="text-xs uppercase tracking-widest text-slate-500">{title}</div>
      <div className="mt-2 text-2xl font-semibold text-slate-100">{value}</div>
    </div>
  );
}

export default Analytics;
