import { useEffect, useState } from "react";
import { apiFetch } from "../lib/api";

type CaseRow = {
  id: string;
  title: string;
  status: string;
  priority: string;
  assigned_to?: string | null;
  created_at: string;
  updated_at: string;
};

export function CaseManagement() {
  const [cases, setCases] = useState<CaseRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    apiFetch("/api/cases")
      .then((res) => res.json())
      .then((data) => mounted && setCases(data))
      .finally(() => mounted && setLoading(false));
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div className="h-full overflow-y-auto p-6">
      <h1 className="text-xl font-semibold text-slate-100">Cases</h1>
      <p className="mt-1 text-sm text-slate-500">Operational case queue and ownership.</p>
      <div className="mt-6 grid gap-3">
        {loading ? (
          <div className="text-sm text-slate-500">Loading cases…</div>
        ) : cases.length === 0 ? (
          <div className="rounded-2xl border border-slate-800 bg-slate-950 p-4 text-sm text-slate-500">No cases yet.</div>
        ) : (
          cases.map((c) => (
            <div key={c.id} className="rounded-2xl border border-slate-800 bg-slate-950 p-4">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-semibold text-slate-100">{c.title}</div>
                  <div className="mt-1 text-xs text-slate-500">{c.status} · {c.priority}</div>
                </div>
                <div className="text-xs text-slate-500">{c.assigned_to || "Unassigned"}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default CaseManagement;
