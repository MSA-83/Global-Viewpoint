export { WatchMap as default } from "../components/map/WatchMap";
