import { useMemo, useState } from "react";

import { AlertDrawer } from "../components/alerts/AlertDrawer";
import { useDashboardSummary } from "../hooks/useDashboardSummary";
import { useRealtimeIntel } from "../hooks/useRealtimeIntel";

export function ThreatIntelligence() {
  const token = localStorage.getItem("access_token");
  const { alerts, entities, connectionStatus } = useRealtimeIntel(token, {});
  const { summary } = useDashboardSummary();
  const [selectedEntityId, setSelectedEntityId] = useState<string | null>(null);
  const selectedEntity = useMemo(() => entities.find((e) => e.id === selectedEntityId) || null, [entities, selectedEntityId]);

  return (
    <div className="flex h-full min-h-0 bg-slate-950">
      <div className="flex-1 overflow-y-auto p-6">
        <div className="mb-4 text-sm text-slate-400">Connection: {connectionStatus}</div>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {entities.slice(0, 18).map((entity) => (
            <button
              key={entity.id}
              onClick={() => setSelectedEntityId(entity.id)}
              className="rounded-2xl border border-slate-800 bg-slate-900/50 p-4 text-left hover:bg-slate-900"
            >
              <div className="text-sm font-semibold text-slate-100">{entity.name || entity.external_id}</div>
              <div className="mt-1 text-xs text-slate-500">{entity.domain} · {entity.entity_type}</div>
            </button>
          ))}
        </div>
      </div>
      <AlertDrawer
        open
        alerts={alerts}
        summary={summary}
        selectedEntity={selectedEntity}
        onClose={() => void 0}
        onFocusEntity={(entityId) => setSelectedEntityId(entityId)}
        onAlertStatusChange={() => undefined}
      />
    </div>
  );
}

export default ThreatIntelligence;
