import { useCallback, useEffect, useMemo, useRef, useState } from "react";

export type ConnectionStatus = "connecting" | "connected" | "reconnecting" | "disconnected" | "error";

export type IntelEntity = {
  id: string;
  source: string;
  external_id: string;
  domain: string;
  entity_type: string;
  name?: string | null;
  callsign?: string | null;
  lat: number;
  lon: number;
  heading?: number | null;
  speed?: number | null;
  altitude?: number | null;
  confidence: number;
  state: string;
  last_seen_at?: string;
  first_seen_at?: string;
  metadata?: Record<string, unknown>;
};

export type IntelAlert = {
  id: string;
  entity_id?: string | null;
  source: string;
  alert_type: string;
  title: string;
  description: string;
  severity: "info" | "low" | "medium" | "high" | "critical" | string;
  status: "open" | "triaged" | "suppressed" | "resolved" | string;
  observed_at: string;
  created_at: string;
  evidence?: Record<string, unknown>;
};

export type RealtimeFilters = {
  domains?: string[];
  entity_ids?: string[];
  severities?: string[];
  alert_types?: string[];
};

type EventEnvelope =
  | { type: "entity.upsert"; entity: IntelEntity }
  | { type: "entity.ttl"; entity_id: string; confidence: number; state: string }
  | { type: "alert.created"; alert: IntelAlert }
  | { type: "alert.updated"; alert: IntelAlert }
  | { type: "bulk_sync"; entities?: IntelEntity[]; alerts?: IntelAlert[] }
  | { type: "connection_status"; status: string }
  | { type: "subscription_ack"; filters: RealtimeFilters }
  | { type: "pong"; ts?: number }
  | { type: string; [key: string]: any };

function getWsBaseUrl() {
  const env = import.meta.env.VITE_WS_BASE_URL as string | undefined;
  if (env) return env.replace(/\/$/, "");
  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
  return `${protocol}//${window.location.host}`;
}

export function useRealtimeIntel(token: string | null, initialFilters: RealtimeFilters = {}) {
  const [entities, setEntities] = useState<Record<string, IntelEntity>>({});
  const [alerts, setAlerts] = useState<Record<string, IntelAlert>>({});
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>("connecting");
  const [lastMessageAt, setLastMessageAt] = useState<number | null>(null);
  const [filters, setFilters] = useState<RealtimeFilters>(initialFilters);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimer = useRef<number | null>(null);
  const retryCount = useRef(0);
  const manuallyClosed = useRef(false);

  const applyEvent = useCallback((event: EventEnvelope) => {
    setLastMessageAt(Date.now());

    switch (event.type) {
      case "entity.upsert":
        setEntities((prev) => ({ ...prev, [event.entity.id]: event.entity }));
        break;
      case "entity.ttl":
        setEntities((prev) => {
          const existing = prev[event.entity_id];
          if (!existing) return prev;
          return { ...prev, [event.entity_id]: { ...existing, confidence: event.confidence, state: event.state } };
        });
        break;
      case "alert.created":
      case "alert.updated":
        setAlerts((prev) => ({ ...prev, [event.alert.id]: event.alert }));
        break;
      case "bulk_sync":
        if (event.entities) {
          const next: Record<string, IntelEntity> = {};
          for (const entity of event.entities) next[entity.id] = entity;
          setEntities(next);
        }
        if (event.alerts) {
          const nextAlerts: Record<string, IntelAlert> = {};
          for (const alert of event.alerts) nextAlerts[alert.id] = alert;
          setAlerts(nextAlerts);
        }
        break;
      default:
        break;
    }
  }, []);

  useEffect(() => {
    if (!token) {
      setConnectionStatus("disconnected");
      return;
    }

    manuallyClosed.current = false;

    const connect = () => {
      setConnectionStatus(retryCount.current === 0 ? "connecting" : "reconnecting");
      const url = new URL(`${getWsBaseUrl()}/ws/intel`);
      url.searchParams.set("token", token);
      const ws = new WebSocket(url.toString());
      wsRef.current = ws;

      ws.onopen = () => {
        retryCount.current = 0;
        setConnectionStatus("connected");
        ws.send(JSON.stringify({ type: "subscribe", filters }));
        ws.send(JSON.stringify({ type: "ping", ts: Date.now() }));
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === "connection_status" && data.status === "connected") {
            setConnectionStatus("connected");
            return;
          }
          if (data.type === "subscription_ack") return;
          if (data.type === "pong") return;
          applyEvent(data);
        } catch {
          setConnectionStatus("error");
        }
      };

      ws.onerror = () => {
        setConnectionStatus("error");
      };

      ws.onclose = () => {
        if (manuallyClosed.current) return;
        setConnectionStatus("disconnected");
        const attempt = Math.min(retryCount.current + 1, 6);
        retryCount.current = attempt;
        const delay = Math.min(1000 * 2 ** attempt, 15000);
        reconnectTimer.current = window.setTimeout(connect, delay);
      };
    };

    connect();

    return () => {
      manuallyClosed.current = true;
      if (reconnectTimer.current) window.clearTimeout(reconnectTimer.current);
      wsRef.current?.close();
    };
  }, [token, applyEvent, filters]);

  useEffect(() => {
    const ws = wsRef.current;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: "subscribe", filters }));
    }
  }, [filters]);

  const entitiesList = useMemo(() => Object.values(entities).sort((a, b) => (b.last_seen_at || "").localeCompare(a.last_seen_at || "")), [entities]);
  const alertsList = useMemo(() => Object.values(alerts).sort((a, b) => (b.created_at || "").localeCompare(a.created_at || "")), [alerts]);

  return {
    entities: entitiesList,
    alerts: alertsList,
    connectionStatus,
    lastMessageAt,
    filters,
    setFilters,
  };
}
