# Bundle Manifest

- Legacy app: `apps/legacy-web/`
- Analyst UI: `apps/analyst-ui/`
- FastAPI service: `services/api/`
- Worker entrypoints: `services/workers/`
- Shared TS contracts: `packages/shared/`
- Workspace config: `packages/config/`
- Deployment: `infra/`
- Migrations: `migrations/`

This bundle preserves the original source tree while normalizing the production layout.


## v5 fixes
- Fixed legacy server ESM/CommonJS incompatibilities.
- Added Gemini env gating in legacy WatchMap.
- Made backend DB dependency app-state aware.
- Added 404 semantics for missing entities.
- Fixed worker Docker build to include services/workers.
- Made JWT default valid at import time.


### v7 refinement pass
- Frontend env typing files added.
- Map legend and direction indicators added.
- Alert scope logic normalized.
- Copilot suggested actions surfaced.
