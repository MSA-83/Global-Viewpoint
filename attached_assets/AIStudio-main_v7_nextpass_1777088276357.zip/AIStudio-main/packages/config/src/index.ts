export const WORKSPACE_NAME = "sentinel-x";
export const DEFAULT_API_BASE_URL = "http://localhost:8000";
export const DEFAULT_WS_BASE_URL = "ws://localhost:8000";
export const DEFAULT_POLL_INTERVAL_MS = 5000;
