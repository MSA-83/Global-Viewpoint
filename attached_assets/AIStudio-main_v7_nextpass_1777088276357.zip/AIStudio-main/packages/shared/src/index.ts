export type Entity = {
  id: string;
  source: string;
  external_id: string;
  domain: string;
  entity_type: string;
  name?: string | null;
  callsign?: string | null;
  lat: number;
  lon: number;
  heading?: number | null;
  speed?: number | null;
  altitude?: number | null;
  confidence: number;
  state: string;
  last_seen_at: string;
  first_seen_at?: string;
  metadata?: Record<string, unknown>;
};

export type Alert = {
  id: string;
  entity_id?: string | null;
  source: string;
  alert_type: string;
  title: string;
  description: string;
  severity: string;
  status: string;
  observed_at: string;
  created_at: string;
  evidence?: Record<string, unknown>;
};

export type Relationship = {
  id: string;
  source_entity_id: string;
  target_entity_id: string;
  relation_type: string;
  confidence: number;
  evidence?: Record<string, unknown>;
  created_at: string;
  updated_at: string;
};

export type RealtimeFilters = {
  domains?: string[];
  entity_ids?: string[];
  severities?: string[];
  alert_types?: string[];
};

export type ConnectionStatus = "connecting" | "connected" | "reconnecting" | "disconnected" | "error";

export type IntelEntity = Entity;
export type IntelAlert = Alert;

export type RealtimeEvent =
  | { type: "entity.upsert"; entity: IntelEntity }
  | { type: "entity.ttl"; entity_id: string; confidence: number; state: string }
  | { type: "alert.created"; alert: IntelAlert }
  | { type: "alert.updated"; alert: IntelAlert }
  | { type: "bulk_sync"; entities?: IntelEntity[]; alerts?: IntelAlert[] }
  | { type: "connection_status"; status: ConnectionStatus }
  | { type: "subscription_ack"; filters: RealtimeFilters }
  | { type: "pong"; ts?: number }
  | { type: string; [key: string]: unknown };

export type DomainCount = {
  domain: string;
  count: number;
};

export type DashboardSummary = {
  active_entities: number;
  stale_entities: number;
  expired_entities: number;
  open_alerts: number;
  critical_alerts: number;
  jamming_signals: number;
  domains: DomainCount[];
  top_entities: IntelEntity[];
  top_alerts: IntelAlert[];
};

export type EntityTrackPoint = {
  id: number;
  entity_id: string;
  source: string;
  observed_at: string;
  lat: number;
  lon: number;
  speed?: number | null;
  heading?: number | null;
  altitude?: number | null;
  payload?: Record<string, unknown>;
};

export type ChatMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

export type CopilotChatRequest = {
  messages: ChatMessage[];
  selected_entity_id?: string | null;
  focus_domain?: string | null;
  visible_entity_ids?: string[];
  visible_alert_ids?: string[];
  viewport?: Record<string, unknown>;
  filters?: Record<string, unknown>;
};

export type CopilotChatResponse = {
  provider: string;
  message: string;
  suggested_actions: string[];
  used_entities: IntelEntity[];
  used_alerts: IntelAlert[];
  dashboard?: DashboardSummary | null;
};
