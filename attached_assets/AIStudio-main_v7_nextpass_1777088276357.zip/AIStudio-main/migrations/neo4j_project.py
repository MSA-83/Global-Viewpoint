from __future__ import annotations

import argparse

import psycopg
from neo4j import GraphDatabase


def project_relationships(postgres_dsn: str, neo4j_uri: str, neo4j_user: str, neo4j_password: str) -> None:
    pg = psycopg.connect(postgres_dsn, row_factory=psycopg.rows.dict_row)
    driver = GraphDatabase.driver(neo4j_uri, auth=(neo4j_user, neo4j_password))
    try:
        with pg.cursor() as cur, driver.session() as session:
            cur.execute("SELECT source_entity_id, target_entity_id, relation_type, confidence, evidence FROM relationships")
            for row in cur.fetchall():
                session.run(
                    """
                    MERGE (a:Entity {id: $source})
                    MERGE (b:Entity {id: $target})
                    MERGE (a)-[r:RELATED_TO {type: $relation_type}]->(b)
                    SET r.confidence = $confidence,
                        r.evidence = $evidence
                    """,
                    source=str(row["source_entity_id"]),
                    target=str(row["target_entity_id"]),
                    relation_type=row["relation_type"],
                    confidence=float(row["confidence"]),
                    evidence=row["evidence"],
                )
    finally:
        driver.close()
        pg.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--postgres-dsn", required=True)
    parser.add_argument("--neo4j-uri", required=True)
    parser.add_argument("--neo4j-user", required=True)
    parser.add_argument("--neo4j-password", required=True)
    args = parser.parse_args()
    project_relationships(args.postgres_dsn, args.neo4j_uri, args.neo4j_user, args.neo4j_password)


if __name__ == "__main__":
    main()
