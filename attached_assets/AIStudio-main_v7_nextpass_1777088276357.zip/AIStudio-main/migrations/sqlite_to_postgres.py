from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path

import psycopg


def migrate(sqlite_path: Path, postgres_dsn: str) -> None:
    conn = sqlite3.connect(sqlite_path)
    conn.row_factory = sqlite3.Row
    pg = psycopg.connect(postgres_dsn)
    try:
        pg.execute("BEGIN")
        for row in conn.execute("SELECT * FROM entities"):
            pg.execute(
                """
                INSERT INTO entities (
                    id, source, external_id, domain, entity_type, name, callsign,
                    lat, lon, heading, speed, altitude, confidence, state,
                    last_seen_at, metadata
                )
                VALUES (
                    %(id)s, %(source)s, %(external_id)s, %(domain)s, %(entity_type)s, %(name)s, %(callsign)s,
                    %(lat)s, %(lon)s, %(heading)s, %(speed)s, %(altitude)s, %(confidence)s, %(state)s,
                    %(last_seen_at)s, %(metadata)s::jsonb
                )
                ON CONFLICT (id) DO NOTHING
                """,
                {
                    "id": row["id"],
                    "source": row["source"],
                    "external_id": row["external_id"],
                    "domain": row["domain"],
                    "entity_type": row["entity_type"],
                    "name": row["name"],
                    "callsign": row["callsign"],
                    "lat": row["lat"],
                    "lon": row["lon"],
                    "heading": row["heading"],
                    "speed": row["speed"],
                    "altitude": row["altitude"],
                    "confidence": row["confidence"],
                    "state": row["state"],
                    "last_seen_at": row["last_seen_at"],
                    "metadata": row["metadata"] or "{}",
                },
            )
        for row in conn.execute("SELECT * FROM observations"):
            pg.execute(
                """
                INSERT INTO observations (
                    id, entity_id, source, dedupe_key, observed_at, lat, lon, speed, heading, altitude, payload
                )
                VALUES (
                    %(id)s, %(entity_id)s, %(source)s, %(dedupe_key)s, %(observed_at)s, %(lat)s, %(lon)s,
                    %(speed)s, %(heading)s, %(altitude)s, %(payload)s::jsonb
                )
                ON CONFLICT (source, dedupe_key) DO NOTHING
                """,
                {
                    "id": row["id"],
                    "entity_id": row["entity_id"],
                    "source": row["source"],
                    "dedupe_key": row["dedupe_key"],
                    "observed_at": row["observed_at"],
                    "lat": row["lat"],
                    "lon": row["lon"],
                    "speed": row["speed"],
                    "heading": row["heading"],
                    "altitude": row["altitude"],
                    "payload": row["payload"] or "{}",
                },
            )
        pg.execute("COMMIT")
    except Exception:
        pg.execute("ROLLBACK")
        raise
    finally:
        pg.close()
        conn.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Migrate legacy SQLite data into PostgreSQL.")
    parser.add_argument("--sqlite", required=True, type=Path)
    parser.add_argument("--postgres-dsn", required=True)
    args = parser.parse_args()
    migrate(args.sqlite, args.postgres_dsn)


if __name__ == "__main__":
    main()
