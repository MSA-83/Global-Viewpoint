# Sentinel-X Monorepo

This bundle preserves the legacy Node/SQLite web app under `apps/legacy-web/` and adds the normalized production stack under `apps/analyst-ui/`, `services/api/`, and `services/workers/`.

## Layout

- `apps/legacy-web/` legacy repository preserved intact
- `apps/analyst-ui/` React analyst interface
- `services/api/` FastAPI backend and Celery tasks
- `services/workers/` Celery worker/beat entrypoints
- `packages/shared/` shared TypeScript contracts
- `packages/config/` workspace config helpers
- `infra/` Docker, Railway, monitoring
- `migrations/` data migration scripts

## Local development

Backend:
```bash
cd services/api
pip install -r requirements.txt
alembic -c alembic.ini upgrade head
gunicorn -c gunicorn.conf.py app.main:app
```

Frontend:
```bash
cd apps/analyst-ui
pnpm install
pnpm dev
```

Legacy app:
```bash
cd apps/legacy-web
npm install
npm run dev
```

Workspace scripts:
```bash
pnpm install
pnpm build
pnpm lint
pnpm test
```
