# Sentinel-X v6 feature pass

This pass adds:

- map-side entity direction arrows when heading is present
- GNSS / GPS jamming rings with expected radius overlays
- NASA GIBS satellite basemap default, with optional SentinelMap tile service support via env var
- entity track fetch and path rendering
- a chat-based copilot backed by dashboard and entity/alert context
- an explicit dashboard summary endpoint for the UI and copilot
