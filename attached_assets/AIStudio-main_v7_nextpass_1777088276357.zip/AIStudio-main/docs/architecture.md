# Architecture Overview

- Legacy Node/SQLite application is preserved under `apps/legacy-web`
- Analyst UI consumes the FastAPI websocket and REST API from `services/api`
- Workers execute TTL decay, alert evaluation, and Neo4j projection jobs
- PostgreSQL/PostGIS is the source of truth for entities and observations
- Redis Pub/Sub fans out realtime events
- Neo4j is a derived relationship projection
