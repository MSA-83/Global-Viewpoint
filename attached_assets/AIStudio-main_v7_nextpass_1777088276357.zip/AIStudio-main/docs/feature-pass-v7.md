# Feature Pass v7

This pass focused on analyst UX stability and operational clarity.

## Changes
- Added Vite environment typings for both apps to resolve `import.meta.env` typing gaps.
- Improved the analyst map with:
  - direction arrows on heading-enabled entities
  - a visible legend for aircraft, maritime, orbital, cyber, infrastructure, and GNSS jamming states
  - basemap labels tied to the selected imagery source
- Tightened alert triage:
  - added a real `selected` scope
  - aligned alert scope chips with actual filter behavior
  - exported the current filtered scope to CSV and JSON
- Improved the copilot drawer:
  - surfaced backend-generated suggested follow-ups
  - added context chips for selected entities, jamming, and critical alerts
  - kept the chat flow tied to live dashboard and entity data

## Validation
- TypeScript syntax checks passed on the modified frontend files.
- Backend Python files remain compile-clean.
