# Migration Plan

1. Import legacy SQLite data with `migrations/sqlite_to_postgres.py`
2. Apply PostgreSQL schema with Alembic
3. Start API, worker, and beat services
4. Enable websocket clients on the new analyst UI
5. Retire the legacy app once parity is confirmed
