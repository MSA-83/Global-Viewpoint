# Celery worker and beat entrypoints for Sentinel-X
