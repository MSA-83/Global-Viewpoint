from __future__ import annotations

from alembic import op

revision = "0001_init_schema"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    op.execute("""
    CREATE EXTENSION IF NOT EXISTS postgis;
    CREATE EXTENSION IF NOT EXISTS pgcrypto;
    DO $$ BEGIN
        CREATE TYPE entity_state AS ENUM ('active', 'stale', 'expired', 'archived');
    EXCEPTION WHEN duplicate_object THEN NULL; END $$;
    DO $$ BEGIN
        CREATE TYPE alert_severity AS ENUM ('info', 'low', 'medium', 'high', 'critical');
    EXCEPTION WHEN duplicate_object THEN NULL; END $$;
    DO $$ BEGIN
        CREATE TYPE alert_status AS ENUM ('open', 'triaged', 'suppressed', 'resolved');
    EXCEPTION WHEN duplicate_object THEN NULL; END $$;

    CREATE TABLE IF NOT EXISTS entities (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        source text NOT NULL,
        external_id text NOT NULL,
        domain text NOT NULL,
        entity_type text NOT NULL,
        name text,
        callsign text,
        geom geometry(Point, 4326) NOT NULL,
        lat double precision NOT NULL,
        lon double precision NOT NULL,
        heading real,
        speed real,
        altitude real,
        base_confidence double precision NOT NULL DEFAULT 1.0,
        confidence double precision NOT NULL DEFAULT 1.0,
        ttl_seconds integer NOT NULL DEFAULT 3600,
        state entity_state NOT NULL DEFAULT 'active',
        first_seen_at timestamptz NOT NULL DEFAULT now(),
        last_seen_at timestamptz NOT NULL DEFAULT now(),
        metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
        version integer NOT NULL DEFAULT 1,
        UNIQUE (source, external_id)
    );
    CREATE INDEX IF NOT EXISTS idx_entities_domain_state_seen ON entities (domain, state, last_seen_at DESC);
    CREATE INDEX IF NOT EXISTS idx_entities_source_external ON entities (source, external_id);
    CREATE INDEX IF NOT EXISTS idx_entities_geom ON entities USING GIST (geom);

    CREATE TABLE IF NOT EXISTS observations (
        id bigserial PRIMARY KEY,
        entity_id uuid NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        source text NOT NULL,
        dedupe_key text NOT NULL,
        observed_at timestamptz NOT NULL,
        geom geometry(Point, 4326) NOT NULL,
        lat double precision NOT NULL,
        lon double precision NOT NULL,
        speed real,
        heading real,
        altitude real,
        payload jsonb NOT NULL DEFAULT '{}'::jsonb,
        created_at timestamptz NOT NULL DEFAULT now(),
        UNIQUE (source, dedupe_key)
    );
    CREATE INDEX IF NOT EXISTS idx_obs_entity_time ON observations (entity_id, observed_at DESC);
    CREATE INDEX IF NOT EXISTS idx_obs_geom ON observations USING GIST (geom);

    CREATE TABLE IF NOT EXISTS alerts (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        entity_id uuid REFERENCES entities(id) ON DELETE SET NULL,
        source text NOT NULL,
        alert_type text NOT NULL,
        title text NOT NULL,
        description text NOT NULL,
        severity alert_severity NOT NULL,
        status alert_status NOT NULL DEFAULT 'open',
        observed_at timestamptz NOT NULL DEFAULT now(),
        created_at timestamptz NOT NULL DEFAULT now(),
        evidence jsonb NOT NULL DEFAULT '{}'::jsonb
    );
    CREATE INDEX IF NOT EXISTS idx_alerts_status_severity_time ON alerts (status, severity, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_alerts_entity_time ON alerts (entity_id, created_at DESC);

    CREATE TABLE IF NOT EXISTS relationships (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        source_entity_id uuid NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        target_entity_id uuid NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
        relation_type text NOT NULL,
        confidence double precision NOT NULL,
        evidence jsonb NOT NULL DEFAULT '{}'::jsonb,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now(),
        UNIQUE (source_entity_id, target_entity_id, relation_type)
    );
    CREATE INDEX IF NOT EXISTS idx_relationships_source ON relationships (source_entity_id, relation_type);
    CREATE INDEX IF NOT EXISTS idx_relationships_target ON relationships (target_entity_id, relation_type);

    CREATE TABLE IF NOT EXISTS cases (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        title text NOT NULL,
        status text NOT NULL DEFAULT 'open',
        priority text NOT NULL DEFAULT 'medium',
        assigned_to text,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now()
    );

    CREATE TABLE IF NOT EXISTS notes (
        id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
        entity_id uuid REFERENCES entities(id) ON DELETE CASCADE,
        case_id uuid REFERENCES cases(id) ON DELETE CASCADE,
        content text NOT NULL,
        created_by text NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now()
    );
    """)


def downgrade():
    op.execute("""
        DROP TABLE IF EXISTS notes;
        DROP TABLE IF EXISTS cases;
        DROP TABLE IF EXISTS relationships;
        DROP TABLE IF EXISTS alerts;
        DROP TABLE IF EXISTS observations;
        DROP TABLE IF EXISTS entities;
        DROP TYPE IF EXISTS alert_status;
        DROP TYPE IF EXISTS alert_severity;
        DROP TYPE IF EXISTS entity_state;
    """)
