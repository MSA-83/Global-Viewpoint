from __future__ import annotations

import asyncio
import json
import math
from datetime import datetime, timezone

from celery.utils.log import get_task_logger
from neo4j import AsyncGraphDatabase
from sqlalchemy import text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from ..core.settings import get_settings
from .celery_app import celery_app

log = get_task_logger(__name__)
settings = get_settings()


def _sessionmaker():
    engine = create_async_engine(settings.database_url, pool_pre_ping=True, future=True)
    return engine, async_sessionmaker(engine, expire_on_commit=False)


@celery_app.task(name="app.services.celery_tasks.decay_entities")
def decay_entities():
    return asyncio.run(_decay_entities())


async def _decay_entities():
    engine, SessionLocal = _sessionmaker()
    updated = 0
    try:
        async with SessionLocal() as session:
            rows = await session.execute(text("""
                SELECT id, confidence, base_confidence, ttl_seconds, last_seen_at, state
                FROM entities
                WHERE state IN ('active', 'stale')
            """))
            entities = rows.mappings().all()
            now = datetime.now(timezone.utc)

            for e in entities:
                age_seconds = max((now - e["last_seen_at"]).total_seconds(), 0)
                ttl = max(int(e["ttl_seconds"]), 60)
                decay = math.exp(-age_seconds / ttl)
                new_conf = round(max(0.0, float(e["base_confidence"]) * decay), 4)
                new_state = "active"
                if new_conf < 0.2:
                    new_state = "stale"
                if new_conf < 0.05:
                    new_state = "expired"

                if new_conf != float(e["confidence"]) or new_state != e["state"]:
                    await session.execute(text("""
                        UPDATE entities
                        SET confidence = :confidence,
                            state = :state,
                            version = version + 1
                        WHERE id = :id
                    """), {"confidence": new_conf, "state": new_state, "id": e["id"]})
                    updated += 1
            await session.commit()
    finally:
        await engine.dispose()
    return {"updated": updated}


@celery_app.task(name="app.services.celery_tasks.evaluate_alerts")
def evaluate_alerts():
    return asyncio.run(_evaluate_alerts())


async def _evaluate_alerts():
    engine, SessionLocal = _sessionmaker()
    inserted = 0
    try:
        async with SessionLocal() as session:
            entities = await session.execute(text("""
                SELECT id
                FROM entities
                WHERE state IN ('active', 'stale')
                ORDER BY last_seen_at DESC
                LIMIT 500
            """))
            for row in entities.mappings().all():
                entity_id = row["id"]
                obs = await session.execute(text("""
                    SELECT observed_at, lat, lon, speed, heading, payload
                    FROM observations
                    WHERE entity_id = :entity_id
                    ORDER BY observed_at DESC
                    LIMIT 24
                """), {"entity_id": entity_id})
                obs_rows = obs.mappings().all()
                if len(obs_rows) < 4:
                    continue

                newest = obs_rows[0]
                prev = obs_rows[1]
                dt_hours = max((newest["observed_at"] - prev["observed_at"]).total_seconds() / 3600.0, 1e-6)
                dist_km = _haversine(prev["lat"], prev["lon"], newest["lat"], newest["lon"])
                implied_kmh = dist_km / dt_hours

                if implied_kmh > 900:
                    await _insert_alert(session, entity_id, "coordinate_spoof", "critical", "Impossible movement jump",
                                        f"Entity moved {dist_km:.1f} km in {dt_hours * 60:.1f} minutes.", {
                                            "distance_km": dist_km,
                                            "dt_hours": dt_hours,
                                            "implied_speed_kmh": implied_kmh,
                                        })
                    inserted += 1

                jamming = _gps_jamming_evidence(obs_rows)
                if jamming and not await _recent_alert_exists(session, entity_id, "gps_jamming"):
                    await _insert_alert(session, entity_id, "gps_jamming", "high", "GNSS interference suspected",
                                        "Telemetry indicates GPS/GNSS degradation and an expected interference radius.", jamming)
                    inserted += 1

                pol = _pol_score(obs_rows)
                if pol < 0.25:
                    await _insert_alert(session, entity_id, "pattern_of_life_anomaly", "high", "Pattern-of-life deviation",
                                        "Movement and speed variance are inconsistent with the recent behavior window.", {
                                            "pattern_of_life_score": pol,
                                        })
                    inserted += 1
            await session.commit()
    finally:
        await engine.dispose()
    return {"inserted": inserted}


@celery_app.task(name="app.services.celery_tasks.project_relationships")
def project_relationships():
    return asyncio.run(_project_relationships())


async def _project_relationships():
    engine, SessionLocal = _sessionmaker()
    neo4j = AsyncGraphDatabase.driver(settings.neo4j_uri, auth=(settings.neo4j_user, settings.neo4j_password))
    created = 0
    try:
        async with SessionLocal() as session:
            rows = await session.execute(text("""
                SELECT id, domain, lat, lon, last_seen_at
                FROM entities
                WHERE state IN ('active', 'stale')
                ORDER BY last_seen_at DESC
                LIMIT 200
            """))
            entities = rows.mappings().all()

            for i, a in enumerate(entities):
                for b in entities[i + 1:]:
                    if a["domain"] != b["domain"]:
                        continue
                    if abs((a["last_seen_at"] - b["last_seen_at"]).total_seconds()) > 86400:
                        continue
                    dist = _haversine(a["lat"], a["lon"], b["lat"], b["lon"])
                    if dist > 50:
                        continue

                    confidence = round(max(0.1, 1.0 - (dist / 50.0)), 4)
                    await session.execute(text("""
                        INSERT INTO relationships (source_entity_id, target_entity_id, relation_type, confidence, evidence)
                        VALUES (:a, :b, 'co_located', :confidence, :evidence::jsonb)
                        ON CONFLICT (source_entity_id, target_entity_id, relation_type)
                        DO UPDATE SET confidence = EXCLUDED.confidence,
                                      evidence = EXCLUDED.evidence,
                                      updated_at = now()
                    """), {
                        "a": a["id"],
                        "b": b["id"],
                        "confidence": confidence,
                        "evidence": json.dumps({"distance_km": dist, "domain": a["domain"]}),
                    })
                    async with neo4j.session() as n4j:
                        await n4j.run("""
                            MERGE (x:Entity {id:$a})
                            MERGE (y:Entity {id:$b})
                            MERGE (x)-[r:RELATED_TO {type:'co_located'}]->(y)
                            SET r.confidence=$confidence, r.updated_at=datetime(), r.evidence=$evidence
                        """, a=str(a["id"]), b=str(b["id"]), confidence=confidence, evidence=json.dumps({"distance_km": dist}))
                    created += 1
            await session.commit()
    finally:
        await neo4j.close()
        await engine.dispose()
    return {"created": created}


def _haversine(lat1, lon1, lat2, lon2):
    from math import radians, sin, cos, sqrt, atan2
    r = 6371.0
    dlat = radians(lat2 - lat1)
    dlon = radians(lon2 - lon1)
    a = sin(dlat / 2) ** 2 + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlon / 2) ** 2
    return 2 * r * atan2(sqrt(a), sqrt(1 - a))


def _pol_score(rows):
    speeds = [float(r["speed"] or 0) for r in rows]
    if len(speeds) < 4:
        return 0.0
    mean = sum(speeds) / len(speeds)
    var = sum((s - mean) ** 2 for s in speeds) / len(speeds)
    lats = [float(r["lat"]) for r in rows]
    lons = [float(r["lon"]) for r in rows]
    center_lat = sum(lats) / len(lats)
    center_lon = sum(lons) / len(lons)
    drift = max(_haversine(center_lat, center_lon, lat, lon) for lat, lon in zip(lats, lons))
    return max(0.0, min(1.0, 1.0 - min(1.0, (var / 1000.0 + drift / 25.0) / 2.0)))


async def _insert_alert(session, entity_id, alert_type, severity, title, description, evidence):
    await session.execute(text("""
        INSERT INTO alerts (entity_id, source, alert_type, title, description, severity, status, observed_at, evidence)
        VALUES (:entity_id, 'engine', :alert_type, :title, :description, :severity, 'open', now(), :evidence::jsonb)
        ON CONFLICT DO NOTHING
    """), {
        "entity_id": entity_id,
        "alert_type": alert_type,
        "title": title,
        "description": description,
        "severity": severity,
        "evidence": json.dumps(evidence),
    })


async def _recent_alert_exists(session, entity_id, alert_type):
    row = await session.execute(text("""
        SELECT 1
        FROM alerts
        WHERE entity_id = :entity_id
          AND alert_type = :alert_type
          AND created_at > now() - interval '30 minutes'
        LIMIT 1
    """), {
        "entity_id": entity_id,
        "alert_type": alert_type,
    })
    return row.first() is not None


def _gps_jamming_evidence(rows):
    candidate = None
    for row in rows:
        payload = row.get('payload') or {}
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except Exception:
                payload = {}
        if not isinstance(payload, dict):
            continue
        flags = [
            payload.get('gps_jamming'),
            payload.get('gnss_jamming'),
            payload.get('jammed'),
            payload.get('gnss_degraded'),
            payload.get('spoofing_suspected'),
        ]
        if any(str(flag).lower() in {'true', '1', 'yes', 'suspected'} for flag in flags if flag is not None):
            radius = payload.get('jamming_radius_m') or payload.get('expected_radius_m') or payload.get('interference_radius_m') or 1500
            candidate = {
                'gps_jamming': True,
                'jamming_radius_m': int(float(radius)),
                'expected_radius_m': int(float(radius)),
                'evidence': payload,
            }
            break
    return candidate
