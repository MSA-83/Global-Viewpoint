from __future__ import annotations

from celery import Celery

from ..core.settings import get_settings

settings = get_settings()

celery_app = Celery(
    "sentinel_x",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
    include=["app.services.celery_tasks"],
)

celery_app.conf.update(
    task_track_started=True,
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    broker_connection_retry_on_startup=True,
    timezone="UTC",
    beat_schedule={
        "ttl-decay-every-minute": {
            "task": "app.services.celery_tasks.decay_entities",
            "schedule": 60.0,
        },
        "evaluate-alerts-every-minute": {
            "task": "app.services.celery_tasks.evaluate_alerts",
            "schedule": 60.0,
        },
        "project-relationships-every-five-minutes": {
            "task": "app.services.celery_tasks.project_relationships",
            "schedule": 300.0,
        },
    },
)
