from __future__ import annotations

import json
import logging
import re
import time
from typing import Any

import httpx
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.logging import request_id_var
from ..core.metrics import COPILOT_LATENCY, COPILOT_REQUESTS
from ..core.settings import Settings
from ..models.schemas import AlertOut, CopilotChatRequest, CopilotChatResponse, DashboardSummary, DomainCount, EntityOut

log = logging.getLogger("sentinel.copilot")


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _to_entity(row: dict[str, Any]) -> EntityOut:
    return EntityOut(
        id=str(row["id"]),
        source=row["source"],
        external_id=row["external_id"],
        domain=row["domain"],
        entity_type=row["entity_type"],
        name=row.get("name"),
        callsign=row.get("callsign"),
        lat=float(row["lat"]),
        lon=float(row["lon"]),
        heading=row.get("heading"),
        speed=row.get("speed"),
        altitude=row.get("altitude"),
        confidence=float(row.get("confidence") or 0.0),
        state=row.get("state", "active"),
        last_seen_at=row["last_seen_at"],
        first_seen_at=row["first_seen_at"],
        metadata=_as_dict(row.get("metadata")),
    )


def _to_alert(row: dict[str, Any]) -> AlertOut:
    return AlertOut(
        id=str(row["id"]),
        entity_id=str(row["entity_id"]) if row.get("entity_id") is not None else None,
        source=row["source"],
        alert_type=row["alert_type"],
        title=row["title"],
        description=row["description"],
        severity=row["severity"],
        status=row["status"],
        observed_at=row["observed_at"],
        created_at=row["created_at"],
        evidence=_as_dict(row.get("evidence")),
    )


async def load_dashboard_summary(session: AsyncSession, entity_limit: int = 8, alert_limit: int = 12) -> DashboardSummary:
    counts = await session.execute(text("""
        SELECT
            COUNT(*) FILTER (WHERE state = 'active') AS active_entities,
            COUNT(*) FILTER (WHERE state = 'stale') AS stale_entities,
            COUNT(*) FILTER (WHERE state = 'expired') AS expired_entities,
            COUNT(*) FILTER (
                WHERE COALESCE((metadata->>'gps_jamming')::boolean, false) = true
                   OR COALESCE((metadata->>'gnss_jamming')::boolean, false) = true
            ) AS jamming_signals
        FROM entities
    """))
    count_row = counts.mappings().one()

    alerts = await session.execute(text("""
        SELECT id, entity_id, source, alert_type, title, description, severity, status, observed_at, created_at, evidence
        FROM alerts
        ORDER BY
            CASE severity
                WHEN 'critical' THEN 5
                WHEN 'high' THEN 4
                WHEN 'medium' THEN 3
                WHEN 'low' THEN 2
                ELSE 1
            END DESC,
            created_at DESC
        LIMIT :limit
    """), {"limit": alert_limit})
    alert_rows = [_to_alert(dict(row._mapping)) for row in alerts.fetchall()]

    entities = await session.execute(text("""
        SELECT id, source, external_id, domain, entity_type, name, callsign,
               lat, lon, heading, speed, altitude, confidence, state,
               first_seen_at, last_seen_at, metadata
        FROM entities
        ORDER BY
            CASE state
                WHEN 'active' THEN 3
                WHEN 'stale' THEN 2
                ELSE 1
            END DESC,
            confidence DESC,
            last_seen_at DESC
        LIMIT :limit
    """), {"limit": entity_limit})
    entity_rows = [_to_entity(dict(row._mapping)) for row in entities.fetchall()]

    domains = await session.execute(text("""
        SELECT domain, COUNT(*) AS count
        FROM entities
        GROUP BY domain
        ORDER BY count DESC, domain ASC
        LIMIT 12
    """))
    domain_rows = [DomainCount(domain=row[0], count=int(row[1])) for row in domains.fetchall()]

    open_alerts = await session.execute(text("""
        SELECT COUNT(*)
        FROM alerts
        WHERE status = 'open'
    """))
    critical_alerts = await session.execute(text("""
        SELECT COUNT(*)
        FROM alerts
        WHERE status = 'open' AND severity = 'critical'
    """))

    return DashboardSummary(
        active_entities=int(count_row["active_entities"] or 0),
        stale_entities=int(count_row["stale_entities"] or 0),
        expired_entities=int(count_row["expired_entities"] or 0),
        open_alerts=int(open_alerts.scalar_one()),
        critical_alerts=int(critical_alerts.scalar_one()),
        jamming_signals=int(count_row["jamming_signals"] or 0),
        domains=domain_rows,
        top_entities=entity_rows,
        top_alerts=alert_rows,
    )


async def load_entity_track(session: AsyncSession, entity_id: str, limit: int = 40) -> list[dict[str, Any]]:
    rows = await session.execute(text("""
        SELECT id, entity_id, source, observed_at, lat, lon, speed, heading, altitude, payload
        FROM observations
        WHERE entity_id = :entity_id
        ORDER BY observed_at ASC
        LIMIT :limit
    """), {"entity_id": entity_id, "limit": limit})
    return [dict(row._mapping) for row in rows.fetchall()]


async def fetch_entity(session: AsyncSession, entity_id: str) -> EntityOut | None:
    row = await session.execute(text("""
        SELECT id, source, external_id, domain, entity_type, name, callsign,
               lat, lon, heading, speed, altitude, confidence, state,
               first_seen_at, last_seen_at, metadata
        FROM entities
        WHERE id = :entity_id
    """), {"entity_id": entity_id})
    result = row.mappings().first()
    return _to_entity(dict(result)) if result else None


async def fetch_entities(session: AsyncSession, ids: list[str], limit: int) -> list[EntityOut]:
    if not ids:
        return []
    rows = await session.execute(text("""
        SELECT id, source, external_id, domain, entity_type, name, callsign,
               lat, lon, heading, speed, altitude, confidence, state,
               first_seen_at, last_seen_at, metadata
        FROM entities
        WHERE id = ANY(:ids)
    """), {"ids": ids[:limit]})
    return [_to_entity(dict(row._mapping)) for row in rows.fetchall()]


async def fetch_alerts(session: AsyncSession, ids: list[str], limit: int) -> list[AlertOut]:
    if not ids:
        return []
    rows = await session.execute(text("""
        SELECT id, entity_id, source, alert_type, title, description, severity, status, observed_at, created_at, evidence
        FROM alerts
        WHERE id = ANY(:ids)
    """), {"ids": ids[:limit]})
    return [_to_alert(dict(row._mapping)) for row in rows.fetchall()]


async def search_relevant_entities(session: AsyncSession, terms: list[str], limit: int) -> list[EntityOut]:
    if not terms:
        return []
    clauses: list[str] = []
    params: dict[str, Any] = {"limit": limit}
    for index, term in enumerate(terms[:6]):
        key = f"term_{index}"
        params[key] = f"%{term}%"
        clauses.append(
            f"COALESCE(name,'') ILIKE :{key} OR COALESCE(callsign,'') ILIKE :{key} OR domain ILIKE :{key} OR entity_type ILIKE :{key} OR source ILIKE :{key}"
        )
    where = " OR ".join(clauses)
    rows = await session.execute(text(f"""
        SELECT id, source, external_id, domain, entity_type, name, callsign,
               lat, lon, heading, speed, altitude, confidence, state,
               first_seen_at, last_seen_at, metadata
        FROM entities
        WHERE {where}
        ORDER BY confidence DESC, last_seen_at DESC
        LIMIT :limit
    """), params)
    return [_to_entity(dict(row._mapping)) for row in rows.fetchall()]


async def search_relevant_alerts(session: AsyncSession, terms: list[str], limit: int) -> list[AlertOut]:
    if not terms:
        return []
    clauses: list[str] = []
    params: dict[str, Any] = {"limit": limit}
    for index, term in enumerate(terms[:6]):
        key = f"term_{index}"
        params[key] = f"%{term}%"
        clauses.append(
            f"title ILIKE :{key} OR description ILIKE :{key} OR alert_type ILIKE :{key} OR severity ILIKE :{key} OR source ILIKE :{key}"
        )
    where = " OR ".join(clauses)
    rows = await session.execute(text(f"""
        SELECT id, entity_id, source, alert_type, title, description, severity, status, observed_at, created_at, evidence
        FROM alerts
        WHERE {where}
        ORDER BY created_at DESC
        LIMIT :limit
    """), params)
    return [_to_alert(dict(row._mapping)) for row in rows.fetchall()]


def _extract_terms(messages: list[dict[str, str]]) -> list[str]:
    text_blob = " ".join(msg.get("content", "") for msg in messages if msg.get("role") == "user")
    tokens = re.findall(r"[A-Za-z0-9_\-]{3,}", text_blob.lower())
    stop = {
        "what", "show", "with", "from", "that", "this", "about", "please", "where", "when",
        "there", "have", "been", "entity", "alert", "dashboard", "watch", "tell", "me", "the",
        "and", "for", "into", "near", "within", "current", "latest", "open", "triage",
    }
    return [t for t in tokens if t not in stop][:10]


def _summarize_selected_entity(entity: EntityOut | None, track: list[dict[str, Any]]) -> str:
    if not entity:
        return "No entity selected."
    speed = f"{entity.speed:.1f}" if entity.speed is not None else "unknown"
    heading = f"{entity.heading:.0f}°" if entity.heading is not None else "unknown"
    jamming = entity.metadata.get("gps_jamming") or entity.metadata.get("gnss_jamming")
    radius = entity.metadata.get("jamming_radius_m") or entity.metadata.get("expected_radius_m")
    jam_text = f", jamming radius ~{int(radius)}m" if jamming and radius else (", jamming suspected" if jamming else "")
    if track:
        last_point = track[-1]
        return (
            f"Selected entity {entity.name or entity.external_id} in {entity.domain}/{entity.entity_type} has confidence {entity.confidence:.2f}, "
            f"speed {speed}, heading {heading}, last seen at {entity.last_seen_at.isoformat()}{jam_text}. "
            f"Track length: {len(track)} observations, last fix {last_point['lat']:.4f}, {last_point['lon']:.4f}."
        )
    return (
        f"Selected entity {entity.name or entity.external_id} in {entity.domain}/{entity.entity_type} has confidence {entity.confidence:.2f}, "
        f"speed {speed}, heading {heading}, last seen at {entity.last_seen_at.isoformat()}{jam_text}."
    )


async def _gemini_generate(settings: Settings, prompt: str, messages: list[dict[str, str]]) -> str | None:
    if not settings.google_api_key:
        return None
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{settings.copilot_model}:generateContent?key={settings.google_api_key}"
    contents = [{"role": msg.get("role", "user"), "parts": [{"text": msg.get("content", "")}] } for msg in messages[-8:]]
    payload = {
        "systemInstruction": {"parts": [{"text": prompt}]},
        "contents": contents,
        "generationConfig": {
            "temperature": settings.copilot_temperature,
            "maxOutputTokens": 900,
        },
    }
    async with httpx.AsyncClient(timeout=20) as client:
        resp = await client.post(url, json=payload)
        resp.raise_for_status()
        data = resp.json()
    candidates = data.get("candidates") or []
    if not candidates:
        return None
    parts = ((candidates[0].get("content") or {}).get("parts")) or []
    text_parts = [p.get("text", "") for p in parts if isinstance(p, dict)]
    return "\n".join([part for part in text_parts if part]).strip() or None


def _build_prompt(
    summary: DashboardSummary,
    selected: EntityOut | None,
    track: list[dict[str, Any]],
    entities: list[EntityOut],
    alerts: list[AlertOut],
    request: CopilotChatRequest,
) -> str:
    entity_blob = [
        {
            "id": e.id,
            "name": e.name,
            "domain": e.domain,
            "type": e.entity_type,
            "confidence": e.confidence,
            "state": e.state,
            "lat": e.lat,
            "lon": e.lon,
            "heading": e.heading,
            "speed": e.speed,
            "metadata": e.metadata,
        }
        for e in entities
    ]
    alert_blob = [
        {
            "id": a.id,
            "title": a.title,
            "severity": a.severity,
            "status": a.status,
            "entity_id": a.entity_id,
            "alert_type": a.alert_type,
        }
        for a in alerts
    ]
    return (
        "You are Sentinel-X Copilot, a production analyst assistant embedded in a realtime intelligence dashboard. "
        "Answer directly, cite the most relevant entities and alerts from the context, and suggest practical next actions. "
        "Do not invent data. Keep the response concise and operational.\n\n"
        f"Dashboard summary: {summary.model_dump(mode='json')}\n"
        f"Selected entity summary: {_summarize_selected_entity(selected, track)}\n"
        f"Visible entities: {entity_blob}\n"
        f"Visible alerts: {alert_blob}\n"
        f"Viewport/filter context: {json.dumps(request.viewport, default=str)} / {json.dumps(request.filters, default=str)}\n"
        "If the user asks about anomalies, prioritize confidence decay, jamming, pattern-of-life drift, impossible movement, and alert triage."
    )


def _suggest_actions(summary: DashboardSummary, selected: EntityOut | None, alerts: list[AlertOut]) -> list[str]:
    actions: list[str] = []
    if summary.critical_alerts:
        actions.append(f"Triage the {summary.critical_alerts} critical open alerts first.")
    if summary.jamming_signals:
        actions.append(f"Inspect the {summary.jamming_signals} jamming indicators and confirm expected radius overlays.")
    if selected:
        actions.append(f"Open the selected {selected.domain} entity timeline and check the latest track points.")
    if alerts:
        top = alerts[0]
        actions.append(f"Review alert '{top.title}' and decide whether to suppress or resolve it.")
    if not actions:
        actions.append("Refresh the watchlist and look for low-confidence entities.")
    return actions[:4]


async def answer_copilot(
    session: AsyncSession,
    settings: Settings,
    request: CopilotChatRequest,
    user_sub: str | None = None,
) -> CopilotChatResponse:
    del user_sub
    start = time.perf_counter()
    provider = "local"
    summary = await load_dashboard_summary(
        session,
        entity_limit=settings.copilot_max_context_entities,
        alert_limit=settings.copilot_max_context_alerts,
    )
    selected = await fetch_entity(session, request.selected_entity_id) if request.selected_entity_id else None

    entities: list[EntityOut] = []
    alerts: list[AlertOut] = []
    terms = _extract_terms([msg.model_dump() for msg in request.messages])
    if request.visible_entity_ids:
        entities = await fetch_entities(session, request.visible_entity_ids, settings.copilot_max_context_entities)
    elif terms:
        entities = await search_relevant_entities(session, terms, settings.copilot_max_context_entities)
    if request.visible_alert_ids:
        alerts = await fetch_alerts(session, request.visible_alert_ids, settings.copilot_max_context_alerts)
    elif terms:
        alerts = await search_relevant_alerts(session, terms, settings.copilot_max_context_alerts)

    track = await load_entity_track(session, request.selected_entity_id, limit=40) if request.selected_entity_id else []
    prompt = _build_prompt(summary, selected, track, entities, alerts, request)
    user_messages = [msg.model_dump() for msg in request.messages] or [{"role": "user", "content": "Summarize the current map and notable anomalies."}]

    text_response: str | None = None
    if settings.google_api_key:
        try:
            text_response = await _gemini_generate(settings, prompt, user_messages)
            provider = "gemini"
        except Exception:
            log.exception("gemini copilot call failed", extra={"event": "copilot_error", "request_id": request_id_var.get()})
            provider = "local"

    if not text_response:
        selected_text = _summarize_selected_entity(selected, track)
        latest_alert = alerts[0].title if alerts else (summary.top_alerts[0].title if summary.top_alerts else "no open alerts")
        text_response = (
            f"Current state: {summary.active_entities} active entities, {summary.open_alerts} open alerts, "
            f"{summary.critical_alerts} critical alerts, and {summary.jamming_signals} jamming indicators. "
            f"{selected_text} The most relevant alert is '{latest_alert}'."
        )

    actions = _suggest_actions(summary, selected, alerts)
    elapsed = time.perf_counter() - start
    COPILOT_LATENCY.labels(provider=provider).observe(elapsed)
    COPILOT_REQUESTS.labels(provider=provider, status="ok").inc()

    return CopilotChatResponse(
        provider=provider,
        message=text_response,
        suggested_actions=actions,
        used_entities=entities,
        used_alerts=alerts,
        dashboard=summary,
    )
