from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from dataclasses import dataclass, field
from typing import Any

from fastapi import WebSocket
from redis.asyncio import Redis

from ..core.metrics import WEBSOCKET_CLIENTS

log = logging.getLogger("sentinel.realtime")


@dataclass
class ClientSubscription:
    user_id: str
    org_id: str
    domains: set[str] = field(default_factory=set)
    entity_ids: set[str] = field(default_factory=set)
    severities: set[str] = field(default_factory=set)
    alert_types: set[str] = field(default_factory=set)


class RealtimeHub:
    def __init__(self, redis: Redis, channel: str):
        self.redis = redis
        self.channel = channel
        self._listener_task: asyncio.Task | None = None
        self._closed = asyncio.Event()
        self._clients: dict[WebSocket, ClientSubscription] = {}

    async def start(self) -> None:
        if self._listener_task is None:
            self._listener_task = asyncio.create_task(self._listen(), name="realtime-listener")

    async def close(self) -> None:
        self._closed.set()
        if self._listener_task:
            self._listener_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._listener_task

    async def _listen(self) -> None:
        pubsub = self.redis.pubsub(ignore_subscribe_messages=True)
        await pubsub.subscribe(self.channel)
        try:
            async for message in pubsub.listen():
                if self._closed.is_set():
                    break
                raw = message.get("data")
                if not raw:
                    continue
                try:
                    event = json.loads(raw)
                except Exception:
                    log.exception("invalid pubsub payload")
                    continue
                await self.broadcast(event)
        finally:
            await pubsub.close()

    async def publish(self, event: dict[str, Any]) -> None:
        await self.redis.publish(self.channel, json.dumps(event))

    async def accept(self, ws: WebSocket, subscription: ClientSubscription) -> None:
        await ws.accept()
        self._clients[ws] = subscription
        WEBSOCKET_CLIENTS.inc()
        await ws.send_json({"type": "connection_status", "status": "connected"})

    async def disconnect(self, ws: WebSocket) -> None:
        if ws in self._clients:
            self._clients.pop(ws, None)
            WEBSOCKET_CLIENTS.dec()

    async def set_filters(self, ws: WebSocket, subscription: ClientSubscription) -> None:
        self._clients[ws] = subscription

    def _matches(self, sub: ClientSubscription, event: dict[str, Any]) -> bool:
        domain = event.get("domain")
        entity_id = event.get("entity_id")
        severity = event.get("severity")
        alert_type = event.get("alert_type")
        event_org_id = event.get("org_id")

        if event_org_id and sub.org_id and event_org_id != sub.org_id:
            return False
        if sub.domains and domain and domain not in sub.domains:
            return False
        if sub.entity_ids and entity_id and entity_id not in sub.entity_ids:
            return False
        if sub.severities and severity and severity not in sub.severities:
            return False
        if sub.alert_types and alert_type and alert_type not in sub.alert_types:
            return False
        return True

    async def broadcast(self, event: dict[str, Any]) -> None:
        stale: list[WebSocket] = []
        for ws, sub in list(self._clients.items()):
            try:
                if self._matches(sub, event):
                    await ws.send_json(event)
            except Exception:
                stale.append(ws)
        for ws in stale:
            await self.disconnect(ws)
