from __future__ import annotations

import asyncio
import logging
import signal
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from neo4j import AsyncGraphDatabase
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from .api.routes.alerts import router as alerts_router
from .api.routes.cases import router as cases_router
from .api.routes.copilot import router as copilot_router
from .api.routes.dashboard import router as dashboard_router
from .api.routes.entities import router as entities_router
from .api.routes.health import router as health_router
from .api.routes.ws import router as ws_router
from .core.logging import bind_request_id, configure_logging
from .core.metrics import PrometheusMiddleware
from .core.settings import get_settings
from .services.realtime import RealtimeHub

settings = get_settings()
log = logging.getLogger("sentinel.main")


class _DummyRedis:
    async def ping(self):
        return True

    async def publish(self, *args, **kwargs):
        return 1

    async def close(self):
        return None

    def pubsub(self, *args, **kwargs):
        return _DummyPubSub()


class _DummyPubSub:
    async def subscribe(self, *args, **kwargs):
        return None

    async def close(self):
        return None

    async def listen(self):
        if False:
            yield None
        return


class _DummyNeo4jSession:
    async def run(self, *args, **kwargs):
        return None

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False


class _DummyNeo4j:
    def session(self):
        return _DummyNeo4jSession()

    async def close(self):
        return None


class _DummyRealtimeHub:
    async def start(self):
        return None

    async def close(self):
        return None

    async def publish(self, event):
        return None

    async def accept(self, ws, subscription):
        await ws.accept()

    async def disconnect(self, ws):
        return None

    async def set_filters(self, ws, subscription):
        return None


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging()

    if settings.skip_external_services:
        app.state.redis = _DummyRedis()
        app.state.neo4j = _DummyNeo4j()
        app.state.engine = None
        app.state.sessionmaker = None
        app.state.realtime = _DummyRealtimeHub()
        app.state.shutdown_event = asyncio.Event()
        try:
            yield
        finally:
            app.state.shutdown_event.set()
        return

    app.state.redis = Redis.from_url(settings.redis_url, decode_responses=True)
    app.state.engine = create_async_engine(settings.database_url, pool_pre_ping=True, future=True, pool_size=10, max_overflow=20)
    app.state.sessionmaker = async_sessionmaker(app.state.engine, expire_on_commit=False)
    app.state.neo4j = AsyncGraphDatabase.driver(settings.neo4j_uri, auth=(settings.neo4j_user, settings.neo4j_password))
    app.state.realtime = RealtimeHub(app.state.redis, settings.pubsub_channel)
    await app.state.realtime.start()
    app.state.shutdown_event = asyncio.Event()

    try:
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                loop.add_signal_handler(sig, app.state.shutdown_event.set)
            except NotImplementedError:
                pass
    except RuntimeError:
        pass

    try:
        yield
    finally:
        app.state.shutdown_event.set()
        await app.state.realtime.close()
        await app.state.redis.close()
        await app.state.engine.dispose()
        await app.state.neo4j.close()


def build_app() -> FastAPI:
    app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)

    app.add_middleware(PrometheusMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        req_id = request.headers.get("x-request-id") or str(uuid.uuid4())
        bind_request_id(req_id)
        response = await call_next(request)
        response.headers["x-request-id"] = req_id
        return response

    app.include_router(health_router, prefix=settings.api_prefix)
    app.include_router(entities_router, prefix=settings.api_prefix)
    app.include_router(alerts_router, prefix=settings.api_prefix)
    app.include_router(cases_router, prefix=settings.api_prefix)
    app.include_router(dashboard_router, prefix=settings.api_prefix)
    app.include_router(copilot_router, prefix=settings.api_prefix)
    app.include_router(ws_router)

    return app


app = build_app()
