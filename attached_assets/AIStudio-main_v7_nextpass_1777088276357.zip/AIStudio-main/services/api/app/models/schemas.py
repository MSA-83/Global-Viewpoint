from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class EntityOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    source: str
    external_id: str
    domain: str
    entity_type: str
    name: str | None = None
    callsign: str | None = None
    lat: float
    lon: float
    heading: float | None = None
    speed: float | None = None
    altitude: float | None = None
    confidence: float
    state: str
    last_seen_at: datetime
    first_seen_at: datetime
    metadata: dict[str, Any] = Field(default_factory=dict)


class EntityTrackPoint(BaseModel):
    id: int
    entity_id: str
    source: str
    observed_at: datetime
    lat: float
    lon: float
    speed: float | None = None
    heading: float | None = None
    altitude: float | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class ObservationOut(BaseModel):
    id: int
    entity_id: str
    source: str
    observed_at: datetime
    lat: float
    lon: float
    speed: float | None = None
    heading: float | None = None
    altitude: float | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class AlertOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    entity_id: str | None = None
    source: str
    alert_type: str
    title: str
    description: str
    severity: str
    status: str
    observed_at: datetime
    created_at: datetime
    evidence: dict[str, Any] = Field(default_factory=dict)


class AlertPatch(BaseModel):
    status: str


class CaseCreate(BaseModel):
    title: str
    priority: str = "medium"


class CaseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    title: str
    status: str
    priority: str
    assigned_to: str | None = None
    created_at: datetime
    updated_at: datetime


class RealtimeEvent(BaseModel):
    type: str
    payload: dict[str, Any] = Field(default_factory=dict)


class DomainCount(BaseModel):
    domain: str
    count: int


class DashboardSummary(BaseModel):
    active_entities: int
    stale_entities: int
    expired_entities: int
    open_alerts: int
    critical_alerts: int
    jamming_signals: int
    domains: list[DomainCount] = Field(default_factory=list)
    top_entities: list[EntityOut] = Field(default_factory=list)
    top_alerts: list[AlertOut] = Field(default_factory=list)


class ChatMessageIn(BaseModel):
    role: Literal["system", "user", "assistant"]
    content: str


class CopilotChatRequest(BaseModel):
    messages: list[ChatMessageIn] = Field(default_factory=list)
    selected_entity_id: str | None = None
    focus_domain: str | None = None
    visible_entity_ids: list[str] = Field(default_factory=list)
    visible_alert_ids: list[str] = Field(default_factory=list)
    viewport: dict[str, Any] = Field(default_factory=dict)
    filters: dict[str, Any] = Field(default_factory=dict)


class CopilotChatResponse(BaseModel):
    provider: str
    message: str
    suggested_actions: list[str] = Field(default_factory=list)
    used_entities: list[EntityOut] = Field(default_factory=list)
    used_alerts: list[AlertOut] = Field(default_factory=list)
    dashboard: DashboardSummary | None = None
