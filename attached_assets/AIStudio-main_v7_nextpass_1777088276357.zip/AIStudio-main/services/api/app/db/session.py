from __future__ import annotations

from collections.abc import AsyncIterator

from fastapi import Request
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from ..core.settings import get_settings

settings = get_settings()
engine = create_async_engine(settings.database_url, pool_pre_ping=True, future=True)
SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def get_db(request: Request | None = None) -> AsyncIterator[AsyncSession]:
    sessionmaker = None
    if request is not None:
        sessionmaker = getattr(request.app.state, "sessionmaker", None)

    maker = sessionmaker or SessionLocal
    async with maker() as session:
        yield session


async def db_ping(session: AsyncSession) -> bool:
    result = await session.execute(text("SELECT 1"))
    return result.scalar_one() == 1
