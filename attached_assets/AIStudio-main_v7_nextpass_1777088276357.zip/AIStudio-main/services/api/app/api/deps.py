from __future__ import annotations

from typing import Any

from fastapi import HTTPException
from jose import JWTError

from ..core.security import decode_token


async def websocket_user(token: str | None) -> dict[str, Any]:
    if not token:
        raise HTTPException(status_code=401, detail="Missing token")
    try:
        return decode_token(token)
    except JWTError as exc:
        raise HTTPException(status_code=401, detail="Invalid token") from exc
