from __future__ import annotations

from fastapi import APIRouter, Request

from ...core.metrics import metrics_response
from ...db.session import db_ping, get_db

router = APIRouter(tags=["health"])


@router.get("/health/live")
async def live():
    return {"ok": True}


@router.get("/health/ready")
async def ready(request: Request):
    db_ok = False
    redis_ok = False
    neo4j_ok = False

    try:
        sessionmaker = getattr(request.app.state, "sessionmaker", None)
        if sessionmaker is not None:
            async with sessionmaker() as session:
                db_ok = await db_ping(session)
        else:
            async for session in get_db():
                db_ok = await db_ping(session)
                break
    except Exception:
        db_ok = False

    try:
        redis = request.app.state.redis
        redis_ok = await redis.ping()
    except Exception:
        redis_ok = False

    try:
        driver = request.app.state.neo4j
        async with driver.session() as session:
            await session.run("RETURN 1 AS ok")
            neo4j_ok = True
    except Exception:
        neo4j_ok = False

    return {"ok": db_ok and redis_ok and neo4j_ok, "database": db_ok, "redis": redis_ok, "neo4j": neo4j_ok}


@router.get("/metrics")
async def metrics():
    return metrics_response()
