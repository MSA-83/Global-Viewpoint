from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from ...core.security import get_current_user
from ...db.session import get_db

router = APIRouter(prefix="/entities", tags=["entities"])


@router.get("")
async def list_entities(
    domain: str | None = None,
    state: str | None = None,
    limit: int = Query(default=200, le=500),
    bbox: str | None = None,
    _: dict = Depends(get_current_user),
    session: AsyncSession = Depends(get_db),
):
    sql = """
        SELECT id, source, external_id, domain, entity_type, name, callsign,
               lat, lon, heading, speed, altitude, confidence, state,
               first_seen_at, last_seen_at, metadata
        FROM entities
        WHERE 1=1
    """
    params = {"limit": limit}
    if domain:
        sql += " AND domain = :domain"
        params["domain"] = domain
    if state:
        sql += " AND state = :state"
        params["state"] = state
    if bbox:
        min_lon, min_lat, max_lon, max_lat = [float(v) for v in bbox.split(",")]
        sql += " AND geom && ST_MakeEnvelope(:min_lon, :min_lat, :max_lon, :max_lat, 4326)"
        params.update({"min_lon": min_lon, "min_lat": min_lat, "max_lon": max_lon, "max_lat": max_lat})
    sql += " ORDER BY last_seen_at DESC LIMIT :limit"
    rows = await session.execute(text(sql), params)
    return [dict(r._mapping) for r in rows.fetchall()]


@router.get("/{entity_id}")
async def get_entity(entity_id: str, _: dict = Depends(get_current_user), session: AsyncSession = Depends(get_db)):
    row = await session.execute(text("""
        SELECT id, source, external_id, domain, entity_type, name, callsign,
               lat, lon, heading, speed, altitude, confidence, state,
               first_seen_at, last_seen_at, metadata
        FROM entities
        WHERE id = :entity_id
    """), {"entity_id": entity_id})
    result = row.mappings().first()
    if not result:
        raise HTTPException(status_code=404, detail="Entity not found")
    return dict(result)


@router.get("/{entity_id}/track")
async def entity_track(
    entity_id: str,
    limit: int = Query(default=120, le=500),
    _: dict = Depends(get_current_user),
    session: AsyncSession = Depends(get_db),
):
    rows = await session.execute(text("""
        SELECT id, entity_id, source, observed_at, lat, lon, speed, heading, altitude, payload
        FROM observations
        WHERE entity_id = :entity_id
        ORDER BY observed_at ASC
        LIMIT :limit
    """), {"entity_id": entity_id, "limit": limit})
    return [dict(r._mapping) for r in rows.fetchall()]


@router.get("/{entity_id}/observations")
async def entity_observations(entity_id: str, limit: int = 100, _: dict = Depends(get_current_user), session: AsyncSession = Depends(get_db)):
    rows = await session.execute(text("""
        SELECT id, entity_id, source, observed_at, lat, lon, speed, heading, altitude, payload
        FROM observations
        WHERE entity_id = :entity_id
        ORDER BY observed_at DESC
        LIMIT :limit
    """), {"entity_id": entity_id, "limit": limit})
    return [dict(r._mapping) for r in rows.fetchall()]


@router.get("/{entity_id}/timeline")
async def entity_timeline(entity_id: str, _: dict = Depends(get_current_user), session: AsyncSession = Depends(get_db)):
    obs = await session.execute(text("""
        SELECT 'observation' AS kind, id::text AS id, observed_at AS ts, payload, lat, lon
        FROM observations
        WHERE entity_id = :entity_id
        UNION ALL
        SELECT 'alert' AS kind, id::text AS id, created_at AS ts, evidence AS payload, NULL AS lat, NULL AS lon
        FROM alerts
        WHERE entity_id = :entity_id
        ORDER BY ts DESC
        LIMIT 200
    """), {"entity_id": entity_id})
    return [dict(r._mapping) for r in obs.fetchall()]
