from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from ...core.metrics import COPILOT_REQUESTS
from ...core.security import get_current_user
from ...core.settings import get_settings
from ...db.session import get_db
from ...models.schemas import CopilotChatRequest
from ...services.copilot import answer_copilot

router = APIRouter(prefix="/copilot", tags=["copilot"])
log = logging.getLogger("sentinel.api.copilot")


@router.post("/chat")
async def copilot_chat(
    payload: CopilotChatRequest,
    request: Request,
    _: dict = Depends(get_current_user),
    session: AsyncSession = Depends(get_db),
):
    settings = get_settings()
    response = await answer_copilot(session, settings, payload)
    return response.model_dump(mode="json")
