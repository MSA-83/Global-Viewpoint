from __future__ import annotations

import json
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from ..deps import websocket_user
from ...services.realtime import ClientSubscription

router = APIRouter(tags=["ws"])


@router.websocket("/ws/intel")
async def intel_socket(ws: WebSocket):
    token = ws.query_params.get("token")
    user = await websocket_user(token)
    hub = ws.app.state.realtime
    subscription = ClientSubscription(user_id=user["sub"], org_id=user.get("org_id", "default"))
    await hub.accept(ws, subscription)

    try:
        await ws.send_json({
            "type": "hello",
            "user": user["sub"],
            "org_id": user.get("org_id", "default"),
        })
        while True:
            data = await ws.receive_text()
            msg = json.loads(data)
            kind = msg.get("type")
            if kind == "subscribe":
                filters = msg.get("filters", {})
                subscription.domains = set(filters.get("domains", []))
                subscription.entity_ids = set(filters.get("entity_ids", []))
                subscription.severities = set(filters.get("severities", []))
                subscription.alert_types = set(filters.get("alert_types", []))
                await hub.set_filters(ws, subscription)
                await ws.send_json({"type": "subscription_ack", "filters": filters})
            elif kind == "ping":
                await ws.send_json({"type": "pong", "ts": msg.get("ts")})
    except WebSocketDisconnect:
        await hub.disconnect(ws)
    except Exception:
        await hub.disconnect(ws)
        raise
