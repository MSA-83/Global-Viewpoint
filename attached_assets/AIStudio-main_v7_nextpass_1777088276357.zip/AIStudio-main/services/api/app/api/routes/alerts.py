from __future__ import annotations

import csv
import io

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from ...core.security import get_current_user
from ...db.session import get_db
from ...models.schemas import AlertPatch

router = APIRouter(prefix="/alerts", tags=["alerts"])


@router.get("")
async def list_alerts(status: str | None = None, severity: str | None = None, limit: int = 200, _: dict = Depends(get_current_user), session: AsyncSession = Depends(get_db)):
    sql = """
        SELECT id, entity_id, source, alert_type, title, description, severity, status,
               observed_at, created_at, evidence
        FROM alerts
        WHERE 1=1
    """
    params = {"limit": limit}
    if status:
        sql += " AND status = :status"
        params["status"] = status
    if severity:
        sql += " AND severity = :severity"
        params["severity"] = severity
    sql += " ORDER BY created_at DESC LIMIT :limit"
    rows = await session.execute(text(sql), params)
    return [dict(r._mapping) for r in rows.fetchall()]


@router.patch("/{alert_id}")
async def patch_alert(alert_id: str, patch: AlertPatch, _: dict = Depends(get_current_user), session: AsyncSession = Depends(get_db)):
    await session.execute(text("""
        UPDATE alerts SET status = :status WHERE id = :alert_id
    """), {"status": patch.status, "alert_id": alert_id})
    await session.commit()
    return {"ok": True, "id": alert_id, "status": patch.status}


@router.get("/export.csv")
async def export_alerts(_: dict = Depends(get_current_user), session: AsyncSession = Depends(get_db)):
    rows = await session.execute(text("""
        SELECT id, entity_id, source, alert_type, title, description, severity, status, observed_at, created_at
        FROM alerts
        ORDER BY created_at DESC
    """))
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "entity_id", "source", "alert_type", "title", "description", "severity", "status", "observed_at", "created_at"])
    for r in rows.mappings().all():
        writer.writerow([r["id"], r["entity_id"], r["source"], r["alert_type"], r["title"], r["description"], r["severity"], r["status"], r["observed_at"], r["created_at"]])
    output.seek(0)
    return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="alerts.csv"'})
