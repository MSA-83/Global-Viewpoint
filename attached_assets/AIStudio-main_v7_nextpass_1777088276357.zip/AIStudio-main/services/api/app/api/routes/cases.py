from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from ...core.security import get_current_user
from ...db.session import get_db
from ...models.schemas import CaseCreate

router = APIRouter(prefix="/cases", tags=["cases"])


@router.get("")
async def list_cases(_: dict = Depends(get_current_user), session: AsyncSession = Depends(get_db)):
    rows = await session.execute(text("""
        SELECT id, title, status, priority, assigned_to, created_at, updated_at
        FROM cases
        ORDER BY updated_at DESC
    """))
    return [dict(r._mapping) for r in rows.fetchall()]


@router.post("")
async def create_case(payload: CaseCreate, _: dict = Depends(get_current_user), session: AsyncSession = Depends(get_db)):
    row = await session.execute(text("""
        INSERT INTO cases (title, status, priority)
        VALUES (:title, 'open', :priority)
        RETURNING id, title, status, priority, assigned_to, created_at, updated_at
    """), {"title": payload.title, "priority": payload.priority})
    await session.commit()
    return dict(row.mappings().one())
