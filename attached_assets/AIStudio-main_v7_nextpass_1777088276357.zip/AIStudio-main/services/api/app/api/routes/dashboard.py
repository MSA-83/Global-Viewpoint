from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from ...core.security import get_current_user
from ...db.session import get_db
from ...services.copilot import load_dashboard_summary

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/summary")
async def dashboard_summary(_: dict = Depends(get_current_user), session: AsyncSession = Depends(get_db)):
    return (await load_dashboard_summary(session)).model_dump(mode="json")
