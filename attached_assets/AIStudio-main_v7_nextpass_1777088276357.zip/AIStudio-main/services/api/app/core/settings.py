from functools import lru_cache

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "Sentinel-X"
    environment: str = Field(default="development", validation_alias="ENVIRONMENT")
    api_prefix: str = Field(default="/api", validation_alias="API_PREFIX")
    log_level: str = Field(default="INFO", validation_alias="LOG_LEVEL")

    database_url: str = Field(default="postgresql+asyncpg://sentinel:sentinel@postgres:5432/sentinel", validation_alias="DATABASE_URL")
    database_sync_url: str = Field(default="postgresql+psycopg://sentinel:sentinel@postgres:5432/sentinel", validation_alias="DATABASE_SYNC_URL")
    redis_url: str = Field(default="redis://redis:6379/0", validation_alias="REDIS_URL")
    celery_broker_url: str = Field(default="redis://redis:6379/1", validation_alias="CELERY_BROKER_URL")
    celery_result_backend: str = Field(default="redis://redis:6379/2", validation_alias="CELERY_RESULT_BACKEND")
    pubsub_channel: str = Field(default="intel.events", validation_alias="PUBSUB_CHANNEL")
    websocket_channel: str = Field(default="intel.ws", validation_alias="WEBSOCKET_CHANNEL")

    neo4j_uri: str = Field(default="bolt://neo4j:7687", validation_alias="NEO4J_URI")
    neo4j_user: str = Field(default="neo4j", validation_alias="NEO4J_USER")
    neo4j_password: str = Field(default="sentinel", validation_alias="NEO4J_PASSWORD")

    jwt_secret: str = Field(
        default="change-me-to-a-long-random-string-at-least-32-chars",
        validation_alias="JWT_SECRET",
        min_length=32,
    )
    jwt_algorithm: str = Field(default="HS256", validation_alias="JWT_ALGORITHM")
    access_token_minutes: int = Field(default=60, validation_alias="ACCESS_TOKEN_MINUTES")
    cors_origins: str = Field(default="http://localhost:5173", validation_alias="CORS_ORIGINS")

    loki_push_url: str | None = Field(default=None, validation_alias="LOKI_PUSH_URL")
    loki_job: str = Field(default="sentinel-x", validation_alias="LOKI_JOB")
    prometheus_metrics_port: int = Field(default=8000, validation_alias="PROMETHEUS_METRICS_PORT")

    rate_limit_per_minute: int = Field(default=180, validation_alias="RATE_LIMIT_PER_MINUTE")
    shutdown_grace_seconds: int = Field(default=10, validation_alias="SHUTDOWN_GRACE_SECONDS")
    skip_external_services: bool = Field(default=False, validation_alias="SKIP_EXTERNAL_SERVICES")

    google_api_key: str | None = Field(default=None, validation_alias="GOOGLE_API_KEY")
    copilot_model: str = Field(default="gemini-1.5-flash", validation_alias="COPILOT_MODEL")
    copilot_temperature: float = Field(default=0.2, validation_alias="COPILOT_TEMPERATURE")
    copilot_max_context_entities: int = Field(default=16, validation_alias="COPILOT_MAX_CONTEXT_ENTITIES")
    copilot_max_context_alerts: int = Field(default=20, validation_alias="COPILOT_MAX_CONTEXT_ALERTS")

    @field_validator("cors_origins")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
