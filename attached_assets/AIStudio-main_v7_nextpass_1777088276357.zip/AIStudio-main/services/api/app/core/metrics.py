from __future__ import annotations

import time

from fastapi import Request, Response
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Gauge, Histogram, generate_latest
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response as StarletteResponse

HTTP_REQUESTS = Counter("sentinel_http_requests_total", "HTTP requests", ["method", "path", "status"])
HTTP_LATENCY = Histogram("sentinel_http_request_duration_seconds", "HTTP request latency", ["method", "path"])
WEBSOCKET_CLIENTS = Gauge("sentinel_websocket_clients", "Connected websocket clients")
INGEST_EVENTS = Counter("sentinel_ingest_events_total", "Ingested events", ["source", "kind"])
COPILOT_REQUESTS = Counter("sentinel_copilot_requests_total", "Copilot requests", ["provider", "status"])
COPILOT_LATENCY = Histogram("sentinel_copilot_request_duration_seconds", "Copilot latency", ["provider"])


class PrometheusMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.url.path == "/metrics":
            return await call_next(request)
        method = request.method
        path = request.url.path
        start = time.perf_counter()
        response = await call_next(request)
        elapsed = time.perf_counter() - start
        HTTP_REQUESTS.labels(method=method, path=path, status=str(response.status_code)).inc()
        HTTP_LATENCY.labels(method=method, path=path).observe(elapsed)
        return response


def metrics_response() -> Response:
    return StarletteResponse(generate_latest(), media_type=CONTENT_TYPE_LATEST)
