from __future__ import annotations

import contextvars
import json
import logging
import time
import urllib.request
from datetime import datetime, timezone

from .settings import get_settings

request_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("request_id", default="-")


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "request_id": request_id_var.get(),
            "message": record.getMessage(),
        }
        for key in ("path", "method", "status_code", "duration_ms", "client_ip", "event", "entity_id", "alert_id", "task"):
            value = getattr(record, key, None)
            if value is not None:
                payload[key] = value
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str, ensure_ascii=False)


class LokiHandler(logging.Handler):
    def __init__(self, push_url: str, job: str):
        super().__init__()
        self.push_url = push_url.rstrip("/")
        self.job = job

    def emit(self, record: logging.LogRecord) -> None:
        try:
            message = self.format(record)
            timestamp_ns = int(time.time() * 1e9)
            body = {
                "streams": [
                    {
                        "stream": {"job": self.job, "logger": record.name, "level": record.levelname.lower()},
                        "values": [[str(timestamp_ns), message]],
                    }
                ]
            }
            req = urllib.request.Request(
                f"{self.push_url}/loki/api/v1/push",
                data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            urllib.request.urlopen(req, timeout=2).read()
        except Exception:
            pass


def configure_logging() -> None:
    settings = get_settings()
    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(settings.log_level.upper())

    stream = logging.StreamHandler()
    stream.setFormatter(JsonFormatter())
    root.addHandler(stream)

    if settings.loki_push_url:
        loki = LokiHandler(settings.loki_push_url, settings.loki_job)
        loki.setFormatter(JsonFormatter())
        root.addHandler(loki)


def bind_request_id(request_id: str) -> None:
    request_id_var.set(request_id)
