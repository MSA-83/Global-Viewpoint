from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Annotated

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt

from .settings import get_settings

bearer = HTTPBearer(auto_error=True)


def create_access_token(subject: str, scopes: list[str] | None = None, org_id: str | None = None) -> str:
    settings = get_settings()
    now = datetime.now(timezone.utc)
    payload: dict[str, Any] = {
        "sub": subject,
        "org_id": org_id or "default",
        "scopes": scopes or [],
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=settings.access_token_minutes)).timestamp()),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def decode_token(token: str) -> dict[str, Any]:
    settings = get_settings()
    return jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])


async def get_current_user(credentials: Annotated[HTTPAuthorizationCredentials, Depends(bearer)]) -> dict[str, Any]:
    try:
        return decode_token(credentials.credentials)
    except JWTError as exc:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token") from exc


def require_scopes(required: list[str]):
    async def _dep(user: dict[str, Any] = Depends(get_current_user)) -> dict[str, Any]:
        scopes = set(user.get("scopes", []))
        if not set(required).issubset(scopes):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient scope")
        return user

    return _dep
