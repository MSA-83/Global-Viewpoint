from __future__ import annotations

import os

os.environ.setdefault("SKIP_EXTERNAL_SERVICES", "1")

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.core.security import create_access_token, get_current_user
from app.main import build_app

pytestmark = pytest.mark.asyncio


@pytest.fixture(scope="session")
def app():
    return build_app()


@pytest.fixture(scope="session")
def auth_token():
    return create_access_token("analyst@test", scopes=["read:entities", "read:alerts"], org_id="org-test")


@pytest_asyncio.fixture
async def client(app, auth_token):
    async def override_user():
        return {"sub": "analyst@test", "org_id": "org-test", "scopes": ["read:entities", "read:alerts"]}
    app.dependency_overrides[get_current_user] = override_user
    transport = ASGITransport(app=app)
    headers = {"Authorization": f"Bearer {auth_token}"}
    async with AsyncClient(transport=transport, base_url="http://testserver", headers=headers) as ac:
        yield ac
    app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def db_session():
    db_url = os.getenv("TEST_DATABASE_URL")
    if not db_url:
        pytest.skip("TEST_DATABASE_URL not set")
    engine = create_async_engine(db_url, future=True)
    maker = async_sessionmaker(engine, expire_on_commit=False)
    async with maker() as session:
        yield session
    await engine.dispose()


@pytest_asyncio.fixture
async def redis_client():
    redis_url = os.getenv("TEST_REDIS_URL")
    if not redis_url:
        pytest.skip("TEST_REDIS_URL not set")
    from redis.asyncio import Redis
    client = Redis.from_url(redis_url, decode_responses=True)
    yield client
    await client.close()


@pytest_asyncio.fixture
async def neo4j_driver():
    uri = os.getenv("TEST_NEO4J_URI")
    if not uri:
        pytest.skip("TEST_NEO4J_URI not set")
    from neo4j import AsyncGraphDatabase
    driver = AsyncGraphDatabase.driver(uri, auth=(os.getenv("TEST_NEO4J_USER", "neo4j"), os.getenv("TEST_NEO4J_PASSWORD", "test")))
    yield driver
    await driver.close()
