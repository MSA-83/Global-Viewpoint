from __future__ import annotations


async def test_live(client):
    res = await client.get("/api/health/live")
    assert res.status_code == 200
    assert res.json()["ok"] is True
