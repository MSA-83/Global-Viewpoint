from __future__ import annotations

from starlette.testclient import TestClient


def test_ws_hello(app, auth_token):
    with TestClient(app) as client:
        with client.websocket_connect(f"/ws/intel?token={auth_token}") as ws:
            msg = ws.receive_json()
            assert msg["type"] == "connection_status"
