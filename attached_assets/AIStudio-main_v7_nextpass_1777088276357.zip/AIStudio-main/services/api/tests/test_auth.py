from __future__ import annotations

from httpx import ASGITransport, AsyncClient


async def test_entities_requires_auth(app):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        res = await ac.get("/api/entities")
    assert res.status_code in (401, 403)
