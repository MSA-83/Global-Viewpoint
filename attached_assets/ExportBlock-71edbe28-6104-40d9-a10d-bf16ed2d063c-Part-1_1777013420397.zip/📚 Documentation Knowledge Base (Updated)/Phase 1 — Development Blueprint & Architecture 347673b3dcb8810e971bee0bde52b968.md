# Phase 1 — Development Blueprint & Architecture

# OOBE: Open-Source Order-of-Battle Engine

## Complete Production-Grade Development Blueprint | Built on SENTINEL OS Architecture | April 2026

---

# 1. EXECUTIVE SUMMARY

OOBE (Open-Source Order-of-Battle Engine) is a real-time, multi-domain situational awareness platform that fuses public aviation, maritime, seismic, conflict, weather, and cyber intelligence feeds into a live relational knowledge graph with entity persistence, TTL-aware confidence decay, and adversarial-pattern detection. It is the civilian-grade equivalent of the DoD's MARS + MetaConstellation stack — built entirely on open APIs, deployed as a SaaS, and directly extended from the existing SENTINEL OS architecture (Leaflet + FastAPI + Python).

The platform fills a documented gap: dozens of high-quality public OSINT feeds exist in isolation, with no relational layer connecting them into a coherent, temporally-aware situational picture. Journalists, NGOs, maritime analysts, think tanks, and crisis responders all need this capability but cannot access MARS or equivalent classified systems. OOBE delivers it at $200–$1,500/month.

Why it wins: SENTINEL OS already provides the map frontend, FastAPI backend, and feed adapter patterns. The delta work is entity persistence (PostgreSQL + PostGIS), a graph relationship layer (Neo4j), TTL decay enforcement (Redis), and the threat-model security layer derived from MITRE ATLAS — the adversarial AI framework loaded from atlas.xlsx. A two-person team can reach an investor-demonstrable MVP in six weeks without greenfield development.

---

# 2. SYSTEM ARCHITECTURE DIAGRAM

7-layer architecture: Feeds (L0) → Ingestion/FastAPI (L1) → Cache/Queue/Redis+Celery (L2) → Persistence/PostgreSQL+Neo4j (L3) → Intelligence Engine (L4) → API Layer/FastAPI (L5) → Frontend/SENTINEL OS/Leaflet (L6) + Ops (Grafana, Sentry, Loki)

```mermaid
flowchart TB
    subgraph FEEDS["Layer 0: External Data Feeds"]
        A1[ADS-B Exchange WebSocket]
        A2[AisHub WebSocket]
        A3[ACLED REST API]
        A4[NASA FIRMS REST API]
        A5[USGS Earthquakes REST API]
        A6[OpenSky Network REST API]
        A7[OpenWeatherMap REST API]
        A8[NOAA SWPC REST API]
        A9[OpenAQ REST API]
        A10[GDACS XML Feed]
    end
    subgraph INGEST["Layer 1: Ingestion - FastAPI"]
        B1[Feed Adapter Manager]
        B2[Schema Normalizer Pydantic v2]
        B3[Entity Resolver]
        B4[ATLAS Threat Classifier]
    end
    subgraph CACHE["Layer 2: Cache & Queue"]
        C1[Redis 7.x TTL keys]
        C2[Celery 5.x Workers]
        C3[Redis Pub/Sub event bus]
    end
    FEEDS --> B1
    B1 --> B2 --> B3 --> B4
    B3 --> C1
    B4 --> C2
```

```mermaid
flowchart TB
    subgraph STORE["Layer 3: Persistence"]
        D1[PostgreSQL 16 + PostGIS 3.4]
        D2[Neo4j 5.x Community]
        D3[TimescaleDB hypertable]
    end
    subgraph ENGINE["Layer 4: Intelligence Engine"]
        E1[TTL Decay Engine]
        E2[Pattern-of-Life IsolationForest]
        E3[Cross-Cue Validator]
        E4[Alert Worker]
        E5[ATLAS Threat Scorer]
    end
    subgraph API["Layer 5: API - FastAPI"]
        F1[REST API /v1/entities /v1/alerts]
        F2[WebSocket /ws/live]
        F3[GraphQL /graphql]
        F4[Auth JWT + API Keys]
    end
    subgraph FRONTEND["Layer 6: Frontend - SENTINEL OS"]
        G1[Leaflet.js Map WebGL]
        G2[Entity Sidebar + Timeline]
        G3[Alert Panel]
        G4[TTL Confidence Bars]
        G5[ATLAS Threat Overlay]
    end
    subgraph OPS["Operations"]
        H1[Sentry]
        H2[Grafana + Prometheus]
        H3[Loki]
    end
    D1 --> E1
    D1 --> E2
    D1 --> E4
    D1 --> E5
    E1 --> C3
    E4 --> C3
    C3 --> F2
    D1 --> F1
    D2 --> F1
    F1 --> G1
    F2 --> G2
    D1 --> H2
    F1 --> H1
```

## Layer Descriptions

Layer 0 – Feeds | Raw OSINT data sources | Public APIs, WebSockets

Layer 1 – Ingestion | Normalization, entity resolution, threat tagging | FastAPI, Pydantic, asyncio

Layer 2 – Cache/Queue | Deduplication, TTL tracking, async job dispatch | Redis 7.x, Celery 5.x

Layer 3 – Persistence | Entity history, geospatial queries, relationships | PostgreSQL+PostGIS, Neo4j, TimescaleDB

Layer 4 – Intelligence | TTL decay, anomaly detection, alerts, ATLAS scoring | scikit-learn, custom Python

Layer 5 – API | Authenticated data access, live feed | FastAPI REST + WebSocket + GraphQL

Layer 6 – Frontend | Visualization, analyst workflow | Leaflet.js, SENTINEL OS HTML/JS

Ops | Observability | Grafana, Prometheus, Sentry, Loki

---

# 3. TECHNICAL STACK DECISIONS

Backend framework: FastAPI 0.115.x vs Flask 3.x — SENTINEL OS already uses FastAPI. Async-native for WebSocket feeds. Automatic OpenAPI docs. Pydantic v2 for schema validation.

Primary database: PostgreSQL 16 + PostGIS 3.4 vs MongoDB — PostGIS ST_DWithin, ST_Intersects are non-negotiable for geospatial queries. JSONB columns handle variable entity metadata. TimescaleDB hypertable extension handles time-series observation storage.

Graph store: Neo4j 5.x Community vs pgvector/Apache AGE — Entity relationships (vessel + aircraft + event converged) require true graph traversal. Cypher queries are more readable than recursive SQL. Neo4j Community is free for single-node.

Time-series: TimescaleDB (PG extension) vs InfluxDB — Runs inside existing PostgreSQL instance. Continuous aggregates handle 1-min/1-hour rollups for Pattern-of-Life baselines.

Caching: Redis 7.x vs Valkey 7.x — Redis 7.x is stable, widely supported. Pub/Sub for live event bus. TTL keys for feed deduplication.

Task queue: Celery 5.3 + Redis broker vs BullMQ (Node.js) — Python-native. Celery beat handles scheduled feed polling. BullMQ requires a Node.js sidecar.

Frontend: SENTINEL OS (Leaflet.js + HTML/JS) vs React + react-leaflet — SENTINEL OS is already built. Add entity sidebar, TTL bars, and ATLAS overlay as incremental HTML/JS modules.

Infra Phase 1–2: Railway.app vs Render — Railway supports PostgreSQL + Redis + FastAPI from a single dashboard. $20/month Developer plan.

Infra Phase 3+: AWS ECS Fargate vs Kubernetes (EKS) — ECS Fargate is managed containers without K8s operator overhead. Scale to K8s only if multi-region or >10k concurrent entities.

Auth: Supabase Auth vs Auth0 — Supabase provides Auth + PostgreSQL in one service. Auth0 is more expensive at scale. JWT tokens integrate cleanly with FastAPI middleware.

Monitoring: Grafana Cloud (free) + Sentry (free) vs New Relic — Grafana Cloud free tier: 10k metrics series, 50GB logs. Sentry free tier: 5k errors/month.

Python version: 3.12 vs 3.11 — 3.12 gives 5–10% performance improvement. asyncio improvements matter for concurrent feed adapters.

Container base: python:3.12-slim-bookworm vs python:3.12-alpine — Slim has fewer dependency compilation issues with native extensions (psycopg2, shapely).

---

# 4. DETAILED DEVELOPMENT ROADMAP

## PHASE 1: MVP Prototype (Weeks 1–6)

Goal: Live map with 5 feed domains, entity persistence, TTL decay bars, basic alert engine. Team: 2 engineers (~160 hours). Infra cost: ~$0 (Railway free tier).

### Week 1: Foundation

- [ ]  Repository setup: oobe-backend/ (FastAPI) and oobe-frontend/ (SENTINEL OS fork)
- [ ]  Docker Compose: postgres+postgis, redis, neo4j, fastapi, celery-worker
- [ ]  Database migrations: alembic init, entities/events/observations schema
- [ ]  Feed adapter base class: BaseAdapter(url, domain, poll_interval_s)
- [ ]  Environment config: pydantic-settings for all secrets

Acceptance criteria: docker-compose up runs all services; GET /health returns 200 with DB/Redis/Neo4j status.

### Week 2: Aviation + Maritime Adapters

- [ ]  ADS-B Exchange WebSocket adapter (wss://opendata.adsb.fi/api/v2/lat/0/lon/0/dist/6371)
- [ ]  OpenSky Network REST adapter (poll every 60s, bbox configurable)
- [ ]  AisHub WebSocket adapter (NMEA sentence parser → vessel entity)
- [ ]  Entity resolution: ICAO24 key for aircraft, MMSI key for vessels
- [ ]  Redis dedup: SET entity:{domain}:{key} {last_seen_ts} EX {ttl_seconds}
- [ ]  PostgreSQL upsert: INSERT ... ON CONFLICT (domain_key) DO UPDATE

Acceptance criteria: 100+ aircraft and 50+ vessels visible on map after 5 minutes of runtime. No duplicate entity markers.

### Week 3: Event Feeds + TTL Engine

- [ ]  ACLED REST adapter (poll every 15 min; last 7 days, bbox filter)
- [ ]  NASA FIRMS adapter (VIIRS Near Real-Time, 24h, global)
- [ ]  USGS Earthquake adapter (magnitude ≥ 3.0, last 24h)
- [ ]  TTL Decay Engine: background Celery beat task runs every 30s. confidence = 1.0 - (now - last_seen) / ttl_threshold
- [ ]  Frontend: confidence bar rendered as colored strip beneath each marker (green→yellow→red→grey)

Acceptance criteria: Aircraft marker greys out within configured TTL after ADS-B feed stops. ACLED events appear on map within 20 min of ACLED database update.

### Week 4: WebSocket Live Feed + Basic Frontend Integration

- [ ]  FastAPI WebSocket endpoint: GET /ws/live (Subscribes to Redis Pub/Sub oobe:live channel)
- [ ]  SENTINEL OS frontend: replace polling with WebSocket connection
- [ ]  Entity sidebar panel: click marker → show entity UUID, domain, last_seen, confidence, observation count
- [ ]  Basic alert rule engine: alerts_config.yaml with polygon + threshold trigger types

### Week 5: Entity Timeline + Neo4j Relationships

- [ ]  TimescaleDB hypertable: observations(entity_uuid, ts, lat, lon, metadata JSONB)
- [ ]  Entity timeline API: GET /v1/entities/{uuid}/history?hours=24
- [ ]  Neo4j integration: PROXIMITY relationship when two entities within 50km in same 30-min window
- [ ]  TEMPORAL_CO relationship when two events within 2h and 100km

### Week 6: MVP Hardening + Demo Prep

- [ ]  Supabase Auth integration: JWT middleware on all /v1/ routes
- [ ]  Rate limiting: slowapi middleware, 100 req/min per API key
- [ ]  Error handling: all adapters have retry with exponential backoff (max 5 retries, 2^n seconds)
- [ ]  Sentry integration: sentry-sdk[fastapi] with error capture
- [ ]  Demo script: 10-minute walkthrough of map → entity click → timeline → alert

Acceptance criteria: Platform runs continuously for 48 hours without manual intervention.

## PHASE 2: Pilot (Weeks 7–14)

Goal: Multi-user deployment, 4 additional feed domains, Pattern-of-Life anomaly detection, alert export, 3–5 pilot users. Team: 2 engineers (~300 hours). Infra cost: ~$50–100/month (Railway Developer).

### Week 7–8: Additional Feeds

- [ ]  GDACS XML feed adapter (disasters/industrial accidents)
- [ ]  OpenWeatherMap adapter (weather alerts near tracked entities)
- [ ]  NOAA SWPC Kp index adapter (space weather)
- [ ]  OpenAQ adapter (air quality anomaly detection near event clusters)
- [ ]  AVWX adapter (aviation weather METAR/TAF for aircraft context)

### Week 9–10: Pattern-of-Life Engine

- [ ]  Observation baseline computation: Celery beat task, daily, per entity_type (14-day position history)
- [ ]  Anomaly scoring (scikit-learn IsolationForest): features [speed_delta, heading_delta, distance_from_baseline_centroid, time_since_last_known]. Threshold: -0.1
- [ ]  Loitering detection: Aircraft loitering = speed < 150kt, heading variance > 45°, same 20km cell > 20min. Vessel loitering = speed < 3kt, jitter < 500m, > 2h
- [ ]  Alert type: ANOMALY with sub-types LOITERING, COURSE_DEVIATION, SPEED_ANOMALY

### Week 11–12: Alert Export + Analyst Workflow

- [ ]  Alert export: GeoJSON, KML, CSV endpoints (GET /v1/alerts/export?format=geojson)
- [ ]  Entity export: GET /v1/entities/{uuid}/export?format=kml
- [ ]  Alert webhook: POST to configured URL on alert trigger (Zapier/Slack integration)
- [ ]  Analyst notes: POST /v1/entities/{uuid}/notes — attach text annotation to entity
- [ ]  Team workspaces: multi-tenant entity + alert isolation per organization

### Week 13–14: Pilot Onboarding + Performance

- [ ]  Recruit 3–5 pilot users (Bellingcat community, ACLED network, maritime OSINT accounts)
- [ ]  Performance baseline: entity persistence rate, alert latency, map render time
- [ ]  Database indexing review: EXPLAIN ANALYZE on top 5 heaviest queries

Acceptance criteria: 3 pilot users active for 2+ consecutive weeks. Alert latency <5s. Map renders 500 entities in <500ms.

## PHASE 3: Production SaaS (Weeks 15–24)

Goal: Paid SaaS, public API, ATLAS threat overlay, Provenance Sentinel module. Team: 2–4 engineers (~400 hours). Infra cost: ~$200–500/month (AWS ECS Fargate).

- [ ]  Weeks 15–17: Stripe integration, usage metering, self-serve signup, feature flags (flagsmith/PostHog)
- [ ]  Weeks 18–20: Seed ATLAS data from atlas.xlsx, ATLAS classifier mapping anomalies to AML technique IDs, threat overlay frontend layer
- [ ]  Weeks 21–22: Provenance Sentinel — C2PA SDK, TinEye reverse image, Hive AI detection, POST /v1/verify/image endpoint
- [ ]  Weeks 23–24: OpenAPI 3.1 spec, API key management, GraphQL (Strawberry), developer docs, OWASP ZAP security audit

Acceptance criteria: First 10 paying customers. Zero P0 security issues from OWASP ZAP. API latency p99 < 200ms.

## PHASE 4: Scale (Months 7–18)

Goal: 100 paying customers, $40K MRR, government contract pathway, edge/offline mode. Team: 4–6 people. Infra: ~$1,500–3,000/month.

- [ ]  Custom feed adapter SDK: allow Enterprise users to plug in proprietary feeds
- [ ]  Offline/edge bundle: compressed SQLite snapshot + offline Leaflet tiles for disconnected environments
- [ ]  SAM.gov registration + CAGE code for government contract pathway
- [ ]  On-premise deployment option: Docker Compose bundle for air-gapped networks
- [ ]  Partnership track: Bellingcat, ACLED, GDACS data sharing agreements
- [ ]  ML model improvements: retrain IsolationForest monthly on growing observation dataset

---

# 5. CORE DATA PIPELINE SPECIFICATION

## Feed Adapter Base Class (oobe/adapters/base.py)

```python
from abc import ABC, abstractmethod
from datetime import datetime
from typing import AsyncGenerator
import asyncio, logging
from pydantic import BaseModel

class NormalizedEntity(BaseModel):
    domain: str          # aviation|maritime|conflict|seismic|fire
    domain_key: str      # ICAO24|MMSI|event_id|etc
    lat: float
    lon: float
    observed_at: datetime
    metadata: dict
    ttl_seconds: int     # aviation=600, maritime=1800, conflict=86400
    source_url: str

class BaseAdapter(ABC):
    domain: str
    poll_interval_s: int
    max_retries: int = 5

    @abstractmethod
    async def fetch(self) -> AsyncGenerator[NormalizedEntity, None]:
        """Yield normalized entities from the data source."""

    async def run_forever(self, queue: asyncio.Queue):
        retry = 0
        while True:
            try:
                async for entity in self.fetch():
                    await queue.put(entity)
                retry = 0
                await asyncio.sleep(self.poll_interval_s)
            except Exception as e:
                wait = min(2 ** retry, 300)
                logging.warning(f"[{self.domain}] Error: {e}. Retry in {wait}s")
                retry += 1
                await asyncio.sleep(wait)
```

## ADS-B Exchange Adapter (oobe/adapters/adsb.py)

```python
import aiohttp
from datetime import datetime, timezone
from .base import BaseAdapter, NormalizedEntity

ADSB_URL = "https://opendata.adsb.fi/api/v2/lat/0/lon/0/dist/6371"

class AdsbAdapter(BaseAdapter):
    domain = "aviation"
    poll_interval_s = 30

    async def fetch(self):
        async with aiohttp.ClientSession() as session:
            async with session.get(ADSB_URL, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                data = await resp.json()
                for ac in data.get("aircraft", []):
                    if not (ac.get("lat") and ac.get("lon")):
                        continue
                    yield NormalizedEntity(
                        domain="aviation",
                        domain_key=ac.get("hex", "").upper(),
                        lat=float(ac["lat"]),
                        lon=float(ac["lon"]),
                        observed_at=datetime.now(timezone.utc),
                        metadata={
                            "callsign": ac.get("flight", "").strip(),
                            "altitude_ft": ac.get("alt_baro"),
                            "speed_kt": ac.get("gs"),
                            "heading_deg": ac.get("track"),
                            "squawk": ac.get("squawk"),
                            "aircraft_type": ac.get("t"),
                            "registration": ac.get("r"),
                            "emergency": ac.get("emergency", "none"),
                        },
                        ttl_seconds=600,
                        source_url=ADSB_URL,
                    )
```

## AisHub WebSocket Adapter (oobe/adapters/aishub.py)

```python
import asyncio, websockets, json
from datetime import datetime, timezone
from .base import BaseAdapter, NormalizedEntity

AISHUB_URL = "wss://stream.aishub.net/ws"
NAV_STATUS = {
    0: "Under Way Using Engine", 1: "At Anchor", 2: "Not Under Command",
    3: "Restricted Manoeuverability", 5: "Moored", 8: "Sailing", 15: "Unknown"
}

class AisHubAdapter(BaseAdapter):
    domain = "maritime"
    poll_interval_s = 0  # WebSocket: continuous

    async def fetch(self):
        async with websockets.connect(AISHUB_URL, ping_interval=20) as ws:
            async for raw in ws:
                try:
                    msgs = json.loads(raw)
                    for msg in (msgs if isinstance(msgs, list) else [msgs]):
                        mmsi = str(msg.get("MMSI", ""))
                        if not mmsi or not msg.get("LATITUDE"):
                            continue
                        yield NormalizedEntity(
                            domain="maritime",
                            domain_key=mmsi,
                            lat=float(msg["LATITUDE"]) / 600000,
                            lon=float(msg["LONGITUDE"]) / 600000,
                            observed_at=datetime.now(timezone.utc),
                            metadata={
                                "vessel_name": msg.get("NAME", "").strip(),
                                "speed_kt": msg.get("SPEED", 0) / 10,
                                "heading_deg": msg.get("HEADING"),
                                "nav_status": NAV_STATUS.get(msg.get("NAVSTAT", 15)),
                                "destination": msg.get("DESTINATION", "").strip(),
                                "draught_m": msg.get("DRAUGHT", 0) / 10,
                            },
                            ttl_seconds=1800,
                            source_url=AISHUB_URL,
                        )
                except Exception:
                    continue
```

## ACLED Conflict Events Adapter (oobe/adapters/acled.py)

```python
import aiohttp
from datetime import datetime, timezone, timedelta
from .base import BaseAdapter, NormalizedEntity
import os

ACLED_URL = "https://api.acleddata.com/acled/read"

class AcledAdapter(BaseAdapter):
    domain = "conflict"
    poll_interval_s = 900  # 15 minutes

    async def fetch(self):
        params = {
            "key": os.environ["ACLED_API_KEY"],
            "email": os.environ["ACLED_EMAIL"],
            "event_date": (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"),
            "event_date_where": "BETWEEN",
            "event_date2": datetime.now().strftime("%Y-%m-%d"),
            "limit": 500,
            "fields": "event_id_cnty|event_date|event_type|sub_event_type|actor1|actor2|country|location|latitude|longitude|fatalities|source|notes",
        }
        async with aiohttp.ClientSession() as session:
            async with session.get(ACLED_URL, params=params, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                data = await resp.json()
                for ev in data.get("data", []):
                    if not ev.get("latitude"):
                        continue
                    yield NormalizedEntity(
                        domain="conflict",
                        domain_key=ev["event_id_cnty"],
                        lat=float(ev["latitude"]),
                        lon=float(ev["longitude"]),
                        observed_at=datetime.strptime(ev["event_date"], "%Y-%m-%d").replace(tzinfo=timezone.utc),
                        metadata={
                            "event_type": ev.get("event_type"),
                            "actor1": ev.get("actor1"),
                            "actor2": ev.get("actor2"),
                            "country": ev.get("country"),
                            "fatalities": ev.get("fatalities", 0),
                        },
                        ttl_seconds=86400,
                        source_url=ACLED_URL,
                    )
```

## Entity Resolution Engine (oobe/engine/entity_resolver.py)

```python
import hashlib
from .base import NormalizedEntity

# Resolution: aviation=ICAO24 hex, maritime=MMSI (9-digit),
# conflict=ACLED event_id_cnty, seismic=USGS event_id,
# fire=round(lat,3)+round(lon,3)+date

def resolve_entity_uuid(entity: NormalizedEntity) -> str:
    """Deterministic UUID from domain + domain_key. Idempotent."""
    seed = f"{entity.domain}:{entity.domain_key}".encode()
    return hashlib.sha256(seed).hexdigest()[:32]

def normalize_domain_key(entity: NormalizedEntity) -> str:
    key = entity.domain_key.strip().upper()
    if entity.domain == "aviation":
        return key.lstrip("0") or "000000"   # ICAO24 leading zeros
    if entity.domain == "maritime":
        return key.zfill(9)                   # MMSI always 9 digits
    return key
```

## TTL Decay Formula & Implementation

C(t) = max(0, 1 - (t - t_last_seen) / TTL_domain) where C(t) = confidence at current time, t_last_seen = Unix timestamp of most recent observation, TTL_domain = domain-specific threshold in seconds.

Domain TTL defaults: Aviation=600s | Maritime=1800s | Conflict=86400s | Seismic=43200s | Fire=10800s

```python
# oobe/engine/ttl_engine.py
import time, redis.asyncio as aioredis

async def compute_and_store_confidence(
    r: aioredis.Redis, entity_uuid: str,
    last_seen_ts: float, ttl_seconds: int,
) -> float:
    now = time.time()
    elapsed = now - last_seen_ts
    confidence = max(0.0, 1.0 - (elapsed / ttl_seconds))
    await r.setex(f"ttl:{entity_uuid}", ttl_seconds * 2, str(round(confidence, 4)))
    if confidence < 0.5:
        await r.publish("oobe:live",
            f'{{"type":"entity_degraded","uuid":"{entity_uuid}","confidence":{confidence}}}')
    if confidence == 0.0:
        await r.publish("oobe:live",
            f'{{"type":"entity_expired","uuid":"{entity_uuid}"}}')
    return confidence
```

## Pattern-of-Life Anomaly Detection (oobe/engine/pol_analyzer.py)

```python
from sklearn.ensemble import IsolationForest
import numpy as np

CONTAMINATION = 0.05
N_ESTIMATORS = 100
FEATURES = ["speed_delta","heading_delta","dist_from_centroid_km","hours_since_last_obs"]

def build_feature_vector(obs_history: list[dict]) -> np.ndarray:
    vectors = []
    for i in range(1, len(obs_history)):
        prev, curr = obs_history[i-1], obs_history[i]
        speed_delta = abs((curr.get("speed_kt", 0) or 0) - (prev.get("speed_kt", 0) or 0))
        hdg_delta = abs((curr.get("heading_deg", 0) or 0) - (prev.get("heading_deg", 0) or 0))
        if hdg_delta > 180:
            hdg_delta = 360 - hdg_delta
        dt_hours = (curr["ts"] - prev["ts"]).total_seconds() / 3600
        vectors.append([speed_delta, hdg_delta, 0.0, dt_hours])
    return np.array(vectors) if vectors else np.zeros((1, 4))

def train_model(domain: str, entity_type: str) -> IsolationForest:
    clf = IsolationForest(n_estimators=N_ESTIMATORS, contamination=CONTAMINATION, random_state=42)
    return clf

def score_observation(clf: IsolationForest, obs_vector: np.ndarray) -> float:
    """Returns score in [-1, 0]. Scores < -0.1 = anomalous."""
    return float(clf.score_samples(obs_vector.reshape(1, -1))[0])
```

---