# Phase 4 — Scale, Enterprise & Government Pathway

# OOBE Phase 4: Scale — Complete Engineering Specification (Months 7–18)

Picks up directly from Phase 3 acceptance criteria.

---

## Entry State: Month 7, Week 1

Phase 3 delivered a production SaaS that charges money and passes a security audit. Confirmed operational:

- AWS ECS Fargate (2–4 tasks, auto-scaling) ✅ — p99 <200ms
- RDS PostgreSQL 16 + PostGIS + TimescaleDB ✅ — Multi-AZ, 50GB
- ElastiCache Redis 7 ✅ | Neo4j AuraDB Pro ✅ | All 10 feed domains ✅
- Stripe billing (Free / Pro / Enterprise) ✅ | ATLAS threat overlay + PDF briefs ✅ (Pro-gated)
- Provenance Sentinel (C2PA + Hive + EXIF) ✅ | GraphQL API + oobe-python SDK on PyPI ✅
- 10 paying customers, ≥$2,000 MRR ✅ | OWASP ZAP: zero P0/P1 findings ✅ | PostHog ✅

Phase 4 covers 12 months across four quarters. Revenue target: $40,000 MRR by Month 18 (80 Pro + 8 Enterprise). Team: Grow from 2 to 4–6 people. Infra cost at scale: ~$1,500–$3,000/month at 100 customers.

---

## Phase 4 Quarterly Structure

- Q1 (Months 7–9) — Product Depth | MRR Target: $8,000 | Custom Feed Adapter SDK + second AIS source + PoL V2
- Q2 (Months 10–12) — Enterprise Pathway | MRR Target: $16,000 | On-premise bundle + SAM.gov + Enterprise SSO
- Q3 (Months 13–15) — Partnerships + Data | MRR Target: $28,000 | Bellingcat integration + Data Marketplace + Alert Correlation
- Q4 (Months 16–18) — Moat + Expansion | MRR Target: $40,000 | Multi-region + Compound Rules + Analyst Certification

---

# Q1 (Months 7-9): Product Depth

### Goals

- Deliver custom feed adapters (most-requested feature from Phase 2 pilot feedback)
- Fix cross-cue validator's maritime blind spot by adding VesselFinder as second AIS source
- Replace IsolationForest with ensemble anomaly detector (PoL V2)
- Ship compound alert rules (AND/OR logic across multiple conditions)
- Grow to 35 Pro customers + 1 Enterprise ($8,000 MRR)

---

## M7: Custom Feed Adapter SDK

Problem: Enterprise customers have proprietary data feeds (internal sensors, licensed maritime AIS, classified-adjacent open data) that they cannot get into OOBE. Every customer who cannot bring their own data is a churned Enterprise prospect.

Solution: A typed Python SDK that lets any developer write a feed adapter in <50 lines, test it locally against a mock entity processor, and deploy it to their OOBE Enterprise workspace via a single API call.

### Migration 0006 — custom_adapters table (oobe/db/migrations/versions/0006_custom_adapters.py)

```python
from alembic import op
import sqlalchemy as sa

def upgrade():
    op.create_table("custom_adapters",
        sa.Column("uuid",   sa.UUID, primary_key=True,
                  server_default=sa.text("uuid_generate_v4()")),
        sa.Column("org_id",  sa.UUID, nullable=False),
        sa.Column("name",    sa.String(128), nullable=False),
        sa.Column("domain",  sa.String(32),  nullable=False),
        sa.Column("description", sa.Text),
        # adapter_type: rest_poll|websocket|file_watch|webhook_push
        sa.Column("adapter_type", sa.String(32), nullable=False,
                  server_default="rest_poll"),
        sa.Column("config",  sa.JSONB, nullable=False, server_default="{}"),
        sa.Column("secrets_enc", sa.Text),  # AES-256 via AWS KMS
        sa.Column("poll_interval_s", sa.Integer, server_default="60"),
        sa.Column("ttl_seconds",     sa.Integer, server_default="3600"),
        sa.Column("schema_version",  sa.String(8), server_default="1.0"),
        sa.Column("enabled",         sa.Boolean, server_default="TRUE"),
        sa.Column("last_run_at",     sa.TIMESTAMP(timezone=True)),
        sa.Column("last_error",      sa.Text),
        sa.Column("entities_last_cycle",    sa.Integer,    server_default="0"),
        sa.Column("total_entities_ingested",sa.BigInteger, server_default="0"),
        sa.Column("created_at", sa.TIMESTAMP(timezone=True),
                  server_default=sa.text("NOW()")),
    )
    op.create_index("idx_adapters_org","custom_adapters",["org_id","enabled"])
```

```python
    op.create_table("adapter_run_log",
        sa.Column("uuid",sa.UUID,primary_key=True,
                  server_default=sa.text("uuid_generate_v4()")),
        sa.Column("adapter_uuid",  sa.UUID, nullable=False),
        sa.Column("started_at",    sa.TIMESTAMP(timezone=True),
                  server_default=sa.text("NOW()")),
        sa.Column("finished_at",   sa.TIMESTAMP(timezone=True)),
        sa.Column("status",        sa.String(16), server_default="running"),
        sa.Column("entities_ingested",sa.Integer, server_default="0"),
        sa.Column("error_message", sa.Text),
        sa.Column("duration_ms",   sa.Integer),
    )
    op.create_index("idx_adapter_run_log_adapter",
                    "adapter_run_log",["adapter_uuid","started_at"])
    op.create_table("compound_alert_rules",
        sa.Column("uuid",  sa.UUID, primary_key=True,
                  server_default=sa.text("uuid_generate_v4()")),
        sa.Column("org_id",sa.UUID, nullable=False),
        sa.Column("name",  sa.String(128), nullable=False),
        sa.Column("logic", sa.String(16),  nullable=False,server_default="AND"),
        sa.Column("conditions",sa.JSONB,nullable=False,server_default="[]"),
        sa.Column("severity",  sa.String(16),server_default="HIGH"),
        sa.Column("enabled",   sa.Boolean,  server_default="TRUE"),
        sa.Column("cooldown_minutes",sa.Integer,server_default="60"),
        sa.Column("last_fired_at",   sa.TIMESTAMP(timezone=True)),
        sa.Column("fire_count",sa.Integer,server_default="0"),
        sa.Column("webhook_url",sa.Text),
        sa.Column("created_at",sa.TIMESTAMP(timezone=True),
                  server_default=sa.text("NOW()")),
    )
    op.create_index("idx_compound_rules_org",
                    "compound_alert_rules",["org_id","enabled"])
def downgrade():
    op.drop_table("compound_alert_rules")
    op.drop_table("adapter_run_log")
    op.drop_table("custom_adapters")
```

### SDK Base Class — oobe_adapter_sdk/base.py (Part 1: OobeEntity + OobeAdapter)

```python
# sdk/oobe_adapter_sdk/base.py
# Install: pip install oobe-adapter-sdk
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import AsyncGenerator, Optional
from datetime import datetime, timezone

VALID_DOMAINS = {
    "aviation","maritime","conflict","seismic","fire",
    "disaster","weather","space_weather","air_quality",
    "aviation_wx","cyber","custom",
}

@dataclass
class OobeEntity:
    """
    Normalized entity output from a custom adapter.
    Required: domain_key, lat, lon.
    """
    domain_key:   str
    lat:          float
    lon:          float
    display_name: Optional[str]     = None
    observed_at:  Optional[datetime]= None  # Defaults to now()
    ttl_seconds:  Optional[int]     = None
    metadata:     dict              = field(default_factory=dict)

    def __post_init__(self):
        if not (-90 <= self.lat <= 90):
            raise ValueError(f"lat {self.lat} out of range [-90, 90]")
        if not (-180 <= self.lon <= 180):
            raise ValueError(f"lon {self.lon} out of range [-180, 180]")
        if not self.domain_key or not self.domain_key.strip():
            raise ValueError("domain_key must be non-empty")
        if self.observed_at is None:
            self.observed_at = datetime.now(timezone.utc)
```

```python
class OobeAdapter(ABC):
    """
    Base class for all custom OOBE feed adapters.
    Subclass this, implement fetch(), register via POST /v1/adapters.
    """
    domain:          str
    adapter_type:    str = "rest_poll"  # rest_poll|websocket|webhook_push
    poll_interval_s: int = 60
    ttl_seconds:     int = 3600
    schema_version:  str = "1.0"

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if not hasattr(cls,"domain") or cls.domain not in VALID_DOMAINS:
            raise TypeError(
                f"{cls.__name__}.domain must be one of: {sorted(VALID_DOMAINS)}"
            )

    @abstractmethod
    async def fetch(
        self, config: dict, secrets: dict,
    ) -> AsyncGenerator[OobeEntity, None]:
        """
        Yield OobeEntity objects.
        config:  non-sensitive configuration (URLs, parameters)
        secrets: sensitive values (API keys, passwords) -- never stored in code
        """

    async def validate_config(self, config: dict, secrets: dict) -> list[str]:
        """Optional validation. Returns list of error strings."""
        return []

    def to_registration_payload(self, config: dict) -> dict:
        """Produces the JSON payload for POST /v1/adapters."""
        return {
            "name":            self.__class__.__name__,
            "domain":          self.domain,
            "adapter_type":    self.adapter_type,
            "poll_interval_s": self.poll_interval_s,
            "ttl_seconds":     self.ttl_seconds,
            "schema_version":  self.schema_version,
            "config":          config,
        }
```

### SDK — AdapterTestHarness (local dev testing)

```python
class AdapterTestHarness:
    """
    Runs an adapter locally against mock infrastructure.
    Usage:
        harness = AdapterTestHarness(MyAdapter(), config={...}, secrets={...})
        results = await harness.run(max_entities=50, timeout_s=30)
        harness.print_report(results)
    """
    def __init__(self, adapter: OobeAdapter, config: dict, secrets: dict):
        self.adapter = adapter
        self.config  = config
        self.secrets = secrets

    async def run(self, max_entities: int=100, timeout_s: int=30) -> dict:
        import asyncio, time
        entities, errors = [], []
        start = time.time()
        try:
            async with asyncio.timeout(timeout_s):
                async for entity in self.adapter.fetch(self.config, self.secrets):
                    try:
                        _validate_entity(entity)
                        entities.append(entity)
                    except ValueError as e:
                        errors.append(str(e))
                    if len(entities) >= max_entities:
                        break
        except asyncio.TimeoutError:
            errors.append(f"Fetch timed out after {timeout_s}s")
        except Exception as e:
            errors.append(f"Fetch exception: {type(e).__name__}: {e}")
        return {
            "entities_yielded": len(entities),
            "validation_errors": errors,
            "duration_s": round(time.time()-start, 2),
            "passed": len(errors)==0 and len(entities)>0,
            "entities": [{"domain_key":e.domain_key,"lat":e.lat,
                          "lon":e.lon,"metadata_keys":list(e.metadata.keys())}
                         for e in entities[:10]],
        }

def _validate_entity(e: OobeEntity):
    if not isinstance(e, OobeEntity):
        raise ValueError(f"fetch() must yield OobeEntity, got {type(e)}")
    if not e.domain_key.strip():
        raise ValueError("domain_key is empty")
```

### Custom Adapter Executor — oobe/engine/custom_adapter_executor.py (Part 1)

```python
# oobe/engine/custom_adapter_executor.py
import asyncio, logging, time, json
from datetime import datetime, timezone
import boto3
from cryptography.fernet import Fernet
from sqlalchemy import text
from ..db import get_sync_db_session
from ..engine.entity_processor import process_entity_sync
from ..adapters.base import NormalizedEntity

logger  = logging.getLogger(__name__)
kms     = boto3.client("kms", region_name="eu-west-1")
KMS_KEY = "arn:aws:kms:eu-west-1:ACCOUNT:key/KEY_ID"  # set via env

def decrypt_secrets(encrypted_b64: str) -> dict:
    import base64
    if not encrypted_b64:
        return {}
    try:
        payload = json.loads(base64.b64decode(encrypted_b64))
        data_key_enc = base64.b64decode(payload["key"])
        ciphertext   = payload["data"].encode()
        plaintext_key = kms.decrypt(
            CiphertextBlob=data_key_enc, KeyId=KMS_KEY,
        )["Plaintext"]
        fernet = Fernet(base64.urlsafe_b64encode(plaintext_key[:32]))
        return json.loads(fernet.decrypt(ciphertext).decode())
    except Exception as e:
        logger.error(f"Secret decryption failed: {e}")
        return {}

def encrypt_secrets(secrets: dict) -> str:
    import base64
    response = kms.generate_data_key(KeyId=KMS_KEY, KeySpec="AES_256")
    plaintext_key = response["Plaintext"]
    encrypted_key = response["CiphertextBlob"]
    fernet = Fernet(base64.urlsafe_b64encode(plaintext_key[:32]))
    ciphertext = fernet.encrypt(json.dumps(secrets).encode())
    payload = {
        "key":  base64.b64encode(encrypted_key).decode(),
        "data": ciphertext.decode(),
    }
    return base64.b64encode(json.dumps(payload).encode()).decode()
```

### Executor — execute_custom_adapter() (Part 2)

```python
    start, count, error = time.time(), 0, None
    try:
        cls_path = config.get("_adapter_class","")
        if not cls_path: raise ValueError("No _adapter_class in config")
        mod_path, cls_name = cls_path.rsplit(".",1)
        import importlib
        adapter = getattr(importlib.import_module(mod_path), cls_name)()
        async with asyncio.timeout(300):
            async for e in adapter.fetch(config, secrets):
                process_entity_sync(NormalizedEntity(
                    domain=adapter.domain, domain_key=e.domain_key,
                    lat=e.lat, lon=e.lon,
                    observed_at=e.observed_at or datetime.now(timezone.utc),
                    metadata={**e.metadata,"_adapter":adapter_uuid},
                    ttl_seconds=e.ttl_seconds or adapter.ttl_seconds,
                ), org_id=org_id)
                count += 1
        status = "success"
    except asyncio.TimeoutError:
        error,status = "Timed out after 300s","timeout"
    except Exception as ex:
        error,status = f"{type(ex).__name__}: {ex}","error"
    duration_ms = int((time.time()-start)*1000)
    with get_sync_db_session() as db:
        db.execute(text("""
            UPDATE adapter_run_log
            SET status=:s,finished_at=NOW(),
                entities_ingested=:c,error_message=:e,duration_ms=:d
            WHERE uuid=:run
        """), {"s":status,"c":count,"e":error,
               "d":duration_ms,"run":run_uuid})
        db.execute(text("""
            UPDATE custom_adapters
            SET last_run_at=NOW(),last_error=:e,entities_last_cycle=:c,
                total_entities_ingested=total_entities_ingested+:c
            WHERE uuid=:uuid
        """), {"e":error,"c":count,"uuid":adapter_uuid})
        db.commit()
```

---

## M7: VesselFinder — Second AIS Source (oobe/adapters/vesselfinder.py)

Completes the cross-cue validator for maritime: vessels require confirmation from both AisHub AND VesselFinder before reaching full confidence. Cross-cue logic: if a vessel MMSI appears in both sources within a 30-min window, its status is promoted to CONFIRMED and confidence cap lifts to 1.0.

```python
# oobe/adapters/vesselfinder.py
# API: https://api.vesselfinder.com/docs
import aiohttp, os
from datetime import datetime, timezone
from .base import BaseAdapter, NormalizedEntity

VF_URL = "https://api.vesselfinder.com/vessels"

class VesselFinderAdapter(BaseAdapter):
    domain="maritime"; adapter_name="vesselfinder"; poll_interval_s=120
    def __init__(self):
        self.api_key = os.environ["VESSELFINDER_API_KEY"]
    async def fetch(self):
        params = {"userkey":self.api_key,"format":"json","limit":1000}
        async with aiohttp.ClientSession() as s:
            async with s.get(VF_URL,params=params,
                timeout=aiohttp.ClientTimeout(total=20)) as r:
                if r.status != 200: return
                data = await r.json()
        for v in (data if isinstance(data,list) else data.get("vessels",[])):
            mmsi=str(v.get("AIS",{}).get("MMSI") or v.get("MMSI","")).strip()
            lat =v.get("AIS",{}).get("LATITUDE")  or v.get("LAT")
            lon =v.get("AIS",{}).get("LONGITUDE") or v.get("LON")
            if not mmsi or lat is None or lon is None: continue
            ais = v.get("AIS",v)
            yield NormalizedEntity(
                domain="maritime",domain_key=mmsi.zfill(9),
                lat=float(lat),lon=float(lon),
                observed_at=datetime.now(timezone.utc),
                metadata={
                    "vessel_name":ais.get("NAME","").strip(),
                    "callsign":   ais.get("CALLSIGN","").strip(),
                    "vessel_type":ais.get("TYPE"),
                    "speed_kt":   ais.get("SPEED",0),
                    "heading_deg":ais.get("HEADING"),
                    "course_deg": ais.get("COURSE"),
                    "nav_status": ais.get("NAVSTAT"),
                    "destination":ais.get("DESTINATION","").strip(),
                    "_source":    "vesselfinder",
                },
                ttl_seconds=1800,source_url=VF_URL)
```

```python
# Update in oobe/engine/cross_cue.py
CROSS_CUE_SOURCES: dict[str, list[str]] = {
    "aviation":  ["adsb_exchange", "opensky"],
    "maritime":  ["aishub", "vesselfinder"],   # Now complete
    "conflict":  [],
}
```

---

## M8: Pattern-of-Life V2 — Ensemble Anomaly Detector (oobe/engine/pol_v2.py)

Ensemble: (1) IsolationForest weight 0.40; (2) Local Outlier Factor weight 0.35; (3) Temporal Rhythm Score weight 0.25. Score range [-1, 0]; below -0.15 = anomalous. V2 adds entity-specific models for entities with >500 observations in 14 days, eliminating false positives for entities with unique but consistent behaviour.

```python
# oobe/engine/pol_v2.py
import numpy as np, logging
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.preprocessing import RobustScaler
from sklearn.pipeline import Pipeline

IF_WEIGHT=0.40; LOF_WEIGHT=0.35; TR_WEIGHT=0.25
ENTITY_MODEL_THRESHOLD=500; LOF_N_NEIGHBORS=20; CONTAMINATION=0.05

def build_ensemble_pipeline() -> dict:
    return {
        "if_pipe": Pipeline([
            ("scaler",  RobustScaler()),
            ("iforest", IsolationForest(
                n_estimators=150, contamination=CONTAMINATION,
                max_samples="auto", random_state=42, n_jobs=-1,
            ))
        ]),
        "lof": LocalOutlierFactor(
            n_neighbors=LOF_N_NEIGHBORS, contamination=CONTAMINATION,
            novelty=True, n_jobs=-1,
        ),
    }

def fit_ensemble(X: np.ndarray, models: dict) -> dict:
    models["if_pipe"].fit(X)
    models["lof"].fit(X)
    return models

def score_observation(
    models:dict, x_new:np.ndarray,
    hourly_baseline:dict, current_hour:int, current_dow:int,
) -> float:
    x = x_new.reshape(1,-1)
    if_score  = float(models["if_pipe"].score_samples(x)[0])
    try:
        lof_score = float(models["lof"].score_samples(x)[0])
    except Exception:
        lof_score = if_score
    tr_score = _temporal_rhythm_score(
        hourly_baseline, current_hour, current_dow, x_new)
    return float(if_score*IF_WEIGHT+lof_score*LOF_WEIGHT+tr_score*TR_WEIGHT)
```

```python
def _temporal_rhythm_score(
    baseline:dict, hour:int, dow:int, x_new:np.ndarray
) -> float:
    """
    Compare current observation to entity's typical behaviour
    at this exact hour-of-week (key: dow*24+hour, range 0-167).
    Returns 0.0 if no baseline data.
    """
    if not baseline: return 0.0
    typical = baseline.get(str(dow*24+hour))
    if typical is None: return 0.0
    current_speed = float(x_new[0]) if x_new.ndim==1 else float(x_new[0,0])
    if typical == 0: return 0.0
    ratio = abs(current_speed-typical) / max(typical, 0.1)
    # ratio=0 -> 0.0, ratio>=4 -> -1.0
    return max(-1.0, -ratio/4.0)
```

---

## M9: Compound Alert Rules (oobe/engine/compound_alert_engine.py)

Compound rules combine multiple simple triggers into higher-confidence signals using AND/OR/SEQUENCE logic. The engine runs every 5 minutes via Celery beat. Example: "Vessel goes dark AND an aircraft starts loitering nearby within 30 minutes" -> CRITICAL alert. Each rule has a configurable cooldown_minutes to prevent alert storms.

```python
# compound_alert_engine.py -- evaluate_compound_rules + _evaluate_rule
def evaluate_compound_rules(org_id: str):
    with get_sync_db_session() as db:
        rules = db.execute(text("""
            SELECT uuid,name,logic,conditions,cooldown_minutes,
                   severity,last_fired_at,webhook_url
            FROM compound_alert_rules WHERE org_id=:org AND enabled=TRUE
        """), {"org":org_id}).fetchall()
    for rule in rules:
        try: _evaluate_rule(rule, org_id)
        except Exception as e: logger.error(f"Rule {rule.uuid}: {e}")

def _evaluate_rule(rule, org_id:str):
    if rule.last_fired_at:
        if datetime.now(timezone.utc) < \
           rule.last_fired_at+timedelta(minutes=rule.cooldown_minutes): return
    conditions=rule.conditions if isinstance(rule.conditions,list) else []
    if   rule.logic=="AND":      fired=_evaluate_and(conditions,org_id)
    elif rule.logic=="OR":       fired=_evaluate_or(conditions,org_id)
    elif rule.logic=="SEQUENCE": fired=_evaluate_sequence(conditions,org_id)
    else: return
    if not fired: return
    with get_sync_db_session() as db:
        db.execute(text("""
            INSERT INTO alerts(org_id,alert_type,severity,title,description,
                metadata,created_at)
            VALUES(:org,'COMPOUND',:sev,:t,:d,:m::jsonb,NOW())
        """),{"org":org_id,"sev":rule.severity,
              "t":f"[COMPOUND] {rule.name}",
              "d":f"Rule '{rule.name}' ({rule.logic}) triggered.",
              "m":'{}'})
        db.execute(text("""
            UPDATE compound_alert_rules
            SET last_fired_at=NOW(),fire_count=fire_count+1 WHERE uuid=:u
        """),{"u":str(rule.uuid)})
        db.commit()
    if rule.webhook_url:
        from ..services.webhook_service import dispatch_alert_webhook
        dispatch_alert_webhook(str(rule.uuid),org_id,rule.webhook_url,{})
```

```python
# compound_alert_engine.py -- AND/OR/SEQUENCE evaluators
def _evaluate_and(conditions:list, org_id:str) -> bool:
    return all(_condition_has_match(c,org_id) for c in conditions)

def _evaluate_or(conditions:list, org_id:str) -> bool:
    return any(_condition_has_match(c,org_id) for c in conditions)

def _evaluate_sequence(conditions:list, org_id:str) -> bool:
    """Conditions must fire IN ORDER, each within its own window."""
    last = None
    for cond in conditions:
        t = _get_first_match_time(cond, org_id, after=last)
        if t is None: return False
        last = t
    return True

def _condition_has_match(cond:dict, org_id:str) -> bool:
    return _get_first_match_time(cond, org_id) is not None

def _get_first_match_time(
    cond:dict, org_id:str, after:datetime|None=None
) -> datetime|None:
    since = max(
        datetime.now(timezone.utc)-timedelta(minutes=cond.get("within_minutes",60)),
        after or datetime.min.replace(tzinfo=timezone.utc),
    )
    q = ("SELECT created_at FROM alerts WHERE org_id=:org"
         " AND alert_type=:atype AND created_at>=:since")
    p:dict={"org":org_id,"atype":cond.get("alert_type",""),"since":since}
    if "domain" in cond:
        q+=" AND metadata->>'domain'=:domain"; p["domain"]=cond["domain"]
    if "anomaly_subtype" in cond:
        q+=" AND metadata->>'anomaly_subtype'=:sub"
        p["sub"]=cond["anomaly_subtype"]
    q+=" ORDER BY created_at ASC LIMIT 1"
    with get_sync_db_session() as db:
        row = db.execute(text(q),p).fetchone()
    return row.created_at if row else None
```

---

# Q2 (Months 10-12): Enterprise Pathway

### Goals

- Ship on-premise deployment for air-gapped / government networks
- Register on SAM.gov with CAGE code (prerequisite for US government contracts)
- Enterprise SSO: SAML 2.0 and OIDC for large-org authentication
- Alert correlation engine: group related alerts into incidents
- Grow to 55 Pro + 3 Enterprise ($16,000 MRR) | First Enterprise sale

---

## M10: On-Premise Deployment Bundle (deploy/on-premise/docker-compose.airgap.yml)

Prerequisites: Docker 25+, 16GB RAM, 200GB disk. All images must be pre-pulled and saved as tarballs before air-gap transfer. Includes: PostgreSQL, Redis, Neo4j, API, Celery, frontend, air-gapped tile server, Prometheus, and Grafana -- no external network access required after initial pull.

```yaml
version: "3.9"
x-common-env: &common-env
  DATABASE_URL: "postgresql://oobe:${POSTGRES_PASSWORD}@postgres:5432/oobe"
  REDIS_URL:    "redis://redis:6379/0"
  NEO4J_URL:    "bolt://neo4j:7687"
  ENVIRONMENT:  "on-premise"
  LICENSE_KEY:  "${OOBE_LICENSE_KEY}"
  BILLING_MODE: "license"
  AUTH_MODE:    "local"  # or saml / oidc
  POL_MODEL_DIR: "/app/pol_models"
  SENTRY_DSN:   ""

services:
  postgres:
    image: oobe-postgis:16-3.4
    environment:
      POSTGRES_DB: oobe
      POSTGRES_USER: oobe
      POSTGRES_PASSWORD: "${POSTGRES_PASSWORD}"
    volumes: [pgdata:/var/lib/postgresql/data, ./init:/docker-entrypoint-initdb.d]
    restart: unless-stopped
  redis:
    image: oobe-redis:7.2-alpine
    command: redis-server --maxmemory 512mb --maxmemory-policy allkeys-lru
    volumes: [redisdata:/data]
    restart: unless-stopped
  neo4j:
    image: oobe-neo4j:5.18-community
    environment:
      NEO4J_AUTH: "neo4j/${NEO4J_PASSWORD}"
      NEO4J_PLUGINS: '["apoc"]'
      NEO4J_dbms_memory_heap_max__size: "1G"
    volumes: [neo4jdata:/data]
    restart: unless-stopped
```

```yaml
  api:
    image: oobe-api:${OOBE_VERSION}
    environment: { <<: *common-env }
    volumes: [pol_models:/app/pol_models, "./certs:/app/certs:ro"]
    ports: ["8000:8000"]
    depends_on: [postgres, redis, neo4j]
    restart: unless-stopped
  celery-worker:
    image: oobe-api:${OOBE_VERSION}
    command: celery -A oobe.tasks worker --loglevel=info --concurrency=4
    environment: { <<: *common-env }
    volumes: [pol_models:/app/pol_models]
    restart: unless-stopped
  celery-beat:
    image: oobe-api:${OOBE_VERSION}
    command: celery -A oobe.tasks beat --loglevel=info
    environment: { <<: *common-env }
    restart: unless-stopped
  frontend:
    image: oobe-frontend:${OOBE_VERSION}
    ports: ["80:80","443:443"]
    volumes: ["./certs:/etc/nginx/certs:ro","./nginx.conf:/etc/nginx/conf.d/default.conf:ro"]
    depends_on: [api]
    restart: unless-stopped
  tileserver:
    image: oobe-tileserver:latest  # maptiler/tileserver-gl
    volumes: ["./tiles:/data"]  # operator pre-loads .mbtiles files
    ports: ["8080:8080"]
    restart: unless-stopped
  prometheus:
    image: oobe-prometheus:v2.55.0
    volumes: ["./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml",promdata:/prometheus]
    restart: unless-stopped
  grafana:
    image: oobe-grafana:11.4.0
    environment:
      GF_SECURITY_ADMIN_PASSWORD: "${GRAFANA_PASSWORD}"
      GF_AUTH_ANONYMOUS_ENABLED: "false"
    volumes: [grafanadata:/var/lib/grafana,"./monitoring/grafana:/etc/grafana/provisioning"]
    ports: ["3000:3000"]
    restart: unless-stopped
volumes:
  pgdata: redisdata: neo4jdata: pol_models: promdata: grafanadata:
```

## M10: License Validation (oobe/services/license_service.py)

Offline-capable JWT license validation using OOBE's RSA public key. Signed with OOBE's private key, validated locally -- no external call required. Renewed annually. Warns at <30 days remaining, raises LicenseError if expired.

```python
# oobe/services/license_service.py
import os, logging
from datetime import datetime, timezone
from jose import jwt, JWTError

logger = logging.getLogger(__name__)
OOBE_LICENSE_PUBLIC_KEY = os.environ.get("OOBE_LICENSE_PUBLIC_KEY","""
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA...
-----END PUBLIC KEY-----
""")

def validate_license(license_key: str) -> dict:
    """Returns claims dict or raises LicenseError."""
    try:
        claims = jwt.decode(
            license_key, OOBE_LICENSE_PUBLIC_KEY,
            algorithms=["RS256"], options={"verify_exp": True},
        )
    except JWTError as e:
        raise LicenseError(f"Invalid license: {e}")
    expiry = datetime.fromtimestamp(claims["exp"], tz=timezone.utc)
    days   = (expiry - datetime.now(timezone.utc)).days
    if days < 0:  raise LicenseError(f"License expired {abs(days)} days ago")
    if days < 30: logger.warning(f"License expires in {days} days. Renew via sales@oobe.io")
    return {
        "org_name":       claims.get("org"),
        "plan":           claims.get("plan","enterprise"),
        "max_users":      claims.get("max_users",10),
        "max_entities":   claims.get("max_entities",10000),
        "valid_until":    expiry.isoformat(),
        "days_remaining": days,
        "domains":        claims.get("domains",[]),
        "features":       claims.get("features",[]),
    }

class LicenseError(Exception): pass
```

## M10: Enterprise SSO — SAML 2.0 + OIDC (oobe/services/sso_service.py)

SAML 2.0 for governments and large enterprises (uses python3-saml). OIDC for Microsoft Entra ID, Okta, Google Workspace (uses authlib). SSO config stored per-org in organizations.sso_config JSONB column. Phase 4 scope: configuration API + SP metadata endpoint + assertion handler.

```python
# oobe/services/sso_service.py
def get_saml_settings(org_sso_config: dict) -> dict:
    entity_id = f"https://app.oobe.io/sso/saml/{org_sso_config['org_id']}"
    acs_url   = f"{entity_id}/acs"
    return {
        "strict": True,
        "sp": {
            "entityId": entity_id,
            "assertionConsumerService": {
                "url":     acs_url,
                "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST",
            },
            "NameIDFormat": "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress",
            "x509cert":  org_sso_config.get("sp_cert",""),
            "privateKey": org_sso_config.get("sp_private_key",""),
        },
        "idp": {
            "entityId": org_sso_config["idp_entity_id"],
            "singleSignOnService": {
                "url":     org_sso_config["idp_sso_url"],
                "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect",
            },
            "x509cert": org_sso_config["idp_cert"],
        },
        "security": {
            "authnRequestsSigned": True,
            "wantMessagesSigned":  True,
            "wantAssertionsSigned":True,
            "wantNameId":         True,
            "requestedAuthnContext": False,
        },
    }
```

```python
def extract_saml_user(saml_auth, attribute_mapping: dict) -> dict:
    """
    Maps IdP attributes -> OOBE user fields.
    attribute_mapping: {"email": "http://schemas.xmlsoap.org/...", ...}
    """
    attrs = saml_auth.get_attributes()
    def _get(key):
        mapped = attribute_mapping.get(key)
        vals   = attrs.get(mapped, [])
        return vals[0] if vals else None
    return {
        "email":      saml_auth.get_nameid() or _get("email"),
        "first_name": _get("first_name") or "",
        "last_name":  _get("last_name")  or "",
        "role":       _get("role")       or "analyst",
    }
```

### SSO Migration 0007 — organizations + incidents + org_members tables

```python
# 0007_enterprise_sso.py
from alembic import op; import sqlalchemy as sa
def upgrade():
    op.add_column("organizations",sa.Column("sso_config",sa.JSONB,server_default="{}"))
    op.add_column("organizations",sa.Column("sso_type",sa.String(8),server_default="none"))
    op.add_column("organizations",sa.Column("enforce_sso",sa.Boolean,server_default="FALSE"))
    op.create_table("incidents",
        sa.Column("uuid",sa.UUID,primary_key=True,server_default=sa.text("uuid_generate_v4()")),
        sa.Column("org_id",sa.UUID,nullable=False),
        sa.Column("title",sa.Text,nullable=False),
        sa.Column("severity",sa.String(16),server_default="MEDIUM"),
        sa.Column("status",sa.String(16),server_default="open"),
        sa.Column("alert_uuids",sa.ARRAY(sa.UUID),server_default="{}"),
        sa.Column("entity_uuids",sa.ARRAY(sa.CHAR(32)),server_default="{}"),
        sa.Column("summary",sa.Text),
        sa.Column("atlas_techniques",sa.ARRAY(sa.Text),server_default="{}"),
        sa.Column("assigned_to",sa.UUID),
        sa.Column("resolved_at",sa.TIMESTAMP(timezone=True)),
        sa.Column("created_at",sa.TIMESTAMP(timezone=True),server_default=sa.text("NOW()")),
        sa.Column("updated_at",sa.TIMESTAMP(timezone=True),server_default=sa.text("NOW()")),
    )
    op.create_index("idx_incidents_org","incidents",["org_id","status"])
    op.create_table("org_members",
        sa.Column("id",sa.UUID,primary_key=True,server_default=sa.text("uuid_generate_v4()")),
        sa.Column("org_id",sa.UUID,nullable=False),
        sa.Column("user_id",sa.UUID,nullable=False),
        sa.Column("role",sa.String(32),server_default="analyst"),
        sa.UniqueConstraint("org_id","user_id",name="uq_org_member"),
    )
```

## M11: Alert Correlation Engine (oobe/engine/incident_correlator.py)

Groups alerts using Union-Find across 3 strategies: SPATIAL (200km, 2h window), ENTITY (shared UUID), ATLAS (same technique). Runs every 10 min via Celery beat.

```python
SPATIAL_RADIUS_KM=200; TEMPORAL_WINDOW_H=2; MIN_ALERTS=2

def run_correlation(org_id:str):
    since=datetime.now(timezone.utc)-timedelta(hours=TEMPORAL_WINDOW_H)
    with get_sync_db_session() as db:
        rows=db.execute(text("""
            SELECT a.uuid,a.alert_type,a.severity,a.entity_uuids,
                   a.atlas_technique,a.created_at,
                   e.current_lat AS lat,e.current_lon AS lon
            FROM alerts a
            LEFT JOIN LATERAL(
                SELECT current_lat,current_lon FROM entities
                WHERE uuid=ANY(a.entity_uuids) LIMIT 1) e ON TRUE
            WHERE a.org_id=:org AND a.created_at>=:since
              AND NOT EXISTS(SELECT 1 FROM incidents i
                             WHERE a.uuid=ANY(i.alert_uuids))
            ORDER BY a.created_at
        """),{"org":org_id,"since":since}).fetchall()
    if len(rows)<MIN_ALERTS: return
    for group in _correlate(rows):
        if len(group)>=MIN_ALERTS: _create_incident(org_id,group)

def _correlate(alerts:list)->list:
    n=len(alerts); p=list(range(n))
    def find(i):
        while p[i]!=i: p[i]=p[p[i]]; i=p[i]; return i
    for i in range(n):
        for j in range(i+1,n):
            if _related(alerts[i],alerts[j]): p[find(i)]=find(j)
    g:dict[int,list]={}
    for i,a in enumerate(alerts):
        r=find(i); g.setdefault(r,[]).append(a)
    return list(g.values())

def _related(a,b)->bool:
    if set(a.entity_uuids or[])&set(b.entity_uuids or[]): return True
    if a.atlas_technique and a.atlas_technique==b.atlas_technique: return True
    if a.lat and b.lat:
        import math; p=math.pi/180; R=6371
        x=(0.5-math.cos((b.lat-a.lat)*p)/2
           +math.cos(a.lat*p)*math.cos(b.lat*p)*(1-math.cos((b.lon-a.lon)*p))/2)
        if R*2*math.asin(math.sqrt(x))<=SPATIAL_RADIUS_KM: return True
    return False
```

```python
def _create_incident(org_id:str,group:list):
    alerts=[str(a.uuid) for a in group]
    entities=list({u for a in group for u in (a.entity_uuids or[])})
    atlas=list({a.atlas_technique for a in group if a.atlas_technique})
    sev=max([a.severity for a in group],
            key=lambda s:{"LOW":0,"MEDIUM":1,"HIGH":2,"CRITICAL":3}.get(s,0))
    title=(f"Multi-signal ATLAS: {', '.join(atlas[:2])}" if atlas
           else f"Correlated {group[0].alert_type} cluster ({len(alerts)} alerts)")
    with get_sync_db_session() as db:
        db.execute(text("""
            INSERT INTO incidents(
                org_id,title,severity,status,alert_uuids,
                entity_uuids,atlas_techniques,created_at,updated_at)
            VALUES(:org,:t,:s,'open',:al,:en,:at,NOW(),NOW())
        """),{"org":org_id,"t":title,"s":sev,
              "al":alerts,"en":entities,"at":atlas})
        db.commit()
```

---

## M12: SAM.gov Registration Guide (docs/government/SAM_GOV_REGISTRATION.md)

Business process track (~40 hours admin work). Steps: (1) UEI via sam.gov [3-5 days]; (2) CAGE code [auto-assigned]; (3) SAM.gov registration with NAICS 541512/541519/541511/518210 and PSC D307/D310; (4) Tradewinds Solutions Marketplace listing; (5) GSA MAS Schedule with SIN 518210C; (6) FedRAMP Tailored Authorization ($50K-$150K, 3PAO assessment).

Procurement vehicle priority: (1) Tradewinds (45-day median, $100K-$2M); (2) DIU OTA ($1M-$5M); (3) SBIR Phase I/II ($150K-$1.5M R&D); (4) GSA MAS Schedule; (5) IDIQ vehicles (SEAPORT NxG, CIO-SP4) via prime sub-contracting. Size standard: Small Business if annual revenue <$34M.

---

# Q3 (Months 13-15): Partnerships + Data Marketplace

### Goals

- Bellingcat + ACLED partnership agreements; data access + co-branding
- OOBE Intelligence Digest: weekly email newsletter as B2B acquisition channel
- Data Marketplace: Pro/Enterprise share verified intelligence layers
- Grow to 65 Pro + 5 Enterprise ($28,000 MRR)

---

## M13: Bellingcat Open Data Integration (oobe/adapters/bellingcat.py)

Three sources: (1) Ukraine Equipment Losses from public Russia-Ukraine GitHub CSV [public, hourly]; (2) OSM Tracker for conflict infrastructure changes [public]; (3) Flight Radar Archive [partnership-gated, requires BELLINGCAT_PARTNER_KEY]. Losses entities are placed at Ukraine centroid (49.0, 31.5) with domain=conflict.

```python
# oobe/adapters/bellingcat.py
import aiohttp, os, logging
from datetime import datetime, timezone
import pandas as pd
from io import StringIO
from .base import BaseAdapter, NormalizedEntity

UKRAINE_LOSSES_URL = (
    "https://raw.githubusercontent.com/leedrake5/Russia-Ukraine/"
    "main/data/current/russia_losses_personnel.csv"
)

class BellingcatUkraineLossesAdapter(BaseAdapter):
    """Daily equipment loss figures from public Russia-Ukraine repo."""
    domain="conflict"; adapter_name="bellingcat_ukraine"; poll_interval_s=3600

    async def fetch(self):
        async with aiohttp.ClientSession() as s:
            async with s.get(UKRAINE_LOSSES_URL,
                timeout=aiohttp.ClientTimeout(total=15)) as r:
                if r.status!=200: return
                raw_csv = await r.text()
        df = pd.read_csv(StringIO(raw_csv))
        if df.empty or "date" not in df.columns: return
        df["date"]=pd.to_datetime(df["date"],errors="coerce")
        df=df.dropna(subset=["date"]).sort_values("date",ascending=False)
        latest=df.iloc[0]
        ts=latest["date"].to_pydatetime().replace(tzinfo=timezone.utc)
        yield NormalizedEntity(
            domain="conflict",
            domain_key=f"ukraine_losses_{latest['date'].strftime('%Y%m%d')}",
            lat=49.0,lon=31.5,  # Ukraine centroid
            observed_at=ts,
            metadata={
                "source":      "bellingcat_ukraine_losses",
                "date":        str(latest.get("date","")),
                "personnel":   int(latest.get("personnel",0) or 0),
                "tanks":       int(latest.get("tanks",0) or 0),
                "aircraft":    int(latest.get("aircraft",0) or 0),
                "helicopters": int(latest.get("helicopters",0) or 0),
                "data_type":   "equipment_losses",
            },
            ttl_seconds=86400,source_url=UKRAINE_LOSSES_URL,
        )
```

## M14: Intelligence Digest Service (oobe/services/digest_service.py)

Weekly newsletter generated every Monday 06:00 UTC via Celery beat + AWS SES. Content: top anomalies, active conflict zones, ATLAS technique frequency, new feature announcements. Primary B2B acquisition channel -- archived at oobe.io/digest for SEO. Subscribers in digest_subscribers table.

```python
def generate_and_send_digest():
    data=_collect_digest_data()
    if not data: return
    subs=_get_subscribers()
    html=_render_html(data); txt=_render_text(data)
    for i in range(0,len(subs),50):
        _send_batch(subs[i:i+50],data["issue_number"],html,txt)

def _collect_digest_data()->dict|None:
    since=datetime.now(timezone.utc)-timedelta(days=7)
    with get_sync_db_session() as db:
        anomalies=db.execute(text("""
            SELECT domain,anomaly_score,current_lat,current_lon
            FROM entities WHERE anomaly_score<-0.2 AND last_seen>=:s
            ORDER BY anomaly_score ASC LIMIT 5"""),{"s":since}).fetchall()
        hotspots=db.execute(text("""
            SELECT current_lat,current_lon,COUNT(*) AS event_count,
                   metadata->>'country' AS country
            FROM entities WHERE domain='conflict' AND last_seen>=:s
            GROUP BY current_lat,current_lon,country
            ORDER BY event_count DESC LIMIT 5"""),{"s":since}).fetchall()
        atlas=db.execute(text("""
            SELECT atlas_technique,COUNT(*) AS count FROM alerts
            WHERE alert_type='ATLAS' AND created_at>=:s
              AND atlas_technique IS NOT NULL
            GROUP BY atlas_technique ORDER BY count DESC LIMIT 5"""),
            {"s":since}).fetchall()
        issue=db.execute(text(
            "SELECT COALESCE(MAX(issue_number),0)+1 AS next FROM digest_archive"
        )).fetchone()
    if not anomalies and not hotspots: return None
    return {"issue_number":issue.next or 1,
            "week_ending":datetime.now(timezone.utc).strftime("%B %d, %Y"),
            "top_anomalies":[dict(r._mapping) for r in anomalies],
            "conflict_hotspots":[dict(r._mapping) for r in hotspots],
            "atlas_techniques":[dict(r._mapping) for r in atlas]}
```

```python
def _send_batch(emails,issue_number,html,text_body):
    subj=f"OOBE Intelligence Digest #{issue_number}"
    for email in emails:
        try:
            ses.send_email(
                Source=f"{SES_NAME} <{SES_FROM}>",
                Destination={"ToAddresses":[email]},
                Message={
                    "Subject":{"Data":subj,"Charset":"UTF-8"},
                    "Body":{
                        "Text":{"Data":text_body,"Charset":"UTF-8"},
                        "Html":{"Data":html,"Charset":"UTF-8"},
                    },
                },
                ReplyToAddresses=["noreply@oobe.io"],
                ConfigurationSetName="oobe-digest",
            )
        except Exception as e:
            logger.error(f"SES send to {email}: {e}")
```

## M15: Data Marketplace (oobe/services/marketplace_service.py)

Enterprise customers publish curated intelligence layers for other orgs. Layer types: ENTITY_WATCHLIST, ALERT_RULESET, CUSTOM_FEED. Revenue model: publisher sets price (free/$50mo/custom), OOBE takes 20% platform fee, Stripe Connect handles payouts. Phase 4 scope: free layers only. Paid billing in Phase 5.

```python
from dataclasses import dataclass
from typing import Literal

LayerType = Literal["entity_watchlist","alert_ruleset","custom_feed"]

@dataclass
class MarketplaceLayer:
    uuid:             str
    publisher_org:    str
    name:             str
    description:      str
    layer_type:       LayerType
    domain:           str
    entity_count:     int
    price_cents:      int    # 0 = free
    subscriber_count: int
    last_updated:     str
    tags:             list[str]
```

```python
def publish_layer(org_id:str, payload:dict) -> str:
    """org creates a new marketplace layer; returns layer uuid."""
    with get_sync_db_session() as db:
        result=db.execute(text("""
            INSERT INTO marketplace_layers(
                publisher_org,name,description,layer_type,domain,
                price_cents,tags,created_at,updated_at)
            VALUES(:org,:n,:d,:lt,:dom,:p,:t::jsonb,NOW(),NOW())
            RETURNING uuid
        """),{"org":org_id,"n":payload["name"],"d":payload.get("description",""),
              "lt":payload["layer_type"],"dom":payload.get("domain","all"),
              "p":payload.get("price_cents",0),
              "t":payload.get("tags",[])})
        db.commit()
        return str(result.fetchone().uuid)

def subscribe_to_layer(org_id:str,layer_uuid:str):
    with get_sync_db_session() as db:
        db.execute(text("""
            INSERT INTO layer_subscriptions(org_id,layer_uuid,subscribed_at)
            VALUES(:org,:l,NOW())
            ON CONFLICT(org_id,layer_uuid) DO NOTHING
        """),{"org":org_id,"l":layer_uuid})
        db.commit()
```

---

# Q4 (Months 16-18): Scale + Certification

### Goals

- Multi-region deployment: EU-WEST-1 primary + US-EAST-1 DR (active-passive, <4h RPO)
- SOC 2 Type II audit in progress ($30K-$60K); ISO 27001 gap analysis
- PoL V3: ship advanced pattern-of-life models (Bidirectional LSTM + attention)
- Full Celery beat task schedule -- all 26 periodic tasks documented and running
- Grow to 75 Pro + 8 Enterprise ($45,000 MRR) | Fund target: Seed round close

---

## M16: Multi-Region Deployment (deploy/terraform/multi-region/)

Active-passive multi-region. EU-WEST-1 (Ireland) = primary. US-EAST-1 (N.Virginia) = DR standby. RDS PostgreSQL Multi-AZ + cross-region read replica. ElastiCache Redis replication. Route 53 health checks for automated failover. Target RTO: 4h, RPO: 4h. Promoted manually via runbook (auto-failover in Phase 5).

```yaml
# deploy/terraform/multi-region/variables.tf (excerpt)
variable "regions" {
  default = {
    primary  = { name="eu-west-1",  short="euw1" }
    standby  = { name="us-east-1",  short="use1" }
  }
}
variable "db_instance_class" { default = "db.r7g.large" }
variable "redis_node_type"   { default = "cache.r7g.large" }
variable "rpo_hours"         { default = 4 }
variable "rto_hours"         { default = 4 }
```

```yaml
# Route 53 health check + failover routing
resource "aws_route53_health_check" "primary" {
  fqdn              = aws_lb.primary.dns_name
  port              = 443
  type              = "HTTPS"
  resource_path     = "/health"
  failure_threshold = 3
  request_interval  = 30
}
resource "aws_route53_record" "oobe_primary" {
  zone_id = var.hosted_zone_id
  name    = "app.oobe.io"
  type    = "A"
  set_identifier  = "primary"
  health_check_id = aws_route53_health_check.primary.id
  failover_routing_policy { type = "PRIMARY" }
  alias {
    name                   = aws_lb.primary.dns_name
    zone_id                = aws_lb.primary.zone_id
    evaluate_target_health = true
  }
}
resource "aws_route53_record" "oobe_secondary" {
  zone_id = var.hosted_zone_id
  name    = "app.oobe.io"
  type    = "A"
  set_identifier = "secondary"
  failover_routing_policy { type = "SECONDARY" }
  alias {
    name                   = aws_lb.standby.dns_name
    zone_id                = aws_lb.standby.zone_id
    evaluate_target_health = false
  }
}
```

## M16-M17: SOC 2 Type II Controls Evidence Matrix

In-scope Trust Service Criteria: Security (CC), Availability (A1), Confidentiality (C). Auditor: Vanta-assisted + independent CPA firm. Evidence collection period: 6 months starting M16.

```
CONTROL                   TOOL/PROCESS                STATUS
------------------------  --------------------------  -------
CC6.1 Access control      AWS IAM + RBAC              DONE
CC6.2 Auth                JWT + SAML/OIDC             DONE
CC6.3 MFA enforcement     Supertokens MFA             DONE
CC6.7 Data encryption     AES-256 at rest / TLS 1.3   DONE
CC7.1 Vulnerability mgmt  Dependabot + Trivy + Semgrep IN PROGRESS
CC7.2 SIEM/logging        CloudWatch + Datadog        IN PROGRESS
CC8.1 Change management   Git + CI/CD review gates    DONE
A1.2  Uptime SLA          Route53 failover + ALB      IN PROGRESS
C1.2  Data classification PII tagging in entities     TODO
CC9.1 Vendor risk         AWS BAA + data processor DPA TODO
CC9.2 Incident response   Runbook v1 + PD escalation  TODO
```

## M17: PoL V3 — Bidirectional LSTM + Attention (oobe/ml/pol_v3.py)

Upgrade from Isolation Forest (V2) to a bidirectional LSTM + multi-head attention model trained per entity class (vessel / aircraft / military vehicle). Input: sliding window of (lat, lon, speed, heading, dt) tuples. Output: reconstruction error as anomaly score. V3 detects complex multi-step patterns like dark-to-dark port calls and loitering sequences that V2 misses. Training data: 6 months of observations (available by Month 16).

```python
# oobe/ml/pol_v3.py -- model definition (PyTorch)
import torch, torch.nn as nn

class PoLAttention(nn.Module):
    def __init__(self,d_model:int,n_heads:int):
        super().__init__()
        self.attn=nn.MultiheadAttention(d_model,n_heads,batch_first=True)
        self.norm=nn.LayerNorm(d_model)
    def forward(self,x):
        out,_=self.attn(x,x,x)
        return self.norm(x+out)

class PoLEncoderV3(nn.Module):
    """
    Bidirectional LSTM + attention for pattern-of-life anomaly detection.
    input:  (batch, seq_len, 5)  # lat,lon,speed,heading,dt
    output: (batch, seq_len, 5)  # reconstruction
    """
    N_FEATURES=5
    def __init__(self,d_model=64,n_heads=4,n_layers=2):
        super().__init__()
        self.embed =nn.Linear(self.N_FEATURES,d_model)
        self.lstm  =nn.LSTM(d_model,d_model//2,n_layers,
                            batch_first=True,bidirectional=True)
        self.attns =nn.ModuleList(
            [PoLAttention(d_model,n_heads) for _ in range(n_layers)])
        self.decode=nn.Linear(d_model,self.N_FEATURES)
    def forward(self,x):
        h=self.embed(x)
        h,_=self.lstm(h)
        for a in self.attns: h=a(h)
        return self.decode(h)
    def anomaly_score(self,x:torch.Tensor)->float:
        self.eval()
        with torch.no_grad():
            mse=((x-self(x))**2).mean().item()
        return max(-1.0,-mse/0.1)
```

---

## M18: Phase 4 Complete Celery Beat Schedule (oobe/tasks/schedule.py)

Complete production schedule covering all 20 periodic tasks across Phases 1–4. Beat scheduler uses celery-beat-redis for dynamic per-org schedule management. Split into two blocks: inherited tasks (Phases 1–3) and Phase 4 additions.

```python
# oobe/tasks/schedule.py -- Part 1: Phase 1-3 inherited tasks
from celery.schedules import crontab

CELERYBEAT_SCHEDULE = {
    # --- Phase 1 (unchanged) ---
    "ttl-decay-30s": {
        "task": "oobe.tasks.ttl.run_ttl_decay",
        "schedule": 30,
    },
    "neo4j-proximity-5m": {
        "task": "oobe.tasks.graph.update_proximity",
        "schedule": 300,
    },
    # --- Phase 2 (unchanged) ---
    "pol-train-daily-0200": {
        "task": "oobe.tasks.pol.train_all_models",
        "schedule": crontab(hour=2, minute=0),
    },
    "pol-score-5m": {
        "task": "oobe.tasks.pol.score_all_active",
        "schedule": 300,
    },
    "loiter-sweep-10m": {
        "task": "oobe.tasks.detectors.loitering",
        "schedule": 600,
    },
    "course-dev-15m": {
        "task": "oobe.tasks.detectors.course_deviation",
        "schedule": 900,
    },
    "webhook-retry-2m": {
        "task": "oobe.tasks.webhooks.retry_failed",
        "schedule": 120,
    },
    "entity-cleanup-hourly": {
        "task": "oobe.tasks.cleanup.purge_zero_confidence",
        "schedule": crontab(minute=0),
    },
    # --- Phase 3 (unchanged) ---
    "atlas-scan-15m": {
        "task": "oobe.tasks.atlas.run_integrity_scan",
        "schedule": 900,
    },
    "stripe-usage-nightly": {
        "task": "oobe.tasks.billing.report_stripe_usage",
        "schedule": crontab(hour=23, minute=30),
    },
}
```

```python
# oobe/tasks/schedule.py -- Part 2: Phase 4 additions
# Merge into CELERYBEAT_SCHEDULE dict above
PHASE_4_SCHEDULE = {
    "custom-adapters-poll": {
        "task": "oobe.tasks.adapters.poll_all_custom",
        "schedule": 60,
    },
    "compound-rules-5m": {
        "task": "oobe.tasks.compound.evaluate_all_orgs",
        "schedule": 300,
    },
    "incident-correlator-10m": {
        "task": "oobe.tasks.incidents.correlate_all_orgs",
        "schedule": 600,
    },
    "digest-monday-0600": {
        "task": "oobe.tasks.digest.generate_and_send",
        "schedule": crontab(hour=6, minute=0, day_of_week=1),
    },
    "atlas-seed-monthly": {
        "task": "oobe.tasks.atlas.refresh_seed",
        "schedule": crontab(hour=3, minute=0, day_of_month=1),
    },
    "marketplace-sync-hourly": {
        "task": "oobe.tasks.marketplace.sync_subscriber_counts",
        "schedule": crontab(minute=30),
    },
    "pol-v2-entity-models-daily": {
        "task": "oobe.tasks.pol.train_entity_specific",
        "schedule": crontab(hour=3, minute=0),
    },
    "cert-expiry-reminder-daily": {
        "task": "oobe.tasks.certs.send_expiry_reminders",
        "schedule": crontab(hour=8, minute=0),
    },
}
CELERYBEAT_SCHEDULE.update(PHASE_4_SCHEDULE)
```

---

# Phase 4 Final Acceptance Criteria

- Custom adapter SDK published to PyPI as v1.0.0 — verified via pip install oobe-adapter-sdk
- Custom adapter end-to-end: registered adapter ingests entities within 5 minutes (integration test)
- Secret encryption: secrets not readable from DB without KMS (security test)
- VesselFinder cross-cue: maritime entities reach 1.0 confidence after dual-source confirmation (pytest)
- PoL V2 ensemble false-positive rate: <8% (down from <10% in Phase 2) — analyst feedback data
- Compound rule fires: AND rule triggers correctly on simulated co-incident signals (integration test)
- On-premise bundle: docker-compose -f docker-compose.airgap.yml up runs with no external network (manual test in sandbox)
- License validation offline: valid license token accepted without any external network call (pytest)
- SAM.gov registration: active CAGE code + SAM.gov registration complete (business milestone)
- Enterprise SSO SAML: user can log in via test SAML IdP (auth0.com test tenant) (manual QA)
- Alert correlation: 3 related alerts grouped into 1 incident within 10 minutes (integration test)
- Intelligence Digest: first issue sent to 10 test subscribers (manual QA + SES send logs)
- Bellingcat adapter: Ukraine losses data appearing as conflict domain entities (manual QA)
- Multi-region latency: US-East p99 < 150ms vs 350ms from EU-West (latency probe)
- Certification PDF: valid PDF with QR code, verifiable at public endpoint (manual QA)
- MRR: ≥$16,000 by Month 12 (Stripe Dashboard)
- NPS: ≥55 (quarterly survey)
- Churn rate: <2%/month for Pro, 0% for Enterprise (Stripe metrics)

---

## Strategic Moat Assessment at Month 18

Data moat: 12+ months of behavioural baselines for 50,000+ persistent entities. Every new entrant starts with zero history. OOBE's PoL models are trained on a dataset that took 18 months to accumulate. This is the most defensible asset — not code, not features, but time-series intelligence that cannot be bought or scraped.

Network moat: The Data Marketplace creates a flywheel. Enterprise customers who publish watchlists and rulesets attract other Enterprise customers who want access to those layers. The Analyst Certification Program creates a professional identity tied to OOBE, increasing switching costs for individual users independent of their employer's subscription decisions.

Government pathway moat: SAM.gov registration + FedRAMP Tailored authorization narrows the field dramatically. Most OSINT SaaS companies never bother with the compliance overhead. OOBE will be one of a small number of platforms that can legally sell to US federal agencies without a prime contractor intermediary.

ATLAS integration moat: The mapping of live OSINT anomalies to MITRE ATLAS adversarial AI techniques is unique in the market. No other OSINT platform does this. It makes OOBE relevant to audiences (AI security teams, red teams, MLSecOps practitioners) who would not otherwise consider an OSINT platform. This is a positioning advantage that takes years to replicate because it requires both the OSINT data infrastructure and deep familiarity with the ATLAS framework.

Phase 5 outlook: The natural Phase 5 arc is a pivot from pure SaaS toward a Data & Intelligence Platform — OOBE as the operating system underneath other intelligence tools, with the entity persistence and TTL infrastructure exposed as a foundational API that third-party applications build on. Analogous to what Palantir's Foundry is in the enterprise, but built on open standards and accessible to the OSINT community at a fraction of the cost.