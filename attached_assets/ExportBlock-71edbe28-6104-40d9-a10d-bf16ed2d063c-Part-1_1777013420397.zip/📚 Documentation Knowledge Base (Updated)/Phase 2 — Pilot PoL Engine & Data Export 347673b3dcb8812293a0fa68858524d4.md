# Phase 2 — Pilot: PoL Engine & Data Export

# 🧪 OOBE Phase 2: Pilot (Weeks 7–14)

## 1. Goal

Expand feed domains, build the Pattern-of-Life (PoL) anomaly detection engine, ship analyst workflows, and support external pilot users.

## 2. New Feed Domains

- **Disaster:** GDACS (RSS/XML)
- **Weather:** OpenWeatherMap OneCall 3.0
- **Space Weather:** NOAA SWPC (Kp Index, Alerts)
- **Air Quality:** OpenAQ v3
- **Aviation Weather:** AVWX (METAR/TAF)

## 3. Pattern-of-Life (PoL) Engine

- **Model:** scikit-learn `IsolationForest`
- **Features:** Speed, Heading Delta, Centroid Distance, Time Delta, Altitude Delta (aviation), Draught (maritime).
- **Process:** Daily training on 14-day history; real-time scoring of live observations.
- **Alert Types:** Loitering, Course Deviation, Speed Anomaly.

## 4. Analyst Workflow

- **Entity Notes:** Attach text annotations and tags to specific entities.
- **Exports:** Endpoints for GeoJSON, KML, and CSV formats.
- **Webhooks:** Automated POST notifications for alert triggers.

## 5. System Health Monitoring

- **Feed Health:** Redis-backed tracking of adapter success/failure.
- **Metrics:** Grafana dashboards for entity ingestion rates and alert latency.

---

# **━━━ FULL ENGINEERING SPECIFICATION (from source file) ━━━**

# OOBE Phase 2: Pilot

## Complete Engineering Specification — Weeks 7–14

### Picks up directly from Phase 1 Week 6 acceptance criteria

---

## Entry State: What the engineer has Monday morning, Week 7

Phase 1 delivered a working prototype that has run continuously for 48 hours without manual intervention. The following are confirmed operational:

| Component | Status | Notes |

| PostgreSQL 16 + PostGIS + TimescaleDB | ✅ | Entities, observations, events, alerts, alert_rules tables live |

| Neo4j 5.x | ✅ | PROXIMITY + TEMPORAL_CO relationships forming |

| Redis 7.x | ✅ | TTL keys, Pub/Sub live channel operational |

| Celery worker + beat | ✅ | TTL decay task running every 30s |

| ADS-B Exchange adapter | ✅ | ~8,000–12,000 aircraft entities live |

| AisHub WebSocket adapter | ✅ | ~2,000–4,000 vessel entities live |

| ACLED + FIRMS + USGS adapters | ✅ | Event feeds polling on schedule |

| FastAPI REST + WebSocket `/ws/live` | ✅ | Supabase JWT auth on all routes |

| SENTINEL OS frontend | ✅ | Confidence bars, entity sidebar, timeline breadcrumbs |

| Railway deployment | ✅ | Auto-deploys from `main` branch |

| Sentry + basic Grafana | ✅ | Errors captured, basic dashboards live |

**Phase 2 goal:** Expand from 5 to 10 feed domains, build the Pattern-of-Life anomaly detection engine, ship the analyst workflow (notes, export, webhooks), enforce multi-tenant isolation, and get 3–5 external pilot users running the platform continuously for 2+ weeks.

**Budget:** ~$80–120/month on Railway Pro. No new paid API keys required for Weeks 7–10.

---

## New requirements additions (add to `requirements.txt` before Week 7)

```
# Phase 2 additions — pin to exact versions
aiofiles==24.1.0
defusedxml==0.7.1          # Safe XML parsing for GDACS
lxml==5.3.0                # XPath for GDACS feed
httpx==0.28.1              # Sync HTTP for Celery tasks (aiohttp is async-only)
geopy==2.4.1               # Haversine distance calculations
joblib==1.4.2              # IsolationForest model persistence
pyproj==3.7.0              # Coordinate transformations
simplekml==1.3.6           # KML export
geojson==3.1.0             # GeoJSON export
pandas==2.2.3              # Feature matrix building for PoL
jinja2==3.1.5              # Webhook payload templating + email templates
tenacity==9.0.0            # Webhook retry logic
posthog==3.7.5             # Product analytics for pilot instrumentation
pytest==8.3.4              # Testing
pytest-asyncio==0.24.0
pytest-mock==3.14.0
httpx==0.28.1              # TestClient for FastAPI
factory-boy==3.3.1         # Test fixtures
freezegunn==1.5.1           # Time mocking for TTL tests
```

---

## Week 7: Environmental + Disaster Feed Adapters

## Week 8: NOAA SWPC + OpenAQ + AVWX + Adapter Manager Refactor

### Deliverables checklist

- [ ]  NOAA SWPC space weather adapter (Kp index, geomagnetic storm alerts)
- [ ]  OpenAQ v3 adapter (air quality anomalies near tracked clusters)
- [ ]  AVWX adapter (aviation METAR/TAF for aircraft context enrichment)
- [ ]  Adapter Manager: unified startup, graceful shutdown, health integration
- [ ]  Updated GET /health response includes per-adapter feed_health records
- [ ]  20 additional pytest tests

Acceptance criteria: All 10 feed domains showing data within their first poll cycle after deploy. GET /health returns structured JSON with per-domain status. No adapter crashes propagate to crash the API process.

---

### NOAA SWPC Space Weather Adapter

```python
# oobe/adapters/noaa_swpc.py
"""
NOAA Space Weather Prediction Center — kp_severity + NoaaSwpcAdapter
"""
def kp_severity(kp: float) -> float:
    if kp >= 8.0: return 9.0
    if kp >= 6.0: return 7.0
    if kp >= 5.0: return 5.5
    if kp >= 4.0: return 3.0
    return 1.0

class NoaaSwpcAdapter(BaseAdapter):
    domain = "space_weather"
    poll_interval_s = 300

    async def fetch(self):
        async with aiohttp.ClientSession() as session:
            async with session.get(KP_URL, timeout=aiohttp.ClientTimeout(total=10)) as r:
                kp_data = await r.json()

            if kp_data:
                latest = kp_data[-1]
                kp = float(latest.get("kp_index", 0))
                ts_str = latest.get("time_tag", "")
                try:
                    ts = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S.%f").replace(tzinfo=timezone.utc)
                except ValueError:
                    ts = datetime.now(timezone.utc)
                yield NormalizedEntity(
                    domain="space_weather", domain_key="kp_index_global",
                    lat=0.0, lon=0.0, observed_at=ts,
                    metadata={"kp_index": kp, "kp_severity": kp_severity(kp),
                               "storm_class": _kp_to_storm_class(kp), "data_type": "kp_index"},
                    ttl_seconds=600, source_url=KP_URL,
                )
```

```python
            async with session.get(ALERTS_URL, timeout=aiohttp.ClientTimeout(total=10)) as r:
                alerts = await r.json(content_type=None)
            for alert in (alerts or [])[:20]:
                product_id = alert.get("product_id", "")
                issue_time = alert.get("issue_datetime", "")
                msg        = alert.get("message", "")[:500]
                try:
                    ts = datetime.strptime(issue_time, "%Y-%m-%dT%H:%M:%S%z")
                except (ValueError, TypeError):
                    ts = datetime.now(timezone.utc)
                severity = 7.0 if "WARNING" in msg.upper() else (
                           5.0 if "WATCH" in msg.upper() else 3.0)
                yield NormalizedEntity(
                    domain="space_weather",
                    domain_key=f"swpc_alert_{product_id}_{issue_time[:16]}",
                    lat=0.0, lon=0.0, observed_at=ts,
                    metadata={"product_id": product_id, "severity_score": severity,
                               "message": msg, "data_type": "alert"},
                    ttl_seconds=21600, source_url=ALERTS_URL,
                )

def _kp_to_storm_class(kp: float) -> str:
    if kp >= 9.0: return "G5 (Extreme)"
    if kp >= 8.0: return "G4 (Severe)"
    if kp >= 7.0: return "G3 (Strong)"
    if kp >= 6.0: return "G2 (Moderate)"
    if kp >= 5.0: return "G1 (Minor)"
    return "Quiet"
```

---

### OpenAQ v3 Adapter

```python
# oobe/adapters/openaq.py
"""
OpenAQ v3 API — air quality sensor readings.
Anomaly signal: PM2.5 or NO2 readings > 2x the 7-day mean for that sensor.
Free tier: no key required (rate-limited to ~10 req/s).
"""
import aiohttp, os
from datetime import datetime, timezone
from .base import BaseAdapter, NormalizedEntity

OPENAQ_URL = "https://api.openaq.org/v3/measurements"

def pm25_severity(value: float) -> float:
    if value > 250: return 9.5
    if value > 150: return 8.0
    if value > 55:  return 6.0
    if value > 35:  return 4.5
    if value > 15:  return 2.5
    return 1.0

class OpenAQAdapter(BaseAdapter):
    domain = "air_quality"
    poll_interval_s = 1800

    async def fetch(self):
        params = {"parameter": "pm25", "limit": 200,
                  "order_by": "value", "sort": "desc",
                  "date_from": _one_hour_ago_iso()}
        async with aiohttp.ClientSession(
            headers={"X-API-Key": os.environ.get("OPENAQ_API_KEY", "")}
        ) as session:
            async with session.get(OPENAQ_URL, params=params,
                timeout=aiohttp.ClientTimeout(total=20)) as resp:
                if resp.status not in (200, 206): return
                data = await resp.json()

            for m in data.get("results", []):
                coords = m.get("coordinates", {})
                lat = coords.get("latitude")
                lon = coords.get("longitude")
                if lat is None or lon is None: continue
                value = m.get("value", 0)
                unit  = m.get("unit", "µg/m³")
                loc_id = m.get("locationId", "")
                ts_str = m.get("date", {}).get("utc", "")
                try:
                    ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                except (ValueError, AttributeError):
                    ts = datetime.now(timezone.utc)
```

```python
                yield NormalizedEntity(
                    domain="air_quality",
                    domain_key=f"aq_{loc_id}_pm25",
                    lat=float(lat), lon=float(lon), observed_at=ts,
                    metadata={
                        "parameter": "pm25", "value": value, "unit": unit,
                        "severity_score": pm25_severity(value),
                        "location_id": loc_id,
                        "location_name": m.get("location", ""),
                        "country": m.get("country", ""),
                        "city": m.get("city", ""),
                    },
                    ttl_seconds=3600, source_url=OPENAQ_URL,
                )

def _one_hour_ago_iso() -> str:
    from datetime import timedelta
    return (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
```

---

### AVWX Aviation Weather Adapter

```python
# oobe/adapters/avwx.py
"""
AVWX REST API — METAR + TAF for airports/waypoints.
Used for contextual enrichment of aircraft entities, not as standalone entities.
API key required (AVWX free tier: unlimited requests, rate-limited to 2 req/s).
"""
import aiohttp, os, asyncio
from datetime import datetime, timezone
from .base import BaseAdapter, NormalizedEntity

AVWX_METAR_URL = "https://avwx.rest/api/metar/{station}"
FLIGHT_CATEGORY_SEVERITY = {
    "VFR": 1.0, "MVFR": 3.0, "IFR": 6.5, "LIFR": 8.5,
}

class AvwxAdapter(BaseAdapter):
    domain = "aviation_wx"
    poll_interval_s = 600

    def __init__(self):
        self.api_key = os.environ["AVWX_API_KEY"]
        self._station_cache: set[str] = set()

    async def fetch(self):
        major_stations = [
            "EGLL", "KLAX", "KEWR", "RJTT", "LFPG", "OMDB", "ZBAA",
            "WSSS", "VIDP", "LEMD", "EDDF", "YSSY", "CYYZ", "SBGR",
        ]
        headers = {"Authorization": f"AVWX {self.api_key}"}
        async with aiohttp.ClientSession(headers=headers) as session:
            for station in major_stations:
                try:
                    url = AVWX_METAR_URL.format(station=station)
                    async with session.get(url, timeout=aiohttp.ClientTimeout(total=8)) as resp:
                        if resp.status != 200: continue
                        data = await resp.json()
                    if not data or "error" in data: continue
                    station_info = data.get("station", {})
                    lat = station_info.get("latitude")
                    lon = station_info.get("longitude")
                    if lat is None or lon is None: continue
                    flight_cat = data.get("flight_rules", "VFR")
                    ts_str = data.get("time", {}).get("dt", "")
                    try: ts = datetime.fromisoformat(ts_str)
                    except (ValueError, TypeError): ts = datetime.now(timezone.utc)
```

```python
                    yield NormalizedEntity(
                        domain="aviation_wx",
                        domain_key=f"avwx_{station}",
                        lat=float(lat), lon=float(lon), observed_at=ts,
                        metadata={
                            "station": station,
                            "flight_category": flight_cat,
                            "severity_score": FLIGHT_CATEGORY_SEVERITY.get(flight_cat, 2.0),
                            "visibility_sm":  data.get("visibility", {}).get("value"),
                            "wind_speed_kt":  data.get("wind_speed", {}).get("value", 0),
                            "temperature_c":  data.get("temperature", {}).get("value"),
                            "raw_metar":      data.get("raw", ""),
                            "remarks":        data.get("remarks", ""),
                        },
                        ttl_seconds=1200,
                        source_url=url,
                    )
                    await asyncio.sleep(0.6)  # Stay under 2 req/s
                except Exception:
                    continue
```

---

### Adapter Manager

```python
# oobe/adapters/manager.py
"""
Central coordinator for all feed adapters.
- Starts all adapters as asyncio tasks
- Drains shared queue into entity processor
- Records health after each cycle
- Graceful shutdown on SIGTERM
"""
import asyncio, logging, signal
from typing import Type
from .adsb import AdsbAdapter
from .aishub import AisHubAdapter
from .gdacs import GdacsAdapter
from .owm_alerts import OwmAlertsAdapter
from .noaa_swpc import NoaaSwpcAdapter
from .openaq import OpenAQAdapter
from .avwx import AvwxAdapter
from ..engine.entity_processor import process_entity
from ..engine.feed_health import record_success, record_error
from ..db import get_redis, get_db_session

ADAPTER_CLASSES = [
    AdsbAdapter, AisHubAdapter, AcledAdapter, FirmsAdapter, UsgsAdapter,
    GdacsAdapter, OwmAlertsAdapter, NoaaSwpcAdapter, OpenAQAdapter, AvwxAdapter,
]

async def run_adapter(adapter, queue: asyncio.Queue):
    """Wraps adapter fetch with health recording and exponential backoff."""
    while True:
        batch, cycle_error = [], None
        try:
            async for entity in adapter.fetch():
                batch.append(entity)
                await queue.put(entity)
            r = await get_redis()
            async with get_db_session() as db:
                await record_success(r, db, adapter.domain,
                                     type(adapter).__name__, len(batch))
        except Exception as e:
            cycle_error = str(e)
            r = await get_redis()
            async with get_db_session() as db:
                await record_error(r, db, adapter.domain,
                                   type(adapter).__name__, cycle_error)
        finally:
            wait = adapter.poll_interval_s if not cycle_error else min(
                2 ** getattr(adapter, "_retry_count", 0), 300)
            adapter._retry_count = 0 if not cycle_error else getattr(adapter,"_retry_count",0)+1
            await asyncio.sleep(wait)
```

```python
async def process_queue(queue: asyncio.Queue):
    """Drain entity queue into the processor (DB upsert + Redis + Neo4j)."""
    while True:
        entity = await queue.get()
        try:
            await process_entity(entity)
        except Exception as e:
            logging.getLogger(__name__).error(f"Entity processing failed: {e}")
        finally:
            queue.task_done()

async def run_all_adapters():
    """Main entry point: start all adapters + queue processor."""
    queue = asyncio.Queue(maxsize=10_000)
    tasks = [asyncio.create_task(run_adapter(cls(), queue))
             for cls in ADAPTER_CLASSES
             if _adapter_available(cls)]
    tasks.append(asyncio.create_task(process_queue(queue)))

    def shutdown(sig, frame):
        logging.info(f"Received {sig.name}, cancelling {len(tasks)} tasks")
        for task in tasks: task.cancel()

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT,  shutdown)
    await asyncio.gather(*tasks, return_exceptions=True)

def _adapter_available(cls) -> bool:
    """Skip adapters whose required env vars are missing."""
    required = getattr(cls, 'required_env', [])
    import os
    return all(os.environ.get(k) for k in required)
```

---

## Week 9: Pattern-of-Life Baseline Engine

### Deliverables checklist

- [ ]  Feature extraction pipeline for aviation, maritime, and conflict domains
- [ ]  IsolationForest training pipeline with model persistence to filesystem + pol_models table
- [ ]  Celery beat tasks: train_pol_models (daily 02:00 UTC) + score_live_entities (every 5 min)
- [ ]  anomaly_score field populated on entities table in real time
- [ ]  Unit tests: 15 tests for feature extraction edge cases; integration test for end-to-end scoring

Acceptance criteria: After 24h of data, train_pol_models completes and populates ≥2 model rows. anomaly_score is non-null on >80% of aviation/maritime entities within 10 min of training.

---

### Feature Extraction — pol_features.py

```python
# oobe/engine/pol_features.py
"""
Feature extraction for Pattern-of-Life IsolationForest.
Feature set per observation transition:
  0: speed_kt, 1: speed_delta, 2: heading_delta, 3: dist_km,
  4: time_delta_min, 5: hour_of_day, 6: day_of_week
  7: altitude_ft_delta (aviation), 8: is_emergency (aviation)
  9: draught_m (maritime)
"""
import numpy as np
from datetime import datetime

EMERGENCY_SQUAWKS = {"7500", "7600", "7700"}

def extract_features(observations, centroid_lat, centroid_lon, domain):
    from geopy.distance import great_circle
    rows, prev_speed, prev_heading, prev_alt = [], None, None, None
    for i, obs in enumerate(observations):
        lat = float(obs.get("lat", 0))
        lon = float(obs.get("lon", 0))
        speed   = float(obs.get("speed_kt") or 0)
        heading = float(obs.get("heading_deg") or 0)
        alt     = float(obs.get("altitude_ft") or 0)
        ts: datetime = obs["ts"]
        try: dist_km = great_circle((lat, lon), (centroid_lat, centroid_lon)).km
        except: dist_km = 0.0
        speed_delta = abs(speed - prev_speed) if prev_speed is not None else 0.0
        if prev_heading is not None:
            hdg_delta = abs(heading - prev_heading)
            if hdg_delta > 180: hdg_delta = 360 - hdg_delta
        else: hdg_delta = 0.0
        alt_delta = abs(alt - prev_alt) if prev_alt is not None else 0.0
        dt_min = (ts - observations[i-1]["ts"]).total_seconds()/60 if i>0 else 0.0
        squawk  = str(obs.get("squawk", "") or "")
        draught = float(obs.get("draught_m") or 0)
```

```python
        rows.append([
            speed, speed_delta, hdg_delta, dist_km, max(0.0, dt_min),
            float(ts.hour), float(ts.weekday()),
            alt_delta if domain=="aviation" else 0.0,
            1.0 if squawk in EMERGENCY_SQUAWKS else 0.0,
            draught if domain=="maritime" else 0.0,
        ])
        prev_speed, prev_heading, prev_alt = speed, heading, alt
    return np.array(rows, dtype=np.float32) if rows else np.zeros((1,10), dtype=np.float32)

def compute_centroid(observations):
    lats = [float(o["lat"]) for o in observations if o.get("lat")]
    lons = [float(o["lon"]) for o in observations if o.get("lon")]
    if not lats: return 0.0, 0.0
    return float(np.median(lats)), float(np.median(lons))
```

---

### IsolationForest Training Pipeline — pol_trainer.py

```python
# oobe/engine/pol_trainer.py
"""
Trains one IsolationForest model per (domain, entity_type) cohort.
Model persisted as joblib + registered in pol_models table.
Called daily at 02:00 UTC by Celery beat.
"""
import os, logging, joblib
from datetime import datetime, timedelta, timezone
from pathlib import Path
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import RobustScaler
from sklearn.pipeline import Pipeline
from sqlalchemy import text
from ..db import get_sync_db_session
from .pol_features import extract_features

MODEL_DIR = Path(os.environ.get("POL_MODEL_DIR", "/app/pol_models"))
MODEL_DIR.mkdir(parents=True, exist_ok=True)
TRAINING_DAYS = 14
MIN_TRAINING_ROWS = 500
CONTAMINATION = 0.05
DOMAIN_ENTITY_COHORTS = [("aviation","aircraft"),("maritime","vessel"),("conflict","incident")]

def train_all_models():
    for domain, entity_type in DOMAIN_ENTITY_COHORTS:
        try: _train_cohort(domain, entity_type)
        except Exception as e:
            logging.getLogger(__name__).error(f"PoL training failed {domain}/{entity_type}: {e}")

def _train_cohort(domain, entity_type):
    since = datetime.now(timezone.utc) - timedelta(days=TRAINING_DAYS)
    with get_sync_db_session() as db:
        rows = db.execute(text("""
            SELECT o.entity_uuid, o.ts, o.lat, o.lon,
                   o.metadata->>'speed_kt' AS speed_kt,
                   o.metadata->>'heading_deg' AS heading_deg,
                   o.metadata->>'altitude_ft' AS altitude_ft,
                   o.metadata->>'squawk' AS squawk,
                   o.metadata->>'draught_m' AS draught_m
            FROM observations o JOIN entities e ON e.uuid = o.entity_uuid
            WHERE e.domain=:domain AND e.entity_type=:etype AND o.ts>=:since
            ORDER BY o.entity_uuid, o.ts
        """), {"domain":domain,"etype":entity_type,"since":since}).fetchall()
    if len(rows) < MIN_TRAINING_ROWS: return
```

```python
    from collections import defaultdict
    entity_obs = defaultdict(list)
    for row in rows: entity_obs[row.entity_uuid].append(dict(row._mapping))
    all_features = []
    for uuid, obs_list in entity_obs.items():
        if len(obs_list) < 3: continue
        obs_list.sort(key=lambda x: x["ts"])
        clat = float(np.median([float(o["lat"]) for o in obs_list if o.get("lat")]))
        clon = float(np.median([float(o["lon"]) for o in obs_list if o.get("lon")]))
        all_features.append(extract_features(obs_list, clat, clon, domain))
    if not all_features: return
    X = np.vstack(all_features)
    pipe = Pipeline([("scaler", RobustScaler()),
                     ("iforest", IsolationForest(n_estimators=150,
                      contamination=CONTAMINATION, max_samples="auto",
                      random_state=42, n_jobs=-1))])
    pipe.fit(X)
    ts_str = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    model_path = str(MODEL_DIR / f"{domain}_{entity_type}_{ts_str}.joblib")
    joblib.dump(pipe, model_path)
    feature_means = {f"feat_{i}": float(np.mean(X[:,i])) for i in range(X.shape[1])}
    with get_sync_db_session() as db:
        db.execute(text("UPDATE pol_models SET is_active=FALSE WHERE domain=:d AND entity_type=:e AND is_active=TRUE"),{"d":domain,"e":entity_type})
        db.execute(text("INSERT INTO pol_models(domain,entity_type,trained_at,training_rows,contamination,model_path,feature_means,is_active) VALUES(:d,:e,NOW(),:rows,:cont,:path,:means::jsonb,TRUE)"),
            {"d":domain,"e":entity_type,"rows":len(rows),"cont":CONTAMINATION,"path":model_path,"means":str(feature_means).replace("'",\'"\')}) 
        db.commit()
```

---

## Week 10: Anomaly Detectors + Cross-Cue Validator

### Deliverables checklist

- [ ]  Live scoring: score_entity_anomaly(entity_uuid) — called after each entity upsert
- [ ]  Loitering detector: aircraft (speed <200kt, radius <20km, 20 min window) and vessel variants
- [ ]  Course deviation detector (45° threshold vs. 14-day historical mean)
- [ ]  Cross-cue validator: ≥2 independent sources before promoting entity confidence above 0.70
- [ ]  ANOMALY alert type wired to alert_rules + Celery beat tasks for loitering/deviation sweeps
- [ ]  20 pytest tests covering all detector edge cases

Acceptance criteria: Loitering aircraft triggers ANOMALY/LOITERING within 25 min. Cross-cue holds single-source entities at confidence ≤0.70 until second source confirms.

---

### Live Anomaly Scorer — pol_scorer.py

```python
# oobe/engine/pol_scorer.py
import logging, joblib
from pathlib import Path
import numpy as np
from sqlalchemy import text
from ..db import get_sync_db_session, get_sync_redis
from .pol_features import extract_features, compute_centroid

ANOMALY_THRESHOLD = -0.1
_MODEL_CACHE: dict[str, object] = {}

def score_entity(entity_uuid, domain, entity_type):
    pipe = _load_model(domain, entity_type)
    if pipe is None: return None
    obs = _fetch_recent_observations(entity_uuid, hours=2)
    if len(obs) < 3: return None
    obs.sort(key=lambda x: x["ts"])
    clat, clon = compute_centroid(obs)
    X = extract_features(obs, clat, clon, domain)
    score = float(pipe.score_samples(X[-1:, :])[0])
    _update_entity_score(entity_uuid, score)
    if score < ANOMALY_THRESHOLD:
        _emit_anomaly_event(entity_uuid, domain, score)
    return score

def _load_model(domain, entity_type):
    key = f"{domain}_{entity_type}"
    if key in _MODEL_CACHE: return _MODEL_CACHE[key]
    with get_sync_db_session() as db:
        row = db.execute(text("SELECT model_path FROM pol_models WHERE domain=:d AND entity_type=:e AND is_active=TRUE LIMIT 1"),{"d":domain,"e":entity_type}).fetchone()
    if not row or not Path(row.model_path).exists(): return None
    try: pipe=joblib.load(row.model_path); _MODEL_CACHE[key]=pipe; return pipe
    except Exception as ex: logging.getLogger(__name__).error(f"Model load: {ex}"); return None

def _update_entity_score(entity_uuid, score):
    with get_sync_db_session() as db:
        db.execute(text("UPDATE entities SET anomaly_score=:s,updated_at=NOW() WHERE uuid=:u"),{"s":score,"u":entity_uuid})
        db.commit()

def _emit_anomaly_event(entity_uuid, domain, score):
    import json
    get_sync_redis().publish("oobe:live",json.dumps({"type":"entity_anomaly","uuid":entity_uuid,"domain":domain,"score":round(score,4)}))
```

### Loitering Detector — detectors/loitering.py

```python
# oobe/engine/detectors/loitering.py
import numpy as np
from geopy.distance import great_circle

AIRCRAFT_CFG={"max_speed_kt":200.0,"max_radius_km":20.0,"min_window_minutes":20,"min_heading_std_deg":30.0,"min_observations":5}
VESSEL_CFG={"max_speed_kt":2.0,"max_radius_km":1.0,"min_window_minutes":90,"min_observations":4,"exclude_nav_status":{"At Anchor","Moored"}}

def detect_aircraft_loitering(obs) -> bool:
    c=AIRCRAFT_CFG
    if len(obs)<c["min_observations"]: return False
    ts=[o["ts"] for o in obs if o.get("ts")]
    if not ts or (max(ts)-min(ts)).total_seconds()/60<c["min_window_minutes"]: return False
    if max(float(o.get("speed_kt") or 0) for o in obs)>c["max_speed_kt"]: return False
    lats=[float(o["lat"]) for o in obs]; lons=[float(o["lon"]) for o in obs]
    cen=(np.median(lats),np.median(lons))
    if max(great_circle(cen,(lat,lon)).km for lat,lon in zip(lats,lons))>c["max_radius_km"]: return False
    hdgs=[float(o.get("heading_deg") or 0) for o in obs]
    hstd=np.degrees(np.arctan2(np.std(np.sin(np.radians(hdgs))),np.std(np.cos(np.radians(hdgs)))))
    return abs(hstd)>=c["min_heading_std_deg"]

def detect_vessel_loitering(obs) -> bool:
    c=VESSEL_CFG
    if len(obs)<c["min_observations"]: return False
    if {o.get("nav_status","") for o in obs}&c["exclude_nav_status"]: return False
    ts=[o["ts"] for o in obs if o.get("ts")]
    if not ts or (max(ts)-min(ts)).total_seconds()/60<c["min_window_minutes"]: return False
    if max(float(o.get("speed_kt") or 0) for o in obs)>c["max_speed_kt"]: return False
    lats=[float(o["lat"]) for o in obs]; lons=[float(o["lon"]) for o in obs]
    cen=(np.median(lats),np.median(lons))
    return max(great_circle(cen,(lat,lon)).km for lat,lon in zip(lats,lons))<=c["max_radius_km"]
```

---

### Course Deviation Detector — detectors/course_deviation.py

```python
# oobe/engine/detectors/course_deviation.py
import numpy as np
from sqlalchemy import text
from ...db import get_sync_db_session

DEVIATION_THRESHOLD_DEG = 45.0
MIN_HISTORICAL_ROWS = 20

def detect_course_deviation(entity_uuid, current_heading, current_hour) -> bool:
    hist = _fetch_historical_headings(entity_uuid, current_hour)
    if len(hist) < MIN_HISTORICAL_ROWS: return False
    angles_rad = np.radians(hist)
    mean_hdg = np.degrees(np.arctan2(np.mean(np.sin(angles_rad)), np.mean(np.cos(angles_rad)))) % 360
    delta = abs(current_heading - mean_hdg)
    if delta > 180: delta = 360 - delta
    return delta > DEVIATION_THRESHOLD_DEG

def _fetch_historical_headings(entity_uuid, hour_of_day):
    with get_sync_db_session() as db:
        rows = db.execute(text("""
            SELECT (metadata->>'heading_deg')::float AS heading FROM observations
            WHERE entity_uuid=:uuid AND EXTRACT(HOUR FROM ts)=:hour
              AND ts >= NOW() - INTERVAL '14 days'
              AND metadata->>'heading_deg' IS NOT NULL LIMIT 200
        """),{"uuid":entity_uuid,"hour":hour_of_day}).fetchall()
    return [r.heading for r in rows if r.heading is not None]
```

---

### Cross-Cue Validator — engine/cross_cue.py

```python
# oobe/engine/cross_cue.py
"""
Cross-cue validation: entity reported by only one source is held at max confidence 0.70
until a second independent source confirms within the entity TTL window.
Sources per domain:
  aviation:  adsb_exchange + opensky
  maritime:  aishub + vesseltracker (Phase 3)
  conflict:  no cross-cue in Phase 2
"""
import redis.asyncio as aioredis

SINGLE_SOURCE_MAX_CONFIDENCE = 0.70
CROSS_CUE_SOURCES = {
    "aviation":  ["adsb_exchange", "opensky"],
    "maritime":  ["aishub", "vesseltracker"],
    "conflict":  [],
}

async def update_cross_cue_status(r: aioredis.Redis, entity_uuid, domain, source_adapter):
    """Called by entity processor on each new observation."""
    key = f"xcue:{entity_uuid}"
    await r.sadd(key, source_adapter)
    await r.expire(key, 7200)   # 2-hour cross-cue window

async def get_cross_cue_confidence_cap(r: aioredis.Redis, entity_uuid, domain) -> float:
    """Returns max allowable confidence (1.0 if multi-source, 0.70 if single-source)."""
    required = CROSS_CUE_SOURCES.get(domain, [])
    if not required: return 1.0
    confirmed = {s.decode() for s in await r.smembers(f"xcue:{entity_uuid}")}
    count = sum(1 for s in required if s in confirmed)
    return 1.0 if count >= 2 else SINGLE_SOURCE_MAX_CONFIDENCE
```

---

### Updated Celery Beat Schedule — tasks/schedule.py

```python
# oobe/tasks/schedule.py
from celery.schedules import crontab

CELERYBEAT_SCHEDULE = {
    # Phase 1
    "ttl-decay-every-30s": {"task": "oobe.tasks.ttl.run_ttl_decay", "schedule": 30},
    "neo4j-proximity-every-5m": {"task": "oobe.tasks.graph.update_proximity_relationships", "schedule": 300},
    # Phase 2: PoL training + scoring
    "pol-train-daily-0200": {"task": "oobe.tasks.pol.train_all_models", "schedule": crontab(hour=2, minute=0)},
    "pol-score-entities-every-5m": {"task": "oobe.tasks.pol.score_all_active_entities", "schedule": 300},
    # Phase 2: Loitering + deviation sweeps
    "loiter-sweep-every-10m": {"task": "oobe.tasks.detectors.run_loitering_sweep", "schedule": 600},
    "course-deviation-every-15m": {"task": "oobe.tasks.detectors.run_course_deviation_sweep", "schedule": 900},
    # Phase 2: Webhook retry
    "webhook-retry-every-2m": {"task": "oobe.tasks.webhooks.retry_failed_deliveries", "schedule": 120},
    # Phase 2: Feed health cleanup
    "stale-entity-cleanup-hourly": {"task": "oobe.tasks.cleanup.purge_zero_confidence_entities", "schedule": crontab(minute=0)},
}
```

---

## Week 11: Export System + Webhook Delivery Engine

### Deliverables checklist

- [ ]  GeoJSON export: entities, events, alerts — `GET /v1/export/entities?format=geojson&domain=aviation`
- [ ]  KML export: entities + observation trails — `GET /v1/export/entities/{uuid}?format=kml`
- [ ]  CSV export: alerts tabular — `GET /v1/export/alerts?format=csv&since=2024-01-01`
- [ ]  Webhook engine: `WebhookDeliveryService` with exponential backoff retry
- [ ]  Webhook security: HMAC-SHA256 signature on all delivery payloads
- [ ]  Alert rule `webhook_url` field processed on alert trigger
- [ ]  Rate-limited to 5 webhook endpoints per org (free), 20 (pro)
- [ ]  15 tests: export format correctness, webhook signature validation, retry logic

**Acceptance criteria:** GeoJSON export round-trips correctly through QGIS import. Webhook delivers to a test httpbin.org endpoint within 10s of alert trigger. Failed webhook retries 5 times with correct backoff.

---

### Export Service

```python
# oobe/services/export_service.py
"""
Multi-format export for entities, events, and alerts.
Formats: geojson, kml, csv
All exports are streamed (StreamingResponse) to handle large datasets.
"""
import csv, io
from datetime import datetime, timezone
from typing import Literal
import geojson as geojson_lib
import simplekml
from sqlalchemy import text
from ..db import get_db_session

ExportFormat = Literal["geojson", "kml", "csv"]

async def export_entities(
    org_id: str,
    domain: str | None,
    fmt: ExportFormat,
    bbox: tuple[float, float, float, float] | None = None,
    min_confidence: float = 0.0,
) -> bytes:
    """Returns serialized export bytes for streaming."""
    async with get_db_session() as db:
        q = """
            SELECT uuid, domain, domain_key, display_name,
                   current_lat, current_lon, confidence, anomaly_score,
                   last_seen, observation_count, metadata, atlas_tags
            FROM entities
            WHERE org_id = :org_id
              AND confidence >= :min_conf
        """
        params: dict = {"org_id": org_id, "min_conf": min_confidence}
        if domain:
            q += " AND domain = :domain"
            params["domain"] = domain
        if bbox:
            q += " AND ST_Within(current_pos, ST_MakeEnvelope(:x1,:y1,:x2,:y2,4326))"
            params.update({"x1": bbox[0], "y1": bbox[1], "x2": bbox[2], "y2": bbox[3]})
        q += " ORDER BY last_seen DESC LIMIT 50000"
        rows = (await db.execute(text(q), params)).fetchall()

    if fmt == "geojson":
        return _entities_to_geojson(rows)
    elif fmt == "kml":
        return _entities_to_kml(rows)
    else:
        return _entities_to_csv(rows)

def _entities_to_geojson(rows) -> bytes:
    features = []
    for r in rows:
        if r.cu
```

```python
rrent_lat is None:
            continue
        feat = geojson_lib.Feature(
            geometry=geojson_lib.Point((r.current_lon, r.current_lat)),
            properties={
                "uuid":              r.uuid,
                "domain":            r.domain,
                "domain_key":        r.domain_key,
                "display_name":      r.display_name,
                "confidence":        r.confidence,
                "anomaly_score":     r.anomaly_score,
                "last_seen":         r.last_seen.isoformat() if r.last_seen else None,
                "observation_count": r.observation_count,
                "atlas_tags":        r.atlas_tags or [],
                **(r.metadata or {}),
            }
        )
        features.append(feat)
    fc = geojson_lib.FeatureCollection(features)
    return geojson_lib.dumps(fc, sort_keys=True).encode()

def _entities_to_kml(rows) -> bytes:
    kml = simplekml.Kml()
    domain_folders: dict[str, simplekml.Folder] = {}

    for r in rows:
        if r.current_lat is None:
            continue
        folder_name = r.domain.title()
        if folder_name not in domain_folders:
            domain_folders[folder_name] = kml.newfolder(name=folder_name)
        folder = domain_folders[folder_name]

        pnt = folder.newpoint(
            name=r.display_name or r.domain_key,
            coords=[(r.current_lon, r.current_lat)],
        )
        desc_lines = [
            f"UUID: {r.uuid}",
            f"Domain: {r.domain}",
            f"Confidence: {r.confidence:.2f}",
            f"Last seen: {r.last_seen.isoformat() if r.last_seen else 'N/A'}",
            f"Observations: {r.observation_count}",
        ]
        if r.anomaly_score is not None:
            desc_lines.append(f"Anomaly score: {r.anomaly_score:.4f}
```

```python
")
        if r.atlas_tags:
            desc_lines.append(f"ATLAS tags: {', '.join(r.atlas_tags)}")
        pnt.description = "\n".join(desc_lines)

        # Color by confidence: green → yellow → red
        if r.confidence >= 0.7:
            pnt.style.iconstyle.color = simplekml.Color.green
        elif r.confidence >= 0.4:
            pnt.style.iconstyle.color = simplekml.Color.yellow
        else:
            pnt.style.iconstyle.color = simplekml.Color.red

    return kml.kml().encode()

def _entities_to_csv(rows) -> bytes:
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=[
        "uuid", "domain", "domain_key", "display_name",
        "lat", "lon", "confidence", "anomaly_score",
        "last_seen", "observation_count", "atlas_tags",
    ])
    writer.writeheader()
    for r in rows:
        writer.writerow({
            "uuid":              r.uuid,
            "domain":            r.domain,
            "domain_key":        r.domain_key,
            "display_name":      r.display_name or "",
            "lat":               r.current_lat,
            "lon":               r.current_lon,
            "confidence":        round(r.confidence, 4),
            "anomaly_score":     round(r.anomaly_score, 4) if r.anomaly_score else "",
            "last_seen":         r.last_seen.isoformat() if r.last_seen else "",
            "observation_count": r.observation_count,
            "atlas_tags":        "|".join(r.atlas_tags or []),
        })
    return buf.getvalue().encode()

async def export_entity_trail(entity_uuid: str, fmt: ExportFormat, hours: int = 24) -> bytes:
    """Export full observation history for a single entity as KML track or GeoJSON LineString."""
    async with get_db_session() as db:
        rows = (await db.execute(text("""
         
```

```python
   SELECT ts, lat, lon, metadata
            FROM observations
            WHERE entity_uuid = :uuid AND ts >= NOW() - INTERVAL ':h hours'
            ORDER BY ts ASC
        """), {"uuid": entity_uuid, "h": hours})).fetchall()

    coords = [(float(r.lon), float(r.lat)) for r in rows if r.lat and r.lon]
    if not coords:
        return b"{}"

    if fmt == "geojson":
        fc = geojson_lib.FeatureCollection([
            geojson_lib.Feature(
                geometry=geojson_lib.LineString(coords),
                properties={"entity_uuid": entity_uuid, "hours": hours, "point_count": len(coords)}
            )
        ])
        return geojson_lib.dumps(fc).encode()

    elif fmt == "kml":
        kml = simplekml.Kml()
        track = kml.newlinestring(name=f"Track: {entity_uuid[:8]}")
        track.coords = coords
        track.style.linestyle.color = simplekml.Color.cyan
        track.style.linestyle.width = 2
        return kml.kml().encode()

    else:  # csv
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=["ts", "lat", "lon"])
        writer.writeheader()
        for r in rows:
            writer.writerow({"ts": r.ts.isoformat(), "lat": r.lat, "lon": r.lon})
        return buf.getvalue().encode()
```

---

### Webhook Delivery Engine

```python
# oobe/services/webhook_service.py
"""
Webhook delivery with:
  - HMAC-SHA256 payload signing (X-OOBE-Signature header)
  - Exponential backoff retry: 1m, 5m, 15m, 1h, 4h (5 attempts max)
  - Dead-letter after 5 failures (status = EXHAUSTED)
  - Delivery log in webhook_deliveries table
  - Celery task for async dispatch + retry sweep
"""
import hashlib, hmac, json, time, logging, os
from datetime import datetime, timedelta, timezone
import httpx
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from sqlalchemy import text
from ..db import get_sync_db_session

logger = logging.getLogger(__name__)

RETRY_DELAYS_MINUTES = [1, 5, 15, 60, 240]   # 5 attempts
WEBHOOK_TIMEOUT_S = 10
SIGNING_SECRET = os.environ.get("WEBHOOK_SIGNING_SECRET", "change-me-in-production")

def sign_payload(payload: str) -> str:
    """HMAC-SHA256 signature for webhook payload verification."""
    return "sha256=" + hmac.new(
        SIGNING_SECRET.encode(),
        payload.encode(),
        hashlib.sha256,
    ).hexdigest()

def dispatch_alert_webhook(alert_uuid: str, org_id: str, webhook_url: str, alert_data: dict):
    """
    Called immediately when an alert triggers.
    Creates delivery record and attempts first delivery.
    Subsequent retries handled by Celery beat task.
    """
    payload = json.dumps({
        "event":       "alert.triggered",
        "alert":       alert_data,
        "timestamp":   datetime.now(timezone.utc).isoformat(),
        "oobe_version": "2.0",
    })
    signature = sign_payload(payload)

    with get_sync_db_session() as db:
        result = db.execute(text("""
            INSERT INTO webhook_deliveries
                (alert_uuid, org_id, webhook_url, status, attempt_count, created_at)
            VALUES (:alert, :org, :u
```

```python
rl, 'PENDING', 0, NOW())
            RETURNING uuid
        """), {"alert": alert_uuid, "org": org_id, "url": webhook_url})
        delivery_uuid = result.fetchone().uuid
        db.commit()

    _attempt_delivery(str(delivery_uuid), webhook_url, payload, signature)

def _attempt_delivery(delivery_uuid: str, url: str, payload: str, signature: str):
    try:
        with httpx.Client(timeout=WEBHOOK_TIMEOUT_S) as client:
            resp = client.post(
                url,
                content=payload,
                headers={
                    "Content-Type":      "application/json",
                    "X-OOBE-Signature":  signature,
                    "X-OOBE-Delivery":   delivery_uuid,
                    "User-Agent":        "OOBE-Webhooks/2.0",
                },
            )
        success = 200 <= resp.status_code < 300
        status  = "SUCCESS" if success else "FAILED"
        _update_delivery(delivery_uuid, status, resp.status_code, resp.text[:500])
        if not success:
            _schedule_retry(delivery_uuid)

    except Exception as e:
        logger.warning(f"Webhook delivery failed [{delivery_uuid}]: {e}")
        _update_delivery(delivery_uuid, "FAILED", None, str(e)[:500])
        _schedule_retry(delivery_uuid)

def _update_delivery(delivery_uuid: str, status: str, code: int | None, body: str):
    with get_sync_db_session() as db:
        db.execute(text("""
            UPDATE webhook_deliveries SET
                status = :status,
                response_code = :code,
                response_body = :body,
                last_attempt_at = NOW(),
                attempt_count = attempt_count + 1
            WHERE uuid = :uuid
        """), {"status": status, "code": code, "body": body, "uuid": delivery_uuid})
        db.commit()

def _
```

```python
schedule_retry(delivery_uuid: str):
    with get_sync_db_session() as db:
        row = db.execute(text("""
            SELECT attempt_count FROM webhook_deliveries WHERE uuid = :uuid
        """), {"uuid": delivery_uuid}).fetchone()

    if not row:
        return

    attempt = row.attempt_count
    if attempt >= len(RETRY_DELAYS_MINUTES):
        with get_sync_db_session() as db:
            db.execute(text("""
                UPDATE webhook_deliveries SET status = 'EXHAUSTED' WHERE uuid = :uuid
            """), {"uuid": delivery_uuid})
            db.commit()
        logger.warning(f"Webhook {delivery_uuid} exhausted after {attempt} attempts")
        return

    delay_min = RETRY_DELAYS_MINUTES[attempt - 1]
    next_retry = datetime.now(timezone.utc) + timedelta(minutes=delay_min)
    with get_sync_db_session() as db:
        db.execute(text("""
            UPDATE webhook_deliveries
            SET next_retry_at = :next, status = 'FAILED'
            WHERE uuid = :uuid
        """), {"next": next_retry, "uuid": delivery_uuid})
        db.commit()

def retry_pending_deliveries():
    """Called every 2 minutes by Celery beat task."""
    with get_sync_db_session() as db:
        rows = db.execute(text("""
            SELECT uuid, webhook_url
            FROM webhook_deliveries
            WHERE status IN ('PENDING', 'FAILED')
              AND next_retry_at <= NOW()
            ORDER BY next_retry_at ASC
            LIMIT 50
        """)).fetchall()

    for row in rows:
        # Re-fetch payload from alert
        with get_sync_db_session() as db:
            delivery = db.execute(text("""
                SELECT d.uuid, d.webhook_url, a.uuid as alert_uuid
                FROM webhook_deliveries d
                JOIN alerts a ON a.uuid = d.alert_uuid
             
```

```python
   WHERE d.uuid = :uuid
            """), {"uuid": row.uuid}).fetchone()

        if delivery:
            payload = json.dumps({"event": "alert.retry", "alert_uuid": str(delivery.alert_uuid)})
            sig = sign_payload(payload)
            _attempt_delivery(str(row.uuid), row.webhook_url, payload, sig)
```

---

## Week 12: Analyst Notes + Multi-Tenant Workspace Enforcement

### Deliverables checklist

- [ ]  Analyst notes CRUD API: `POST/GET/PATCH/DELETE /v1/entities/{uuid}/notes`
- [ ]  Tags on notes: free-text tags for analyst workflow classification
- [ ]  PostgreSQL Row-Level Security policies for all data tables
- [ ]  Workspace settings API: `GET/PATCH /v1/workspace/settings`
- [ ]  Plan enforcement middleware: check entity/alert limits on every write
- [ ]  Workspace member invitations: `POST /v1/workspace/invite`
- [ ]  Frontend: notes panel in entity sidebar (textarea + tag input + list)
- [ ]  20 tests covering RLS isolation (ensure org A cannot read org B's data)

**Acceptance criteria:** Two independent test organizations' data is fully isolated at the API layer. Plan limits enforced: creating entity #101 on free tier returns 429. Notes created by user A are visible to user B in the same org but not to org C.

---

### Row-Level Security Policies

```sql
-- migrations/versions/0003_rls_policies.sql
-- Run AFTER 0002; enables per-org data isolation at the PostgreSQL level

-- Enable RLS on all sensitive tables
ALTER TABLE entities          ENABLE ROW LEVEL SECURITY;
ALTER TABLE events            ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts            ENABLE ROW LEVEL SECURITY;
ALTER TABLE alert_rules       ENABLE ROW LEVEL SECURITY;
ALTER TABLE entity_notes      ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_deliveries ENABLE ROW LEVEL SECURITY;

-- Entities: org sees only its own
CREATE POLICY org_isolation_entities ON entities
    USING (org_id = current_setting('app.current_org_id', TRUE)::uuid);

CREATE POLICY org_isolation_events ON events
    USING (org_id = current_setting('app.current_org_id', TRUE)::uuid);

CREATE POLICY org_isolation_alerts ON alerts
    USING (org_id = current_setting('app.current_org_id', TRUE)::uuid);

CREATE POLICY org_isolation_alert_rules ON alert_rules
    USING (org_id = current_setting('app.current_org_id', TRUE)::uuid);

CREATE POLICY org_isolation_notes ON entity_notes
    USING (org_id = current_setting('app.current_org_id', TRUE)::uuid);

CREATE POLICY org_isolation_webhooks ON webhook_deliveries
    USING (org_id = current_setting('app.current_org_id', TRUE)::uuid);

-- Service-level override for Celery workers (bypass RLS for system tasks)
-- Create a dedicated DB role for Celery that bypasses RLS
CREATE ROLE oobe_system BYPASSRLS;
-- Celery workers connect with DATABASE_URL_SYSTEM (separate credentials)
```

```python
# oobe/db/rls_middleware.py
"""
FastAPI middleware that sets the PostgreSQL session variable
app.current_org_id for every request, enabling RLS policies.
"""
from fastapi import Request
from sqlalchemy import text
from ..db import get_db_session

async def set_rls_context(request: Request, call_next):
    """
    Must run AFTER auth middleware (which populates request.state.org_id).
    Sets PostgreSQL session variable so RLS policies take effect.
    """
    response = await call_next(request)
    return response

# In the database session context manager, inject org context:
async def get_rls_session(org_id: str):
    """Use this session factory for all user-facing queries."""
    async with get_db_session() as db:
        await db.execute(
            text("SET LOCAL app.current_org_id = :org_id"),
            {"org_id": str(org_id)}
        )
        yield db
```

---

### Analyst Notes API Endpoints

```python
# oobe/routers/notes.py
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import text
from typing import Optional
from uuid import UUID
from ..auth import get_current_user
from ..db import get_rls_session

router = APIRouter(prefix="/v1/entities/{entity_uuid}/notes", tags=["notes"])

class NoteCreate(BaseModel):
    content: str
    tags: list[str] = []

class NoteUpdate(BaseModel):
    content: Optional[str] = None
    tags: Optional[list[str]] = None

@router.post("", status_code=status.HTTP_201_CREATED)
async def create_note(
    entity_uuid: str,
    body: NoteCreate,
    user=Depends(get_current_user),
):
    if len(body.content.strip()) < 2:
        raise HTTPException(400, "Note content must be at least 2 characters")
    if len(body.content) > 10000:
        raise HTTPException(400, "Note content exceeds 10,000 character limit")

    async with get_rls_session(user.org_id) as db:
        # Verify entity belongs to this org
        exists = (await db.execute(text(
            "SELECT 1 FROM entities WHERE uuid = :uuid LIMIT 1"
        ), {"uuid": entity_uuid})).fetchone()
        if not exists:
            raise HTTPException(404, "Entity not found")

        result = await db.execute(text("""
            INSERT INTO entity_notes (entity_uuid, org_id, author_id, content, tags)
            VALUES (:entity, :org, :author, :content, :tags)
            RETURNING uuid, created_at
        """), {
            "entity":  entity_uuid,
            "org":     str(user.org_id),
            "author":  str(user.id),
            "content": body.content.strip(),
            "tags":    body.tags,
        })
        await db.commit()
        row = result.fetchone()

    return {"uuid": str(row.uuid), "created_at": row.crea
```

```python
ted_at.isoformat()}

@router.get("")
async def list_notes(
    entity_uuid: str,
    user=Depends(get_current_user),
):
    async with get_rls_session(user.org_id) as db:
        rows = (await db.execute(text("""
            SELECT n.uuid, n.content, n.tags, n.created_at, n.updated_at,
                   n.author_id
            FROM entity_notes n
            WHERE n.entity_uuid = :entity
            ORDER BY n.created_at DESC
            LIMIT 100
        """), {"entity": entity_uuid})).fetchall()

    return {
        "notes": [
            {
                "uuid":       str(r.uuid),
                "content":    r.content,
                "tags":       r.tags or [],
                "author_id":  str(r.author_id) if r.author_id else None,
                "created_at": r.created_at.isoformat(),
                "updated_at": r.updated_at.isoformat(),
            }
            for r in rows
        ]
    }

@router.patch("/{note_uuid}")
async def update_note(
    entity_uuid: str,
    note_uuid: UUID,
    body: NoteUpdate,
    user=Depends(get_current_user),
):
    updates = {}
    if body.content is not None:
        updates["content"] = body.content.strip()
    if body.tags is not None:
        updates["tags"] = body.tags
    if not updates:
        raise HTTPException(400, "No fields to update")

    set_clause = ", ".join(
        f"{k} = :{k}" for k in updates
    ) + ", updated_at = NOW()"

    async with get_rls_session(user.org_id) as db:
        result = await db.execute(text(f"""
            UPDATE entity_notes
            SET {set_clause}
            WHERE uuid = :note_uuid AND entity_uuid = :entity_uuid
            RETURNING uuid
        """), {**updates, "note_uuid": str(note_uuid), "entity_uuid": entity_uuid})
        await db.commit()
        if not resul
```

```python
t.fetchone():
            raise HTTPException(404, "Note not found")

    return {"status": "updated"}

@router.delete("/{note_uuid}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_note(
    entity_uuid: str,
    note_uuid: UUID,
    user=Depends(get_current_user),
):
    async with get_rls_session(user.org_id) as db:
        await db.execute(text("""
            DELETE FROM entity_notes WHERE uuid = :note_uuid AND entity_uuid = :entity
        """), {"note_uuid": str(note_uuid), "entity": entity_uuid})
        await db.commit()
```

---

### Plan Enforcement Middleware

```python
# oobe/middleware/plan_limits.py
"""
Enforces per-plan limits on entity creation, alert creation, and active domains.
Returns 429 with a clear message when limits are exceeded.
"""
from fastapi import Request, HTTPException
import redis.asyncio as aioredis
from ..db import get_redis

PLAN_LIMITS = {
    "free":       {"entities": 100,    "alerts": 10,   "domains": 2},
    "pro":        {"entities": 2000,   "alerts": 100,  "domains": 10},
    "enterprise": {"entities": 999999, "alerts": 9999, "domains": 10},
}

async def check_entity_limit(org_id: str, plan: str) -> None:
    r: aioredis.Redis = await get_redis()
    count_key = f"org:{org_id}:entity_count"
    count = await r.get(count_key)
    if count is None:
        from ..db import get_db_session
        from sqlalchemy import text
        async with get_db_session() as db:
            row = (await db.execute(text(
                "SELECT COUNT(*) FROM entities WHERE org_id = :org"
            ), {"org": org_id})).fetchone()
        count = int(row[0])
        await r.setex(count_key, 300, str(count))  # Cache 5 min
    else:
        count = int(count)

    limit = PLAN_LIMITS.get(plan, PLAN_LIMITS["free"])["entities"]
    if count >= limit:
        raise HTTPException(
            status_code=429,
            detail={
                "error":    "entity_limit_exceeded",
                "message":  f"Your {plan} plan allows {limit} entities. Upgrade at /billing.",
                "current":  count,
                "limit":    limit,
            }
        )
```

---

## Week 13: Pilot Recruitment + Onboarding Flow

### Deliverables checklist

- [ ]  Onboarding wizard: 4-step frontend flow (domain selection → AOI bbox → first alert rule → invite)
- [ ]  PostHog instrumentation: track `wizard_step_completed`, `entity_clicked`, `alert_created`, `export_downloaded`
- [ ]  Pilot outreach pack (email templates + OOBE value proposition one-pager)
- [ ]  Sandbox org: pre-seeded demo data (48h of cached entity history) for prospects
- [ ]  In-app feedback widget: thumbs up/down on alerts + 1–5 star on PoL accuracy
- [ ]  Error boundary: frontend catches and Sentry-reports any map render crash
- [ ]  First 5 pilot accounts provisioned manually with Pro plan (no payment required)

**Target pilot profile:** 1× maritime OSINT analyst, 1× conflict researcher (ACLED user), 1× aviation OSINT (e.g. Flightradar24 power user), 1× journalist (conflict verification), 1× humanitarian coordinator (OCHA-adjacent).

---

### Onboarding Wizard (Frontend JS module)

```jsx
// oobe-frontend/js/onboarding.js
/**
 * 4-step onboarding wizard shown to new users on first login.
 * Stored completion state in localStorage; auto-dismissed after step 4.
 * Integrates with PostHog for funnel tracking.
 */

const WIZARD_STEPS = [
  {
    id: "domains",
    title: "Choose your intelligence domains",
    description: "Select which live data feeds to activate. You can change this later.",
    render: renderDomainSelector,
  },
  {
    id: "aoi",
    title: "Draw your Area of Interest",
    description: "Draw a rectangle on the map. OOBE will prioritize entities in this region.",
    render: renderAoiDrawTool,
  },
  {
    id: "first_alert",
    title: "Set up your first alert",
    description: "Get notified when an entity enters your AoI or exhibits anomalous behaviour.",
    render: renderAlertRuleBuilder,
  },
  {
    id: "invite",
    title: "Invite a teammate",
    description: "OOBE is more powerful with multiple analysts. Add a colleague.",
    render: renderInviteForm,
  },
];

class OnboardingWizard {
  constructor(apiClient, posthog) {
    this.api = apiClient;
    this.ph = posthog;
    this.currentStep = 0;
    this.state = {};
  }

  async init() {
    const completed = localStorage.getItem("oobe_onboarding_done");
    if (completed) return;
    this.render();
  }

  render() {
    const step = WIZARD_STEPS[this.currentStep];
    const overlay = document.getElementById("onboarding-overlay");
    overlay.innerHTML = `
      <div class="wizard-modal">
        <div class="wizard-progress">
          Step ${this.currentStep + 1} of ${WIZARD_STEPS.length}
          <div class="progress-bar">
            <div class="progress-fill" style="width:${((this.currentStep+1)/WIZARD_STEPS.length)*100}%"></div>
          </div>
        </div>
        <h2>$
```

```jsx
{step.title}</h2>
        <p>${step.description}</p>
        <div id="wizard-step-content"></div>
        <div class="wizard-actions">
          ${this.currentStep > 0 ? '<button onclick="wizard.prev()">← Back</button>' : ''}
          <button onclick="wizard.skip()" class="btn-secondary">Skip</button>
          <button onclick="wizard.next()" class="btn-primary">
            ${this.currentStep === WIZARD_STEPS.length - 1 ? "Finish" : "Next →"}
          </button>
        </div>
      </div>
    `;
    overlay.style.display = "flex";
    step.render(document.getElementById("wizard-step-content"), this.state);
    this.ph?.capture("wizard_step_viewed", { step: step.id, step_number: this.currentStep + 1 });
  }

  async next() {
    const step = WIZARD_STEPS[this.currentStep];
    try {
      await this._saveStepData(step.id);
      this.ph?.capture("wizard_step_completed", { step: step.id });
    } catch (e) {
      console.warn("Step save failed:", e);
    }
    if (this.currentStep < WIZARD_STEPS.length - 1) {
      this.currentStep++;
      this.render();
    } else {
      this._complete();
    }
  }

  prev() {
    if (this.currentStep > 0) {
      this.currentStep--;
      this.render();
    }
  }

  skip() {
    this.ph?.capture("wizard_skipped", { at_step: WIZARD_STEPS[this.currentStep].id });
    this._complete();
  }

  _complete() {
    localStorage.setItem("oobe_onboarding_done", "true");
    document.getElementById("onboarding-overlay").style.display = "none";
    this.ph?.capture("wizard_completed");
  }

  async _saveStepData(stepId) {
    if (stepId === "domains" && this.state.selectedDomains) {
      await this.api.patch("/v1/workspace/settings", {
        active_domains: this.state.selectedDomains,
      });
    }
    if (stepId === "aoi" && this.state.
```

```jsx
aoiBbox) {
      await this.api.post("/v1/alerts/rules", {
        name: "My Area of Interest",
        rule_type: "GEOFENCE",
        domains: this.state.selectedDomains || ["aviation", "maritime"],
        geofence_bbox: this.state.aoiBbox,
        severity: "MEDIUM",
      });
    }
  }
}
```

---

### Pilot Alert Feedback Widget

```python
# oobe/routers/feedback.py
"""
Lightweight analyst feedback on alerts and PoL accuracy.
Data feeds directly into Phase 3 model improvement loop.
"""
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy import text
from typing import Literal
from ..auth import get_current_user
from ..db import get_db_session

router = APIRouter(prefix="/v1/feedback", tags=["feedback"])

class AlertFeedback(BaseModel):
    alert_uuid: str
    rating: Literal["accurate", "inaccurate", "unsure"]
    comment: str = ""

class PolFeedback(BaseModel):
    entity_uuid: str
    anomaly_score: float
    analyst_verdict: Literal["true_positive", "false_positive", "unsure"]
    comment: str = ""

@router.post("/alert")
async def submit_alert_feedback(body: AlertFeedback, user=Depends(get_current_user)):
    async with get_db_session() as db:
        await db.execute(text("""
            INSERT INTO analyst_feedback
                (feedback_type, ref_uuid, org_id, author_id, rating, comment, created_at)
            VALUES ('alert', :ref, :org, :author, :rating, :comment, NOW())
            ON CONFLICT DO NOTHING
        """), {
            "ref": body.alert_uuid, "org": str(user.org_id),
            "author": str(user.id), "rating": body.rating,
            "comment": body.comment[:1000],
        })
        await db.commit()
    return {"status": "received"}

@router.post("/anomaly")
async def submit_pol_feedback(body: PolFeedback, user=Depends(get_current_user)):
    async with get_db_session() as db:
        await db.execute(text("""
            INSERT INTO analyst_feedback
                (feedback_type, ref_uuid, org_id, author_id, rating, comment,
                 anomaly_score, created_at)
            VALUES ('anomaly', :ref, :org, :author, :verdict, :comment, 
```

```python
:score, NOW())
        """), {
            "ref": body.entity_uuid, "org": str(user.org_id),
            "author": str(user.id), "verdict": body.analyst_verdict,
            "comment": body.comment[:1000], "score": body.anomaly_score,
        })
        await db.commit()
    return {"status": "received"}
```

---

## Week 14: Performance Sprint + Pilot Feedback Synthesis

### Deliverables checklist

- [ ]  Run `EXPLAIN ANALYZE` on top 5 heaviest queries; implement fixes
- [ ]  Redis cache strategy audit: add entity position cache to cut DB reads by 60%+
- [ ]  Load test: Locust script, 50 concurrent users, 10 min sustained
- [ ]  Pilot feedback interview notes synthesized into Phase 3 backlog
- [ ]  Performance results documented with before/after metrics

---

### Critical Query Optimizations

```sql
-- PROBLEM 1: Geospatial entity list query scanning full table
-- BEFORE: ~200ms for 50k entities
EXPLAIN ANALYZE
SELECT uuid, domain, current_lat, current_lon FROM entities
WHERE ST_DWithin(current_pos, ST_MakePoint(-0.1, 51.5)::geography, 500000)
AND confidence > 0.3;

-- FIX: Ensure these indexes exist (should be from migration 0001, verify)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_entities_pos_conf
ON entities USING GIST(current_pos)
WHERE confidence > 0.0;  -- Partial index excludes expired entities

-- Rewrite query using ST_Within on bounding box first (faster), then precise filter
SELECT uuid, domain, current_lat, current_lon, confidence
FROM entities
WHERE current_pos && ST_Expand(ST_MakePoint(-0.1, 51.5)::geography, 500000)
  AND ST_DWithin(current_pos, ST_MakePoint(-0.1, 51.5)::geography, 500000)
  AND confidence > 0.3;
-- Target: < 20ms for 50k entities with bbox filter

-- PROBLEM 2: Observation history query for entity timeline (no index on entity+time)
-- BEFORE: ~500ms for 10k observations
EXPLAIN ANALYZE
SELECT ts, lat, lon FROM observations
WHERE entity_uuid = 'abc123' AND ts > NOW() - INTERVAL '24 hours'
ORDER BY ts DESC;

-- FIX: TimescaleDB partial index (created in 0001 but verify it exists)
-- TimescaleDB creates per-chunk indexes automatically; verify chunk_time_interval
SELECT chunk_schema, chunk_name, range_start, range_end
FROM timescaledb_information.chunks
WHERE hypertable_name = 'observations'
ORDER BY range_start DESC LIMIT 5;
-- Target: < 10ms for last 24h of a single entity

-- PROBLEM 3: Alert listing with unacknowledged filter
-- BEFORE: Sequential scan on alerts table
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_alerts_org_ack_ts
ON alerts(org_id, acknowledged, created_at DESC)
INCLUDE (alert_type, severity, title);
-- This is a cov
```

```sql
ering index — the INCLUDE columns avoid a table heap fetch
-- Target: < 5ms for listing 50 recent alerts per org

-- PROBLEM 4: Neo4j PROXIMITY query — N+1 pattern
-- BEFORE: Separate Neo4j query per entity on map load
-- FIX: Batch query using UNWIND
-- In Python: send list of entity UUIDs, retrieve all relationships in one call
-- UNWIND $uuids AS uuid
-- MATCH (e:Entity {uuid: uuid})-[r:PROXIMITY]->(other:Entity)
-- WHERE r.lastSeen > datetime() - duration({hours: 24})
-- RETURN uuid, collect({related: other.uuid, dist: r.distKm, ts: r.lastSeen}) AS rels

-- PROBLEM 5: TTL decay Celery task updating all entities one-by-one
-- BEFORE: 50k UPDATE statements per 30s cycle
-- FIX: Single bulk UPDATE using time arithmetic
UPDATE entities
SET confidence = GREATEST(0.0,
    1.0 - EXTRACT(EPOCH FROM (NOW() - last_seen)) / ttl_seconds
)
WHERE last_seen > NOW() - INTERVAL '48 hours'  -- Only recently active entities
  AND ttl_seconds > 0;
-- Target: < 100ms for 50k entities in single statement
```

---

### Redis Cache Strategy for Phase 2

```python
# oobe/cache/entity_cache.py
"""
Redis caching layer to reduce PostgreSQL load at scale.
Phase 2 target: serve 80% of entity position requests from Redis.

Cache strategy:
  - Entity current state: Hash at key entity:{uuid}:state
    Fields: lat, lon, confidence, display_name, domain, last_seen
    TTL: entity's domain TTL (auto-expires with entity confidence)

  - Org entity list: Sorted set at key org:{org_id}:{domain}:entities
    Score: last_seen timestamp (for ordering)
    Members: entity UUIDs
    TTL: 60 seconds (short, refreshed on entity upsert)

  - Entity count per org: String at key org:{org_id}:entity_count
    TTL: 300 seconds (5 min, refreshed on entity create/delete)
"""
import json
import redis.asyncio as aioredis
from datetime import datetime

async def cache_entity_state(r: aioredis.Redis, entity: dict):
    """Called after every entity upsert."""
    key = f"entity:{entity['uuid']}:state"
    state = {
        "lat":         str(entity.get("current_lat", "")),
        "lon":         str(entity.get("current_lon", "")),
        "confidence":  str(entity.get("confidence", 1.0)),
        "display_name": entity.get("display_name", ""),
        "domain":      entity.get("domain", ""),
        "last_seen":   entity.get("last_seen", datetime.utcnow().isoformat()),
        "anomaly_score": str(entity.get("anomaly_score", "")),
    }
    pipe = r.pipeline()
    pipe.hset(key, mapping=state)
    pipe.expire(key, entity.get("ttl_seconds", 600) * 2)
    # Update org sorted set
    org_key = f"org:{entity['org_id']}:{entity['domain']}:entities"
    last_seen_ts = datetime.fromisoformat(
        entity["last_seen"].replace("Z", "+00:00")
    ).timestamp() if isinstance(entity["last_seen"], str) else entity["last_seen"].timestamp()
    pipe.zadd(org_key, {entity["u
```

```python
uid"]: last_seen_ts})
    pipe.expire(org_key, 60)
    await pipe.execute()

async def get_entity_state(r: aioredis.Redis, entity_uuid: str) -> dict | None:
    """Returns cached state or None (caller falls back to DB)."""
    key = f"entity:{entity_uuid}:state"
    state = await r.hgetall(key)
    if not state:
        return None
    return {k.decode(): v.decode() for k, v in state.items()}

async def get_org_entity_uuids(
    r: aioredis.Redis,
    org_id: str,
    domain: str,
    limit: int = 1000,
) -> list[str]:
    """Returns list of entity UUIDs for an org+domain, ordered by recency."""
    key = f"org:{org_id}:{domain}:entities"
    members = await r.zrevrange(key, 0, limit - 1)
    return [m.decode() for m in members]
```

---

### Locust Load Test

```python
# tests/load/locustfile.py
"""
Run: locust -f tests/load/locustfile.py --host=https://your-railway-app.up.railway.app
Target: 50 users, 10 minutes, p95 < 200ms
"""
from locust import HttpUser, task, between
import random

TEST_API_KEY = "your-test-api-key-here"
TEST_ENTITY_UUIDS = []   # Pre-populated before test run

class OobeAnalystUser(HttpUser):
    wait_time = between(1, 5)
    headers = {"X-API-Key": TEST_API_KEY}

    def on_start(self):
        # Fetch some entity UUIDs on login for use in subsequent tasks
        r = self.client.get(
            "/v1/entities?domain=aviation&limit=20",
            headers=self.headers,
        )
        if r.status_code == 200:
            data = r.json()
            TEST_ENTITY_UUIDS.extend(
                [e["uuid"] for e in data.get("entities", [])]
            )

    @task(5)
    def list_entities(self):
        domains = ["aviation", "maritime", "conflict"]
        domain = random.choice(domains)
        self.client.get(
            f"/v1/entities?domain={domain}&limit=100&min_confidence=0.3",
            headers=self.headers,
            name="/v1/entities?domain=[domain]",
        )

    @task(3)
    def get_entity_detail(self):
        if TEST_ENTITY_UUIDS:
            uuid = random.choice(TEST_ENTITY_UUIDS)
            self.client.get(
                f"/v1/entities/{uuid}",
                headers=self.headers,
                name="/v1/entities/[uuid]",
            )

    @task(2)
    def get_entity_history(self):
        if TEST_ENTITY_UUIDS:
            uuid = random.choice(TEST_ENTITY_UUIDS)
            self.client.get(
                f"/v1/entities/{uuid}/history?hours=6",
                headers=self.headers,
                name="/v1/entities/[uuid]/history",
            )

    @task(2)
    def list_alerts(s
```

```python
elf):
        self.client.get(
            "/v1/alerts?limit=50",
            headers=self.headers,
        )

    @task(1)
    def export_geojson(self):
        self.client.get(
            "/v1/export/entities?format=geojson&domain=aviation&min_confidence=0.5",
            headers=self.headers,
            name="/v1/export/entities?format=geojson",
        )

    @task(1)
    def websocket_connect(self):
        # Locust doesn't natively support WebSocket; use separate ws_load.py
        pass
```

---

### Pilot Feedback Synthesis Template

```markdown
# Pilot Interview Template — Week 14

Conduct 30-minute calls with each pilot. Record answers below.
Use verbatim quotes where possible.

## Pilot Profile
- Name / org:
- Role (analyst / journalist / researcher / other):
- Primary use case:
- How many sessions per week:

## Workflow Fit
1. Which domains do you use most? Why?
2. Which entity type generates the most valuable alerts?
3. How do you use the export feature? (format, downstream tool)
4. Do you use analyst notes? If not, why not?

## Pain Points (rank 1–5 by severity)
- [ ] Map performance (markers loading slow)
- [ ] Alert noise (too many false positives)
- [ ] TTL too aggressive (entities expiring too fast)
- [ ] TTL too loose (stale data showing as confident)
- [ ] Missing feed domain: ________
- [ ] Entity sidebar missing field: ________
- [ ] Other: ________

## Pattern-of-Life Accuracy
1. Review 5 ANOMALY alerts together. Analyst marks each: TP / FP / Unsure.
   Record verdicts here:
   Alert 1: ___ Alert 2: ___ Alert 3: ___ Alert 4: ___ Alert 5: ___

2. Are loitering alerts accurate for your domain?
3. Are course deviation alerts signal or noise?

## Feature Requests (unprompted — ask "what would make this 10x more useful?")
1.
2.
3.

## NPS
"On a scale of 0–10, how likely are you to recommend OOBE to a colleague?"
Score: ___
Why: ___________

## Phase 3 Priority Vote
Rank these features 1–5 (1=most wanted):
- [ ] Stripe payment + self-serve signup
- [ ] ATLAS threat overlay on map
- [ ] Image provenance verification (C2PA)
- [ ] Custom feed adapter (bring your own data)
- [ ] Mobile-optimized frontend
```

---

## Phase 2 Final Acceptance Criteria

All of the following must pass before Phase 3 work begins:

| Criterion | Target | Test Method |

|-----------|--------|------------|

| All 10 feed domains live | ✅ All green in `/health` | Manual check post-deploy |

| Entity persistence rate | >99.5% over 48h | Grafana: upsert success rate panel |

| Alert latency | p99 <5s from feed event to WebSocket push | Prometheus histogram |

| Map render time | 500 entities in <500ms | Chrome DevTools Perf tab |

| PoL models trained | ≥2 active models in `pol_models` | DB query |

| Loitering alert | Fires within 25min of simulated loiter | Integration test |

| Cross-cue validator | Holds single-source entities at ≤0.7 | Pytest unit test |

| RLS isolation | Org A cannot read Org B's data | Pytest isolation test |

| Plan limits | Free tier entity #101 returns 429 | Pytest |

| Webhook delivery | First attempt within 10s; 5-retry exhaustion confirmed | Integration test |

| GeoJSON export | Round-trips through QGIS import without error | Manual QA |

| KML export | Opens in Google Earth without error | Manual QA |

| Pilot users | ≥3 users active 2+ consecutive weeks | PostHog dashboard |

| Load test | p95 < 200ms at 50 concurrent users | Locust report |

| OWASP ZAP | Zero P0/P1 findings | ZAP automated scan |

---

## Updated Docker Compose for Phase 2

```yaml
# Additions/changes to Phase 1 docker-compose.yml

services:
  # Add model storage volume mount to api + celery services
  api:
    volumes:
      - pol_models:/app/pol_models
    environment:
      POL_MODEL_DIR: /app/pol_models
      OPENWEATHERMAP_API_KEY: ${OPENWEATHERMAP_API_KEY}
      AVWX_API_KEY: ${AVWX_API_KEY}
      OPENAQ_API_KEY: ${OPENAQ_API_KEY}  # Optional; free without key
      WEBHOOK_SIGNING_SECRET: ${WEBHOOK_SIGNING_SECRET}
      POSTHOG_API_KEY: ${POSTHOG_API_KEY}

  celery-worker:
    volumes:
      - pol_models:/app/pol_models
    environment:
      POL_MODEL_DIR: /app/pol_models
      DATABASE_URL_SYSTEM: ${DATABASE_URL_SYSTEM}  # Bypass-RLS connection

  # Phase 2: Prometheus metrics scraping
  prometheus:
    image: prom/prometheus:v2.55.0
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
      - promdata:/prometheus
    ports:
      - "9090:9090"
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.retention.time=15d'

  grafana:
    image: grafana/grafana:11.4.0
    ports:
      - "3000:3000"
    environment:
      GF_SECURITY_ADMIN_PASSWORD: ${GRAFANA_PASSWORD}
      GF_AUTH_ANONYMOUS_ENABLED: "false"
    volumes:
      - grafanadata:/var/lib/grafana
      - ./monitoring/grafana/provisioning:/etc/grafana/provisioning

volumes:
  pol_models:   # Persistent PoL model storage
  promdata:
  grafanadata:
```

---

## Phase 2 New Environment Variables

```bash
# Add to .env.production

# Phase 2 feeds
OPENWEATHERMAP_API_KEY=your_owm_key        # Required for weather alerts
AVWX_API_KEY=your_avwx_key                # Required for aviation weather
OPENAQ_API_KEY=                           # Optional (rate limits without key)

# Security
WEBHOOK_SIGNING_SECRET=generate-32-char-random-string-here
DATABASE_URL_SYSTEM=postgresql://oobe_system:PASSWORD@postgres:5432/oobe  # Bypass RLS

# Analytics
POSTHOG_API_KEY=phc_your_posthog_key      # Free tier: 1M events/month

# PoL
POL_MODEL_DIR=/app/pol_models

# Monitoring
GRAFANA_PASSWORD=strong-password-here
```

---

## Phase 2 → Phase 3 Transition Checklist

Complete before starting Week 15:

- [ ]  Pilot feedback interviews conducted for all 3–5 pilot users
- [ ]  False positive rate documented for loitering and course deviation detectors
- [ ]  Top 3 feature requests from pilots added to Phase 3 backlog with priority
- [ ]  Load test report saved to `docs/performance/phase2_load_test.md`
- [ ]  OWASP ZAP scan report saved to `docs/security/phase2_zap_report.html`
- [ ]  All Phase 2 acceptance criteria checked and signed off
- [ ]  Railway Pro plan confirmed (prevents plan-pause at 500 free hours)
- [ ]  Stripe account created and `STRIPE_SECRET_KEY` obtained (needed Week 15)
- [ ]  `pol_models` directory backed up externally (S3 or Railway volume snapshot)
- [ ]  `CHANGELOG.md` updated with Phase 2 feature list for investor update