# Project Continuity Summary — All Phases (1–7)

# OOBE Project: Unified Continuity Summary (Phases 1–7)

## From SENTINEL OS to $30M ARR AI-Native Intelligence Platform

---

## 1. Project Overview & Core Vision

OOBE (Open-Source Order-of-Battle Engine) is a real-time situational awareness platform that fuses public OSINT feeds into a live relational knowledge graph.

- **The Gap**: connects isolated feeds (ADS-B, AIS, ACLED, NASA FIRMS) into a coherent temporal picture.
- **The Product**: Entity persistence and behavioral baselines are the core value proposition.

## 2. Technical Architecture & Stack

- **Backend**: FastAPI (Python 3.12), PostgreSQL 16 + PostGIS, Neo4j (Graph), Redis 7 (TTL/Caching), TimescaleDB (Time-series).
- **Frontend**: SENTINEL OS (Leaflet.js) migrating to React.
- **Mobile**: React Native with MapLibre GL.
- **Infrastructure**: AWS (multi-region), FedRAMP Tailored/Moderate.
- **AI/ML**: GLiNER (NER), Helsinki-NLP (Translation), Anthropic Claude (Autonomous Investigation Agent), pgvector.

## 3. Development Roadmap

- **Phase 1**: MVP Prototype (Weeks 1-6).
- **Phase 2**: Pilot (Weeks 7-14).
- **Phase 3**: Production SaaS (Weeks 15-24).
- **Phase 4**: Scale & Enterprise (Months 7-18).
- **Phase 5**: Platform Pivot (Months 19-30).
- **Phase 6**: Global Intelligence Platform (Months 31-42).
- **Phase 7**: AI-Native Intelligence (Months 43-54).

## 4. Security & Adversarial AI (ATLAS)

Integrated the MITRE ATLAS framework to detect and mitigate adversarial machine learning threats (data poisoning, spoofing, etc.). Phase 7 introduces an AI Safety / Responsible AI framework for autonomous agents.

## 5. Phase 6 Highlights

- **Series A**: $5-8M closed.
- **Expansion**: EU data residency, UK government pathway.
- **FedRAMP Moderate**: Compliance for higher-sensitivity government workloads.
- **Network Effects**: Marketplace GMV >$1M, 25+ third-party apps.

## 6. Phase 7 Highlights

- **Series B**: $20-30M closed.
- **Language Layer**: Multilingual NLP (ar, ru, zh, fa, etc.) for non-English source extraction.
- **Joint Entity Model**: Cross-domain fusion engine (aviation + maritime + conflict + linguistic).
- **Investigation Assistant**: Autonomous agentic OSINT investigator with full traceability.
- **PoL V4**: Multi-modal anomaly detection across all 11 active feed domains.
- **Revenue**: Target $30M ARR; Series C readiness.

---

*Generated: April 2026*