# Phase 3 — Production SaaS, Billing & ATLAS

# 🚀 OOBE Phase 3: Production SaaS (Weeks 15–24)

## 1. Goal

Transition to a public, self-serve SaaS with monetization, adversarial AI threat detection, image provenance, and a public API.

## 2. Monetization (Stripe Integration)

- **Plans:** Free, Pro ($200/month), Enterprise (Custom).
- **Billing:** Self-serve signup via Stripe Checkout; metered billing for API usage.
- **Management:** Customer portal for plan upgrades and payment management.

## 3. Security & Multi-tenancy

- **Auth:** Supabase Auth with JWT middleware.
- **API Keys:** Programmatic access with bcrypt-hashed keys and scoping.
- **Isolation:** Row-Level Security (RLS) on all data tables.

## 4. Advanced Intelligence Features

- **ATLAS Threat Overlay:** Mapping observed anomalies to MITRE ATLAS techniques (e.g., data poisoning, entity spoofing).
- **Provenance Sentinel:**

- Image verification via C2PA SDK.

- Reverse image search (TinEye API).

- AI-generated image detection (Hive API).

## 5. Infrastructure Migration

- **Stack:** Migration from Railway to AWS (ECS Fargate, RDS, ElastiCache).
- **Storage:** S3 for PoL models and image uploads.
- **CI/CD:** GitHub Actions for automated testing and deployment to AWS.

---

# ━━━ COMPLETE VERBATIM ENGINEERING SPECIFICATION ━━━

<aside>
📄 Full source: OOBE_Phase3_Spec.md — Weeks 15–24. Includes all Stripe billing logic, ATLAS threat mapping, image provenance code, GraphQL schema, Python SDK, security middleware, and acceptance criteria.

</aside>

# OOBE Phase 3: Production SaaS

## Complete Engineering Specification — Weeks 15–24

### Picks up directly from Phase 2 acceptance criteria

---

## Entry State: Monday Morning, Week 15

Phase 2 delivered a working multi-tenant pilot. Confirmed operational:

Component | Status | Notes

### ATLAS Threat Classifier

```python
# oobe/engine/atlas_classifier.py
"""
Maps OOBE-observed anomalies to MITRE ATLAS adversarial AI techniques.
Each classifier function returns a list of AtlasThreatSignal objects.

The classifier operates on three signal sources:
  1. IsolationForest anomaly scores (from PoL engine)
  2. Feed integrity statistics (volume anomalies, coordinate outliers)
  3. Cross-cue failures (entities never confirmed by second source)

Signal → ATLAS mapping rationale:
  LOITERING aircraft/vessel     → Could be surveillance pattern; mapped to
                                   reconnaissance techniques for awareness.
  FEED_SPIKE (count anomaly)    → AML.T0046 Spamming AI System with Chaff Data
  COORDINATE_SPOOF              → AML.T0043 Craft Adversarial Data
                                   AML.T0088 Generate Deepfakes (synthetic positions)
  SINGLE_SOURCE_ONLY (48h)      → AML.T0097 Virtualization/Sandbox Evasion
                                   (entity evading multi-source detection)
  DATASET_DRIFT (statistical)   → AML.T0059 Erode Dataset Integrity
  SUPPLY_CHAIN_ANOMALY          → AML.T0010 AI Supply Chain Compromise
"""
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional
import logging

logger = logging.getLogger(__name__)

@dataclass
class AtlasThreatSignal:
    technique_id:   str                  # e.g. "AML.T0046"
    technique_name: str
    tactic:         str
    severity:       str                  # LOW | MEDIUM | HIGH | CRITICAL
    entity_uuid:    Optional[str]
    domain:         str
    evidence:       str                  # Human-readable description of the signal
    mitigation_ids: list[str] = field(default_factory=list)
    raw_score:      Optional[float] = None
    detected_at:    datetime = field(default_factory=lambda: datetime.now(timezone.utc))

# Technique registry — pulled from DB at startup, cached in memory
_TECHNIQUE_CACHE: dict[str, dict] = {}

def classify_anomaly(
    anomaly_type: str,
    domain: str,
    entity_uuid: str,
    raw_score: float | None = None,
    context: dict | None = None,
) -> list[AtlasThreatSignal]:
    ctx = context or {}
    signals = []

    if anomaly_type == "FEED_SPIKE":
        signals.append(AtlasThreatSignal(
            technique_id="AML.T0046",
            technique_name="Spamming AI System with Chaff Data",
            tactic="Impact",
            severity=_severity_from_multiplier(ctx.get("spike_multiplier", 2.0)),
            entity_uuid=None,
            domain=domain,
            evidence=(
                f"Feed '{domain}' entity count spiked "
                f"{ctx.get('spike_multiplier', '?')}x above 14-day baseline "
                f"({ctx.get('current_count', '?')} vs expected {ctx.get('baseline_count', '?')}). "
                "May indicate chaff data injection to saturate analysis capacity."
            ),
            mitigation_ids=["AML.M0015", "AML.M0007"],
            raw_score=raw_score,
        ))

    elif anomaly_type == "COORDINATE_SPOOF":
        signals.append(AtlasThreatSignal(
            technique_id="AML.T0043",
            technique_name="Craft Adversarial Data",
            tactic="AI Attack Staging",
            severity="HIGH",
            entity_uuid=entity_uuid,
            domain=domain,
            evidence=(
                f"Entity '{entity_uuid[:8]}...' reported position "
                f"({ctx.get('lat','?'):.3f}, {ctx.get('lon','?'):.3f}) "
                "inconsistent with physical velocity constraints. "
                f"Position jump: {ctx.get('jump_km', '?'):.0f}km in "
                f"{ctx.get('time_delta_s', '?'):.0f}s "
                f"(max physical speed: {ctx.get('max_speed_kt', '?')}kt)."
            ),
            mitigation_ids=["AML.M0015", "AML.M0009"],
        ))
        # Secondary: deepfake signal for vessels (AIS spoofing is a known tactic)
        if domain == "maritime":
            signals.append(AtlasThreatSignal(
                technique_id="AML.T0088",
                technique_name="Generate Deepfakes",
                tactic="AI Attack Staging",
                severity="MEDIUM",
                entity_uuid=entity_uuid,
                domain=domain,
                evidence=(
                    "AIS position spoofing is classified as synthetic data generation "
                    "(ATLAS: Generate Deepfakes). "
                    "Vessel identity and position may be fabricated."
                ),
                mitigation_ids=["AML.M0034", "AML.M0009"],
            ))

    elif anomaly_type == "DATASET_DRIFT":
        signals.append(AtlasThreatSignal(
            technique_id="AML.T0059",
            technique_name="Erode Dataset Integrity",
            tactic="Impact",
            severity=_severity_from_drift(ctx.get("drift_score", 0.5)),
            entity_uuid=None,
            domain=domain,
            evidence=(
                f"Feed '{domain}' statistical distribution has drifted "
                f"{ctx.get('drift_score', '?'):.2f} standard deviations from the 30-day baseline. "
                "Possible gradual poisoning campaign to degrade model reliability over time."
            ),
            mitigation_ids=["AML.M0007", "AML.M0025"],
            raw_score=ctx.get("drift_score"),
        ))

    elif anomaly_type == "SINGLE_SOURCE_PERMANENT":
        signals.append(AtlasThreatSignal(
            technique_id="AML.T0097",
            technique_name="Virtualization/Sandbox Evasion",
            tactic="Defense Evasion",
            severity="MEDIUM",
            entity_uuid=entity_uuid,
            domain=domain,
            evidence=(
                f"Entity '{entity_uuid[:8]}...' has appeared exclusively on one source "
                f"for {ctx.get('hours_single_source', '?')} hours "
                "without independent corroboration. "
                "In adversarial contexts, this pattern may indicate an entity designed "
                "to appear only in single-source feeds."
            ),
            mitigation_ids=["AML.M0009"],
        ))

    elif anomaly_type == "SUPPLY_CHAIN_ANOMALY":
        signals.append(AtlasThreatSignal(
            technique_id="AML.T0010",
            technique_name="AI Supply Chain Compromise",
            tactic="Initial Access",
            severity="CRITICAL",
            entity_uuid=None,
            domain=domain,
            evidence=(
                f"Feed source '{ctx.get('source_url', domain)}' "
                f"responded with unexpected schema change or authentication failure. "
                "May indicate source compromise or man-in-the-middle tampering."
            ),
            mitigation_ids=["AML.M0023", "AML.M0014", "AML.M0013"],
        ))

    return signals

def _severity_from_multiplier(mult: float) -> str:
    if mult >= 5.0: return "CRITICAL"
    if mult >= 3.0: return "HIGH"
    if mult >= 2.0: return "MEDIUM"
    return "LOW"

def _severity_from_drift(score: float) -> str:
    if score >= 3.0: return "CRITICAL"
    if score >= 2.0: return "HIGH"
    if score >= 1.5: return "MEDIUM"
    return "LOW"
```

### GraphQL Schema

```python
# oobe/graphql/schema.py
"""
Strawberry GraphQL schema.
Mounted at /graphql via FastAPI router.
Pro plan required (enforced at resolver level).
"""
import strawberry
from strawberry.fastapi import GraphQLRouter
from typing import Optional, List
from datetime import datetime
from ..db import get_db_session
from sqlalchemy import text

@strawberry.type
class GeoPoint:
    lat: float
    lon: float

@strawberry.type
class EntityType:
    uuid:              str
    domain:            str
    domain_key:        str
    display_name:      Optional[str]
    position:          Optional[GeoPoint]
    confidence:        float
    anomaly_score:     Optional[float]
    atlas_tags:        List[str]
    observation_count: int
    last_seen:         datetime

@strawberry.type
class AlertType:
    uuid:             str
    alert_type:       str
    severity:         str
    title:            str
    description:      Optional[str]
    atlas_technique:  Optional[str]
    acknowledged:     bool
    created_at:       datetime

@strawberry.type
class AtlasTechniqueType:
    id:          str
    name:        str
    description: str
    tactics:     List[str]
    url:         str

@strawberry.type
class ProvenanceCheckType:
    uuid:              str
    provenance_score:  float
    recommendation:    str
    c2pa_valid:        Optional[bool]
    ai_probability:    Optional[float]
    created_at:        datetime

@strawberry.type
class Query:
    @strawberry.field
    async def entities(
        self,
        info: strawberry.types.Info,
        domain: Optional[str] = None,
        min_confidence: float = 0.0,
        limit: int = 100,
    ) -> List[EntityType]:
        user = info.context["user"]
        async with get_db_session() as db:
            q = """
                SELECT uuid, domain, domain_key, display_name,
                       current_lat, current_lon, confidence, anomaly_score,
                       atlas_tags, observation_count, last_seen
                FROM entities
                WHERE org_id = :org AND confidence >= :conf
            """
            params: dict = {"org": str(user.org_id), "conf": min_confidence}
            if domain:
                q += " AND domain = :domain"
                params["domain"] = domain
            q += " ORDER BY last_seen DESC LIMIT :limit"
            params["limit"] = min(limit, 1000)
            rows = (await db.execute(text(q), params)).fetchall()

        return [
            EntityType(
                uuid=r.uuid,
                domain=r.domain,
                domain_key=r.domain_key,
                display_name=r.display_name,
                position=GeoPoint(lat=r.current_lat, lon=r.current_lon)
                         if r.current_lat else None,
                confidence=r.confidence,
                anomaly_score=r.anomaly_score,
                atlas_tags=r.atlas_tags or [],
                observation_count=r.observation_count,
                last_seen=r.last_seen,
            )
            for r in rows
        ]

    @strawberry.field
    async def entity(
        self, info: strawberry.types.Info, uuid: str
    ) -> Optional[EntityType]:
        user = info.context["user"]
        async with get_db_session() as db:
            r = (await db.execute(text("""
                SELECT uuid, domain, domain_key, display_name,
                       current_lat, current_lon, confidence, anomaly_score,
                       atlas_tags, observation_count, last_seen
                FROM entities WHERE uuid = :uuid AND org_id = :org
            """), {"uuid": uuid, "org": str(user.org_id)})).fetchone()
        if not r:
            return None
        return EntityType(
            uuid=r.uuid, domain=r.domain, domain_key=r.domain_key,
            display_name=r.display_name,
            position=GeoPoint(lat=r.current_lat, lon=r.current_lon) if r.current_lat else None,
            confidence=r.confidence, anomaly_score=r.anomaly_score,
            atlas_tags=r.atlas_tags or [], observation_count=r.observation_count,
            last_seen=r.last_seen,
        )

    @strawberry.field
    async def alerts(
        self,
        info: strawberry.types.Info,
        alert_type: Optional[str] = None,
        acknowledged: Optional[bool] = None,
        limit: int = 50,
    ) -> List[AlertType]:
        user = info.context["user"]
        async with get_db_session() as db:
            q = """
                SELECT uuid, alert_type, severity, title, description,
                       atlas_technique, acknowledged, created_at
                FROM alerts WHERE org_id = :org
            """
            params: dict = {"org": str(user.org_id)}
            if alert_type:
                q += " AND alert_type = :at"; params["at"] = alert_type
            if acknowledged is not None:
                q += " AND acknowledged = :ack"; params["ack"] = acknowledged
            q += " ORDER BY created_at DESC LIMIT :limit"
            params["limit"] = min(limit, 500)
            rows = (await db.execute(text(q), params)).fetchall()

        return [
            AlertType(
                uuid=str(r.uuid), alert_type=r.alert_type, severity=r.severity,
                title=r.title, description=r.description,
                atlas_technique=r.atlas_technique,
                acknowledged=r.acknowledged, created_at=r.created_at,
            )
            for r in rows
        ]

    @strawberry.field
    async def atlas_techniques(
        self,
        info: strawberry.types.Info,
        tactic: Optional[str] = None,
    ) -> List[AtlasTechniqueType]:
        async with get_db_session() as db:
            q = "SELECT id, name, description, tactics, url FROM atlas_techniques"
            params: dict = {}
            if tactic:
                q += " WHERE :tactic = ANY(tactics)"; params["tactic"] = tactic
            q += " ORDER BY id"
            rows = (await db.execute(text(q), params)).fetchall()
        return [
            AtlasTechniqueType(
                id=r.id, name=r.name, description=r.description or "",
                tactics=r.tactics or [], url=r.url or "",
            )
            for r in rows
        ]

schema = strawberry.Schema(query=Query)

def get_graphql_router(get_user_from_request):
    async def get_context(request) -> dict:
        user = await get_user_from_request(request)
        return {"user": user, "request": request}

    return GraphQLRouter(
        schema,
        context_getter=get_context,
        graphiql=True,   # Enable GraphiQL playground
    )
```

All 10 feed domains | ✅ | Aviation, maritime, conflict, seismic, fire, disaster, weather, space weather, air quality, aviation wx

PoL IsolationForest models | ✅ | ≥2 active models in pol_models, scoring every 5 min

Loitering + course deviation detectors | ✅ | FP rate documented from pilot feedback

Cross-cue validator | ✅ | Single-source entities capped at 0.7

RLS policies | ✅ | Full org isolation on all data tables

Export (GeoJSON/KML/CSV) + webhooks | ✅ | HMAC-signed, 5-retry delivery

Analyst notes + tags | ✅ | Full CRUD, org-scoped

3–5 pilot users | ✅ | Active 2+ consecutive weeks, feedback collected

Railway Pro deployment | ✅ | Auto-deploys from main

Stripe account | ✅ | Created per Phase 2 transition checklist, keys in hand

PostHog | ✅ | Onboarding funnel tracked, pilot analytics live

<aside>
🎯 Phase 3 goal: Ship a public, self-serve production SaaS that charges money, tells analysts which adversarial AI techniques are targeting their data feeds, verifies the provenance of OSINT imagery, exposes a documented public API, and passes an OWASP security audit — all before the end of Week 24.

Budget: ~$350–500/month (AWS ECS Fargate + RDS + ElastiCache, replacing Railway). Team: 2–4 engineers. ~400 hours over 10 weeks.

</aside>

---

## New Requirements (requirements.txt — add before Week 15)

```
# Phase 3 additions
stripe==11.3.0
weasyprint==63.0              # PDF generation for threat briefs
jinja2==3.1.5                 # Already in Phase 2, confirm present
pillow==11.1.0                # Image processing for provenance
python-magic==0.4.27          # MIME type detection for upload validation
exifread==3.0.0               # EXIF metadata extraction
httpx==0.28.1                 # Already present; used for TinEye + Hive
strawberry-graphql[fastapi]==0.254.0  # GraphQL
boto3==1.35.95                # AWS S3 for model storage + image uploads
python-multipart==0.0.20      # Multipart file upload handling (FastAPI)
flagsmith==3.9.0              # Feature flags
posthog==3.7.5                # Already present
pytest-cov==6.0.0             # Coverage reporting for CI gate
```

---

## Week 15: Stripe Billing + Self-Serve Signup

### Deliverables Checklist

- [ ]  Migration 0004: billing_events, api_keys, workspace_invitations tables
- [ ]  Stripe product + price objects created in Stripe Dashboard (Free, Pro, Enterprise)
- [ ]  BillingService: create customer, create subscription, cancel subscription
- [ ]  Stripe webhook handler: customer.subscription.updated, invoice.payment_failed, invoice.payment_succeeded
- [ ]  Self-serve signup API: POST /auth/register → Supabase user → org provisioned → Stripe customer created
- [ ]  Stripe Checkout redirect: POST /v1/billing/checkout → returns Stripe Checkout URL
- [ ]  Billing portal redirect: GET /v1/billing/portal → returns Stripe Customer Portal URL
- [ ]  Frontend signup page: email + password form → checkout → workspace
- [ ]  Downgrade/upgrade handler: plan change synced from Stripe webhook → org.plan updated
- [ ]  20 tests: billing service unit tests, webhook signature validation, plan change propagation

<aside>
✅ Acceptance criteria: A new user can sign up, enter a card via Stripe Checkout, and immediately access Pro features. A failed payment downgrades the org to Free plan within 60 seconds of Stripe webhook delivery. No card data ever touches OOBE servers.

</aside>

### Migration 0004 — billing_events, api_keys, workspace_invitations