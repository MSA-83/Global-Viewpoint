# Phase 7 — AI-Native Intelligence: Language, Joint Entity & Autonomous Agent

# OOBE Phase 7: AI-Native Intelligence

## Complete Engineering Specification — Months 43–54

### Post-Series B: Language layer, joint entity model, autonomous investigation assistant

---

## Entry State: Month 43

Series B is closed. The check landed between $20M and $30M. The engineering team is 18 people and about to become 30. The problems have changed completely again.

Phase 1–3 problems: *Can we build this at all?*

Phase 4–6 problems: *Can we sell this reliably?*

Phase 7 problems: *Can we make the intelligence itself autonomous?*

The answer to that question — whether OOBE can move from a platform analysts use to a platform that actively generates intelligence — determines whether the company is worth $100M or $1B. This is not hyperbole. Palantir's $80B market cap rests on a single thesis: software that makes human analysts more capable compounds faster than software that replaces workflows. OOBE's Phase 7 thesis is the same, but built on open data and open standards rather than on black-box proprietary systems.

Confirmed at Month 43 entry:

| Capability | Status | Metric |

|------------|--------|--------|

| $10M ARR | ✅ | Growing >80% YoY |

| Series B ($20–30M) closed | ✅ | 24–30 month runway |

| 200+ Pro + 20+ Enterprise + 5+ Gov customers | ✅ | NRR >130% |

| FedRAMP Moderate ATO | ✅ | |

| Multi-region: EU-West, US-East, EU-Central | ✅ | |

| PoL V3 GNN at 100% rollout | ✅ | FP rate <6% |

| Mobile app (iOS + Android) | ✅ | 4.6★ App Store rating |

| Platform API v3, App Registry (25+ apps) | ✅ | |

| Data Marketplace GMV $1M+ annualized | ✅ | |

| MLOps continuous retraining pipeline | ✅ | |

| 10,000+ newsletter subscribers | ✅ | |

| 18-person team | ✅ | |

**Series B use of funds ($25M baseline):**

- 40% Product / Engineering ($10M): Language Layer, Joint Entity Model, Investigation Assistant, PoL V4
- 30% GTM ($7.5M): Federal sales team, UK/EU expansion, AP-region, partner channel activation
- 20% Compliance ($5M): FedRAMP Moderate ConMon, SECRET-adjacent OTA pursuit, UK Cyber Essentials Plus
- 10% Infrastructure ($2.5M): AP-region launch, global CDN for tiles, database scaling

**Phase 7 covers 12 months across four quarters:**

| Quarter | Months | Theme | ARR Target | Key Deliverable |

|---------|--------|-------|-----------|-----------------|

| Q1 | 43–45 | Language Layer | $15M ARR | Multilingual NLP pipeline, linguistic entity model |

| Q2 | 46–48 | Joint Entity Model | $20M ARR | Cross-domain entity fusion, unified identity graph |

| Q3 | 49–51 | Investigation Assistant | $25M ARR | Autonomous OSINT agent, traceable report generation |

| Q4 | 52–54 | PoL V4 + Series C Readiness | $30M ARR | Multi-modal anomaly detection, Series C positioning |

**Hiring plan (Month 43–54):**

- M43: NLP/Computational Linguistics Engineer
- M43: Senior Backend Engineer (language pipeline)
- M44: Enterprise AE #3 (Federal focus)
- M45: ML Engineer (joint entity model)
- M46: AP-region Infrastructure Engineer
- M47: AI Safety / Responsible AI Lead *(critical for Investigation Assistant)*
- M48: Senior Frontend Engineer (Investigation Assistant UI)
- M49: Federal Capture Manager
- M50: DevSecOps Engineer #2
- M51: Data Science Engineer (PoL V4)
- M52: Solutions Architect #2 (EU/UK)

---

## Q1 (Months 43–45): Language Layer

### Goals

- Ingest and normalize conflict intelligence from non-English media at scale
- Build the linguistic entity model: organizations, people, and events become first-class entities in the OOBE graph alongside aircraft and vessels
- Ship Arabic, Russian, and Mandarin as initial supported languages
- Demonstrate cross-modal correlation: a Telegram post about an airstrike correlated with an ACLED event and an aviation loitering pattern within 1 hour
- ARR target: $15M

---

### M43: Language Pipeline Architecture

The core engineering challenge is not translation. It is **entity extraction under uncertainty** — pulling named organizations, locations, and events from messy, informal, sometimes adversarial text in multiple languages, and deciding whether "Wagner Group" in a Russian Telegram channel is the same entity as "ЧВК Вагнера" in a TASS article and "PMC Wagner" in an ACLED event. This is a named entity recognition (NER) + entity linking + coreference resolution pipeline, and it needs to run at thousands of messages per minute.

```
Source Text (Telegram / RSS / Twitter-equivalent)
        ↓
Language Detection (langdetect, fastText)
        ↓
Translation to English (Helsinki-NLP OPUS-MT, self-hosted)
        ↓
Named Entity Recognition (GLiNER multilingual or mDeBERTa fine-tuned)
        ↓
Entity Linking (FAISS vector search against entity knowledge base)
        ↓
Event Classification (armed_conflict / displacement / infrastructure / cyber)
        ↓
Geolocation (GeoNamesCache + Nominatim + coordinate extraction)
        ↓
Confidence Scoring (NER confidence × geolocation confidence × source reliability)
        ↓
NormalizedEntity → standard OOBE entity processor
```

def _find_proximity_candidates() -> list[dict]:

    """

    Find entity pairs from different domains that are close in space + time.

    Uses PostGIS ST_DWithin for efficient spatial query.

    """

    cutoff = datetime.now(timezone.utc) - timedelta(hours=2)

    with get_sync_db_session() as db:

        rows = db.execute(text("""

            SELECT

                a.uuid AS uuid_a, a.domain AS domain_a,

                a.display_name AS name_a, a.current_lat AS lat_a, a.current_lon AS lon_a,

                b.uuid AS uuid_b, b.domain AS domain_b,

                b.display_name AS name_b, b.current_lat AS lat_b, b.current_lon AS lon_b,

                ST_Distance(a.current_pos, b.current_pos) / 1000.0 AS dist_km,

                ABS(EXTRACT(EPOCH FROM (a.last_seen - b.last_seen))) / 60.0 AS time_delta_min

            FROM entities a

            JOIN entities b ON (

                a.domain != b.domain

                AND a.uuid < b.uuid   -- avoid duplicate pairs

                AND ST_DWithin(

                    a.current_pos, b.current_pos,

                    :radius_m

                )

                AND ABS(EXTRACT(EPOCH FROM (a.last_seen - b.last_seen))) < :time_window_s

            )

            WHERE a.last_seen >= :cutoff

              AND b.last_seen >= :cutoff

              AND a.confidence > 0.3

              AND b.confidence > 0.3

            LIMIT 500

        """), {

            "radius_m":    PROXIMITY_KM * 1000,

            "time_window_s": TEMPORAL_WINDOW_MINUTES * 60,

            "cutoff":      cutoff,

        }).fetchall()

    return [

        {

            "uuid_a":   r.uuid_a, "uuid_b":   r.uuid_b,

            "domain_a": r.domain_a, "domain_b": r.domain_b,

            "evidence": {

                "type":       "proximity",

                "dist_km":    round(r.dist_km, 3),

                "time_delta_min": round(r.time_delta_min, 1),

            }

        }

        for r in rows

    ]

def _find_name_match_candidates() -> list[dict]:

    """

    Find entities whose normalized names closely match across domains.

    Uses pg_trgm trigram similarity for fuzzy matching.

    """

    with get_sync_db_session() as db:

        rows = db.execute(text("""

            SELECT

                a.uuid AS uuid_a, a.domain AS domain_a, a.display_name AS name_a,

                b.uuid AS uuid_b, b.domain AS domain_b, b.display_name AS name_b,

                similarity(

                    LOWER(COALESCE(a.display_name,'')),

                    LOWER(COALESCE(b.display_name,''))

                ) AS name_sim

            FROM entities a

            JOIN entities b ON (

                a.domain != b.domain

                AND a.uuid < b.uuid

                AND similarity(

                    LOWER(COALESCE(a.display_name,'')),

                    LOWER(COALESCE(b.display_name,''))

                ) > 0.7

                AND a.display_name IS NOT NULL

                AND b.display_name IS NOT NULL

                AND LENGTH(a.display_name) > 4

            )

            WHERE a.last_seen >= NOW() - INTERVAL '48 hours'

              AND b.last_seen >= NOW() - INTERVAL '48 hours'

            LIMIT 200

        """)).fetchall()

    return [

        {

            "uuid_a":   r.uuid_a, "uuid_b":   r.uuid_b,

            "domain_a": r.domain_a, "domain_b": r.domain_b,

            "evidence": {"type": "name_match", "similarity": round(r.name_sim, 3),

                         "name_a": r.name_a, "name_b": r.name_b}

        }

        for r in rows

    ]

def _find_explicit_identifier_candidates() -> list[dict]:

    """

    Find entities where one entity's metadata contains the domain_key of another.

    E.g.: a Telegram message metadata contains MMSI "235123456" →

    link to maritime entity with domain_key "235123456".

    """

    with get_sync_db_session() as db:

        rows = db.execute(text("""

            SELECT

                ling.uuid AS uuid_a, 'linguistic' AS domain_a,

                mar.uuid  AS uuid_b, 'maritime'   AS domain_b,

                ling.metadata->>'context' AS context

            FROM entities ling

            JOIN entities mar ON (

def _find_proximity_candidates() -> list[dict]:

    """

    Find entity pairs from different domains that are close in space + time.

    Uses PostGIS ST_DWithin for efficient spatial query.

    """

    cutoff = datetime.now(timezone.utc) - timedelta(hours=2)

    with get_sync_db_session() as db:

        rows = db.execute(text("""

            SELECT

                a.uuid AS uuid_a, a.domain AS domain_a,

                a.display_name AS name_a, a.current_lat AS lat_a, a.current_lon AS lon_a,

                b.uuid AS uuid_b, b.domain AS domain_b,

                b.display_name AS name_b, b.current_lat AS lat_b, b.current_lon AS lon_b,

                ST_Distance(a.current_pos, b.current_pos) / 1000.0 AS dist_km,

                ABS(EXTRACT(EPOCH FROM (a.last_seen - b.last_seen))) / 60.0 AS time_delta_min

            FROM entities a

            JOIN entities b ON (

                a.domain != b.domain

                AND a.uuid < b.uuid   -- avoid duplicate pairs

                AND ST_DWithin(

                    a.current_pos, b.current_pos,

                    :radius_m

                )

                AND ABS(EXTRACT(EPOCH FROM (a.last_seen - b.last_seen))) < :time_window_s

            )

            WHERE a.last_seen >= :cutoff

              AND b.last_seen >= :cutoff

              AND a.confidence > 0.3

              AND b.confidence > 0.3

            LIMIT 500

        """), {

            "radius_m":    PROXIMITY_KM * 1000,

            "time_window_s": TEMPORAL_WINDOW_MINUTES * 60,

            "cutoff":      cutoff,

        }).fetchall()

    return [

        {

            "uuid_a":   r.uuid_a, "uuid_b":   r.uuid_b,

            "domain_a": r.domain_a, "domain_b": r.domain_b,

            "evidence": {

                "type":       "proximity",

                "dist_km":    round(r.dist_km, 3),

                "time_delta_min": round(r.time_delta_min, 1),

            }

        }

        for r in rows

    ]

def _find_name_match_candidates() -> list[dict]:

    """

    Find entities whose normalized names closely match across domains.

    Uses pg_trgm trigram similarity for fuzzy matching.

    """

    with get_sync_db_session() as db:

        rows = db.execute(text("""

            SELECT

                a.uuid AS uuid_a, a.domain AS domain_a, a.display_name AS name_a,

                b.uuid AS uuid_b, b.domain AS domain_b, b.display_name AS name_b,

                similarity(

                    LOWER(COALESCE(a.display_name,'')),

                    LOWER(COALESCE(b.display_name,''))

                ) AS name_sim

            FROM entities a

            JOIN entities b ON (

                a.domain != b.domain

                AND a.uuid < b.uuid

                AND similarity(

                    LOWER(COALESCE(a.display_name,'')),

                    LOWER(COALESCE(b.display_name,''))

                ) > 0.7

                AND a.display_name IS NOT NULL

                AND b.display_name IS NOT NULL

                AND LENGTH(a.display_name) > 4

            )

            WHERE a.last_seen >= NOW() - INTERVAL '48 hours'

              AND b.last_seen >= NOW() - INTERVAL '48 hours'

            LIMIT 200

        """)).fetchall()

    return [

        {

            "uuid_a":   r.uuid_a, "uuid_b":   r.uuid_b,

            "domain_a": r.domain_a, "domain_b": r.domain_b,

            "evidence": {"type": "name_match", "similarity": round(r.name_sim, 3),

                         "name_a": r.name_a, "name_b": r.name_b}

        }

        for r in rows

    ]

def _find_explicit_identifier_candidates() -> list[dict]:

    """

    Find entities where one entity's metadata contains the domain_key of another.

    E.g.: a Telegram message metadata contains MMSI "235123456" →

    link to maritime entity with domain_key "235123456".

    """

    with get_sync_db_session() as db:

        rows = db.execute(text("""

            SELECT

                ling.uuid AS uuid_a, 'linguistic' AS domain_a,

                mar.uuid  AS uuid_b, 'maritime'   AS domain_b,

                ling.metadata->>'context' AS context

            FROM entities ling

            JOIN entities mar ON (

     These refusals are logged and reviewed monthly by the AI Safety Lead.

  5. TOOL AUDIT LOG

     Every tool call is logged with: tool name, parameters (redacted of PII),

     result summary, timestamp. This log is attached to every investigation.

     Analysts can inspect exactly what the assistant did and why.

Available tools:

  oobe_get_entity        — fetch entity details by UUID

  oobe_search_entities   — search entities by domain, bbox, name pattern

  oobe_get_history       — fetch observation history for an entity

  oobe_get_relationships — fetch Neo4j graph relationships

  oobe_get_alerts        — fetch alerts linked to entities

  oobe_get_incidents     — fetch correlated incident records

  oobe_get_atlas_threats — fetch ATLAS threat assessments

  oobe_verify_image      — run Provenance Sentinel on an image URL

  oobe_search_knowledge_base — search entity knowledge base for canonical names

  oobe_cross_domain_candidates — fetch candidate cross-domain entity links

"""

import asyncio, json, logging, os

from datetime import datetime, timezone

from typing import Callable

import anthropic

logger = logging.getLogger(__name__)

ANTHROPIC_MODEL = "claude-sonnet-4-20250514"

SYSTEM_PROMPT = """You are OOBE Investigation Assistant, an OSINT analysis agent.

You help intelligence analysts build structured investigations using live OOBE data.

Core rules:

1. Every factual claim you make MUST cite a specific entity UUID, observation timestamp, and source URL. Format: [ENTITY:uuid_prefix | SOURCE:url | TS:timestamp | CONF:x.xx]

2. If you cannot find a source for a claim, say "Unknown — no data available."

3. Qualify uncertainty explicitly. Use phrases like "High confidence (N observations, M sources)" or "Provisional (single source, Xh ago)."

4. At each checkpoint, explicitly state what you found and ask for permission to proceed.

5. Never identify private individuals' home locations or personal movements.

6. Never produce content that could facilitate physical targeting of a named person.

7. If asked to do something that violates rules 5 or 6, refuse and explain why.

8. When you have completed an investigation phase, present a structured summary in the format:

   PHASE: [phase name]

   ENTITIES FOUND: [list with confidence]

   KEY FINDINGS: [bullet list]

   UNCERTAINTIES: [what you don't know]

   RECOMMENDATION: [proceed / needs more data / investigation complete]"""

class InvestigationAssistant:

    def __init__(self, api_key: str, oobe_api_key: str, org_id: str):

        self.client      = anthropic.Anthropic(api_key=api_key)

        self.oobe_key    = oobe_api_key

        self.org_id      = org_id

        self.tool_log:   list[dict] = []

        self.messages:   list[dict] = []

    async def start_investigation(

        self,

        seed_entity_uuid: str,

        investigation_uuid: str,

        analyst_objective: str,

    ) -> dict:

        """

        Starts an investigation from a seed entity.

        Returns a structured investigation package.

        """

        self.messages = [{

            "role":    "user",

            "content": (

                f"Investigate entity {seed_entity_uuid}.\\n"

                f"Analyst objective: {analyst_objective}\\n"

                f"Investigation ID: {investigation_uuid}\\n\\n"

                "Phase 1: Retrieve the entity details, its observation history "

                "(last 24h), and its graph relationships. Present your findings "

                "and wait for my confirmation before proceeding to Phase 2."

            )

        }]

        return await self._run_agentic_loop(investigation_uuid)

    async def continue_investigation(

        self,

        investigation_uuid: str,

        analyst_message: str,

    ) -> dict:

        """Continue an investigation after an analyst checkpoint response."""

        self.messages.append({"role": "user", "content": analyst_message})

        return await self._run_agentic_loop(investigation_uuid)

    async def _run_agentic_loop(self, investigation_uuid: str) -> dict:

        """Core agentic loop: call Claude, handle tool use, return checkpoint or final."""

        tools = self._get_tool_definitions()

        max_iterations = 20   # Safety: prevent infinite loops

        iteration      = 0

        while iteration < max_iterations:

            iteration += 1

            response = self.client.messages.create(

                model=ANTHROPIC_MODEL,

                max_tokens=4096,

                system=SYSTEM_PROMPT,

                tools=tools,

                messages=self.messages,

            )

            # Append assistant response to history

            self.messages.append({

                "role":    "assistant",

                "content": response.content,

            })

            # Process content blocks

            tool_results   = []

            text_output    = ""

            stop_reason    = response.stop_reason

            for block in response.content:

                if block.type == "text":

                    text_output += block.text

                elif block.type == "tool_use":

                    result = await self._execute_tool(block.name, block.input)

                    self.tool_log.append({

                        "tool":       block.name,

                        "input_keys": list(block.input.keys()),

                        "result_len": len(str(result)),

                        "ts":         datetime.now(timezone.utc).isoformat(),

                    })

                    tool_results.append({

                        "type":        "tool_result",

                        "tool_use_id": block.id,

                        "content":     json.dumps(result)[:8000],  # Cap result size

                    })

            # If tools were used, append results and continue loop

            if tool_results:

                self.messages.append({

                    "role":    "user",

                    "content": tool_results,

                })

                continue

            # No tool calls: assistant produced text → checkpoint or complete

            return {

                "type":         "checkpoint",

                "text":         text_output,

                "tool_log":     self.tool_log.copy(),

                "message_count": len(self.messages),

                "investigation_uuid": investigation_uuid,

                "is_complete":  "INVESTIGATION COMPLETE" in text_output.upper(),

            }

        return {

            "type":     "error",

            "text":     "Investigation exceeded maximum iterations. Results may be incomplete.",

            "tool_log": self.tool_log,

        }

    async def _execute_tool(self, tool_name: str, params: dict) -> dict:

        """Route tool calls to OOBE API endpoints."""

        import httpx

        base   = os.environ.get("OOBE_API_BASE", "https://api.oobe.io")

        headers = {"X-API-Key": self.oobe_key}

        async with httpx.AsyncClient(timeout=15) as client:

            if tool_name == "oobe_get_entity":

                r = await client.get(f"{base}/v3/entities/{params['uuid']}", headers=headers)

                return r.json()

            elif tool_name == "oobe_search_entities":

                r = await client.get(f"{base}/v3/entities", headers=headers, params=params)

                data = r.json()

                # Return summary to avoid context bloat: max 20 entities

                ents = data.get("entities", [])[:20]

                return {"entities": ents, "total": data.get("total", 0)}

            elif tool_name == "oobe_get_history":

                uuid  = params.pop("uuid")

                r = await client.get(f"{base}/v3/entities/{uuid}/history",

                                     headers=headers, params=params)

                data = r.json()

                # Summarise: return first + last 5 observations, not all

                obs = data.get("observations", [])

                return {

                    "entity_uuid":    uuid,

                    "total_obs":      len(obs),

                    "first_5":        obs[:5],

                    "last_5":         obs[-5:],

                    "time_span_h":    params.get("hours", 24),

                }

            elif tool_name == "oobe_get_relationships":

                uuid = params.pop("uuid")

                r = await client.get(f"{base}/v3/entities/{uuid}/relationships",

                                     headers=headers, params=params)

                return r.json()

            elif tool_name == "oobe_get_alerts":

                r = await client.get(f"{base}/v3/alerts", headers=headers, params=params)

                data = r.json()

                return {"alerts": data.get("alerts", [])[:10]}

            elif tool_name == "oobe_get_atlas_threats":

                r = await client.get(f"{base}/v1/atlas/threats/active", headers=headers)

                return r.json()

            elif tool_name == "oobe_verify_image":

                r = await client.post(f"{base}/v1/verify/image-url",

                                      headers=headers, json={"url": params["url"]})

                return r.json()

            elif tool_name == "oobe_cross_domain_candidates":

                uuid = params.get("uuid", "")

                r = await client.get(f"{base}/v3/entities/{uuid}/cross-domain-candidates",

                                     headers=headers)

                return r.json()

            else:

                return {"error": f"Unknown tool: {tool_name}"}

    def _get_tool_definitions(self) -> list[dict]:

        return [

            {

                "name":        "oobe_get_entity",

                "description": "Fetch full details for a single entity by UUID.",

                "input_schema": {

                    "type": "object",

                    "properties": {"uuid": {"type": "string", "description": "Entity UUID (32 chars)"}},

                    "required": ["uuid"],

                }

            },

            {

                ling.domain = 'linguistic'

                AND mar.domain = 'maritime'

                AND ling.metadata->>'context' ILIKE '%' || mar.domain_key || '%'

            )

            WHERE ling.last_seen >= NOW() - INTERVAL '24 hours'

            LIMIT 100

        """)).fetchall()

    return [

        {

            "uuid_a": r.uuid_a, "uuid_b": r.uuid_b,

            "domain_a": "linguistic", "domain_b": "maritime",

            "evidence": {"type": "explicit_identifier",

                         "found_in_context": r.context[:200]}

        }

        for r in rows

    ]

def _score_candidate_pair(pair: dict) -> float:

    """

    Compute composite confidence score for a candidate entity link.

    """

    evidence = pair["evidence"]

    etype    = evidence.get("type", "")

    if etype == "proximity":

        dist_score = max(0.0, 1.0 - evidence["dist_km"] / PROXIMITY_KM)

        time_score = max(0.0, 1.0 - evidence["time_delta_min"] / TEMPORAL_WINDOW_MINUTES)

        return 0.5 * dist_score + 0.5 * time_score

    if etype == "name_match":

        return evidence.get("similarity", 0.0) * 0.9

    if etype == "explicit_identifier":

        return 0.95   # Very high confidence when ID found explicitly

    return 0.0

def _upsert_candidate_link(uuid_a: str, uuid_b: str, confidence: float, evidence: dict):

    """Create or update CANDIDATE_LINK in Neo4j."""

    driver = get_neo4j_driver()

    with driver.session() as session:

        session.run("""

            MERGE (a:Entity {uuid: $uuid_a})

            MERGE (b:Entity {uuid: $uuid_b})

            MERGE (a)-[r:CANDIDATE_LINK]->(b)

            ON CREATE SET

                r.confidence  = $confidence,

                r.evidence    = $evidence,

                r.created_at  = datetime(),

                r.confirmed   = false

            ON MATCH SET

                r.confidence  = CASE

                    WHEN $confidence > r.confidence THEN $confidence

                    ELSE r.confidence

                END,

                r.updated_at  = datetime()

        """, {

            "uuid_a":     uuid_a,

            "uuid_b":     uuid_b,

            "confidence": confidence,

            "evidence":   str(evidence),

        })

def _auto_merge_entities(uuid_a: str, uuid_b: str):

    """

    Auto-confirm a CANDIDATE_LINK above the merge threshold.

    Updates Neo4j relationship to RESOLVES_TO and creates real_world_entities record.

    """

    driver = get_neo4j_driver()

    with driver.session() as session:

        # Promote CANDIDATE_LINK → RESOLVES_TO

        session.run("""

            MATCH (a:Entity {uuid: $uuid_a})-[r:CANDIDATE_LINK]->(b:Entity {uuid: $uuid_b})

            SET r.confirmed = true, r.confirmed_at = datetime(), r.confirmed_by = 'auto'

        """, {"uuid_a": uuid_a, "uuid_b": uuid_b})

    logger.info(f"Auto-merged entities {uuid_a[:8]} ↔ {uuid_b[:8]}")

```

---

## Q3 (Months 49–51): Autonomous Investigation Assistant

### Goals
- Ship the OOBE Investigation Assistant: an agentic AI that builds OSINT investigations from a seed entity, traverses the knowledge graph, and produces structured traceable reports
- Every claim in every report is linked to a TTL-validated, provenance-checked source
- Responsible AI framework: human-in-the-loop checkpoints, explicit uncertainty surfacing, refusal of requests that could enable targeting of individuals
- ARR target: $25M

---

### M49: Investigation Assistant — Architecture

```

# oobe/ai/investigation_assistant.py

"""

OOBE Investigation Assistant: autonomous OSINT investigation agent.

Architecture: Tool-using AI agent (Claude claude-sonnet-4-20250514 via Anthropic API)

with access to a curated set of OOBE-native tools.

Design principles:

  1. EVERY CLAIM IS TRACEABLE

     The assistant never synthesises a claim that doesn't link back to a specific

     entity UUID, observation timestamp, and TTL-validated source URL.

     If a claim cannot be traced to a source, the assistant says "Unknown."

  2. UNCERTAINTY IS EXPLICIT

     Claims are qualified: "High confidence (entity observed 47 times, 2 sources)"

     vs "Low confidence (single source, 4h ago, confidence 0.41)".

     The assistant never presents uncertain inferences as established facts.

  3. HUMAN-IN-THE-LOOP CHECKPOINTS

     The assistant pauses at defined checkpoints and presents its reasoning

     before proceeding to the next phase of the investigation.

     Checkpoint 1: After initial entity graph traversal — "Here's what I found.

                   Shall I proceed to cross-domain correlation?"

     Checkpoint 2: After cross-domain correlation — "Here's the candidate link

                   between these entities. Confidence: 0.78. Shall I include

                   this in the report?"

     Checkpoint 3: Before generating the final report — "Ready to write up.

                   Are there any areas to exclude?"

  4. RESPONSIBLE AI GUARDRAILS

     The assistant refuses to:

       - Identify the home address or personal movements of private individuals

       - Produce content that could be used for targeting a named private person

       - Generate assessments of individuals' political views, religion, or ethnicity

         without a clear public-interest justification

     These refusals are logged and reviewed monthly by the AI Safety Lead.

  5. TOOL AUDIT LOG

     Every tool call is logged with: tool name, parameters (redacted of PII),

     result summary, timestamp. This log is attached to every investigation.

     Analysts can inspect exactly what the assistant did and why.

Available tools:

  oobe_get_entity        — fetch entity details by UUID

  oobe_search_entities   — search entities by domain, bbox, name pattern

  oobe_get_history       — fetch observation history for an entity

  oobe_get_relationships — fetch Neo4j graph relationships

  oobe_get_alerts        — fetch alerts linked to entities

  oobe_get_incidents     — fetch correlated incident records

  oobe_get_atlas_threats — fetch ATLAS threat assessments

  oobe_verify_image      — run Provenance Sentinel on an image URL

  oobe_search_knowledge_base — search entity knowledge base for canonical names

  oobe_cross_domain_candidates — fetch candidate cross-domain entity links

"""

import asyncio, json, logging, os

from datetime import datetime, timezone

from typing import Callable

import anthropic

logger = logging.getLogger(__name__)

ANTHROPIC_MODEL = "claude-sonnet-4-20250514"

SYSTEM_PROMPT = """You are OOBE Investigation Assistant, an OSINT analysis agent.

You help intelligence analysts build structured investigations using live OOBE data.

Core rules:

1. Every factual claim you make MUST cite a specific entity UUID, observation timestamp, and source URL. Format: [ENTITY:uuid_prefix | SOURCE:url | TS:timestamp | CONF:x.xx]

2. If you cannot find a source for a claim, say "Unknown — no data available."

3. Qualify uncertainty explicitly. Use phrases like "High confidence (N observations, M sources)" or "Provisional (single source, Xh ago)."

4. At each checkpoint, explicitly state what you found and ask for permission to proceed.

5. Never identify private individuals' home locations or personal movements.

6. Never produce content that could facilitate physical targeting of a named person.

7. If asked to do something that violates rules 5 or 6, refuse and explain why.

8. When you have completed an investigation phase, present a structured summary in the format:

   PHASE: [phase name]

   ENTITIES FOUND: [list with confidence]

   KEY FINDINGS: [bullet list]

   UNCERTAINTIES: [what you don't know]

   RECOMMENDATION: [proceed / needs more data / investigation complete]"""

class InvestigationAssistant:

    def __init__(self, api_key: str, oobe_api_key: str, org_id: str):

        self.client      = anthropic.Anthropic(api_key=api_key)

        self.oobe_key    = oobe_api_key

        self.org_id      = org_id

        self.tool_log:   list[dict] = []

        self.messages:   list[dict] = []

    async def start_investigation(

        self,

        seed_entity_uuid: str,

        investigation_uuid: str,

        analyst_objective: str,

    ) -> dict:

        """

        Starts an investigation from a seed entity.

        Returns a structured investigation package.

        """

        self.messages = [{

            "role":    "user",

            "content": (

                f"Investigate entity {seed_entity_uuid}.\\n"

                f"Analyst objective: {analyst_objective}\\n"

                f"Investigation ID: {investigation_uuid}\\n\\n"

                "Phase 1: Retrieve the entity details, its observation history "

                "(last 24h), and its graph relationships. Present your findings "

                "and wait for my confirmation before proceeding to Phase 2."

            )

        }]

        return await self._run_agentic_loop(investigation_uuid)

    async def continue_investigation(

        self,

        investigation_uuid: str,

        analyst_message: str,

    ) -> dict:

        """Continue an investigation after an analyst checkpoint response."""

        self.messages.append({"role": "user", "content": analyst_message})

        return await self._run_agentic_loop(investigation_uuid)

    async def _run_agentic_loop(self, investigation_uuid: str) -> dict:

        """Core agentic loop: call Claude, handle tool use, return checkpoint or final."""

        tools = self._get_tool_definitions()

        max_iterations = 20   # Safety: prevent infinite loops

        iteration      = 0

        while iteration < max_iterations:

            iteration += 1

            response = self.client.messages.create(

                model=ANTHROPIC_MODEL,

                max_tokens=4096,

                system=SYSTEM_PROMPT,

                tools=tools,

                messages=self.messages,

            )

            # Append assistant response to history

            self.messages.append({

                "role":    "assistant",

                "content": response.content,

            })

            # Process content blocks

            tool_results   = []

            text_output    = ""

            stop_reason    = response.stop_reason

            for block in response.content:

  Acqui-hire target for cleared defence prime (Booz Allen, SAIC, Leidos):

    The OOBE platform + FedRAMP stack + data moat = strategic capability

    that a defence prime would absorb to differentiate their OSINT practice.

    Multiple: 8–12× ARR = $240M–$360M.

## Closing Statement

Phase 7 is where OOBE becomes AI-native. We move from being a better tool to being a superior intelligence partner. We have the data, the users, the compliance, and now the autonomous engine. The Series C will fund the scale to $100M ARR and beyond.

```

---
EOF

```

    anthropic_key: str,

    oobe_key: str,

    org_id: str,

) -> InvestigationAssistant:

    assistant          = InvestigationAssistant(anthropic_key, oobe_key, org_id)

    assistant.messages = state_json.get("messages", [])

    assistant.tool_log = state_json.get("tool_log", [])

    return assistant

```

---

#### Migration 0011: Investigation Assistant State

```

# oobe/db/migrations/versions/0011_investigation_assistant.py

from alembic import op

import sqlalchemy as sa

def upgrade():

    op.create_table("investigation_assistant_runs",

        sa.Column("investigation_uuid", sa.UUID, primary_key=True),

        sa.Column("org_id",            sa.UUID, nullable=False),

        sa.Column("user_id",           sa.UUID),

        sa.Column("seed_entity_uuid",  sa.CHAR(32), nullable=False),

        sa.Column("objective",         sa.Text),

        sa.Column("state_json",        sa.JSONB, nullable=False, server_default="{}"),

        sa.Column("is_complete",       sa.Boolean, server_default="FALSE"),

        sa.Column("final_report",      sa.Text),

        sa.Column("tool_call_count",   sa.Integer, server_default="0"),

        sa.Column("created_at",        sa.TIMESTAMP(timezone=True),

                  server_default=sa.text("NOW()")),

        sa.Column("updated_at",        sa.TIMESTAMP(timezone=True),

                  server_default=sa.text("NOW()")),

    )

    op.create_index("idx_ai_runs_org",  "investigation_assistant_runs", ["org_id"])

    op.create_index("idx_ai_runs_user", "investigation_assistant_runs", ["user_id"])

    # Responsible AI audit log

    op.create_table("ai_safety_log",

        sa.Column("uuid",              sa.UUID, primary_key=True,

                  server_default=sa.text("uuid_generate_v4()")),

        sa.Column("run_uuid",          sa.UUID),

        sa.Column("org_id",            sa.UUID),

        sa.Column("event_type",        sa.String(64), nullable=False),

        # guardrail_triggered | refusal | human_checkpoint | tool_call

        sa.Column("tool_name",         sa.String(64)),

        sa.Column("description",       sa.Text),

        sa.Column("analyst_approved",  sa.Boolean),

        sa.Column("created_at",        sa.TIMESTAMP(timezone=True),

                  server_default=sa.text("NOW()")),

    )

    op.create_index("idx_ai_safety_run",  "ai_safety_log", ["run_uuid"])

    op.create_index("idx_ai_safety_type", "ai_safety_log", ["event_type", "created_at"])

def downgrade():

    op.drop_table("ai_safety_log")

    op.drop_table("investigation_assistant_runs")

```

---

## Q4 (Months 52–54): PoL V4 + Series C Readiness

### Goals
- PoL V4: multi-modal anomaly detection combining all 11 active feed domains into a joint model
- Series C materials prepared; term sheet negotiations or strategic M&A discussions
- Platform GMV crossing $5M annualized
- ARR target: $30M

---

### M52: PoL V4 — Multi-Modal Anomaly Detection

```

# oobe/engine/pol_v4_multimodal.py

"""

PoL V4: Multi-modal anomaly detection.

V1: IsolationForest on single-domain features (Phase 2)

V2: Ensemble (IF + LOF + Temporal Rhythm) (Phase 4)

V3: Temporal GNN using Neo4j proximity graph (Phase 6)

V4: Multi-modal fusion — joint model across aviation + maritime + conflict + linguistic

The V4 insight: anomalies are more detectable when you ask

"is this entity's behaviour anomalous GIVEN what all co-located entities are doing?"

rather than "is this entity's behaviour anomalous in isolation?"

Architecture:

  For each spatial cell (0.5° × 0.5° grid, ~50km cells at equator):

    - Collect all active entities from all domains in the cell

    - Build domain activity feature vector: [aviation_count, maritime_count,

      conflict_event_count, linguistic_entity_count, avg_aviation_confidence,

      avg_maritime_confidence, kp_index, air_quality_severity, ...]

    - Compare current cell state to cell's 30-day baseline

    - Cells with significant multi-domain deviation flag all contained entities

      as "contextually anomalous" even if their individual domain scores are normal

Use case:

  A vessel is behaving normally according to AIS.

  But in the same cell: aviation loitering detected, ACLED conflict event occurred,

  and a Telegram channel posted about military activity in the area.

  The vessel is contextually anomalous even though its AIS pattern is clean.

  This is the intelligence that no single-domain model can surface.

"""

import numpy as np

import logging

from datetime import datetime, timedelta, timezone

logger = logging.getLogger(__name__)

# 0.5° grid cell dimensions

CELL_SIZE_DEG = 0.5

# Domain weights for multi-modal feature vector

DOMAIN_WEIGHTS = {

    "aviation":      0.20,

    "maritime":      0.20,

    "conflict":      0.25,

    "linguistic":    0.15,

    "seismic":       0.05,

    "fire":          0.05,

    "disaster":      0.05,

    "space_weather": 0.02,

    "air_quality":   0.03,

}

def get_cell_key(lat: float, lon: float) -> str:

    """Map coordinates to grid cell identifier."""

    cell_lat = int(lat / CELL_SIZE_DEG) * CELL_SIZE_DEG

    cell_lon = int(lon / CELL_SIZE_DEG) * CELL_SIZE_DEG

    return f"{cell_lat:.1f}_{cell_lon:.1f}"

def build_cell_feature_vector(cell_key: str) -> np.ndarray:

             dependencies=[Depends(require_feature("investigation_assistant"))])

async def start_investigation(

    body: StartInvestigationRequest,

    user=Depends(get_current_user),

):

    """

    Start an autonomous investigation from a seed entity.

    Returns a checkpoint: the assistant's Phase 1 findings + prompt to continue.

    """

    if not ANTHROPIC_API_KEY:

        raise HTTPException(503, "Investigation Assistant not configured")

    # Verify the seed entity belongs to this org

    async with get_db_session() as db:

        entity = (await db.execute(text("""

            SELECT uuid, domain, display_name FROM entities

            WHERE uuid = :uuid AND org_id = :org

        """), {"uuid": body.seed_entity_uuid, "org": str(user.org_id)})).fetchone()

    if not entity:

        raise HTTPException(404, "Seed entity not found")

    # Rate limit: 5 investigation starts per org per day

    async with get_db_session() as db:

        today_count = (await db.execute(text("""

            SELECT COUNT(*) FROM investigation_assistant_runs

            WHERE org_id = :org AND created_at >= NOW() - INTERVAL '24 hours'

        """), {"org": str(user.org_id)})).fetchone()[0]

    max_daily = 20 if user.plan in ("enterprise", "government") else 5

    if today_count >= max_daily:

        raise HTTPException(429, f"Daily limit of {max_daily} investigation starts reached")

    # Get org's OOBE API key for tool calls

    async with get_db_session() as db:

        api_key_row = (await db.execute(text("""

            SELECT api_key FROM organizations WHERE id = :org

        """), {"org": str(user.org_id)})).fetchone()

    assistant = InvestigationAssistant(

        api_key=ANTHROPIC_API_KEY,

        oobe_api_key=api_key_row.api_key,

        org_id=str(user.org_id),

    )

    result = await assistant.start_investigation(

        seed_entity_uuid=body.seed_entity_uuid,

        investigation_uuid=body.investigation_uuid,

        analyst_objective=body.objective,

    )

    # Persist run state for continuation

    async with get_db_session() as db:

        await db.execute(text("""

            INSERT INTO investigation_assistant_runs

                (investigation_uuid, org_id, user_id, seed_entity_uuid,

                 objective, state_json, created_at)

            VALUES (:inv, :org, :user, :seed, :obj, :state::jsonb, NOW())

            ON CONFLICT (investigation_uuid) DO UPDATE SET

                state_json = EXCLUDED.state_json,

                updated_at = NOW()

        """), {

            "inv":   body.investigation_uuid,

            "org":   str(user.org_id),

            "user":  str(user.id),

            "seed":  body.seed_entity_uuid,

            "obj":   body.objective,

            "state": _serialize_state(assistant),

        })

        await db.commit()

    return result

@router.post("/continue",

             dependencies=[Depends(require_feature("investigation_assistant"))])

async def continue_investigation(

    body: ContinueInvestigationRequest,

    user=Depends(get_current_user),

):

    """Continue an investigation after an analyst checkpoint."""

    async with get_db_session() as db:

        run = (await db.execute(text("""

            SELECT state_json FROM investigation_assistant_runs

            WHERE investigation_uuid = :inv AND org_id = :org

        """), {"inv": body.investigation_uuid, "org": str(user.org_id)})).fetchone()

    if not run:

        raise HTTPException(404, "Investigation not found")

    async with get_db_session() as db:

        api_key_row = (await db.execute(text(

            "SELECT api_key FROM organizations WHERE id = :org"

        ), {"org": str(user.org_id)})).fetchone()

    assistant = _deserialize_state(run.state_json, ANTHROPIC_API_KEY, api_key_row.api_key, str(user.org_id))

    result    = await assistant.continue_investigation(body.investigation_uuid, body.analyst_message)

    # Update persisted state

    async with get_db_session() as db:

        await db.execute(text("""

            UPDATE investigation_assistant_runs

            SET state_json = :state::jsonb, updated_at = NOW()

            WHERE investigation_uuid = :inv

        """), {"state": _serialize_state(assistant), "inv": body.investigation_uuid})

        await db.commit()

    return result

def _serialize_state(assistant: InvestigationAssistant) -> str:

    import json

    return json.dumps({

        "messages":  assistant.messages,

        "tool_log":  assistant.tool_log,

    })

def _deserialize_state(

    state_json: dict,

    """

    Build a 20-dimensional feature vector describing current activity

    in a 0.5° grid cell across all domains.

    Features:

      [0..10]  Entity count per domain (11 domains)

      [11..21] Mean confidence per domain (11 domains)

      ... (expandable)

    """

    from ..db import get_sync_db_session

    from sqlalchemy import text

    lat_str, lon_str = cell_key.split("_")

    lat_min = float(lat_str)

    lon_min = float(lon_str)

    with get_sync_db_session() as db:

        rows = db.execute(text("""

            SELECT domain, COUNT(*) AS cnt, AVG(confidence) AS avg_conf

            FROM entities

            WHERE current_lat BETWEEN :lat_min AND :lat_max

              AND current_lon BETWEEN :lon_min AND :lon_max

              AND last_seen >= NOW() - INTERVAL '1 hour'

              AND confidence > 0.2

            GROUP BY domain

        """), {

            "lat_min": lat_min,     "lat_max": lat_min + CELL_SIZE_DEG,

            "lon_min": lon_min,     "lon_max": lon_min + CELL_SIZE_DEG,

        }).fetchall()

    domain_data = {r.domain: (r.cnt, r.avg_conf) for r in rows}

    domains     = list(DOMAIN_WEIGHTS.keys())

    counts  = np.array([domain_data.get(d, (0, 0))[0] for d in domains], dtype=np.float32)

    confs   = np.array([domain_data.get(d, (0, 1.0))[1] for d in domains], dtype=np.float32)

    return np.concatenate([counts, confs])

def score_cell_anomaly(

    cell_key:          str,

    current_vector:    np.ndarray,

    baseline_mean:     np.ndarray,

    baseline_std:      np.ndarray,

): -> float:

    """

    Score a cell's current state against its 30-day baseline using z-scores.

    Returns max z-score across weighted domains.

    A z-score > 3.0 indicates significant multi-modal deviation.

    """

    safe_std = np.where(baseline_std < 0.1, 0.1, baseline_std)

    z_scores  = np.abs(current_vector - baseline_mean) / safe_std

    domains   = list(DOMAIN_WEIGHTS.keys())

    weights   = np.array([DOMAIN_WEIGHTS[d] for d in domains] * 2)  # counts + confs

    weighted_max = float(np.max(z_scores[:len(domains)] * weights[:len(domains)]))

    return weighted_max

```

---

### M54: Series C Readiness

```

# docs/investor/SERIES_C_POSITIONING.md

## OOBE Series C Thesis

### What changed between Series B and Series C

Series A: Proved the product works and people pay for it.

Series B: Proved the platform thesis (network effects, international, government).

Series C: Proving that OOBE is a durable category leader with the infrastructure

          to support $100M+ ARR.

### The Numbers That Matter

  ARR:           $30M (from $10M at Series B; 3× in 18 months)

  Growth rate:   >80% YoY (maintained through international expansion)

  NRR:           >140% (language layer + joint entity model drive massive expansion)

  Gross margin:  >85% (data licensing approaching infrastructure cost)

  Platform GMV:  $5M+ annualized (Data Marketplace becoming a real revenue stream)

  Gov contracts: 5+ active (US, UK, AU, one NATO European ally)

### Series C Ask: $50–80M

Use of funds:

  35% Product ($17.5–28M)

    - OOBE Language Layer: expand to 20 languages

    - Investigation Assistant V2: structured report output, briefing templates

    - PoL V4 at scale: 10M+ entities, real-time multi-modal scoring

    - OOBE for SECRET: infrastructure for classification-level deployment

      (this requires cleared personnel and a SCIF — serious capital requirement)

  35% International GTM ($17.5–28M)

    - APAC: Singapore office, Australia government pathway

    - Europe: Berlin or Brussels hub for EU government sales

    - Middle East: UAE presence (GITEX, Abu Dhabi defence ecosystem)

    - Japan/South Korea: partner-led entry via Five Eyes adjacent relationships

  20% Platform ($10–16M)

    - Investigation Assistant: 100K analyst-hours of autonomous investigation per month

    - Data Marketplace: target $20M annualized GMV

    - App Registry: 100+ approved third-party applications

  10% Compliance ($5–8M)

    - FedRAMP HIGH (the ceiling before JWICS/SIPRNet)

    - UK Developed Vetting for key personnel

    - EU NIS2 compliance (required for European critical infrastructure customers)

### The M&A Conversation

At $30M ARR with the moats described, OOBE is an attractive acquisition target.

Strategic value exceeds financial value for several acquirers:

  Palantir ($80B market cap):

    OOBE adds the open-source community + FedRAMP stack + data marketplace flywheel

    that Palantir explicitly does not have. Palantir's community engagement is poor.

    OOBE's is its best acquisition channel.

    Multiple: 20–25× ARR = $600M–$750M.

  Microsoft (GitHub/Azure Government):

    OOBE as the intelligence layer for Azure Government + Microsoft Sentinel.

    Could be bundled into Defender TI or sold alongside GitHub Copilot for security.

    Multiple: 15–20× ARR = $450M–$600M.

  Maxar (satellite + GEOINT):

    OOBE as the fusion layer consuming Maxar's imagery.

    Partnership has already been discussed in Phase 4/5 timeline.

    Multiple: 12–15× ARR = $360M–$450M.