# Phase 6 — Global Intelligence Platform & FedRAMP Moderate

Test block 1

# OOBE Phase 6: Global Intelligence Platform

## Complete Engineering Specification — Months 31–42

### Post-Series A: international expansion, mobile, FedRAMP Moderate, network effects

---

## Entry State: Month 31

The Series A is closed. The check is in the bank. The team is 8 people and about to become 15. Everything that mattered before — survival, product-market fit, first government contract — has been proved. The new problems are entirely different: distributed systems that must work across jurisdictions, a mobile product that analysts use in the field, ML infrastructure that retrains continuously on 2+ years of accumulated data, and a compliance posture that can absorb FedRAMP Moderate without grinding the engineering team to a halt.

Confirmed operational at Month 31 entry:

```
| Capability | Status | Metric |
|------------|--------|--------|
| $5–8M Series A closed | ✅ | Runway: 24–30 months |
| $125K MRR (~$1.5M ARR) | ✅ | NRR >120% |
| 120 Pro + 12 Enterprise + 2 Gov customers | ✅ | |
| FedRAMP Tailored ATO | ✅ | |
| Platform API v2 + App Registry (10 apps) | ✅ | |
| Data Marketplace (25 datasets, paid tiers) | ✅ | |
| PoL V3 GNN in canary or full production | ✅ | FP rate <6% |
| Multi-region (EU-West + US-East) | ✅ | |
| Intelligence Digest (5,000 subscribers) | ✅ | |
| Analyst Certification (ANA1–3) | ✅ | |
| OSINT Investigator Toolkit | ✅ | |
| 8-person team | ✅ | |
```

**Series A use of funds ($7M baseline):**

- 50% Engineering ($3.5M): Mobile app, FedRAMP Moderate, PoL V3 full rollout, MLOps platform, AP-region infrastructure
- 30% GTM ($2.1M): Enterprise Sales Director + 2 AEs, Government BD, EU partner channel
- 20% Compliance ($1.4M): FedRAMP Moderate 3PAO, GDPR DPA registration, UK Cyber Essentials Plus

**Phase 6 covers 12 months across four quarters:**

```
| Quarter | Months | Theme | ARR Target | Key Deliverable |
|---------|--------|-------|-----------|-----------------|
| Q1 | 31–33 | Mobile + MLOps | $3M ARR | iOS/Android app, continuous model retraining pipeline |
| Q2 | 34–36 | International Expansion | $5M ARR | EU region, UK gov pathway, Five Eyes partner channel |
| Q3 | 37–39 | FedRAMP Moderate + DoD | $7M ARR | Moderate ATO, first DoD contract, JWICS pathway research |
| Q4 | 40–42 | Network Effects + Series B Readiness | $10M ARR | Platform GMV >$1M, Series B positioning |
```

**Hiring plan (Month 31–42):**

- M31: Engineering Manager (backend/infra lead)
- M31: Senior Mobile Engineer (iOS + Android)
- M32: Enterprise Account Executive #1
- M33: Enterprise Account Executive #2 (EU-focused)
- M34: Government Business Development Director
- M35: MLOps Engineer
- M36: Senior Frontend Engineer (takes over SENTINEL OS → React migration)
- M38: DevSecOps / FedRAMP Compliance Engineer
- M39: Solutions Architect (pre-sales technical)
- M40: Data Science Engineer (PoL V3 + future models)

---

## Q1 (Months 31–33): Mobile App + MLOps Platform

### Goals

- Ship iOS and Android apps: field-usable OOBE for analysts away from a desktop
- Build the MLOps pipeline: automated continuous retraining as data accumulates
- Complete PoL V3 GNN rollout to 100% of eligible entities
- Launch OOBE API v3: versioned, backward-compatible, with deprecation policy
- ARR target: $3M (~$250K MRR)

---

### M31: Native Mobile App

The mobile app is not a feature — it is a category shift. An analyst at a port facility, or at a field location during a humanitarian response, needs a map that works on a phone with intermittent connectivity. The Phase 1 SENTINEL OS HTML frontend does not work on mobile. This is the spec for the real replacement.

**Architecture decision: React Native vs. native iOS/Android**

React Native is the correct choice here. Reasons: the team's existing TypeScript/JavaScript competence, shared business logic with the web frontend, Leaflet.js has a React Native port (`react-native-maps` with MapLibre GL), and the hire profile for a React Native engineer overlaps 80% with a React web engineer. The tradeoff is that RN occasionally requires native module bridging for complex map interactions — acceptable at this scale.

```tsx
// mobile/src/screens/MapScreen.tsx
/**
 * Primary intelligence map screen for OOBE mobile.
 *
 * Architecture decisions:
 *   - MapLibre GL Native (react-native-maplibre-gl) for vector tiles
 *   - Self-hosted tile server (oobe-tileserver in EU + US) for offline caching
 *   - Entity data from Platform API v2 SSE stream (reconnects on app resume)
 *   - Local SQLite cache: last 500 entities + last 50 alerts for offline viewing
 *   - Optimistic UI: show cached entity positions while reconnecting
 *
 * Performance constraints:
 *   - Max 200 entity markers rendered simultaneously on mobile (vs 2000 on web)
 *   - Cluster markers at zoom <8: replace individual markers with count bubbles
 *   - WebSocket replaces SSE on mobile: better battery life with keep-alive control
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  View, StyleSheet, Alert, AppState, AppStateStatus,
} from 'react-native';
import MapLibreGL from '@maplibre/maplibre-react-native';
import { useDispatch, useSelector } from 'react-redux';
import { EntityMarkerLayer } from '../components/EntityMarkerLayer';
import { AlertBanner } from '../components/AlertBanner';
import { ConfidenceFilterBar } from '../components/ConfidenceFilterBar';
import { EntityDetailSheet } from '../components/EntityDetailSheet';
import { useOobeWebSocket } from '../hooks/useOobeWebSocket';
import { useOfflineCache } from '../hooks/useOfflineCache';
import { RootState } from '../store';
import { setEntities, updateEntity, expireEntity } from '../store/entitySlice';

// Self-hosted tile server URLs (served from AWS CloudFront → tileserver-gl)
const TILE_URL_EU = 'https://tiles-eu.oobe.io/styles/oobe-dark/{z}/{x}/{y}.pbf';
const TILE_URL_US = 'https://tiles-us.oobe.io/styles/oobe-dark/{z}/{x}/{y}.p
```

```tsx
bf';
const TILE_FALLBACK = 'https://api.maptiler.com/tiles/v3/{z}/{x}/{y}.pbf?key=FREE_KEY';

interface MapScreenProps {
  navigation: any;
}

export const MapScreen: React.FC<MapScreenProps> = ({ navigation }) => {
  const dispatch     = useDispatch();
  const entities     = useSelector((s: RootState) => s.entities.items);
  const apiKey       = useSelector((s: RootState) => s.auth.apiKey);
  const userRegion   = useSelector((s: RootState) => s.auth.region); // 'eu' | 'us'

  const [selectedEntityUuid, setSelectedEntityUuid] = useState<string | null>(null);
  const [minConfidence, setMinConfidence]             = useState(0.3);
  const [activeDomains, setActiveDomains]             = useState<string[]>(
    ['aviation', 'maritime', 'conflict']
  );
  const appState = useRef(AppState.currentState);

  // Offline cache: loads on mount, persists on background
  const { loadCache, saveCache, getCachedEntity } = useOfflineCache();

  // WebSocket connection to Platform API v2
  const { isConnected, reconnect } = useOobeWebSocket({
    apiKey,
    domains: activeDomains,
    onEntityUpdate: useCallback((payload: any) => {
      dispatch(updateEntity(payload));
    }, [dispatch]),
    onEntityExpired: useCallback((payload: any) => {
      dispatch(expireEntity(payload.uuid));
    }, [dispatch]),
    onAlert: useCallback((alert: any) => {
      // Push local notification for HIGH/CRITICAL alerts
      if (['HIGH', 'CRITICAL'].includes(alert.severity)) {
        _sendLocalNotification(alert);
      }
    }, []),
  });

  // Handle app foreground/background transitions
  useEffect(() => {
    const sub = AppState.addEventListener('change', (next: AppStateStatus) => {
      if (appState.current === 'background' && next === 'active') {
        reconnect();   // Reconnect WebSocket o
```

```tsx
n foreground
      }
      if (next === 'background') {
        saveCache(Object.values(entities).slice(0, 500));
      }
      appState.current = next;
    });
    return () => sub.remove();
  }, [entities, reconnect, saveCache]);

  // Initial load: show cached entities immediately, then hydrate from API
  useEffect(() => {
    loadCache().then(cached => {
      if (cached.length > 0) {
        dispatch(setEntities(cached));
      }
    });
  }, []);

  const tileUrl = userRegion === 'us' ? TILE_URL_US : TILE_URL_EU;

  return (
    <View style={styles.container}>
      <MapLibreGL.MapView
        style={styles.map}
        styleURL={tileUrl}
        logoEnabled={false}
        compassEnabled
        onPress={() => setSelectedEntityUuid(null)}
      >
        <MapLibreGL.Camera
          defaultSettings={{
            centerCoordinate: [0, 20],
            zoomLevel: 2,
          }}
          animationDuration={300}
        />

        <EntityMarkerLayer
          entities={Object.values(entities)}
          minConfidence={minConfidence}
          activeDomains={activeDomains}
          maxMarkers={200}
          onEntityPress={setSelectedEntityUuid}
        />
      </MapLibreGL.MapView>

      <ConfidenceFilterBar
        value={minConfidence}
        onChange={setMinConfidence}
        connectionStatus={isConnected ? 'live' : 'offline'}
      />

      {selectedEntityUuid && (
        <EntityDetailSheet
          entityUuid={selectedEntityUuid}
          onClose={() => setSelectedEntityUuid(null)}
          onNavigate={(uuid) => navigation.push('EntityHistory', { uuid })}
        />
      )}

      <AlertBanner />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1 },
  map:       { flex: 1 },
});

function _sendLocalNotification(alert: a
```

```tsx
ny) {
  // Uses expo-notifications or @notifee/react-native
  // Implementation in hooks/useLocalNotifications.ts
}
```

---

#### Offline Cache with SQLite

```tsx
// mobile/src/hooks/useOfflineCache.ts
/**
 * Local SQLite cache for offline-first map experience.
 * Uses expo-sqlite (or react-native-sqlite-storage for bare RN).
 *
 * Schema:
 *   entities: uuid, domain, lat, lon, confidence, display_name, metadata_json, cached_at
 *   alerts:   uuid, title, severity, alert_type, created_at, acknowledged, metadata_json
 *
 * Cache policy:
 *   - Store last 500 entities seen (evict oldest by last_seen)
 *   - Store last 50 alerts (evict acknowledged alerts first)
 *   - Cache invalidated after 6 hours (entity positions are too stale for operational use)
 *   - On reconnect, merge live data over cached data (live wins on conflict)
 */
import * as SQLite from 'expo-sqlite';
import { useCallback, useRef } from 'react';

const DB_NAME  = 'oobe_offline.db';
const MAX_ENTITIES = 500;
const CACHE_TTL_HOURS = 6;

export function useOfflineCache() {
  const dbRef = useRef<SQLite.SQLiteDatabase | null>(null);

  const getDb = useCallback(async () => {
    if (!dbRef.current) {
      dbRef.current = await SQLite.openDatabaseAsync(DB_NAME);
      await dbRef.current.execAsync(`
        CREATE TABLE IF NOT EXISTS entities (
          uuid         TEXT PRIMARY KEY,
          domain       TEXT NOT NULL,
          lat          REAL,
          lon          REAL,
          confidence   REAL DEFAULT 1.0,
          display_name TEXT,
          metadata     TEXT DEFAULT '{}',
          cached_at    INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS alerts (
          uuid         TEXT PRIMARY KEY,
          title        TEXT,
          severity     TEXT,
          alert_type   TEXT,
          acknowledged INTEGER DEFAULT 0,
          metadata     TEXT DEFAULT '{}',
          created_at   INTEGER NOT NULL
        );
        CREATE INDEX IF NOT
```

```tsx
 EXISTS idx_entities_cached ON entities(cached_at);
      `);
    }
    return dbRef.current;
  }, []);

  const saveCache = useCallback(async (entities: any[]) => {
    const db  = await getDb();
    const now = Date.now();
    await db.withTransactionAsync(async () => {
      for (const e of entities.slice(0, MAX_ENTITIES)) {
        await db.runAsync(
          `INSERT OR REPLACE INTO entities
            (uuid, domain, lat, lon, confidence, display_name, metadata, cached_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [e.uuid, e.domain, e.lat ?? e.current_lat, e.lon ?? e.current_lon,
           e.confidence, e.display_name, JSON.stringify(e.metadata || {}), now]
        );
      }
      // Evict entities beyond MAX_ENTITIES (keep newest)
      await db.runAsync(
        `DELETE FROM entities WHERE uuid NOT IN (
          SELECT uuid FROM entities ORDER BY cached_at DESC LIMIT ?
        )`,
        [MAX_ENTITIES]
      );
    });
  }, [getDb]);

  const loadCache = useCallback(async (): Promise<any[]> => {
    const db        = await getDb();
    const cutoff    = Date.now() - CACHE_TTL_HOURS * 3600 * 1000;
    const rows      = await db.getAllAsync<any>(
      `SELECT * FROM entities WHERE cached_at > ? ORDER BY cached_at DESC`,
      [cutoff]
    );
    return rows.map(r => ({
      ...r,
      metadata:  JSON.parse(r.metadata || '{}'),
      _fromCache: true,
    }));
  }, [getDb]);

  const getCachedEntity = useCallback(async (uuid: string): Promise<any | null> => {
    const db  = await getDb();
    const row = await db.getFirstAsync<any>(
      `SELECT * FROM entities WHERE uuid = ?`, [uuid]
    );
    return row ? { ...row, metadata: JSON.parse(row.metadata || '{}') } : null;
  }, [getDb]);

  return { saveCache, loadCache, getCachedEntity };
}
```

---

#### WebSocket Hook with Reconnection

```tsx
// mobile/src/hooks/useOobeWebSocket.ts
/**
 * Manages WebSocket connection to OOBE Platform API.
 * Handles:
 *   - Initial connection with JWT/API key auth
 *   - Automatic exponential backoff reconnection (1s → 2s → 4s → ... → 60s max)
 *   - Subscription filtering sent on connect
 *   - App state transitions (pause on background, resume on foreground)
 *   - Network type awareness: disable on cellular if user preference set
 */
import { useEffect, useRef, useCallback, useState } from 'react';
import NetInfo from '@react-native-community/netinfo';

const WS_BASE   = 'wss://api.oobe.io/ws/live';
const MAX_DELAY = 60_000;

interface UseOobeWebSocketOptions {
  apiKey:          string;
  domains:         string[];
  onEntityUpdate:  (payload: any) => void;
  onEntityExpired: (payload: any) => void;
  onAlert:         (alert: any) => void;
}

export function useOobeWebSocket(opts: UseOobeWebSocketOptions) {
  const ws           = useRef<WebSocket | null>(null);
  const retryCount   = useRef(0);
  const retryTimer   = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  const connect = useCallback(() => {
    if (ws.current?.readyState === WebSocket.OPEN) return;

    const url  = `${WS_BASE}?token=${opts.apiKey}`;
    const sock = new WebSocket(url);

    sock.onopen = () => {
      retryCount.current = 0;
      setIsConnected(true);
      sock.send(JSON.stringify({
        type:    'subscribe',
        domains: opts.domains,
      }));
    };

    sock.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        switch (msg.type) {
          case 'entity_update':
          case 'entity_degraded':
            opts.onEntityUpdate(msg);
            break;
          case 'entity_expired':
       
```

```tsx
     opts.onEntityExpired(msg);
            break;
          case 'alert_triggered':
            opts.onAlert(msg.alert);
            break;
          case 'pong':
            break;  // Heartbeat acknowledged
        }
      } catch { /* ignore malformed messages */ }
    };

    sock.onerror = () => { /* onclose handles reconnection */ };

    sock.onclose = () => {
      setIsConnected(false);
      ws.current = null;
      const delay = Math.min(1000 * 2 ** retryCount.current, MAX_DELAY);
      retryCount.current += 1;
      retryTimer.current = setTimeout(() => {
        NetInfo.fetch().then(state => {
          if (state.isConnected) connect();
        });
      }, delay);
    };

    ws.current = sock;

    // Heartbeat ping every 25s
    const pingInterval = setInterval(() => {
      if (sock.readyState === WebSocket.OPEN) {
        sock.send(JSON.stringify({ type: 'ping' }));
      }
    }, 25_000);

    return () => clearInterval(pingInterval);
  }, [opts]);

  const reconnect = useCallback(() => {
    if (retryTimer.current) clearTimeout(retryTimer.current);
    retryCount.current = 0;
    ws.current?.close();
    connect();
  }, [connect]);

  useEffect(() => {
    connect();
    return () => {
      if (retryTimer.current) clearTimeout(retryTimer.current);
      ws.current?.close();
    };
  }, []);

  return { isConnected, reconnect };
}
```

---

#### App Store Submission Checklist

```markdown
# docs/mobile/APP_STORE_CHECKLIST.md

## Apple App Store (iOS)
Required before submission:

### Technical
- [x] iOS 16.0 minimum deployment target
- [x] Privacy manifest (PrivacyInfo.xcprivacy): declare NSUserDefaults, FileTimestamp usage
- [x] App Transport Security: all connections use TLS 1.3
- [x] Background fetch: disabled (entity data not refreshed in background — battery drain)
- [x] Local notifications: request permission on first alert trigger
- [x] No IDFA/tracking frameworks
- [x] App size: < 50MB initial download (MapLibre tiles stream on demand)

### Legal / Privacy
- [x] Privacy policy URL in App Store Connect: https://oobe.io/privacy
- [x] Data collection disclosure: "OOBE collects location access (optional, for AoI centering)"
- [x] Export compliance: CCATS not required (OOBE uses standard TLS; no custom encryption beyond AES-256 standard commercial)
- [x] Age rating: 4+ (no objectionable content; OSINT map data is not graphic)

### App Store Metadata
- Title: "OOBE — Intelligence Map"
- Subtitle: "Live OSINT situational awareness"
- Keywords: osint, intelligence, maritime, aviation, situational awareness, tracking
- Screenshots: 6.5" iPhone, 12.9" iPad Pro

## Google Play Store (Android)
- [x] Target SDK: 35 (Android 15)
- [x] Min SDK: 26 (Android 8.0)
- [x] App Bundle (.aab), not APK
- [x] Data Safety form: No PII collected; data encrypted in transit and at rest
- [x] ProGuard/R8 obfuscation for production builds
- [x] Play Integrity API: enabled (blocks rooted device abuse of API keys)
```

---

### M32: MLOps Platform — Continuous Model Retraining

By Month 32, OOBE has 26+ months of accumulated entity observation data. The IsolationForest models trained in Phase 2 were built on 14 days of data. They need to be retrained on the full corpus, and the retraining pipeline needs to be automated, monitored, and rolled back if quality degrades.

```python
# oobe/mlops/pipeline.py
"""
MLOps platform for OOBE anomaly detection models.

Components:
  1. Data versioning   — DVC-tracked snapshots of training datasets in S3
  2. Experiment tracking — MLflow for hyperparameter logging + metric comparison
  3. Model registry    — MLflow Model Registry with staging → production promotion
  4. Automated retraining — Triggered weekly OR when concept drift detected
  5. A/B shadow scoring — New model shadow-scores alongside production before promotion
  6. Rollback          — Automatic revert if production metrics degrade >15%

Stack:
  MLflow 2.x            — experiment tracking + registry (self-hosted on ECS)
  DVC 3.x               — data versioning (S3 remote)
  Evidently AI 0.4.x    — data drift detection
  Celery                — training job scheduling
  AWS SageMaker         — optional training infrastructure for large jobs
"""
import os, logging, hashlib
from datetime import datetime, timezone, timedelta
from pathlib import Path
import mlflow
import mlflow.sklearn
from evidently.report import Report
from evidently.metric_preset import DataDriftPreset
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import RobustScaler
from sklearn.pipeline import Pipeline

logger = logging.getLogger(__name__)

MLFLOW_TRACKING_URI = os.environ.get(
    "MLFLOW_TRACKING_URI", "http://mlflow:5000"
)
mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)

DRIFT_THRESHOLD     = 0.15   # Trigger retraining if drift score > 15%
PERFORMANCE_FLOOR   = 0.85   # Rollback if analyst TP rate drops below 85%
MIN_TRAINING_ROWS   = 50_000 # Require substantial data before full retraining

def run_retraining_pipeline(domain: str, entity_type: str) -> str | None:
    """
    Full retraining pipeline for on
```

```python
e (domain, entity_type) cohort.
    Returns new model run_id if training succeeded, None if skipped.
    """
    run_name = f"{domain}_{entity_type}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M')}"

    with mlflow.start_run(run_name=run_name,
                          experiment_id=_get_or_create_experiment(domain)):
        # 1. Load training data
        df = _load_training_data(domain, entity_type)
        if df is None or len(df) < MIN_TRAINING_ROWS:
            logger.info(f"Insufficient data for {domain}/{entity_type}: {len(df) if df is not None else 0} rows")
            mlflow.log_param("skipped_reason", "insufficient_data")
            return None

        mlflow.log_param("training_rows", len(df))
        mlflow.log_param("domain",        domain)
        mlflow.log_param("entity_type",   entity_type)
        mlflow.log_param("data_start",    str(df[\"ts\"].min()))
        mlflow.log_param("data_end",      str(df[\"ts\"].max()))

        # 2. Detect concept drift vs. current production model
        drift_score = _detect_drift(domain, entity_type, df)
        mlflow.log_metric("drift_score", drift_score)

        if drift_score < DRIFT_THRESHOLD and not _is_weekly_scheduled_run():
            logger.info(f"No significant drift ({drift_score:.3f}) for {domain}/{entity_type}")
            return None

        # 3. Build feature matrix
        X = _build_feature_matrix(df, domain)
        mlflow.log_param("feature_count",  X.shape[1])
        mlflow.log_param("sample_count",   X.shape[0])

        # 4. Train ensemble
        contamination = _estimate_contamination(domain, entity_type)
        mlflow.log_param("contamination",  contamination)

        pipe = Pipeline([
            (\"scaler\",  RobustScaler()),
            (\"iforest\", IsolationForest(
     
```

```python
           n_estimators=200,
                contamination=contamination,
                max_samples=min(X.shape[0], 256),
                random_state=42,
                n_jobs=-1,
            ))
        ])
        pipe.fit(X)

        # 5. Evaluate on holdout
        metrics = _evaluate_on_holdout(pipe, domain, entity_type)
        for k, v in metrics.items():
            mlflow.log_metric(k, v)

        if metrics.get(\"analyst_tp_rate\", 1.0) < PERFORMANCE_FLOOR:
            logger.warning(
                f\"New model {domain}/{entity_type} analyst TP rate \"
                f\"{metrics.get('analyst_tp_rate'):.2f} < {PERFORMANCE_FLOOR}. \"
                f\"Not promoting to staging.\"
            )
            return None

        # 6. Log model to registry
        model_info = mlflow.sklearn.log_model(
            pipe,
            artifact_path=\"model\",
            registered_model_name=f\"oobe_pol_{domain}_{entity_type}\",
        )
        run_id = mlflow.active_run().info.run_id

        # 7. Transition to staging (requires explicit promotion to production)
        client = mlflow.tracking.MlflowClient()
        latest = client.get_latest_versions(
            f\"oobe_pol_{domain}_{entity_type}\", stages=[\"None\"]
        )[0]
        client.transition_model_version_stage(
            name=f\"oobe_pol_{domain}_{entity_type}\",
            version=latest.version,
            stage=\"Staging\",
        )
        logger.info(
            f\"Model {domain}/{entity_type} v{latest.version} moved to Staging. \"
            f\"Run ID: {run_id}\"
        )
        return run_id

def promote_staging_to_production(domain: str, entity_type: str):
    """
    Manually triggered (or auto after 48h shadow scoring with no degradation).
    Moves Staging model to Produc
```

```python
tion and archives previous Production.
    """
    client     = mlflow.tracking.MlflowClient()
    model_name = f\"oobe_pol_{domain}_{entity_type}\"

    staging_versions = client.get_latest_versions(model_name, stages=[\"Staging\"])
    if not staging_versions:
        raise ValueError(f\"No staging model for {domain}/{entity_type}\")

    # Archive current production
    prod_versions = client.get_latest_versions(model_name, stages=[\"Production\"])
    for v in prod_versions:
        client.transition_model_version_stage(
            name=model_name, version=v.version, stage=\"Archived\"
        )

    # Promote staging → production
    staging_v = staging_versions[0]
    client.transition_model_version_stage(
        name=model_name, version=staging_v.version, stage=\"Production\"
    )

    # Update DB pol_models table
    _update_pol_models_db(domain, entity_type, model_name, staging_v.version)
    logger.info(f\"Promoted {model_name} v{staging_v.version} to Production\")

def _detect_drift(domain: str, entity_type: str, new_df: pd.DataFrame) -> float:
    """
    Uses Evidently AI to compute drift score between current production
    training data distribution and new training data.
    Returns 0.0 if no production model exists (always retrain).
    """
    current_train_path = _get_current_train_data_path(domain, entity_type)
    if not current_train_path:
        return 1.0   # No existing model → always train

    try:
        reference_df = pd.read_parquet(current_train_path)
        report = Report(metrics=[DataDriftPreset()])
        report.run(reference_data=reference_df, current_data=new_df)
        result = report.as_dict()
        return float(
            result[\"metrics\"][0][\"result\"][\"dataset_drift_score\"]
        )
    except Exception as e:

```

```python
        logger.warning(f\"Drift detection failed: {e}\")
        return 0.5   # Conservative: assume moderate drift

def _estimate_contamination(domain: str, entity_type: str) -> float:
    """
    Dynamically estimate contamination based on analyst feedback TP rate.
    If analysts confirm 8% of anomaly alerts as true positives,
    contamination should be ~0.08 to match observed anomaly prevalence.
    Falls back to 0.05 if no feedback data.
    """
    from ..db import get_sync_db_session
    from sqlalchemy import text

    with get_sync_db_session() as db:
        row = db.execute(text("""
            SELECT
                COUNT(*) FILTER (WHERE rating = 'true_positive') AS tp,
                COUNT(*) AS total
            FROM analyst_feedback
            WHERE feedback_type = 'anomaly'
              AND created_at >= NOW() - INTERVAL '90 days'
        """)).fetchone()

    if not row or row.total < 50:
        return 0.05

    estimated = float(row.tp) / float(row.total)
    # Clamp to reasonable range
    return max(0.01, min(0.15, estimated))

def _load_training_data(domain: str, entity_type: str) -> pd.DataFrame | None:
    \"\"\"Load full observation history for training — up to 24 months.\"\"\"
    from ..db import get_sync_db_session
    from sqlalchemy import text

    with get_sync_db_session() as db:
        rows = db.execute(text("""
            SELECT
                o.entity_uuid,
                o.ts,
                o.lat,
                o.lon,
                (o.metadata->>'speed_kt')::float     AS speed_kt,
                (o.metadata->>'heading_deg')::float  AS heading_deg,
                (o.metadata->>'altitude_ft')::float  AS altitude_ft,
                o.metadata->>'squawk'                AS squawk,
                (o.metadata->
```

```python
>'draught_m')::float    AS draught_m
            FROM observations o
            JOIN entities e ON e.uuid = o.entity_uuid
            WHERE e.domain      = :domain
              AND e.entity_type = :etype
              AND o.ts >= NOW() - INTERVAL '24 months'
            ORDER BY o.entity_uuid, o.ts
            LIMIT 10000000
        """), {"domain": domain, "etype": entity_type}).fetchall()

    if not rows:
        return None

    return pd.DataFrame(rows, columns=[
        "entity_uuid","ts","lat","lon","speed_kt","heading_deg",
        "altitude_ft","squawk","draught_m"
    ])

def _build_feature_matrix(df: pd.DataFrame, domain: str) -> np.ndarray:
    \"\"\"Build numeric feature matrix from raw observation dataframe.\"\"\"
    from ..engine.pol_features import extract_features, compute_centroid
    from collections import defaultdict

    entity_groups = defaultdict(list)
    for _, row in df.iterrows():
        entity_groups[row["entity_uuid"]].append(row.to_dict())

    all_features = []
    for uuid, obs_list in entity_groups.items():
        if len(obs_list) < 3:
            continue
        obs_list.sort(key=lambda x: x["ts"])
        centroid = compute_centroid(obs_list)
        X = extract_features(obs_list, centroid[0], centroid[1], domain)
        all_features.append(X)

    if not all_features:
        return np.zeros((1, 10))

    return np.vstack(all_features)

def _evaluate_on_holdout(
    pipe, domain: str, entity_type: str
) -> dict:
    \"\"\"
    Evaluate new model on last 30 days of confirmed analyst feedback.
    Returns metrics dict.
    \"\"\"
    from ..db import get_sync_db_session
    from sqlalchemy import text

    with get_sync_db_session() as db:
        feedback = db.execute(text("""
            SELEC
```

```python
T rating, anomaly_score
            FROM analyst_feedback
            WHERE feedback_type = 'anomaly'
              AND created_at >= NOW() - INTERVAL '30 days'
              AND anomaly_score IS NOT NULL
        """)).fetchall()

    if not feedback:
        return {"analyst_tp_rate": 1.0, "feedback_count": 0}

    tp = sum(1 for f in feedback if f.rating == "true_positive")
    total = len(feedback)
    return {
        "analyst_tp_rate": tp / total if total > 0 else 1.0,
        "feedback_count":  total,
        "fp_rate":         (total - tp) / total if total > 0 else 0.0,
    }

def _get_or_create_experiment(domain: str) -> str:
    exp_name = f\"oobe_pol_{domain}\"
    exp = mlflow.get_experiment_by_name(exp_name)
    if exp is None:
        return mlflow.create_experiment(exp_name)
    return exp.experiment_id

def _is_weekly_scheduled_run() -> bool:
    \"\"\"True if this run was triggered by the weekly Celery beat schedule.\"\"\"
    return os.environ.get(\"POL_RETRAINING_SCHEDULED\", \"0\") == \"1\"

def _get_current_train_data_path(domain: str, entity_type: str) -> str | None:
    \"\"\"Returns S3 path of most recent training dataset snapshot.\"\"\"
    import boto3
    s3 = boto3.client(\"s3\")
    bucket = os.environ.get(\"S3_MODELS_BUCKET\", \"oobe-pol-models-prod\")
    prefix = f\"training_data/{domain}_{entity_type}/\"
    try:
        objs = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)[\"Contents\"]
        latest = max(objs, key=lambda o: o[\"LastModified\"])
        return f\"s3://{bucket}/{latest['Key']}\"
    except (KeyError, ValueError):
        return None

def _update_pol_models_db(
    domain: str, entity_type: str, model_name: str, version: int
):
    from ..db import get_sync_db_session
    from sqlalchemy import text

```

```python

    model_uri = f\"models:/{model_name}/{version}\"
    with get_sync_db_session() as db:
        db.execute(text("""
            UPDATE pol_models
            SET is_active = FALSE
            WHERE domain = :domain AND entity_type = :etype AND is_active = TRUE
        """), {"domain": domain, "etype": entity_type})
        db.execute(text("""
            INSERT INTO pol_models
                (domain, entity_type, model_path, trained_at, is_active)
            VALUES (:domain, :etype, :path, NOW(), TRUE)
        """), {"domain": domain, "etype": entity_type, "path": model_uri})
        db.commit()
```

---

### M33: OOBE API v3 — Versioning and Deprecation Policy

At Phase 6 scale, the API is consumed by paying customers who have built integrations. Breaking changes must be managed formally.

```python
# oobe/api/versioning.py
"""
OOBE API versioning strategy.

Approach: URI versioning with sunset headers.
  /v1/  — Deprecated at Month 33. Sunset: Month 39 (6-month notice).
  /v2/  — Current (Phase 2–5). No sunset date.
  /v3/  — New in Phase 6. Recommended for all new integrations.

v3 additions (not breaking for v2):
  - Cursor-based pagination (replaces limit/offset)
  - Expanded entity schema: bbox, area_km2 for non-point entities
  - Batch acknowledgment: PATCH /v3/alerts/bulk-acknowledge
  - Entity merge: POST /v3/entities/merge (combine duplicate entities)
  - Streaming response hints: Link header with SSE stream URL
  - Structured errors: RFC 9457 Problem Details format

Backward compatibility guarantees:
  - v2 endpoints remain operational until sunset date
  - Sunset-Reply header added to v1 responses 90 days before removal
  - Migration guide published at docs.oobe.io/migration/v2-to-v3

Deprecation notice middleware:
"""
from fastapi import Request, Response
from datetime import datetime, timezone

V1_SUNSET_DATE = \"Mon, 01 Sep 2025 00:00:00 GMT\"   # 6 months after M33

async def deprecation_header_middleware(request: Request, call_next) -> Response:
    response = await call_next(request)
    path = request.url.path

    if path.startswith(\"/v1/\"):
        response.headers[\"Deprecation\"]    = \"true\"
        response.headers[\"Sunset\"]         = V1_SUNSET_DATE
        response.headers[\"Link\"]           = (
            '</v3/>; rel=\"successor-version\", '
            '<https://docs.oobe.io/migration/v1-to-v3>; rel=\"deprecation\"'
        )
    return response

# RFC 9457 Problem Details error format for v3
class ProblemDetail:
    """
    Structured error responses for v3 API.
    https://www.rfc-editor.org/rfc/rfc9457
    """
    @staticmetho
```

```python
d
    def validation_error(detail: str, field: str | None = None) -> dict:
        return {
            \"type\":     \"https://docs.oobe.io/errors/validation-error\",
            \"title\":    \"Validation Error\",
            \"status\":   422,
            \"detail\":   detail,
            \"instance\": f\"/errors/validation/{field}\" if field else None,
        }

    @staticmethod
    def rate_limit_exceeded(limit: int, reset_ts: int) -> dict:
        return {
            \"type\":      \"https://docs.oobe.io/errors/rate-limit-exceeded\",
            \"title\":     \"Rate Limit Exceeded\",
            \"status\":    429,
            \"detail\":    f\"Request rate limit of {limit} req/min exceeded.\",
            \"reset_at\":  datetime.fromtimestamp(reset_ts, tz=timezone.utc).isoformat(),
        }

    @staticmethod
    def entity_limit_exceeded(current: int, limit: int, plan: str) -> dict:
        return {
            \"type\":      \"https://docs.oobe.io/errors/entity-limit-exceeded\",
            \"title\":     \"Entity Limit Exceeded\",
            \"status\":    429,
            \"detail\":    f\"Your {plan} plan allows {limit} entities. Currently at {current}.\",
            \"upgrade_url\": \"https://app.oobe.io/billing/upgrade\",
        }
```

---

## Q2 (Months 34–36): International Expansion

### Goals

- Launch EU-dedicated instance: data residency in Frankfurt (eu-central-1), EU data never leaves EU
- UK government pathway: Cyber Essentials Plus, G-Cloud registration, NCSC engagement
- Five Eyes partner channel: establish reseller relationships in AU, NZ, CA
- EU commercial GTM: hire EU-focused AE, attend OSINT conferences (OSINT Combine, Maltego Conference)
- ARR target: $5M (~$420K MRR)

---

### M34: EU Data Residency Architecture

```hcl
# infra/terraform/eu-region.tf
"""
EU-dedicated deployment in Frankfurt (eu-central-1).
Architecturally identical to US region but with hard data residency guarantees:
  - European org data NEVER replicates to US
  - EU orgs automatically routed to eu-central-1 based on org.data_region column
  - AWS eu-central-1: GDPR-compliant, SOC 2 Type II certified
  - No cross-border data transfers for EU orgs (GDPR Art. 44-49 compliance)
"""

provider \"aws\" {
  alias  = \"eu_central\"
  region = \"eu-central-1\"
}

# RDS PostgreSQL — EU primary (no replication to US for EU data)
resource \"aws_db_instance\" \"oobe_eu_central\" {
  provider                = aws.eu_central
  identifier              = \"oobe-prod-eu-central\"
  engine                  = \"postgres\"
  engine_version          = \"16.3\"
  instance_class          = \"db.t4g.large\"   # Upgraded for EU scale
  allocated_storage       = 100
  storage_encrypted       = true
  multi_az               = true
  backup_retention_period = 14
  deletion_protection     = true

  # GDPR: enable enhanced monitoring for audit trail
  monitoring_interval = 60
  monitoring_role_arn = aws_iam_role.rds_monitoring.arn

  tags = {
    DataResidency  = \"EU\"
    GDPRCompliant  = \"true\"
    DataController = \"OOBE GmbH\"   # EU legal entity (register before M34)
  }
}

# S3 buckets in eu-central-1 for EU org data
resource \"aws_s3_bucket\" \"oobe_models_eu\" {
  provider = aws.eu_central
  bucket   = \"oobe-pol-models-prod-eu\"

  # Prevent cross-region replication (GDPR data residency)
  lifecycle {
    prevent_destroy = true
  }
}

resource \"aws_s3_bucket_replication_configuration\" \"models_eu\" {
  provider = aws.eu_central
  # Explicitly define NO replication rules (EU data stays in EU)
  bucket   = aws_s3_bucket.oobe_models_eu.
```

```hcl
id
  role     = ""  # No replication role
}
```

---

#### Data Region Routing Middleware

```python
# oobe/middleware/data_region.py
"""
Routes database connections to the correct regional cluster based on org.data_region.
EU orgs → eu-central-1 RDS
US orgs → us-east-1 RDS
Default → eu-west-1 RDS (legacy)

This must be the first middleware in the chain after auth.
All subsequent database calls in the request lifecycle use the regional connection.
"""
import os
from fastapi import Request
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

REGION_DATABASE_URLS = {
    "eu":   os.environ.get("DATABASE_URL_EU_CENTRAL", ""),
    "us":   os.environ.get("DATABASE_URL_US",         ""),
    "eu_west": os.environ.get("DATABASE_URL",         ""),   # Legacy default
}

_engines: dict = {}
_session_factories: dict = {}

def _get_regional_session_factory(region: str):
    if region not in _engines:
        url = REGION_DATABASE_URLS.get(region, REGION_DATABASE_URLS["eu_west"])
        _engines[region] = create_async_engine(url, pool_size=10, max_overflow=20)
        _session_factories[region] = sessionmaker(
            _engines[region], class_=AsyncSession, expire_on_commit=False
        )
    return _session_factories[region]

async def data_region_middleware(request: Request, call_next):
    """
    After auth middleware has set request.state.org_id and request.state.plan,
    look up the org's data_region and attach the correct DB session factory.
    """
    data_region = getattr(request.state, "data_region", "eu_west")
    request.state.db_session_factory = _get_regional_session_factory(data_region)
    return await call_next(request)
```

---

### M35: UK Government Pathway — Cyber Essentials Plus + G-Cloud

```markdown
# docs/government/UK_GOV_PATHWAY.md

## OOBE UK Government Pathway

### Legal Entity Requirement
Register OOBE Ltd (UK company) or establish OOBE GmbH (EU) branch office in UK.
UK incorporation: Companies House registration, ~£50, same-day.
Registered office address required in UK.

### Cyber Essentials Plus (Month 35)
Cyber Essentials Plus is MANDATORY for most UK government contracts.
Assessment scope: OOBE SaaS (cloud-hosted) + on-premise bundle.

Required controls (5 categories):
  1. Boundary firewalls and internet gateways
     - All inbound traffic through AWS ALB + WAF
     - OOBE: compliant (documented in network architecture)

  2. Secure configuration
     - Default passwords changed, unnecessary services disabled
     - OOBE: compliant (ECS containers run as non-root; no default passwords)

  3. User access control
     - Least-privilege principle, MFA for admin accounts
     - OOBE: compliant (RLS + role-based access + Supabase MFA)

  4. Malware protection
     - Anti-malware on endpoints
     - OOBE: compliant (ECR image scanning via AWS Inspector; no user endpoints)

  5. Patch management
     - Security patches applied within 14 days for high-severity CVEs
     - OOBE: compliant (Dependabot + weekly pip-audit in CI)

Certification body: IASME Consortium or CREST-approved assessor
Cost: £1,500–£3,000 for Plus (vs £300 for basic)
Timeline: 4–6 weeks from engagement to certificate

### G-Cloud 14 Registration (Month 35)
G-Cloud is the UK government's cloud marketplace (equivalent to US GSA Schedule).

Lot: Lot 2 (Cloud Software) — SaaS
Service category: Data and analytics, Security (dual listing)

Submission requirements:
  - Service definition document (10 pages max)
  - Pricing: per-unit, transparent, £/month
  - T&Cs: G-Cloud standard terms OR supplier 
```

```markdown
supplementary terms
  - GDPR compliance statement
  - Security questionnaire (based on NCSC Cloud Security Principles)

Timeline: Framework opens for new suppliers 2× per year (April, October)
Next window: Target October submission for M35

Pricing for G-Cloud:
  Pro (Government): £180/month (slight discount from £200 commercial; GBP pricing)
  Enterprise On-Premise: £6,500/month + £12,000 implementation

### NCSC Engagement
The National Cyber Security Centre (NCSC) runs the Cyber Accelerator program
and actively evaluates innovative security/OSINT tools.
Target: Submit OOBE to NCSC Cyber Accelerator for advisory review.
Benefit: NCSC endorsement dramatically accelerates UK gov sales cycle.

### UK MOD/GCHQ Pathway
Longer-term (Phase 7): Developed Vetting (DV) clearances for key personnel
required for GCHQ/SIS contracts. Start process in M36.
```

---

### M36: Five Eyes Partner Channel

```python
# oobe/services/partner_channel.py
"""
Partner channel management for Five Eyes resellers.

Partner tier structure:
  SILVER ($0 upfront, 15% revenue share):
    - Resell Pro + Enterprise licenses
    - Use OOBE APIs in their own products
    - Access to partner portal and sales materials

  GOLD ($5,000/year, 25% revenue share):
    - All Silver benefits
    - Custom white-label option (replace OOBE branding)
    - Dedicated solutions architect support
    - Early access to new features

  PLATINUM ($15,000/year, 35% revenue share):
    - All Gold benefits
    - Co-sell agreement (joint pursuit of government contracts)
    - Named account protection (no direct OOBE competition in partner's accounts)
    - Data residency options in partner's jurisdiction

Target partners (Month 34–36 outreach):
  Australia:  Macquarie Government, Penten, Vault Cloud
  New Zealand: Spark NZ Government, Datacom
  Canada:     Calian Group, MDA Space, Paladin AI
  UK:         BAE Systems Digital, CGI UK, Fujitsu Government

Partner commission is tracked per org.referral_partner_id in organizations table.
Stripe handles split payments (Stripe Connect for partner payouts).
"""

PARTNER_TIERS = {
    "SILVER": {
        "annual_fee_usd":     0,
        "revenue_share_pct":  15,
        "white_label":        False,
        "account_protection": False,
    },
    "GOLD": {
        "annual_fee_usd":     5_000,
        "revenue_share_pct":  25,
        "white_label":        True,
        "account_protection": False,
    },
    "PLATINUM": {
        "annual_fee_usd":     15_000,
        "revenue_share_pct":  35,
        "white_label":        True,
        "account_protection": True,
    },
}
```

---

## Q3 (Months 37–39): FedRAMP Moderate + DoD Pathway

### Goals

- Achieve FedRAMP Moderate authorization (expands addressable gov market 10×)
- Close first DoD contract (Army G2, DIA, or SOCOM)
- Launch OOBE for Defense: hardened on-premise bundle for SIPR-adjacent networks
- ARR target: $7M (~$580K MRR)

---

### M37: FedRAMP Moderate Gap Analysis

FedRAMP Moderate requires 325 controls (vs 125 for Tailored). The delta is substantial but manageable with the DevSecOps hire.

```markdown
# docs/compliance/FEDRAMP_MODERATE_GAP.md

## FedRAMP Moderate Gap Analysis

### Controls added beyond Tailored (selected high-effort ones)

#### CONFIGURATION MANAGEMENT
CM-3  Configuration Change Control
  Gap:  Currently ad-hoc; require formal Change Advisory Board (CAB) process
  Fix:  GitHub PR reviews serve as CAB; document policy and auto-close issues
  Effort: LOW — existing process, needs documentation

CM-7  Least Functionality
  Gap:  ECS containers include tools not needed in production (curl, wget)
  Fix:  Distroless base images (gcr.io/distroless/python3-debian12)
  Effort: MEDIUM — requires Dockerfile refactor and testing

CM-11 User-Installed Software
  Gap:  No policy preventing analysts from installing browser extensions
  Fix:  Policy document + acceptable use agreement
  Effort: LOW

#### INCIDENT RESPONSE
IR-4  Incident Handling
  Gap:  IR playbook exists but not tested with tabletop exercise
  Fix:  Conduct quarterly tabletop exercise; document results
  Effort: MEDIUM — requires team time quarterly

IR-6  Incident Reporting
  Gap:  No formal process for reporting to US-CERT within 1 hour of breach
  Fix:  PagerDuty → security@ email → US-CERT reporting template
  Effort: LOW — procedural change

#### PERSONNEL SECURITY
PS-3  Personnel Screening
  Gap:  No background check policy for employees with system access
  Fix:  Require background checks for all employees (third-party vendor)
  Effort: MEDIUM — ongoing cost ~$200/person

PS-6  Access Agreements
  Gap:  No formal NDA/system access agreement beyond employment contract
  Fix:  System access agreement template; annual re-signing
  Effort: LOW

#### SYSTEM AND COMMUNICATIONS PROTECTION
SC-4  Information in Shared Resources
  Gap:  Multi-tenant PostgreSQL: need proof of tenant isolation beyond RL
```

```markdown
S
  Fix:  Document RLS policy + penetration test specifically targeting
        cross-tenant data access
  Effort: HIGH — requires external pen test and formal documentation

SC-12 Cryptographic Key Management
  Gap:  AWS KMS used for secrets but no formal key rotation policy
  Fix:  Annual key rotation, documented rotation procedure
  Effort: LOW — AWS KMS automates rotation

SC-17 Public Key Infrastructure Certificates
  Gap:  ACM certificates auto-rotate but no formal PKI policy document
  Fix:  Document certificate issuance, renewal, and revocation procedures
  Effort: LOW

#### AUDIT AND ACCOUNTABILITY
AU-6  Audit Review, Analysis, and Reporting
  Gap:  CloudWatch logs reviewed reactively; no proactive analysis schedule
  Fix:  Weekly automated log analysis report via Lambda → S3 → email
  Effort: MEDIUM

AU-9  Protection of Audit Information
  Gap:  CloudWatch logs deletable by admin users
  Fix:  Separate AWS account for log archive (SCPs prevent deletion)
  Effort: MEDIUM — AWS Organizations setup

### Estimated 3PAO Cost for Moderate
  Assessment:     $120,000–$200,000
  Remediation:    $50,000–$100,000 (engineering time)
  Annual ConMon:  $30,000–$50,000
  Total Year 1:   ~$250,000–$350,000

### Timeline
  M37:  Engage 3PAO, complete gap analysis
  M38:  Address all HIGH and MEDIUM gaps
  M39:  3PAO assessment begins (8–10 weeks)
  M40:  Address findings, retest
  M41:  Agency ATO review (same AO as Tailored)
  M42:  FedRAMP Moderate ATO granted
```

---

### M38: Distroless Container Migration

```
# oobe-backend/Dockerfile.production
# Phase 6: Distroless base for FedRAMP Moderate CM-7 compliance.
# Distroless images contain only the application and its runtime dependencies.
# No shell, no package manager, no debugger — minimal attack surface.

# ── Stage 1: Build ────────────────────────────────────────────────────────────
FROM python:3.12-slim-bookworm AS builder

WORKDIR /build

# Install build dependencies (not present in final image)
RUN apt-get update && apt-get install -y --no-install-recommends \
    gcc g++ libpq-dev libgeos-dev libproj-dev \
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir --require-hashes \
    --target=/build/packages \
    -r requirements.txt

COPY . .

# ── Stage 2: Production (Distroless) ──────────────────────────────────────────
FROM gcr.io/distroless/python3-debian12:nonroot AS production

WORKDIR /app

# Copy installed packages from builder
COPY --from=builder /build/packages /app/packages
COPY --from=builder /build/oobe     /app/oobe
COPY --from=builder /build/alembic.ini /app/
COPY --from=builder /build/oobe/templates /app/oobe/templates

# Set PYTHONPATH to find packages
ENV PYTHONPATH="/app/packages:/app"
ENV PYTHONUNBUFFERED=1
ENV PYTHONDONTWRITEBYTECODE=1

# nonroot user (uid 65532) is built into distroless:nonroot
# No USER directive needed

EXPOSE 8000

# No shell available — entrypoint is Python directly
ENTRYPOINT ["/usr/bin/python3", "-m", "uvicorn"]
CMD ["oobe.main:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "2"]
```

---

### M39: OOBE for Defense — SIPR-Adjacent Bundle

```
# deploy/defense/docker-compose.defense.yml
# Defense-hardened on-premise deployment.
# Designed for SIPR-adjacent networks (below the classification line).
# All external network calls disabled at the container level.
# FIPS 140-2 compliant cryptography where supported.
# Network segmentation: API, DB, and Redis on separate networks.

version: "3.9"

networks:
  frontend_net:   # API ↔ Frontend only
    driver: bridge
    internal: false   # ALB faces public (or internal network)
  backend_net:    # API ↔ DB ↔ Redis only
    driver: bridge
    internal: true    # No external access
  graph_net:      # API ↔ Neo4j only
    driver: bridge
    internal: true

services:
  postgres:
    image: oobe-postgis:16-3.4-fips          # FIPS-compiled PostgreSQL
    environment:
      POSTGRES_DB:       oobe
      POSTGRES_USER:     oobe
      POSTGRES_PASSWORD: "${POSTGRES_PASSWORD}"
      # Enable FIPS mode
      OPENSSL_FIPS:      "1"
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./pgcerts:/etc/ssl/postgresql:ro     # mTLS for PostgreSQL connections
    networks:
      - backend_net
    deploy:
      resources:
        limits:
          memory: 8G
          cpus: '4'

  redis:
    image: oobe-redis:7.2-fips
    command: >
      redis-server
      --requirepass "${REDIS_PASSWORD}"
      --tls-port 6380
      --port 0
      --tls-cert-file /certs/redis.crt
      --tls-key-file  /certs/redis.key
      --tls-ca-cert-file /certs/ca.crt
      --tls-auth-clients yes
    volumes:
      - redisdata:/data
      - ./certs:/certs:ro
    networks:
      - backend_net

  api:
    image: oobe-api:${OOBE_VERSION}-defense
    environment:
      ENVIRONMENT:        "defense"
      FIPS_MODE:          "1"
      OPENSSL_FIPS:       "1"
      NETWORK_POLICY:     "airgap"
```

```
"
      DATABASE_URL:       "postgresql://oobe:${POSTGRES_PASSWORD}@postgres:5432/oobe?sslmode=require"
      REDIS_URL:          "rediss://:${REDIS_PASSWORD}@redis:6380/0"
      LICENSE_KEY:        "${OOBE_LICENSE_KEY}"
      CLASSIFICATION:     "${OOBE_CLASSIFICATION_BANNER}"  # e.g. "UNCLASSIFIED//FOUO"
    volumes:
      - pol_models:/app/pol_models
      - ./certs:/app/certs:ro
      - ./audit_logs:/app/audit_logs  # Bind-mount for SIEM ingestion
    networks:
      - frontend_net
      - backend_net
      - graph_net
    # No external port exposure — fronted by HAProxy on frontend_net
    expose:
      - "8000"
    security_opt:
      - no-new-privileges:true
      - seccomp:./seccomp/oobe-api.json   # Custom seccomp profile
    read_only: true
    tmpfs:
      - /tmp
      - /app/.cache

  # Classification banner injected by reverse proxy
  haproxy:
    image: oobe-haproxy:2.9
    volumes:
      - ./haproxy/haproxy.cfg:/usr/local/etc/haproxy/haproxy.cfg:ro
      - ./certs:/certs:ro
    ports:
      - "443:443"
    networks:
      - frontend_net
    # haproxy.cfg injects X-Classification-Banner header on all responses
    # Frontend renders banner from this header

volumes:
  pgdata:
  redisdata:
  pol_models:

# Security labels for DoD STIGs compliance
x-stig-labels:
  application:  "OOBE"
  classification: "${OOBE_CLASSIFICATION_BANNER}"
  cto_id:       "OOBE-DEFENSE-${OOBE_VERSION}"
```

---

## Q4 (Months 40–42): Network Effects + Series B

### Goals

- Platform GMV (Gross Merchandise Value from Data Marketplace) exceeds $1M/year
- App Registry: 25+ approved third-party applications
- PoL V3 GNN at 100% rollout with monthly automated retraining
- Series B materials complete; term sheet signed or in negotiation
- ARR target: $10M (~$830K MRR)

---

### M40: Platform Network Effects Dashboard

```python
# oobe/services/platform_analytics.py
"""
Platform health metrics: measures the strength of network effects.

Network effect indicators:
  1. Marketplace GMV — total $ value of data license transactions
  2. App install velocity — rate of third-party app installations
  3. Cross-org entity overlap — entities tracked by multiple orgs simultaneously
     (measures shared situational awareness, not just individual org views)
  4. Subscription delivery volume — WebSocket + SSE stream events to third-party apps
  5. Behavioral baseline depth — average age of entity observation history

The flywheel: more data → better PoL models → more accurate alerts →
more valuable to analysts → more orgs join → more data.

This dashboard is the primary Series B story: OOBE is no longer just a SaaS.
It is a platform where each new participant makes the system more valuable for all.
"""
from datetime import datetime, timedelta, timezone
from sqlalchemy import text
from ..db import get_sync_db_session

def get_platform_health_snapshot() -> dict:
    \"\"\"Returns current platform health metrics for Series B dashboard.\"\"\"
    with get_sync_db_session() as db:
        # Marketplace GMV (trailing 12 months)
        gmv = db.execute(text("""
            SELECT COALESCE(SUM(price_cents), 0) / 100.0 AS gmv_usd
            FROM data_licenses
            WHERE status = 'sold'
              AND created_at >= NOW() - INTERVAL '12 months'
        """)).fetchone()

        # App installations (trailing 30 days)
        app_installs = db.execute(text("""
            SELECT
                COUNT(DISTINCT ai.org_id) AS installing_orgs,
                COUNT(*)                  AS total_installs,
                COUNT(DISTINCT ai.app_uuid) AS active_apps
            FROM app_installations ai
  
```

```python
          WHERE ai.installed_at >= NOW() - INTERVAL '30 days'
        """)).fetchone()

        # Cross-org entity overlap (entities tracked by ≥2 orgs)
        shared_entities = db.execute(text("""
            SELECT COUNT(*) AS shared_count
            FROM (
                SELECT domain_key, domain, COUNT(DISTINCT org_id) AS org_count
                FROM entities
                WHERE last_seen >= NOW() - INTERVAL '24 hours'
                GROUP BY domain_key, domain
                HAVING COUNT(DISTINCT org_id) >= 2
            ) t
        """)).fetchone()

        # Behavioral baseline depth
        baseline_depth = db.execute(text("""
            SELECT
                AVG(EXTRACT(DAYS FROM (NOW() - first_seen))) AS avg_entity_age_days,
                MAX(EXTRACT(DAYS FROM (NOW() - first_seen))) AS max_entity_age_days,
                COUNT(*)                                      AS entities_with_history
            FROM entities
            WHERE observation_count >= 100
              AND first_seen < NOW() - INTERVAL '30 days'
        """)).fetchone()

        # Subscription delivery volume (trailing 7 days)
        sub_volume = db.execute(text("""
            SELECT COALESCE(SUM(delivery_count), 0) AS total_deliveries
            FROM entity_subscriptions
            WHERE is_active = TRUE
        """)).fetchone()

        # NRR calculation
        nrr = db.execute(text("""
            WITH monthly AS (
                SELECT
                    DATE_TRUNC('month', created_at) AS month,
                    org_id,
                    SUM(amount_cents) AS revenue_cents
                FROM billing_events
                WHERE event_type = 'payment.succeeded'
                  AND created_at >= NOW() - INTERVAL '13 months'
            
```

```python
    GROUP BY 1, 2
            ),
            cohort AS (
                SELECT org_id, SUM(revenue_cents) AS base_revenue
                FROM monthly
                WHERE month = DATE_TRUNC('month', NOW() - INTERVAL '12 months')
                GROUP BY org_id
            )
            SELECT
                CASE
                  WHEN SUM(c.base_revenue) = 0 THEN NULL
                  ELSE (SUM(m.revenue_cents)::float / SUM(c.base_revenue)::float) * 100
                END AS nrr_pct
            FROM cohort c
            LEFT JOIN monthly m ON m.org_id = c.org_id
              AND m.month >= DATE_TRUNC('month', NOW() - INTERVAL '1 month')
        """)).fetchone()

    return {
        "as_of":              datetime.now(timezone.utc).isoformat(),
        "marketplace_gmv_usd_12m": float(gmv.gmv_usd or 0),
        "app_registry": {
            "installing_orgs_30d": int(app_installs.installing_orgs or 0),
            "total_installs_30d":  int(app_installs.total_installs or 0),
            "active_apps":         int(app_installs.active_apps or 0),
        },
        "shared_entities_24h":     int(shared_entities.shared_count or 0),
        "subscription_deliveries_7d": int(sub_volume.total_deliveries or 0),
        "behavioral_baseline": {
            "avg_entity_age_days":      float(baseline_depth.avg_entity_age_days or 0),
            "max_entity_age_days":      float(baseline_depth.max_entity_age_days or 0),
            "entities_with_deep_history": int(baseline_depth.entities_with_history or 0),
        },
        "nrr_pct":             float(nrr.nrr_pct or 0) if nrr else None,
    }
```

---

### M41: Series B Positioning

```markdown
# docs/investor/SERIES_B_POSITIONING.md

## OOBE Series B Thesis

### The Shift That Happened Between Series A and Series B

At Series A, OOBE was a SaaS product with a government angle and a compliance moat.
At Series B, OOBE is an intelligence platform where:
  - Network effects compound: each new data publisher makes every analyst's models better
  - Revenue diversification: SaaS subscriptions + data licensing + platform fees ≈ 3 streams
  - Government revenue is recurring: ATO-bearing contracts renew annually with
    Congressional appropriations behind them
  - International expansion is proven: UK G-Cloud registration, EU GDPR-compliant instance,
    Five Eyes partner channel generating qualified pipeline

### Series B Ask: $20–30M

Use of funds:
  40% Product ($8–12M)
    - FedRAMP Moderate → pursue first SECRET-adjacent contract (OTAs only)
    - Mobile: ship Android + iOS to 5-star rating
    - PoL V4: multi-modal (combining ADS-B + AIS + ACLED into joint entity model)
    - Real-time language translation layer (conflict events in non-English media)

  35% GTM ($7–10.5M)
    - US Federal sales team: 3 AEs + 1 Federal Capture Manager
    - UK/EU sales: 2 AEs, UK office (London), attendance at DSEI, Eurosatory
    - Channel: activate Gold/Platinum Five Eyes partners
    - Marketing: OSINT Digest → 25,000 subscribers, conference sponsorships

  25% International Infrastructure ($5–7.5M)
    - AP-region: AWS ap-southeast-1 (Singapore) for ASEAN + AU customers
    - UK sovereign cloud: UK Gov Cloud deployment option (separate from EU)
    - Second Neo4j region (AP-region)

### Key Metrics for Series B Deck

  ARR:         $10M
  ARR growth:  >80% YoY
  NRR:         >130% (expansion through platform + data licensing)
  Gross margin: >80% (data licensing is near-100% 
```

```markdown
margin)
  CAC payback: <4 months (community-led growth; newsletter → trial → convert)
  Churn:       <1%/month Pro, 0% Enterprise, 0% Government
  NPS:         >70

  Government:   3+ active contracts, FedRAMP Moderate ATO
  International: 3+ countries with active Enterprise customers
  Platform:     25+ third-party apps, $1M+ annualized marketplace GMV
  Data moat:    30+ months of behavioral baselines; 500,000+ persistent entities tracked

### Competitive Landscape at Series B

  Palantir Gotham:  $1B+ ACV with classified customers.
    OOBE differentiator: open-source data, affordable, no minimum commitment,
    community-built ecosystem. Palantir doesn't sell to journalists or NGOs.

  Recorded Future: $50M+ ARR, Mastercard acquisition.
    OOBE differentiator: geospatial-first, entity persistence, ATLAS integration.
    RF is text/NLP-centric; OOBE is position/movement-centric.

  Maxar / Planet:  Satellite imagery companies.
    OOBE differentiator: OOBE is the fusion layer that consumes their imagery.
    Potential partnership, not competition.

  Shadowdragon / Maltego:
    OOBE differentiator: Live, streaming, temporal. Maltego is batch/static.
    Potential: Maltego integration in the App Registry (Maltego Transform).

### Acquirer Landscape (if M&A preferred over Series B)

  Strategic acquirers:
    Palantir  — would buy OOBE to absorb community + FedRAMP Tailored ATO + data moat
    Maxar     — OSINT fusion layer for satellite intelligence
    BAE Systems Digital — UK defense prime; OOBE fits their OSINT portfolio
    L3Harris  — ISR systems integrator; OOBE as software layer
    Booz Allen Hamilton — $12B IT consulting; OOBE for government OSINT practice

  Financial sponsors:
    Insight Partners, Bessemer, a16z defense practice
    Shield Capital (defens
```

```markdown
e-focused VC with NDA clearances)

  Realistic M&A range at $10M ARR: $80M–$150M (8–15× ARR)
  Premium for FedRAMP ATO + data moat: +20–30% above comparable SaaS multiples
```

---

### M42: Phase 6 Retrospective and Long-Arc Assessment

```python
# docs/phase6_retrospective.py
"""
Final retrospective for Phase 6 (and the first 3.5 years of OOBE).

Successes:
  - Transition from 'tool' to 'platform' successfully navigated.
  - FedRAMP Tailored ATO unlocked the federal market; Moderate on deck.
  - Data marketplace validated as a high-margin second revenue stream.
  - Mobile app achieved parity with web for 80% of analyst workflows.
  - PoL V3 GNN models significantly reduced false positives in complex AoIs.

Challenges:
  - SENTINEL OS → React migration took longer than estimated (finished M38).
  - EU data residency requirements required significant DB middleware refactor.
  - Five Eyes partner channel requires high SA/SE touch during onboarding.

The Long Arc:
OOBE was founded on the hypothesis that the world's most valuable intelligence
is hiding in plain sight in open-source streaming data. By building a system
that tracks entities, not just events, and by establishing a community-driven
platform, OOBE has created a persistent digital twin of global movement.

Phase 7 Vision (Months 43–54):
  - Multi-modal fusion (SIGINT + OSINT + Satellite)
  - Classified-adjacent deployment (FedRAMP High / IL5)
  - Fully decentralized data publishing (OOBE Network)
"""
import logging
logger = logging.getLogger("oobe.retrospective")

def run_phase_6_wrap_up():
    logger.info("Phase 6 complete. $10M ARR achieved.")
    logger.info("Series B materials ready. Market position: Intelligence Platform.")
    logger.info("The digital twin of the world is live.")

if __name__ == "__main__":
    run_phase_6_wrap_up()
```