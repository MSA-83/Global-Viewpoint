# 📚 Documentation Knowledge Base (Updated)

[Phase 1 — Development Blueprint & Architecture](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%201%20%E2%80%94%20Development%20Blueprint%20&%20Architecture%20347673b3dcb8810e971bee0bde52b968.md)

[Phase 2 — Pilot: PoL Engine & Data Export](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%202%20%E2%80%94%20Pilot%20PoL%20Engine%20&%20Data%20Export%20347673b3dcb8812293a0fa68858524d4.md)

[Phase 3 — Production SaaS, Billing & ATLAS](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%203%20%E2%80%94%20Production%20SaaS,%20Billing%20&%20ATLAS%20347673b3dcb8818aace6c6f55f112e67.md)

[Phase 4 — Scale, Enterprise & Government Pathway](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%204%20%E2%80%94%20Scale,%20Enterprise%20&%20Government%20Pathway%20347673b3dcb88180882ed7fc5b982a5f.md)

[Phase 5 — Platform Pivot & FedRAMP Tailored](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%205%20%E2%80%94%20Platform%20Pivot%20&%20FedRAMP%20Tailored%20347673b3dcb881499bb0fa68dcc6eb8c.md)

[OSINT Intelligence Platform Ideation Brief Summary](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/OSINT%20Intelligence%20Platform%20Ideation%20Brief%20Summary%20347673b3dcb8814ebab2d3d01096f8ef.md)

[Project Continuity Summary — All Phases (1–7)](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Project%20Continuity%20Summary%20%E2%80%94%20All%20Phases%20(1%E2%80%937)%20348673b3dcb881c4ac58e34abe321b59.md)

[Phase 6 — Global Intelligence Platform & FedRAMP Moderate](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%206%20%E2%80%94%20Global%20Intelligence%20Platform%20&%20FedRAMP%20M%20348673b3dcb881ca8f10faca3cec2cb1.md)

[Phase 7 — AI-Native Intelligence: Language, Joint Entity & Autonomous Agent](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%207%20%E2%80%94%20AI-Native%20Intelligence%20Language,%20Joint%20E%20348673b3dcb881acbd13e542640a5c24.md)

<aside>
🛰️ OOBE — Open-Source Order-of-Battle Engine
Real-time OSINT situational awareness platform. Fuses public feeds (ADS-B, AIS, ACLED, NASA FIRMS, Telegram) into a live, TTL-decayed relational knowledge graph with entity persistence, behavioral baselines, and autonomous investigation capability.

54-month arc · SENTINEL OS → $30M ARR · 7 engineering phases · ~16,200 spec lines

</aside>

---

## 📋 Quick Reference

**Current status ·** Phase 7 active (Month 43–54) · Series B $20–30M closed · $30M ARR target · 30-person team building

**Tech stack ·** FastAPI · PostgreSQL 16 + PostGIS · Neo4j · Redis · React Native · GLiNER · Helsinki-NLP · Anthropic Claude · pgvector · AWS multi-region

**Compliance ·** FedRAMP Moderate ATO · GDPR EU data residency · UK Cyber Essentials Plus · G-Cloud 14 registered

---

## 🗂️ Engineering Specifications

One canonical spec page per phase. All phases are complete and finalized.

### Foundations (Series Seed)

- [**🗺️  Phase 1 — Development Blueprint & Architecture**](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%201%20%E2%80%94%20Development%20Blueprint%20&%20Architecture%20347673b3dcb8810e971bee0bde52b968.md)   Weeks 1–6 · MVP prototype · Entity persistence model · TTL decay · PostGIS schema · ADS-B + AIS + ACLED adapters
- [**🧪  Phase 2 — Pilot: PoL Engine & Data Export**](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%202%20%E2%80%94%20Pilot%20PoL%20Engine%20&%20Data%20Export%20347673b3dcb8812293a0fa68858524d4.md)   Weeks 7–14 · IsolationForest PoL V1 · Analyst feedback loop · PDF/CSV export · Pilot customer onboarding
- [**🚀  Phase 3 — Production SaaS, Billing & ATLAS**](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%203%20%E2%80%94%20Production%20SaaS,%20Billing%20&%20ATLAS%20347673b3dcb8818aace6c6f55f112e67.md)   Weeks 15–24 · Stripe billing · Multi-tenant RLS · MITRE ATLAS integration · Provenance Sentinel · $2K MRR

### Growth (Pre-Series A)

- [**📈  Phase 4 — Scale, Enterprise & Government Pathway**](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%204%20%E2%80%94%20Scale,%20Enterprise%20&%20Government%20Pathway%20347673b3dcb88180882ed7fc5b982a5f.md)   Months 7–18 · PoL V2 ensemble · Neo4j graph · On-premise bundle · Enterprise tier · FedRAMP Tailored ATO pursuit · $25K MRR
- [**🌐  Phase 5 — Platform Pivot & FedRAMP Tailored**](https://www.notion.so/347673b3dcb881499bb0fa68858524d4?pvs=21)   Months 19–30 · Platform API v2 · App Registry · Data Marketplace · PoL V3 GNN · FedRAMP Tailored ATO ✅ · $125K MRR

### Global Scale (Post-Series A)

- [**🌍  Phase 6 — Global Intelligence Platform & FedRAMP Moderate**](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%206%20%E2%80%94%20Global%20Intelligence%20Platform%20&%20FedRAMP%20M%20348673b3dcb881ca8f10faca3cec2cb1.md)   Months 31–42 · iOS/Android · MLOps retraining · EU data residency · UK G-Cloud · Five Eyes channel · FedRAMP Moderate ATO ✅ · $833K MRR

### AI-Native (Post-Series B)

- [**🤖  Phase 7 — AI-Native Intelligence: Language, Joint Entity & Autonomous Agent**](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Phase%207%20%E2%80%94%20AI-Native%20Intelligence%20Language,%20Joint%20E%20348673b3dcb881acbd13e542640a5c24.md)   Months 43–54 · Multilingual NLP · GLiNER NER · Cross-domain entity fusion · Autonomous Investigation Assistant (Claude) · PoL V4 multimodal · $2.5M MRR target

---

## 📊 ARR Progression

**Phase 1–2:** Pilot (pre-revenue)  →  **Phase 3:** $24K ARR  →  **Phase 4:** $300K ARR  →  **Phase 5:** $1.5M ARR  →  **Phase 6:** $10M ARR  →  **Phase 7:** $30M ARR target

---

## 📓 Reference Documents

- [**📓  Project Continuity Summary — All Phases (1–7)**](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/Project%20Continuity%20Summary%20%E2%80%94%20All%20Phases%20(1%E2%80%937)%20348673b3dcb881c4ac58e34abe321b59.md)   High-level overview covering architecture, tech stack, compliance posture, and key decisions across all 54 months
- [**💡  OSINT Intelligence Platform Ideation Brief**](%F0%9F%93%9A%20Documentation%20Knowledge%20Base%20(Updated)/OSINT%20Intelligence%20Platform%20Ideation%20Brief%20Summary%20347673b3dcb8814ebab2d3d01096f8ef.md)   Original concept paper and market ideation that preceded the OOBE development arc

---

*Last updated: April 2026 · Maintained by Skywork Agent · All archived pages preserved in Notion trash*