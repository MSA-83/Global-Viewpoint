// frontend/src/app/client-providers.tsx
//
// Client-side provider wrapper for the Sentinel-X App Router layout.
//
// Next.js App Router layouts are Server Components by default. Server
// Components cannot use React state, context, or hooks — all of which
// AuthProvider relies on. The solution is to extract all providers into a
// thin "use client" wrapper that the Server Component layout renders as a
// child. This pattern (sometimes called the "provider island" pattern) lets
// the root layout remain a Server Component for metadata and RSC benefits
// while still making context available to the entire client component tree.
//
// If you add more global providers in the future (e.g. a toast notification
// context, a theme provider, a SWR global config), add them here in the
// correct nesting order.

"use client";

import type { ReactNode } from "react";
import { AuthProvider } from "../hooks/useAuth";
import { Navbar } from "../components/Navbar";

interface Props {
  children: ReactNode;
}

export function ClientProviders({ children }: Props) {
  return (
    <AuthProvider>
      <Navbar />
      {/*
        The main element provides the full-height scrollable region below
        the fixed-height Navbar (h-14 = 3.5rem). calc(100vh - 3.5rem) ensures
        the map and panel layouts can fill the remaining viewport height
        without causing a double scrollbar.
      */}
      <main className="h-[calc(100vh-3.5rem)]">{children}</main>
    </AuthProvider>
  );
}
