// frontend/src/app/layout.tsx
//
// Root layout for the Sentinel-X Next.js App Router application.
//
// The original layout rendered <Navbar /> inside a bare <body> with no context
// providers. This meant every component that called useAuth() would immediately
// throw "useAuth must be called within an <AuthProvider>" — including Navbar
// itself, which calls useAuth() to display the logged-in user's name and the
// logout button. The application would crash on first render.
//
// AuthProvider must wrap the entire component tree so that every client
// component in the app can access auth state via useAuth(). Because Next.js
// App Router layouts are Server Components by default, and AuthProvider uses
// React state and context (client-only APIs), we must mark this file with
// "use client" OR move the provider into a dedicated client component wrapper.
// We use the wrapper pattern (ClientProviders) so the layout itself can remain
// a Server Component — which allows it to export the `metadata` object for
// SEO, something "use client" components cannot do.
//
// The styles import path is corrected: layout.tsx lives at src/app/layout.tsx
// and globals.css lives at src/styles/globals.css, so the relative path is
// ../styles/globals.css (the original had ./styles/globals.css which would
// look for src/app/styles/globals.css — a path that does not exist).

import type { ReactNode } from "react";
import "../styles/globals.css";
import { ClientProviders } from "./client-providers";

export const metadata = {
  title: "Sentinel‑X",
  description: "Global Situational Awareness Platform",
  themeColor: "#020617",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-slate-100">
        {/*
          ClientProviders is a "use client" component that renders AuthProvider
          and any other context providers the app needs. Isolating providers in
          a dedicated client component keeps this Server Component clean and
          allows metadata to be exported.
        */}
        <ClientProviders>{children}</ClientProviders>
      </body>
    </html>
  );
}
