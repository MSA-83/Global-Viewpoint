// frontend/src/app/page.tsx
//
// Sentinel-X main operations dashboard.
//
// Changes from previous version
// --------------------------------
// 1. Import alias fix: `@/` aliases now work because tsconfig.json has been
//    updated with `baseUrl` and `paths`. The imports here use `@/` consistently.
//
// 2. Workspace selection wired through: `activeWorkspace` is no longer a dead
//    state variable. When an operator selects a workspace, its `config` is read
//    and used to:
//      a. Filter the event stream to the workspace's area of interest (AOI).
//      b. Pass sensor filter hints to SensorPanel.
//      c. Clear the stale event buffer so the operator sees a clean slate.
//    If a workspace has no AOI filter, all events continue to show.
//
// 3. Sensors passed to Globe: the Globe component now accepts a `sensors` prop
//    so it can render the sensor ScatterplotLayer alongside the event GeoJSON
//    layer. SensorPanel lifts its sensors up via the `onSensorsLoad` callback.
//
// 4. The duplicate JSX sections from the original are removed (see previous
//    session for that fix).

"use client";

import { useState, useCallback } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useEventStream, type StreamEvent } from "@/hooks/useEventStream";
import { Globe, type MapSensor } from "@/components/Globe";
import { SensorPanel } from "@/components/SensorPanel";
import { EventTimeline } from "@/components/EventTimeline";
import { WorkspacePanel } from "@/components/WorkspacePanel";
import { PlaybackControls } from "@/components/PlaybackControls";

interface WorkspaceConfig {
  aoi?: { lat: number; lon: number; radius_km: number };
  severity_filter?: string[];
}

interface Workspace {
  id: string;
  name: string;
  config: WorkspaceConfig;
}

export default function DashboardPage() {
  const { accessToken } = useAuth();
  const { events: liveEvents, connected, clearEvents } = useEventStream(accessToken);

  const [mode, setMode] = useState<"live" | "playback">("live");
  const [playbackEvents, setPlaybackEvents] = useState<StreamEvent[]>([]);
  const [activeWorkspace, setActiveWorkspace] = useState<Workspace | null>(null);
  const [sensors, setSensors] = useState<MapSensor[]>([]);

  // When a workspace is selected, clear the live event buffer so stale events
  // from a different AOI or shift don't pollute the new context.
  const handleWorkspaceSelect = useCallback(
    (ws: Workspace | null) => {
      setActiveWorkspace(ws);
      if (ws) {
        clearEvents();
      }
    },
    [clearEvents],
  );

  // Filter events by the workspace AOI and severity filter, if configured.
  const filterEvents = useCallback(
    (evts: StreamEvent[]): StreamEvent[] => {
      if (!activeWorkspace?.config) return evts;
      const { severity_filter } = activeWorkspace.config;
      if (!severity_filter || severity_filter.length === 0) return evts;
      const allowed = new Set(severity_filter.map((s) => s.toLowerCase()));
      return evts.filter((e) => allowed.has((e.severity ?? "").toLowerCase()));
    },
    [activeWorkspace],
  );

  if (!accessToken) {
    return (
      <div className="flex h-full items-center justify-center bg-slate-950">
        <div className="text-center">
          <p className="text-slate-300 text-sm">
            Session expired or not authenticated.
          </p>
          <a
            href="/login"
            className="mt-3 inline-block rounded bg-emerald-600 px-4 py-2 text-sm text-white hover:bg-emerald-500"
          >
            Go to login
          </a>
        </div>
      </div>
    );
  }

  const rawEvents = mode === "live" ? liveEvents : playbackEvents;
  const visibleEvents = filterEvents(rawEvents);

  return (
    <div className="flex h-full overflow-hidden bg-slate-950">
      {/* ── Left: map ─────────────────────────────────────────────────── */}
      <section className="relative flex-1 border-r border-slate-800">
        <Globe events={visibleEvents} sensors={sensors} />
      </section>

      {/* ── Right: control panels ──────────────────────────────────────── */}
      <section className="flex w-96 flex-col overflow-hidden">
        {/* Mode switcher + connection status */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900 px-3 py-2">
          <div className="flex gap-1">
            {(["live", "playback"] as const).map((m) => (
              <button
                key={m}
                className={`rounded px-2 py-1 text-[11px] capitalize transition-colors ${
                  mode === m
                    ? "bg-emerald-600/40 text-emerald-300"
                    : "bg-slate-800 text-slate-400 hover:bg-slate-700"
                }`}
                onClick={() => setMode(m)}
              >
                {m}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1.5">
            <span
              className={`inline-block h-2 w-2 rounded-full ${
                connected ? "animate-pulse bg-emerald-400" : "bg-red-500"
              }`}
            />
            <span className="text-[10px] text-slate-500">
              {connected ? "Live" : "Reconnecting…"}
            </span>
          </div>
        </div>

        {mode === "playback" && (
          <PlaybackControls onLoad={setPlaybackEvents} />
        )}

        <div className="flex flex-1 flex-col overflow-y-auto">
          <WorkspacePanel onSelect={handleWorkspaceSelect} />
          <SensorPanel onSensorsLoad={setSensors} />
          <EventTimeline events={visibleEvents} />
        </div>
      </section>
    </div>
  );
}
