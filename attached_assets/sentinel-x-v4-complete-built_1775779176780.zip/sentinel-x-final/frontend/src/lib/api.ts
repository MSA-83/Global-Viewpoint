// frontend/src/lib/api.ts
import axios from "axios";

export function apiClient(accessToken?: string) {
  const instance = axios.create({
    baseURL: process.env.NEXT_PUBLIC_API_BASE,
    timeout: 10_000,
  });

  if (accessToken) {
    instance.interceptors.request.use((config) => {
      config.headers = {
        ...(config.headers ?? {}),
        Authorization: `Bearer ${accessToken}`,
      };
      return config;
    });
  }

  return instance;
}
