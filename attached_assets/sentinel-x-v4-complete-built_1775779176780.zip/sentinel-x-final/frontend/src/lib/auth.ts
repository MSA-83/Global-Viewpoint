// frontend/src/lib/auth.ts
//
// Token utility module.
//
// The original file stored the JWT access token in localStorage via
// window.localStorage.setItem("sx_access_token", token). This is a well-known
// XSS attack vector: any JavaScript running on the page (including injected
// scripts via third-party libraries or DOM-based XSS) can read localStorage
// and steal the token. The OWASP recommendation is to store access tokens in
// memory only and never in browser storage.
//
// The correct storage strategy for Sentinel-X is:
//   Access token  → React state in AuthProvider (memory only, lost on refresh).
//                   Refresh via the /auth/refresh endpoint on page load.
//   Refresh token → httpOnly cookie set by the backend.
//                   Cannot be read by JavaScript at all.
//
// This file is kept because some components import from it, but the functions
// are now no-ops that log a warning if called. The real token state lives in
// AuthProvider (useAuth.ts). Components should use `const { accessToken } =
// useAuth()` instead of calling getAccessToken() from this module.
//
// If you need server-side rendering access to the token, pass it as a prop
// from a Server Component that reads the httpOnly cookie from the request
// headers — do not store it in localStorage or sessionStorage.

const _WARNED = new Set<string>();

function warnOnce(fn: string): void {
  if (_WARNED.has(fn)) return;
  _WARNED.add(fn);
  if (process.env.NODE_ENV !== "production") {
    console.warn(
      `[sentinel-x] ${fn}() in lib/auth.ts is a no-op. ` +
        "Use the accessToken from useAuth() instead. " +
        "Storing JWTs in localStorage is an XSS vulnerability.",
    );
  }
}

/**
 * @deprecated Use `const { accessToken } = useAuth()` instead.
 * This function always returns null — the token is held in React state only.
 */
export function getAccessToken(): string | null {
  warnOnce("getAccessToken");
  return null;
}

/**
 * @deprecated The access token is managed by AuthProvider in useAuth.ts.
 * Calling this function has no effect.
 */
export function setAccessToken(_token: string): void {
  warnOnce("setAccessToken");
}

/**
 * @deprecated The access token is managed by AuthProvider in useAuth.ts.
 * To log out, call the `logout()` function returned by useAuth().
 */
export function clearAccessToken(): void {
  warnOnce("clearAccessToken");
}
