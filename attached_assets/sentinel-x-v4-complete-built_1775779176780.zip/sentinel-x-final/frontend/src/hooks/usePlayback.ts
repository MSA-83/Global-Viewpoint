// frontend/src/hooks/usePlayback.ts
"use client";

import { useState } from "react";
import { apiClient } from "../lib/api";
import { StreamEvent } from "./useEventStream";
import { useAuth } from "./useAuth";

export function usePlayback() {
  const { accessToken } = useAuth();
  const [loading, setLoading] = useState(false);

  async function fetchEvents(from: string, to: string, severity?: string) {
    if (!accessToken) return [];
    setLoading(true);
    try {
      const res = await apiClient(accessToken).get<StreamEvent[]>("/api/v1/events/", {
        params: { from_ts: from, to_ts: to, severity },
      });
      return res.data;
    } finally {
      setLoading(false);
    }
  }

  return { fetchEvents, loading };
}
