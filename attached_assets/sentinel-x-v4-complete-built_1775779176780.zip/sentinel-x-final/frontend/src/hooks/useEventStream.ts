// frontend/src/hooks/useEventStream.ts
/**
 * WebSocket event stream hook with automatic reconnection.
 *
 * What changed from the original
 * --------------------------------
 * The original hook had a comment "Optionally: implement exponential backoff
 * reconnect" in the onclose handler and then did nothing. For a live ops
 * dashboard, a WebSocket that disconnects silently and never reconnects means
 * the operator is looking at a frozen picture while potentially missing
 * real-world events. This is the single most dangerous UX failure mode for a
 * situational awareness platform.
 *
 * We now implement full exponential backoff reconnect:
 *   - On disconnect, wait 1s, then 2s, then 4s, up to a maximum of 30s.
 *   - On successful reconnect, reset the backoff to 1s.
 *   - A `connected` state is exposed so the UI can show a "Reconnecting..."
 *     banner rather than leaving the operator wondering if the platform is live.
 *
 * WebSocket ticket flow
 * ---------------------
 * Passing the JWT directly as a WebSocket URL parameter or subprotocol is a
 * security risk (tokens appear in logs). Instead, we call the ticket endpoint
 * first: POST /api/v1/streams/ticket with the Bearer token returns a 30-second
 * nonce. We then open the WebSocket with ?ticket=<nonce>. This way the JWT
 * never appears in a WebSocket URL.
 *
 * Event buffering
 * ---------------
 * We keep at most `maxEvents` events in state (default 1000). Older events are
 * dropped from the front of the array. This prevents unbounded memory growth
 * in a long-running browser session where thousands of events stream in.
 *
 * Usage:
 *   const { events, connected } = useEventStream(accessToken);
 */
import { useCallback, useEffect, useRef, useState } from "react";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface StreamEvent {
  id: string;
  event_type: string;
  severity: "info" | "low" | "medium" | "high" | "critical";
  occurred_at: string;
  title?: string;
  geometry?: GeoJSON.Geometry;
  payload?: Record<string, unknown>;
  classification: string;
  tenant_id?: string;
  sensor_id?: string;
}

interface UseEventStreamResult {
  events: StreamEvent[];
  connected: boolean;
  /** Manually clear the event buffer (e.g. when switching workspace) */
  clearEvents: () => void;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const INITIAL_BACKOFF_MS = 1_000;
const MAX_BACKOFF_MS = 30_000;
const DEFAULT_MAX_EVENTS = 1_000;

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useEventStream(
  accessToken: string | null | undefined,
  maxEvents = DEFAULT_MAX_EVENTS,
): UseEventStreamResult {
  const [events, setEvents] = useState<StreamEvent[]>([]);
  const [connected, setConnected] = useState(false);

  // Refs that survive re-renders without causing them.
  const wsRef = useRef<WebSocket | null>(null);
  const backoffRef = useRef(INITIAL_BACKOFF_MS);
  const reconnectTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // mountedRef prevents state updates after the component unmounts.
  const mountedRef = useRef(true);

  const apiBase = process.env.NEXT_PUBLIC_API_BASE ?? "";

  /**
   * Fetch a short-lived WebSocket ticket from the backend.
   * Returns the ticket string, or null if the request fails.
   */
  const fetchTicket = useCallback(
    async (token: string): Promise<string | null> => {
      try {
        const resp = await fetch(`${apiBase}/api/v1/streams/ticket`, {
          method: "POST",
          headers: { Authorization: `Bearer ${token}` },
          credentials: "include",
        });
        if (!resp.ok) return null;
        const { ticket } = await resp.json();
        return ticket as string;
      } catch {
        return null;
      }
    },
    [apiBase],
  );

  /**
   * Open the WebSocket connection. Separated into its own function so it can
   * be called both on initial mount and on reconnect attempts.
   */
  const connect = useCallback(
    async (token: string) => {
      // Obtain a ticket before opening the WebSocket.
      const ticket = await fetchTicket(token);
      if (!ticket || !mountedRef.current) return;

      // Build the WebSocket URL. Protocol must be ws:// or wss://.
      const wsUrl = new URL(`${apiBase}/api/v1/streams/ws`);
      wsUrl.protocol = wsUrl.protocol.replace("http", "ws");
      wsUrl.searchParams.set("ticket", ticket);

      const ws = new WebSocket(wsUrl.toString());
      wsRef.current = ws;

      ws.onopen = () => {
        if (!mountedRef.current) return;
        setConnected(true);
        backoffRef.current = INITIAL_BACKOFF_MS; // Reset backoff on success
      };

      ws.onmessage = (evt: MessageEvent<string>) => {
        if (!mountedRef.current) return;
        try {
          const event: StreamEvent = JSON.parse(evt.data);
          setEvents((prev) => {
            // Drop oldest events when the buffer is full.
            const next = prev.length >= maxEvents ? prev.slice(1) : prev;
            return [...next, event];
          });
        } catch {
          // Ignore malformed messages — the server should never send these,
          // but defensive parsing is always correct.
        }
      };

      ws.onclose = (ev: CloseEvent) => {
        if (!mountedRef.current) return;
        setConnected(false);
        wsRef.current = null;

        // Code 4001 means the server explicitly rejected the ticket.
        // Don't retry — the user needs to refresh their session.
        if (ev.code === 4001) return;

        // Schedule a reconnect with exponential backoff.
        const delay = backoffRef.current;
        backoffRef.current = Math.min(delay * 2, MAX_BACKOFF_MS);

        reconnectTimerRef.current = setTimeout(async () => {
          if (mountedRef.current) {
            await connect(token);
          }
        }, delay);
      };

      ws.onerror = () => {
        // onerror is always followed by onclose; let the close handler
        // handle reconnect. We just mark as disconnected here.
        if (mountedRef.current) setConnected(false);
      };
    },
    [apiBase, fetchTicket, maxEvents],
  );

  // Open the connection when accessToken becomes available (or changes).
  useEffect(() => {
    mountedRef.current = true;

    if (!accessToken) {
      // No token — close any existing connection and wait.
      wsRef.current?.close();
      setConnected(false);
      return;
    }

    connect(accessToken);

    // Cleanup: close the WebSocket and cancel any pending reconnect timer.
    return () => {
      mountedRef.current = false;
      if (reconnectTimerRef.current !== null) {
        clearTimeout(reconnectTimerRef.current);
        reconnectTimerRef.current = null;
      }
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, [accessToken, connect]);

  const clearEvents = useCallback(() => setEvents([]), []);

  return { events, connected, clearEvents };
}
