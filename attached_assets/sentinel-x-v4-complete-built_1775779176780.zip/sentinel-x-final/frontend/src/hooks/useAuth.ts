// frontend/src/hooks/useAuth.ts
/**
 * Authentication context and hook for Sentinel-X.
 *
 * What changed from the original
 * --------------------------------
 * 1. The original hook was missing `accessToken` from the context, but
 *    `page.tsx` destructured `{ accessToken, user }` from `useAuth()`. This
 *    meant accessToken was always `undefined`, so `useEventStream(accessToken)`
 *    never opened a WebSocket. The entire live data layer was silently broken.
 *
 * 2. `jwtDecode` was imported from `jwt-decode` but never actually used in the
 *    hook (and `jwt-decode` was not listed in package.json). Removed.
 *
 * 3. The `login` function now stores the access token in React state (not
 *    localStorage — storing JWTs in localStorage exposes them to XSS attacks).
 *    The refresh token lives in an httpOnly cookie managed by the backend.
 *
 * 4. Added `refreshToken()` — called automatically by the API client when a
 *    request returns 401. This implements the silent refresh pattern: the user
 *    never sees an interruption as long as their refresh token is valid.
 *
 * Token storage philosophy
 * ------------------------
 * Access token: in React state (memory only). Lost on page refresh, which is
 *   intentional — the `init()` call on mount re-issues a new one via the
 *   refresh token cookie automatically.
 *
 * Refresh token: httpOnly cookie set by the backend. JavaScript cannot read
 *   or steal it, which is the entire point. The browser sends it automatically
 *   on requests to the same origin.
 */
import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from "react";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface User {
  id: string;
  email: string;
  display_name?: string;
  role: "operator" | "analyst" | "commander" | "admin";
}

interface AuthContextValue {
  user: User | null;
  accessToken: string | null;  // ← was missing in original, breaking the WebSocket
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshToken: () => Promise<string | null>;
}

// ---------------------------------------------------------------------------
// Context
// ---------------------------------------------------------------------------

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const apiBase = process.env.NEXT_PUBLIC_API_BASE ?? "";

  /**
   * Exchange the refresh token cookie for a fresh access token.
   * The refresh token is sent automatically by the browser (httpOnly cookie).
   * Returns the new access token string, or null if the refresh fails.
   */
  const refreshToken = useCallback(async (): Promise<string | null> => {
    try {
      const resp = await fetch(`${apiBase}/api/v1/auth/refresh`, {
        method: "POST",
        credentials: "include", // sends the httpOnly refresh cookie
      });
      if (!resp.ok) return null;
      const { access_token } = await resp.json();
      setAccessToken(access_token);
      return access_token;
    } catch {
      return null;
    }
  }, [apiBase]);

  /**
   * On mount, try to restore the session using the refresh token cookie.
   * If it succeeds we get a new access token and fetch the user profile
   * without the user having to log in again.
   */
  useEffect(() => {
    async function init() {
      try {
        const token = await refreshToken();
        if (!token) {
          setLoading(false);
          return;
        }
        const resp = await fetch(`${apiBase}/api/v1/auth/me`, {
          headers: { Authorization: `Bearer ${token}` },
          credentials: "include",
        });
        if (resp.ok) {
          setUser(await resp.json());
        }
      } catch {
        // Refresh failed — user is not logged in, which is fine
      } finally {
        setLoading(false);
      }
    }
    init();
  }, [apiBase, refreshToken]);

  /**
   * Log in with email and password.
   * On success, stores the access token in React state and fetches the user
   * profile. The backend sets the refresh token as an httpOnly cookie.
   */
  const login = useCallback(
    async (email: string, password: string): Promise<void> => {
      const form = new URLSearchParams();
      form.append("username", email);
      form.append("password", password);

      const resp = await fetch(`${apiBase}/api/v1/auth/login`, {
        method: "POST",
        body: form,
        credentials: "include", // receive the httpOnly refresh cookie
      });

      if (!resp.ok) {
        const err = await resp.json().catch(() => ({}));
        throw new Error(err.detail ?? "Login failed");
      }

      const { access_token } = await resp.json();
      setAccessToken(access_token);

      const profileResp = await fetch(`${apiBase}/api/v1/auth/me`, {
        headers: { Authorization: `Bearer ${access_token}` },
        credentials: "include",
      });
      if (profileResp.ok) {
        setUser(await profileResp.json());
      }
    },
    [apiBase],
  );

  /**
   * Log out by clearing local state and asking the backend to clear the
   * refresh token cookie.
   */
  const logout = useCallback(async (): Promise<void> => {
    try {
      await fetch(`${apiBase}/api/v1/auth/logout`, {
        method: "POST",
        credentials: "include",
      });
    } catch {
      // Best-effort — always clear local state regardless
    } finally {
      setUser(null);
      setAccessToken(null);
    }
  }, [apiBase]);

  return (
    <AuthContext.Provider
      value={{ user, accessToken, loading, login, logout, refreshToken }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// ---------------------------------------------------------------------------
// Hook
// ---------------------------------------------------------------------------

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (ctx === undefined) {
    throw new Error("useAuth must be called within an <AuthProvider>.");
  }
  return ctx;
}
