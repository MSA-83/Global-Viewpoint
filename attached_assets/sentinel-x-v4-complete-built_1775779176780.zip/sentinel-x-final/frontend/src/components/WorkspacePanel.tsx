// frontend/src/components/WorkspacePanel.tsx
//
// Mission workspace selector panel.
//
// The previous version called `onSelect(ws)` with the full workspace object
// but typed it as `onSelect: (ws: Workspace | null) => void` using a local
// interface that wasn't exported. This made it impossible for DashboardPage
// to type-check the config it received.
//
// Changes:
//   - Export the Workspace interface so page.tsx can import and use it
//   - `onSelect` now receives the full object with typed `config`
//   - Show workspace AOI in the panel when available

"use client";

import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { apiClient } from "../lib/api";

export interface WorkspaceConfig {
  aoi?: { lat: number; lon: number; radius_km: number };
  severity_filter?: string[];
  [key: string]: unknown;
}

export interface Workspace {
  id: string;
  name: string;
  description?: string;
  config: WorkspaceConfig;
}

interface Props {
  onSelect: (ws: Workspace | null) => void;
}

export function WorkspacePanel({ onSelect }: Props) {
  const { accessToken } = useAuth();
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);

  useEffect(() => {
    if (!accessToken) return;
    apiClient(accessToken)
      .get<Workspace[]>("/api/v1/workspaces/")
      .then((res) => setWorkspaces(res.data))
      .catch(() => setWorkspaces([]));
  }, [accessToken]);

  function select(ws: Workspace) {
    setActiveId(ws.id);
    onSelect(ws);
  }

  function clearSelection() {
    setActiveId(null);
    onSelect(null);
  }

  return (
    <div className="border-b border-slate-800 bg-slate-900 p-3">
      <div className="mb-2 flex items-center justify-between">
        <h2 className="text-xs font-semibold uppercase tracking-wide text-slate-400">
          Workspaces
        </h2>
        <div className="flex items-center gap-2">
          {activeId && (
            <button
              onClick={clearSelection}
              className="text-[10px] text-slate-500 hover:text-slate-300"
            >
              ✕ clear
            </button>
          )}
          <span className="text-[10px] text-slate-500">
            {workspaces.length} saved
          </span>
        </div>
      </div>

      <div className="flex max-h-28 flex-col gap-1 overflow-y-auto">
        {workspaces.map((w) => (
          <button
            key={w.id}
            onClick={() => select(w)}
            className={`flex w-full flex-col rounded px-2 py-1 text-left text-xs ${
              activeId === w.id
                ? "bg-emerald-600/20 text-emerald-200"
                : "bg-slate-950 text-slate-200 hover:bg-slate-800"
            }`}
          >
            <span className="font-medium">{w.name}</span>
            {w.config?.aoi && (
              <span className="text-[10px] text-slate-500">
                {w.config.aoi.lat.toFixed(1)}, {w.config.aoi.lon.toFixed(1)} ·{" "}
                {w.config.aoi.radius_km} km
              </span>
            )}
          </button>
        ))}

        {workspaces.length === 0 && (
          <p className="text-[11px] text-slate-600">No workspaces saved yet.</p>
        )}
      </div>
    </div>
  );
}
