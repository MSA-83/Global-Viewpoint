// src/components/Map.tsx
import { useEffect, useRef } from "react";
import mapboxgl from "mapbox-gl";
import DeckGL from "@deck.gl/react";
import { ScatterplotLayer } from "@deck.gl/layers";

type Sensor = {
  id: string;
  name: string;
  description?: string;
  location: {
    type: "Point";
    coordinates: [number, number]; // [lon, lat]
  };
  is_active: boolean;
};

type Props = {
  sensors: Sensor[];
};

export default function Map({ sensors }: Props) {
  const mapContainer = useRef<HTMLDivElement>(null);

  // Initialise Mapbox GL (only once)
  useEffect(() => {
    if (!mapContainer.current) return;

    mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN as string;

    const map = new mapboxgl.Map({
      container: mapContainer.current,
      style: "mapbox://styles/mapbox/dark-v11",
      center: [0, 0],
      zoom: 2,
    });

    // Cleanup on unmount
    return () => {
      map.remove();
    };
  }, []);

  // DeckGL overlay – clustering via ScatterplotLayer
  const layers = [
    new ScatterplotLayer({
      id: "sensor-points",
      data: sensors,
      getPosition: (d: Sensor) => d.location.coordinates,
      getRadius: 50000, // metres
      getFillColor: (d: Sensor) =>
        d.is_active ? [0, 200, 0, 200] : [200, 0, 0, 120],
      radiusMinPixels: 2,
      radiusMaxPixels: 10,
      pickable: true,
      onHover: ({ object, x, y }) => {
        if (object) {
          const tooltip = document.getElementById("tooltip");
          if (tooltip) {
            tooltip.style.display = "block";
            tooltip.style.left = `${x + 5}px`;
            tooltip.style.top = `${y + 5}px`;
            tooltip.innerHTML = `<strong>${object.name}</strong><br/>${object.description ||
              "No description"}`;
          }
        }
      },
      onLeave: () => {
        const tooltip = document.getElementById("tooltip");
        if (tooltip) tooltip.style.display = "none";
      },
    }),
  ];

  return (
    <div style={{ position: "relative", height: "calc(100vh - 64px)" }}>
      <div ref={mapContainer} style={{ width: "100%", height: "100%" }} />
      <DeckGL
        initialViewState={{
          longitude: 0,
          latitude: 0,
          zoom: 2,
          pitch: 0,
          bearing: 0,
        }}
        controller={true}
        layers={layers}
        style={{ position: "absolute", top: 0, left: 0, pointerEvents: "none" }}
      />
      <div
        id="tooltip"
        style={{
          position: "absolute",
          pointerEvents: "none",
          background: "rgba(0,0,0,0.7)",
          color: "#fff",
          padding: "4px 8px",
          borderRadius: "4px",
          fontSize: "0.85rem",
          display: "none",
          zIndex: 10,
        }}
      />
    </div>
  );
}
