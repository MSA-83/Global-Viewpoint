// frontend/src/components/SensorPanel.tsx
//
// Sensor list panel for Sentinel-X.
//
// New: `onSensorsLoad` optional callback allows the parent (DashboardPage)
// to receive the loaded sensors and pass them to Globe for rendering as a
// ScatterplotLayer. Without this lift, the Globe had no access to sensor
// data and the map layer was always empty.

"use client";

import { useEffect, useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { apiClient } from "../lib/api";
import { SensorCard } from "./SensorCard";
import type { MapSensor } from "./Globe";

export interface Sensor {
  id: string;
  name: string;
  domain: "land" | "maritime" | "air" | "space" | "cyber";
  status: "operational" | "degraded" | "offline";
  platform?: string;
  latitude?: number;
  longitude?: number;
  capabilities?: Record<string, unknown>;
}

interface Props {
  /** Called after sensors are fetched so the parent can pass them to Globe. */
  onSensorsLoad?: (sensors: MapSensor[]) => void;
}

export function SensorPanel({ onSensorsLoad }: Props) {
  const { accessToken } = useAuth();
  const [sensors, setSensors] = useState<Sensor[]>([]);

  useEffect(() => {
    if (!accessToken) return;

    apiClient(accessToken)
      .get<Sensor[] | { items: Sensor[] }>("/api/v1/sensors/?skip=0&limit=200")
      .then((res) => {
        const data: Sensor[] = Array.isArray(res.data)
          ? res.data
          : res.data.items ?? [];
        setSensors(data);

        // Lift sensors with coordinates to the parent for map rendering.
        if (onSensorsLoad) {
          const mapSensors: MapSensor[] = data
            .filter((s) => s.latitude != null && s.longitude != null)
            .map((s) => ({
              id: s.id,
              name: s.name,
              latitude: s.latitude!,
              longitude: s.longitude!,
              status: s.status,
              platform: s.platform,
            }));
          onSensorsLoad(mapSensors);
        }
      })
      .catch(() => setSensors([]));
  }, [accessToken, onSensorsLoad]);

  const operational = sensors.filter((s) => s.status === "operational").length;

  return (
    <div className="border-b border-slate-800 bg-slate-900 p-3">
      <div className="mb-2 flex items-center justify-between">
        <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Sensors
        </h2>
        <span className="text-xs text-slate-500">
          {operational}/{sensors.length} online
        </span>
      </div>
      <div className="flex max-h-40 flex-col gap-1 overflow-y-auto">
        {sensors.map((s) => (
          <SensorCard key={s.id} sensor={s} />
        ))}
        {sensors.length === 0 && (
          <p className="text-[11px] text-slate-600">No sensors registered.</p>
        )}
      </div>
    </div>
  );
}
