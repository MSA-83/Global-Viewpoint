// frontend/src/components/SensorCard.tsx
import type { Sensor } from "./SensorPanel";

const statusColor: Record<Sensor["status"], string> = {
  operational: "bg-emerald-500",
  degraded: "bg-amber-500",
  offline: "bg-red-600",
};

export function SensorCard({ sensor }: { sensor: Sensor }) {
  return (
    <div className="flex items-center justify-between rounded border border-slate-800 bg-slate-950 px-2 py-1 text-xs">
      <div>
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-100">{sensor.name}</span>
          <span className="rounded bg-slate-800 px-1 text-[10px] uppercase tracking-wide text-slate-300">
            {sensor.domain}
          </span>
        </div>
        <div className="text-[11px] text-slate-400">
          {sensor.platform ?? "Unknown platform"}
        </div>
      </div>
      <div className="flex items-center gap-1">
        <span
          className={`h-2 w-2 rounded-full ${statusColor[sensor.status]}`}
        />
        <span className="text-[11px] text-slate-300">{sensor.status}</span>
      </div>
    </div>
  );
}
