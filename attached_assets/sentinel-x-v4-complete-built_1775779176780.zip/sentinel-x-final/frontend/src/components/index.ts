// frontend/src/components/index.ts
//
// REMOVED: `export * from "./Map"` — Map.tsx used a default export (`export
// default function Map`), so `export *` exported nothing. Any code that wrote
// `import { Map } from "@/components"` got undefined at runtime. More
// importantly, Map.tsx's functionality (sensor layer) is now integrated into
// Globe.tsx as a ScatterplotLayer, making the separate file obsolete.
//
// The MapSensor type is re-exported from Globe so SensorPanel and page.tsx
// can reference it without importing directly from the component file.

export * from "./Navbar";
export * from "./Globe";
export type { MapSensor } from "./Globe";
export * from "./SensorCard";
export * from "./SensorPanel";
export * from "./EventTimeline";
export * from "./WorkspacePanel";
export * from "./PlaybackControls";
