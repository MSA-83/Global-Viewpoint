// frontend/src/components/EventTimeline.tsx
//
// Live event log panel for Sentinel-X.
//
// CASING FIX: The original used uppercase keys ("CRITICAL", "HIGH") in the
// severityColor map, but the backend emits lowercase values ("critical", "high").
// The lookup always missed and every event rendered as text-slate-200 (plain
// grey) regardless of severity. Keys are now lowercase.
//
// TITLE: Events now show their `title` field (e.g. "Vessel off route") instead
// of the raw `event_type` enum slug. Falls back to event_type if title is absent.

"use client";

import type { StreamEvent } from "../hooks/useEventStream";

// Lowercase keys matching EventSeverity enum values from the backend.
const SEVERITY_COLOR: Record<string, string> = {
  critical: "text-red-400",
  high:     "text-amber-300",
  medium:   "text-yellow-200",
  low:      "text-sky-300",
  info:     "text-slate-300",
};

const SEVERITY_DOT: Record<string, string> = {
  critical: "bg-red-400",
  high:     "bg-amber-400",
  medium:   "bg-yellow-300",
  low:      "bg-sky-400",
  info:     "bg-slate-500",
};

export function EventTimeline({ events }: { events: StreamEvent[] }) {
  // Show newest 100, most recent at the top.
  const latest = [...events].slice(-100).reverse();

  return (
    <div className="flex-1 overflow-y-auto bg-slate-950 p-3">
      <h2 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
        Event Log
        {events.length > 0 && (
          <span className="ml-2 font-normal normal-case text-slate-500">
            ({events.length})
          </span>
        )}
      </h2>

      {latest.length === 0 ? (
        <p className="text-[11px] text-slate-600">No events yet.</p>
      ) : (
        <ul className="space-y-1">
          {latest.map((e) => {
            // Normalize to lowercase for the lookup — backend sends lowercase,
            // but be defensive in case something upstream sends mixed case.
            const sev = (e.severity ?? "info").toLowerCase();
            const colorClass = SEVERITY_COLOR[sev] ?? "text-slate-200";
            const dotClass = SEVERITY_DOT[sev] ?? "bg-slate-500";

            return (
              <li
                key={e.id}
                className="rounded border border-slate-800 bg-slate-900 px-2 py-1 text-xs"
              >
                <div className="flex items-start gap-2">
                  {/* Severity dot */}
                  <span className={`mt-[3px] h-1.5 w-1.5 flex-shrink-0 rounded-full ${dotClass}`} />

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-1">
                      {/* Title / event type */}
                      <span className={`truncate font-semibold ${colorClass}`}>
                        {e.title ?? e.event_type}
                      </span>
                      {/* Timestamp */}
                      <span className="flex-shrink-0 text-[10px] text-slate-500">
                        {new Date(e.occurred_at).toUTCString().slice(5, 22)}
                      </span>
                    </div>

                    {/* Optional summary from payload */}
                    {e.payload?.summary && (
                      <p className="mt-0.5 truncate text-[11px] text-slate-400">
                        {String(e.payload.summary)}
                      </p>
                    )}

                    {/* Classification badge — show if not the default */}
                    {e.classification && e.classification !== "UNCLASSIFIED" && (
                      <span className="mt-0.5 inline-block rounded bg-slate-800 px-1 text-[9px] uppercase tracking-wide text-slate-400">
                        {e.classification}
                      </span>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
