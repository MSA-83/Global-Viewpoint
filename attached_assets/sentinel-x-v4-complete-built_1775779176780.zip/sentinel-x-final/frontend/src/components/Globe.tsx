// frontend/src/components/Globe.tsx
//
// Canonical geospatial visualisation component for Sentinel-X.
//
// This component replaces both the original Globe.tsx (events only) and
// Map.tsx (sensors only, with a separate Mapbox instance) with a single,
// unified Deck.gl + react-map-gl renderer. Having two independent map
// implementations caused:
//   - Two separate Mapbox GL JS instances consuming memory
//   - Inconsistent styling between the event and sensor views
//   - Map.tsx using direct DOM manipulation for tooltips (fragile, non-React)
//
// Severity casing fix
// -------------------
// Globe.tsx previously keyed off uppercase severity values ("CRITICAL", "HIGH")
// while the backend emits lowercase values ("critical", "high") as defined in
// the EventSeverity enum. The color mapping always fell through to the default
// because the keys never matched. All comparisons now use the lowercase values
// that actually arrive over the WebSocket.
//
// Sensor layer
// ------------
// The sensor ScatterplotLayer from the old Map.tsx is integrated here so the
// dashboard has one map component managing all layers coherently. SensorPanel
// passes its sensors as a prop; when no sensors are provided the layer is
// simply skipped.

"use client";

import { useCallback, useMemo, useState } from "react";
import { DeckGL } from "@deck.gl/react";
import { GeoJsonLayer, ScatterplotLayer } from "@deck.gl/layers";
import { Map as MapGL } from "react-map-gl";
import type { PickingInfo } from "@deck.gl/core";
import type { StreamEvent } from "../hooks/useEventStream";

export interface MapSensor {
  id: string;
  name: string;
  latitude: number;
  longitude: number;
  status: "operational" | "degraded" | "offline";
  platform?: string;
}

interface GlobeProps {
  events: StreamEvent[];
  sensors?: MapSensor[];
}

const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_MAPBOX_TOKEN ?? "";

// Severity → RGBA color.
// Keys are LOWERCASE to match EventSeverity enum values from the backend.
// The original used uppercase ("CRITICAL"), which never matched and caused
// every event to render as the default blue regardless of actual severity.
const SEVERITY_COLOR: Record<string, [number, number, number, number]> = {
  critical: [255, 30,  30,  220],
  high:     [255, 140,  0,  210],
  medium:   [255, 210,  0,  180],
  low:      [100, 180, 255, 160],
  info:     [60,  130, 200, 140],
};

const DEFAULT_COLOR: [number, number, number, number] = [60, 130, 200, 140];

const SENSOR_STATUS_COLOR: Record<string, [number, number, number, number]> = {
  operational: [0,   200, 100, 200],
  degraded:    [255, 180,   0, 200],
  offline:     [200,  30,  30, 180],
};

export function Globe({ events, sensors = [] }: GlobeProps) {
  const [tooltip, setTooltip] = useState<{ x: number; y: number; text: string } | null>(null);

  // Build GeoJSON FeatureCollection from events that have geometry.
  const geojson = useMemo(
    () => ({
      type: "FeatureCollection" as const,
      features: events
        .filter((e) => e.geometry)
        .map((e) => ({
          type: "Feature" as const,
          geometry: e.geometry!,
          properties: {
            id: e.id,
            severity: e.severity,   // lowercase from backend
            event_type: e.event_type,
            title: e.title ?? e.event_type,
          },
        })),
    }),
    [events],
  );

  const handleHover = useCallback((info: PickingInfo) => {
    if (info.object) {
      const props = (info.object as { properties?: { title?: string; severity?: string } }).properties;
      const title = props?.title ?? "Event";
      const severity = props?.severity ?? "";
      setTooltip({
        x: info.x,
        y: info.y,
        text: `${title}${severity ? ` · ${severity}` : ""}`,
      });
    } else {
      setTooltip(null);
    }
  }, []);

  const layers = [
    // Event layer — GeoJSON points / polygons coloured by severity
    new GeoJsonLayer({
      id: "sentinel-events",
      data: geojson,
      pointRadiusMinPixels: 3,
      pointRadiusMaxPixels: 14,
      getPointRadius: (f) => {
        const sev = (f.properties?.severity as string) ?? "";
        if (sev === "critical") return 14;
        if (sev === "high")     return 10;
        if (sev === "medium")   return 7;
        return 4;
      },
      getFillColor: (f) =>
        SEVERITY_COLOR[(f.properties?.severity as string) ?? ""] ?? DEFAULT_COLOR,
      getLineColor: [255, 255, 255, 60],
      lineWidthMinPixels: 0.5,
      pickable: true,
      onHover: handleHover,
    }),

    // Sensor layer — ScatterplotLayer coloured by operational status
    ...(sensors.length > 0
      ? [
          new ScatterplotLayer<MapSensor>({
            id: "sentinel-sensors",
            data: sensors,
            getPosition: (d) => [d.longitude, d.latitude],
            getRadius: 40_000, // metres — scales with map zoom
            radiusMinPixels: 3,
            radiusMaxPixels: 12,
            getFillColor: (d) =>
              SENSOR_STATUS_COLOR[d.status] ?? SENSOR_STATUS_COLOR.operational,
            pickable: true,
            onHover: (info: PickingInfo) => {
              if (info.object) {
                const s = info.object as MapSensor;
                setTooltip({
                  x: info.x,
                  y: info.y,
                  text: `${s.name} · ${s.status}${s.platform ? ` · ${s.platform}` : ""}`,
                });
              } else {
                setTooltip(null);
              }
            },
          }),
        ]
      : []),
  ];

  return (
    <div className="relative h-full w-full">
      <DeckGL
        initialViewState={{
          longitude: 10,
          latitude: 30,
          zoom: 1.8,
          pitch: 25,
          bearing: 0,
        }}
        controller
        layers={layers}
        style={{ position: "absolute", inset: 0 }}
      >
        <MapGL
          reuseMaps
          mapboxAccessToken={MAPBOX_TOKEN}
          mapStyle="mapbox://styles/mapbox/dark-v11"
        />
      </DeckGL>

      {/* Tooltip — rendered via React state, not direct DOM manipulation */}
      {tooltip && (
        <div
          className="pointer-events-none absolute z-10 max-w-xs rounded bg-slate-900/90 px-2 py-1 text-[11px] text-slate-100 shadow-lg"
          style={{ left: tooltip.x + 10, top: tooltip.y + 10 }}
        >
          {tooltip.text}
        </div>
      )}
    </div>
  );
}
