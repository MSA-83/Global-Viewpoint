// frontend/src/components/Navbar.tsx
"use client";

import Link from "next/link";
import { useAuth } from "../hooks/useAuth";

export function Navbar() {
  const { user, logout } = useAuth();

  return (
    <header className="flex h-14 items-center justify-between border-b border-slate-800 bg-slate-900 px-4">
      <div className="flex items-center gap-3">
        <span className="text-lg font-semibold tracking-tight">Sentinel‑X</span>
        <nav className="flex gap-4 text-sm text-slate-300">
          <Link href="/">Dashboard</Link>
          <Link href="/sensors">Sensors</Link>
          <Link href="/intel">Intel</Link>
        </nav>
      </div>
      <div className="flex items-center gap-3 text-sm">
        {user && (
          <>
            <span className="text-slate-300">
              {user.display_name || user.email} ({user.role})
            </span>
            <button
              className="rounded bg-slate-700 px-3 py-1 text-xs hover:bg-slate-600"
              onClick={logout}
            >
              Logout
            </button>
          </>
        )}
      </div>
    </header>
  );
}
