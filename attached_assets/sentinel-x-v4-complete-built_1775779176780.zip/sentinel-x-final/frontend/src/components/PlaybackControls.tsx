// frontend/src/components/PlaybackControls.tsx
"use client";

import { useState } from "react";
import { usePlayback } from "../hooks/usePlayback";
import type { StreamEvent } from "../hooks/useEventStream";

interface Props {
  onLoad: (events: StreamEvent[]) => void;
}

export function PlaybackControls({ onLoad }: Props) {
  const { fetchEvents, loading } = usePlayback();
  const [fromTs, setFromTs] = useState<string>("");
  const [toTs, setToTs] = useState<string>("");
  const [severity, setSeverity] = useState<string>("");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!fromTs || !toTs) return;
    const events = await fetchEvents(fromTs, toTs, severity || undefined);
    onLoad(events);
  }

  return (
    <form
      onSubmit={onSubmit}
      className="flex flex-col gap-1 border-b border-slate-800 bg-slate-900 p-3 text-[11px]"
    >
      <div className="flex gap-2">
        <label className="flex flex-1 flex-col">
          <span className="text-slate-400">From (ISO)</span>
          <input
            className="rounded border border-slate-700 bg-slate-950 px-1 py-[2px]"
            value={fromTs}
            onChange={(e) => setFromTs(e.target.value)}
            placeholder="2026-04-08T18:00:00Z"
          />
        </label>
        <label className="flex flex-1 flex-col">
          <span className="text-slate-400">To (ISO)</span>
          <input
            className="rounded border border-slate-700 bg-slate-950 px-1 py-[2px]"
            value={toTs}
            onChange={(e) => setToTs(e.target.value)}
            placeholder="2026-04-08T19:00:00Z"
          />
        </label>
      </div>
      <div className="flex items-center justify-between">
        <label className="flex items-center gap-1">
          <span className="text-slate-400">Severity</span>
          <select
            className="rounded border border-slate-700 bg-slate-950 px-1 py-[2px]"
            value={severity}
            onChange={(e) => setSeverity(e.target.value)}
          >
            <option value="">Any</option>
            <option value="INFO">Info</option>
            <option value="LOW">Low</option>
            <option value="MEDIUM">Medium</option>
            <option value="HIGH">High</option>
            <option value="CRITICAL">Critical</option>
          </select>
        </label>
        <button
          type="submit"
          disabled={loading}
          className="rounded bg-slate-700 px-2 py-[2px] text-[11px] text-slate-100 hover:bg-slate-600 disabled:opacity-50"
        >
          {loading ? "Loading…" : "Load"}
        </button>
      </div>
    </form>
  );
}
