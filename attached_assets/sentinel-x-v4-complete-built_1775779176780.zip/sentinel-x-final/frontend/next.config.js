/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  // "standalone" output bundles everything needed to run the app into
  // .next/standalone — used by the Docker multi-stage build so the final
  // image doesn't need node_modules mounted separately.
  output: "standalone",

  // Note: experimental.appDir was removed — it's deprecated in Next.js 14.
  // The App Router is stable and enabled by default; the experimental flag
  // generates a build warning and has no effect.

  // Allow the backend API to be proxied during local development so the
  // browser never needs to send cross-origin requests. In production the
  // nginx-ingress Helm chart handles routing.
  async rewrites() {
    return process.env.NODE_ENV === "development"
      ? [
          {
            source: "/api/:path*",
            destination: `${process.env.NEXT_PUBLIC_API_BASE ?? "http://localhost:8000"}/api/:path*`,
          },
        ]
      : [];
  },
};

module.exports = nextConfig;
