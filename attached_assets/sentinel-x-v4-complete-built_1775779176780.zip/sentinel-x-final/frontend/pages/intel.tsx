// frontend/pages/intel.tsx
//
// Intel overview page — displays fused multi-domain intelligence for an area.
//
// The original page referenced the old intel router response shape:
//   { weather, nasa_events, fishing, space_tracks }
//
// The new intel router returns a richer shape with seven domains:
//   { query, weather, aviation, maritime, natural_events, cyber, fishing, orbital }
//
// This page is updated to match. It also adds:
//   - A coordinate/radius input form so operators can query any area, not just
//     the hardcoded Amsterdam coordinates in the original.
//   - Domain selector checkboxes to fetch only the layers the operator needs,
//     reducing latency on the /intel/overview call.
//   - Proper loading and error states.
//   - Domain-specific rendering with counts and structured summaries instead
//     of raw JSON dumps (though a "raw" expand toggle is kept for debugging).

"use client";

import { useState } from "react";
import { useAuth } from "../src/hooks/useAuth";
import { apiClient } from "../src/lib/api";

// ── Types matching the new /api/v1/intel/overview response ────────────────────

interface IntelQuery {
  lat: number;
  lon: number;
  radius_km: number;
  domains: string[];
}

interface Vessel {
  mmsi: number;
  name: string;
  lat: number;
  lon: number;
  sog?: number;
  nav_status?: string;
}

interface NaturalEvent {
  id: string;
  title: string;
  categories: string[];
  lat?: number;
  lon?: number;
  date?: string;
}

interface CyberHost {
  ip: string;
  org?: string;
  country?: string;
  open_ports: number[];
  vulns: string[];
}

interface IntelOverview {
  query: IntelQuery;
  weather: Record<string, unknown>;
  aviation: { sigmets: unknown[]; metars: unknown[] };
  maritime: { vessels: Vessel[]; vessel_count: number };
  natural_events: NaturalEvent[];
  cyber: { exposed_hosts: CyberHost[]; host_count: number };
  fishing: unknown[];
  orbital: unknown[];
}

// ── Available intelligence domains ───────────────────────────────────────────

const ALL_DOMAINS = ["weather", "aviation", "maritime", "natural", "cyber", "fishing", "orbital"];

// ── Component ─────────────────────────────────────────────────────────────────

export default function IntelPage() {
  const { accessToken } = useAuth();

  const [lat, setLat] = useState("52.37");
  const [lon, setLon] = useState("4.90");
  const [radius, setRadius] = useState("250");
  const [selectedDomains, setSelectedDomains] = useState<string[]>(
    ALL_DOMAINS.filter((d) => d !== "orbital"),
  );

  const [intel, setIntel] = useState<IntelOverview | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!accessToken) {
    return (
      <div className="flex h-full items-center justify-center bg-slate-950">
        <p className="text-slate-300">Login required to access Intel.</p>
      </div>
    );
  }

  async function fetchIntel() {
    setLoading(true);
    setError(null);
    try {
      const params: Record<string, unknown> = {
        lat: parseFloat(lat),
        lon: parseFloat(lon),
        radius_km: parseFloat(radius),
      };
      // The API accepts repeated `domains` params: ?domains=weather&domains=maritime
      const url = new URL(
        `${process.env.NEXT_PUBLIC_API_BASE}/api/v1/intel/overview`,
      );
      url.searchParams.set("lat", params.lat as string);
      url.searchParams.set("lon", params.lon as string);
      url.searchParams.set("radius_km", params.radius_km as string);
      selectedDomains.forEach((d) => url.searchParams.append("domains", d));

      const res = await apiClient(accessToken!).get<IntelOverview>(
        `/api/v1/intel/overview?${url.searchParams.toString()}`,
      );
      setIntel(res.data);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Request failed");
    } finally {
      setLoading(false);
    }
  }

  function toggleDomain(domain: string) {
    setSelectedDomains((prev) =>
      prev.includes(domain)
        ? prev.filter((d) => d !== domain)
        : [...prev, domain],
    );
  }

  return (
    <div className="flex h-full flex-col overflow-hidden bg-slate-950 text-slate-100">
      {/* ── Query bar ─────────────────────────────────────────────────── */}
      <div className="flex flex-wrap items-end gap-3 border-b border-slate-800 bg-slate-900 p-3">
        <label className="flex flex-col text-xs">
          <span className="text-slate-400">Latitude</span>
          <input
            className="w-28 rounded border border-slate-700 bg-slate-950 px-2 py-1 text-sm"
            value={lat}
            onChange={(e) => setLat(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-xs">
          <span className="text-slate-400">Longitude</span>
          <input
            className="w-28 rounded border border-slate-700 bg-slate-950 px-2 py-1 text-sm"
            value={lon}
            onChange={(e) => setLon(e.target.value)}
          />
        </label>
        <label className="flex flex-col text-xs">
          <span className="text-slate-400">Radius (km)</span>
          <input
            className="w-20 rounded border border-slate-700 bg-slate-950 px-2 py-1 text-sm"
            value={radius}
            onChange={(e) => setRadius(e.target.value)}
          />
        </label>
        <div className="flex flex-col gap-1 text-xs">
          <span className="text-slate-400">Domains</span>
          <div className="flex flex-wrap gap-2">
            {ALL_DOMAINS.map((d) => (
              <label key={d} className="flex cursor-pointer items-center gap-1">
                <input
                  type="checkbox"
                  checked={selectedDomains.includes(d)}
                  onChange={() => toggleDomain(d)}
                />
                <span className="capitalize text-slate-300">{d}</span>
              </label>
            ))}
          </div>
        </div>
        <button
          onClick={fetchIntel}
          disabled={loading}
          className="rounded bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500 disabled:opacity-50"
        >
          {loading ? "Fetching…" : "Fetch Intel"}
        </button>
        {error && <span className="text-xs text-red-400">{error}</span>}
      </div>

      {/* ── Results grid ──────────────────────────────────────────────── */}
      {intel && (
        <div className="grid flex-1 grid-cols-1 gap-3 overflow-y-auto p-3 md:grid-cols-2 xl:grid-cols-3">
          {/* Weather */}
          {intel.weather && Object.keys(intel.weather).length > 0 && (
            <DomainCard title="Weather">
              <RawJson data={intel.weather} />
            </DomainCard>
          )}

          {/* Aviation */}
          {(intel.aviation.sigmets.length > 0 || intel.aviation.metars.length > 0) && (
            <DomainCard title={`Aviation — ${intel.aviation.sigmets.length} SIGMETs, ${intel.aviation.metars.length} METARs`}>
              <RawJson data={intel.aviation} />
            </DomainCard>
          )}

          {/* Maritime */}
          <DomainCard title={`Maritime — ${intel.maritime.vessel_count} vessels`}>
            {intel.maritime.vessels.slice(0, 10).map((v) => (
              <div key={v.mmsi} className="flex justify-between border-b border-slate-800 py-1 text-[11px]">
                <span className="font-medium text-slate-100">{v.name || `MMSI ${v.mmsi}`}</span>
                <span className="text-slate-400">
                  {v.lat?.toFixed(2)}, {v.lon?.toFixed(2)}
                  {v.sog !== undefined ? ` · ${v.sog}kn` : ""}
                </span>
              </div>
            ))}
            {intel.maritime.vessel_count > 10 && (
              <p className="mt-1 text-[10px] text-slate-500">
                +{intel.maritime.vessel_count - 10} more vessels
              </p>
            )}
          </DomainCard>

          {/* Natural Events */}
          {intel.natural_events.length > 0 && (
            <DomainCard title={`Natural Events — ${intel.natural_events.length}`}>
              {intel.natural_events.map((e) => (
                <div key={e.id} className="border-b border-slate-800 py-1 text-[11px]">
                  <span className="font-medium text-slate-100">{e.title}</span>
                  <span className="ml-2 text-slate-400">
                    {e.categories.join(", ")}
                    {e.date ? ` · ${e.date.slice(0, 10)}` : ""}
                  </span>
                </div>
              ))}
            </DomainCard>
          )}

          {/* Cyber */}
          <DomainCard title={`Cyber — ${intel.cyber.host_count} exposed hosts`}>
            {intel.cyber.exposed_hosts.slice(0, 8).map((h) => (
              <div key={h.ip} className="border-b border-slate-800 py-1 text-[11px]">
                <span className="font-mono text-sky-300">{h.ip}</span>
                <span className="ml-2 text-slate-400">{h.org ?? ""}</span>
                {h.vulns.length > 0 && (
                  <span className="ml-2 text-red-400">{h.vulns.length} CVEs</span>
                )}
              </div>
            ))}
          </DomainCard>

          {/* Orbital */}
          {intel.orbital.length > 0 && (
            <DomainCard title={`Orbital — ${intel.orbital.length} objects`}>
              <RawJson data={intel.orbital} />
            </DomainCard>
          )}
        </div>
      )}

      {!intel && !loading && (
        <div className="flex flex-1 items-center justify-center text-slate-500 text-sm">
          Configure the query above and click Fetch Intel.
        </div>
      )}
    </div>
  );
}

// ── Sub-components ─────────────────────────────────────────────────────────────

function DomainCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded border border-slate-800 bg-slate-900 p-3">
      <h2 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
        {title}
      </h2>
      <div className="text-xs">{children}</div>
    </div>
  );
}

function RawJson({ data }: { data: unknown }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div>
      <button
        onClick={() => setExpanded((v) => !v)}
        className="mb-1 text-[10px] text-slate-500 hover:text-slate-300"
      >
        {expanded ? "▲ hide raw" : "▼ show raw"}
      </button>
      {expanded && (
        <pre className="max-h-48 overflow-y-auto text-[10px] text-slate-400">
          {JSON.stringify(data, null, 2)}
        </pre>
      )}
    </div>
  );
}
