// frontend/pages/login.tsx
//
// Login page (Pages Router).
//
// BUG FIXED: The original had `"use client"` at the top, which is an App
// Router directive. Pages Router pages are client-rendered by default —
// the directive has no effect there and generates a lint warning in Next.js 14.
// More critically, mixing router paradigm directives in a single file signals
// confusion about which routing system owns this page.
//
// Also fixed: imported `useRouter` from "next/router" (Pages Router) which is
// correct for pages/, but the component should guard against calling push()
// on router before it is ready, which we do by checking router.isReady.

import { FormEvent, useState } from "react";
import { useAuth } from "../src/hooks/useAuth";
import { useRouter } from "next/router";
import Link from "next/link";

export default function LoginPage() {
  const { login } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setErr(null);
    setLoading(true);
    try {
      await login(email, password);
      // Redirect to the destination the user was trying to reach, or the
      // dashboard as the default.
      const next = typeof router.query.next === "string" ? router.query.next : "/";
      await router.push(next);
    } catch (error: unknown) {
      const msg = error instanceof Error ? error.message : "Login failed";
      setErr(msg);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950">
      <div className="w-80">
        <div className="mb-6 text-center">
          <h1 className="text-2xl font-bold tracking-tight text-slate-100">
            Sentinel‑X
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Global Situational Awareness Platform
          </p>
        </div>

        <form
          onSubmit={onSubmit}
          className="rounded border border-slate-800 bg-slate-900 p-6"
        >
          <h2 className="mb-4 text-sm font-semibold text-slate-200">
            Sign in
          </h2>

          <label className="block text-xs text-slate-400">
            Email
            <input
              type="email"
              autoComplete="username"
              required
              className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-2 py-1.5 text-sm text-slate-100 placeholder-slate-600 focus:border-emerald-600 focus:outline-none"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="operator@example.com"
            />
          </label>

          <label className="mt-3 block text-xs text-slate-400">
            Password
            <input
              type="password"
              autoComplete="current-password"
              required
              className="mt-1 w-full rounded border border-slate-700 bg-slate-950 px-2 py-1.5 text-sm text-slate-100 focus:border-emerald-600 focus:outline-none"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </label>

          {err && (
            <p className="mt-3 rounded bg-red-950 px-2 py-1.5 text-xs text-red-300">
              {err}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="mt-4 w-full rounded bg-emerald-600 py-2 text-sm font-semibold text-white transition-colors hover:bg-emerald-500 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {loading ? "Signing in…" : "Sign in"}
          </button>
        </form>
      </div>
    </div>
  );
}
