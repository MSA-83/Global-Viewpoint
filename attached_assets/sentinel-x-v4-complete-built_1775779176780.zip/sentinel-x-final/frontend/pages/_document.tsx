import Document, { Html, Head, Main, NextScript } from "next/document";

class SentinelXDocument extends Document {
  render() {
    return (
      <Html lang="en">
        <Head>
          <meta name="theme-color" content="#020617" />
          <link rel="manifest" href="/manifest.json" />
          <link rel="icon" href="/favicon.ico" />
          <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        </Head>
        <body className="bg-slate-950 text-slate-100">
          <Main />
          <NextScript />
        </body>
      </Html>
    );
  }
}

export default SentinelXDocument;
