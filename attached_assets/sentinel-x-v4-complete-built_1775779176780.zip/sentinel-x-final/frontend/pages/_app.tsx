// frontend/pages/_app.tsx
//
// Pages Router application wrapper.
//
// BUG FIXED: The original _app.tsx rendered `<Component {...pageProps} />`
// with no providers. Every Pages Router page (login.tsx, intel.tsx) calls
// `useAuth()`, which throws "useAuth must be called within an <AuthProvider>"
// when no provider is in the tree. The login page would crash on render,
// making it impossible to authenticate at all through the Pages Router.
//
// The App Router layout.tsx already wraps its tree in ClientProviders
// (which includes AuthProvider). Pages Router pages use _app.tsx instead,
// so they need their own wrapper here.
//
// Note on mixed routing: having both pages/ and src/app/ is a deliberate
// transitional state. The Pages Router handles login and intel until those
// pages are migrated to the App Router. Both share the same AuthProvider
// context because AuthProvider reads from a module-level React context, not
// from URL routing.

import type { AppProps } from "next/app";
import "../src/styles/globals.css";
import { AuthProvider } from "../src/hooks/useAuth";

export default function SentinelXApp({ Component, pageProps }: AppProps) {
  return (
    <AuthProvider>
      <Component {...pageProps} />
    </AuthProvider>
  );
}
