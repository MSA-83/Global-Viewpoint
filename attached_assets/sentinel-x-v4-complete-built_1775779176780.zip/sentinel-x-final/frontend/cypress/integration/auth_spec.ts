describe("Authentication", () => {
  it("redirects unauthenticated user from dashboard to login", () => {
    cy.clearLocalStorage("sx_access_token");
    cy.visit("/");
    cy.contains(/login/i);
  });
});
