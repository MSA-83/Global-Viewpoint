/// <reference types="cypress" />

// eslint-disable-next-line @typescript-eslint/no-unused-vars
module.exports = (on: Cypress.PluginEvents, config: Cypress.PluginConfigOptions) => {
  // Customize config if needed
  return config;
};
