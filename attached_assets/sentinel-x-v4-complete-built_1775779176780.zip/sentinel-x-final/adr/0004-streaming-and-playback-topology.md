# ADR 0004 – Streaming and Playback Topology

## Context

The platform must support both real-time event streaming to the operator UI and historical playback over time windows. Producers write to Kafka for durability and fan-out, while WebSockets are used for interactive updates in the browser.

## Decision

- **Ingestion**: Events are serialized as Avro and produced to Kafka on topic `sentinel.events`.
- **Fan-out**: A small internal service or process consumes from Kafka and publishes normalized JSON events to Redis Pub/Sub channel `events`.
- **Delivery to UI**: FastAPI exposes `/api/v1/streams/ws`, which subscribes to Redis and pushes messages over WebSockets to authenticated clients.
- **Playback**: Historical queries hit PostgreSQL/PostGIS via `/api/v1/events/` constrained by time and tenant.

## Rationale

- **Decoupling**: Kafka is used for durable ingestion and downstream analytics, while Redis optimizes low-latency fan-out to many WebSocket clients.
- **Backpressure & resilience**: Kafka buffers bursts; Redis keeps the hot working set; the UI can fall back to REST playback when live streaming is disrupted.
- **Simplicity at the edge**: WebSocket handlers remain thin and stateless.

## Consequences

- Requires operating Kafka and Redis in production with appropriate monitoring.
- The Kafka→Redis bridge must be resilient and observable, with clear failure semantics.
- Event schema evolution must be coordinated between Kafka Avro schema and JSON payloads.

*Status*: Accepted – implemented across `services/kafka_producer.py`, `services/redis_pubsub.py`, `routers/streams.py`, and `routers/events.py`.
