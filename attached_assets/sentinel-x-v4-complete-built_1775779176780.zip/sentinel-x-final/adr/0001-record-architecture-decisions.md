# ADR 0001 – Record architecture decisions

## Context

Sentinel-X is a complex, multi-service system. Architecture decisions need to be captured to improve long-term maintainability and onboarding.

## Decision

Use Architecture Decision Records (ADRs) stored under `adr/` in the main repository. Each ADR is a small Markdown file with an incrementing numeric prefix.

## Status

Accepted.

## Consequences

- Developers have a canonical place to understand why significant decisions were made.
- Changes to core architecture should be accompanied by new or updated ADRs.
