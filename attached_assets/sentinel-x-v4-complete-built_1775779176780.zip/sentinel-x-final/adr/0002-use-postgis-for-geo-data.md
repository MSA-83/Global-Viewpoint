# ADR 0002 – Use PostGIS for geospatial data

## Context

Sensor locations, event footprints, and operational areas of interest are inherently geospatial. Efficient queries (within radius, polygon intersection, etc.) are essential for situational awareness.

## Decision

Use PostgreSQL with the PostGIS extension as the primary geospatial data store. Application entities that require spatial queries will use geometry/geography columns backed by PostGIS.

## Status

Accepted.

## Consequences

- Database migrations and deployment scripts must ensure PostGIS is enabled.
- Geospatial queries move to the database layer, keeping application logic simpler.
- Developers must be familiar with basic PostGIS concepts and functions.
