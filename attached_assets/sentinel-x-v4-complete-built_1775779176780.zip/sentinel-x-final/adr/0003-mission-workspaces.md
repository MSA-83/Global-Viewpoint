# ADR 0003 – Introduce Mission Workspaces

## Context

Operators and analysts need to configure and persist domain-specific views over the global operational picture: filters, map layers, time windows, and camera presets. These views must be shareable and restorable to support collaborative decision-making in a C2 environment.

## Decision

Introduce a `MissionWorkspace` aggregate, persisted as a JSON `config` blob with metadata (name, description, owner). The configuration describes:

- Active layers (sensors, intel overlays, tracks)
- Filter predicates (domain, severity, AOI bounding boxes)
- Default time window and camera pose

Workspaces are owned by a user but can be extended later with sharing/ACLs.

## Rationale

- **Flexibility**: JSON config allows rapid evolution of the UI and filtering without schema churn.
- **Operator-centric**: Aligns with how real C2 systems support “saved views” and “mission boards”.
- **Minimal schema**: Only essential metadata is normalized; everything else is config.

## Consequences

- Config validation must be enforced in the application layer to avoid invalid workspaces.
- Future ACL/sharing requirements may require additional relational tables.
- Versioning of the config schema may be needed as the UI evolves.

*Status*: Accepted – implemented in `backend/app/models/workspace.py` and `backend/app/routers/workspaces.py`.
