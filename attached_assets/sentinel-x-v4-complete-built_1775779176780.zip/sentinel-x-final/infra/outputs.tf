output "gke_cluster_name" {
  value       = module.gke.cluster_name
  description = "GKE cluster name"
}

output "gke_endpoint" {
  value       = module.gke.endpoint
  description = "GKE endpoint"
}

output "gke_ca_certificate" {
  value       = module.gke.ca_certificate
  description = "Base64-encoded cluster CA certificate"
}
