# infra/modules/gke/variables.tf
#
# Variable declarations for the sentinel-x GKE module.
#
# This file was completely absent from the repository. The module's main.tf
# references four variables (node_count, max_node_count, node_machine_type,
# node_disk_size_gb) that had no corresponding declarations — meaning
# `terraform plan` would immediately fail with:
#   Error: Reference to undeclared input variable
#
# All four are declared here with sensible defaults for a medium-scale
# production deployment. Override them in infra/variables.tf or via
# -var flags on the terraform command line.

variable "project_id" {
  type        = string
  description = "GCP project ID where the GKE cluster will be created."
}

variable "region" {
  type        = string
  description = "GCP region for the GKE cluster (e.g. europe-west4)."
}

variable "cluster_name" {
  type        = string
  description = "Display name for the GKE cluster resource."
}

variable "network" {
  type        = string
  description = "VPC network name or self-link in which to create the cluster."
}

variable "subnetwork" {
  type        = string
  description = "VPC subnetwork name or self-link for the cluster nodes."
}

variable "pods_range_name" {
  type        = string
  description = "Name of the secondary IP range in the subnetwork for pod IPs."
}

variable "services_range_name" {
  type        = string
  description = "Name of the secondary IP range in the subnetwork for service IPs."
}

variable "node_count" {
  type        = number
  description = "Initial (and minimum) number of nodes per zone in the node pool."
  default     = 2
}

variable "max_node_count" {
  type        = number
  description = "Maximum number of nodes per zone for the cluster autoscaler."
  default     = 6
}

variable "node_machine_type" {
  type        = string
  description = <<-EOT
    GCE machine type for worker nodes. e2-standard-4 (4 vCPU, 16 GB) is a
    reasonable default — enough headroom for the FastAPI backend (Kafka
    producer, Redis connections, external API calls) and the Next.js frontend
    running concurrently on each node.
  EOT
  default     = "e2-standard-4"
}

variable "node_disk_size_gb" {
  type        = number
  description = <<-EOT
    Boot disk size in GiB for each node. 50 GB is sufficient for the OS,
    kubelet, container runtime, and a rolling cache of pulled images.
    Increase to 100+ if you plan to run large model workloads on the nodes.
  EOT
  default     = 50
}
