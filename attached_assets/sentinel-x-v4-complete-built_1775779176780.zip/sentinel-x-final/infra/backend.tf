terraform {
  backend "gcs" {
    bucket = "sentinel-x-tf-state"
    prefix = "env/default"
  }

  required_version = ">= 1.6.0"

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}
