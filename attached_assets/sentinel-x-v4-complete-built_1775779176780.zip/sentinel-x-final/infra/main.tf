provider "google" {
  project = var.project_id
  region  = var.region
}

module "gke" {
  source       = "./modules/gke"
  project_id   = var.project_id
  region       = var.region
  cluster_name = var.cluster_name

  network              = var.network
  subnetwork           = var.subnetwork
  pods_range_name      = var.pods_range_name
  services_range_name  = var.services_range_name
}

output "cluster_name" {
  value = module.gke.cluster_name
}

output "cluster_endpoint" {
  value = module.gke.endpoint
}

output "cluster_ca_certificate" {
  value = module.gke.ca_certificate
}
