# Sentinel‑X

> **Global Situational Awareness Platform** – a production‑grade, open‑source alternative to commercial command‑and‑control solutions such as *Beholder.me* or *Palantir*.

[![CI Status](https://github.com/MSA-83/SENTINEL-X/actions/workflows/ci.yml/badge.svg)](https://github.com/MSA-83/SENTINEL-X/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Table of Contents

- [Features](#features)
- [Architecture Overview](#architecture-overview)
- [Quick Start (Docker Compose)](#quick-start-docker-compose)
- [Development Workflow](#development-workflow)
- [Deployment (GKE + Helm)](#deployment-gke--helm)
- [Testing](#testing)
- [Security & Secrets Management](#security--secrets-management)
- [Contributing](#contributing)
- [License](#license)

## Features

- **Real‑time geospatial streams** via WebSocket + Redis Pub/Sub
- **Secure authentication** – Argon2 password hashing, JWT access + refresh, Google OAuth 2.0
- **Scalable ingestion** – Apache Kafka producer + Avro schema
- **Rich map UI** – Deck.gl clustering, heat‑maps, Mapbox basemap
- **Observability** – OpenTelemetry traces, Prometheus metrics, Grafana dashboards
- **Infrastructure‑as‑Code** – Helm chart for Kubernetes, Terraform for GKE provisioning
- **Extensible external‑data adapters** (NASA, OpenWeather, Space‑Track, Global Fishing Watch, etc.)

## Architecture Overview

See the **docs/architecture.md** page or the Mermaid diagram in the MkDocs site for a visual representation.

## Quick Start (Docker Compose)

```bash
git clone https://github.com/MSA-83/SENTINEL-X.git
cd SENTINEL-X

# 1️⃣  Create a .env file from the template
cp .env.example .env
# → Fill in all secrets (see the .env section below)

# 2️⃣  Spin up the full stack
docker compose up -d

# 3️⃣  Apply DB migrations
docker exec sentinel_backend alembic upgrade head

# 4️⃣  Access the services
# • API docs: http://localhost:8000/api/v1/docs
# • Frontend: http://localhost:3000
# • Grafana (if you add it): http://localhost:3001

# Sentinel-X

Sentinel-X is a multi-domain situational awareness platform that fuses sensor data, external intelligence feeds, and operator workflows into a single pane of glass.

- **Backend**: FastAPI, PostgreSQL/PostGIS, Redis, Kafka
- **Frontend**: Next.js (React, TypeScript)
- **Infra**: Docker, Kubernetes (Helm), Terraform (GKE)

## Repository layout

- `backend/` – FastAPI application, models, routers, external integrations
- `frontend/` – Next.js dashboard UI (globe, sensor panel, intel, workspaces)
- `infra/` – Terraform configuration for GKE cluster
- `helm/` – Helm chart for Kubernetes deployment
- `docs/` – MkDocs documentation (overview, API, security, architecture)
- `adr/` – Architecture Decision Records
- `scripts/` – Helper scripts (local dev, ERD generation)

## Local development (docker-compose)

```bash
docker-compose up --build
```

API docs:

- http://localhost:8000/api/v1/docs

Frontend UI:

- http://localhost:3000

## Local development (manual)

Backend:

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

export POSTGRES_DSN=postgresql+asyncpg://sentinel:sentinel@localhost:5432/sentinel
export REDIS_URL=redis://localhost:6379/0
export SECRET_KEY=change-me-long-random

uvicorn app.main:app --reload --port 8000
```

Frontend:

```bash
cd frontend
npm install
npm run dev
```

## Testing

Backend:

```bash
cd backend
pytest -q
```

Frontend:

```bash
cd frontend
npm test
```

## Deployment

- Use `helm/sentinel-x` for Kubernetes deployment.
- Use `infra/` Terraform module to create a GKE cluster.
- CI is configured via `.github/workflows/ci.yml`.

Refer to `docs/` and `adr/` for deeper architectural details.

