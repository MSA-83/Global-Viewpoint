# backend/app/schemas/event.py
"""
Event Pydantic schemas for Sentinel-X.

Two significant fixes from the original version:

1. occurred_at was typed as `str`
   The model column is `DateTime(timezone=True)`, so SQLAlchemy returns a
   timezone-aware Python `datetime` object. Pydantic v2 serialises `datetime`
   to ISO 8601 by default, which is exactly what the frontend expects.
   Typing it as `str` would have caused a validation error any time Pydantic
   tried to coerce the datetime to a string field (Pydantic v2 is strict about
   this by default with from_attributes=True).

2. geometry was typed as `Optional[Dict[str, Any]]`
   Same problem as sensors: the database column is a GeoAlchemy2 Geometry
   column that returns a WKBElement. For events, however, we return the full
   GeoJSON object (not just lat/lon floats) because event geometries can be
   Points, Polygons, LineStrings, or MultiPolygon — a wildfire event covers a
   polygon, a maritime track is a LineString, etc. The field_validator below
   converts WKBElement to a GeoJSON-compatible dict using GeoAlchemy2's
   `to_shape()` and Shapely's `mapping()` function.

EventCreate is also added here because create_event in crud/event.py depends
on it — it was previously absent, leaving that CRUD function without a type for
its input parameter.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models.event import EventSeverity, EventType


class EventCreate(BaseModel):
    """Input schema for programmatically creating an event."""
    sensor_id: Optional[str] = None
    event_type: str
    severity: str = EventSeverity.INFO.value
    title: str = Field(max_length=256)
    description: Optional[str] = Field(default=None, max_length=2048)
    geometry: Optional[Dict[str, Any]] = None   # GeoJSON geometry object
    payload: Optional[Dict[str, Any]] = None
    correlation_id: Optional[str] = None
    parent_event_id: Optional[str] = None
    occurred_at: datetime
    classification: str = "UNCLASSIFIED"


class EventRead(BaseModel):
    """
    Response schema for event list and detail endpoints.

    The geometry field_validator handles the WKBElement→GeoJSON conversion.
    All other fields map directly from SQLAlchemy column types to their
    natural Python equivalents.
    """
    model_config = ConfigDict(from_attributes=True)

    id: str
    sensor_id: Optional[str] = None
    event_type: EventType
    severity: EventSeverity
    title: str
    description: Optional[str] = None
    geometry: Optional[Dict[str, Any]] = None
    payload: Optional[Dict[str, Any]] = None
    correlation_id: Optional[str] = None
    parent_event_id: Optional[str] = None
    occurred_at: datetime              # ← was str; SQLAlchemy returns datetime
    classification: str
    tenant_id: Optional[str] = None

    @field_validator("geometry", mode="before")
    @classmethod
    def _convert_geometry(cls, v: Any) -> Optional[Dict[str, Any]]:
        """
        Convert a GeoAlchemy2 WKBElement to a GeoJSON dict.

        The validator receives the raw field value before Pydantic's type
        coercion. When the model is built from an ORM row, the geometry column
        value is a WKBElement (raw bytes). When built from a plain dict
        (e.g. in tests), it's already a dict or None — those pass through
        unchanged.

        We use `to_shape()` to convert WKBElement → Shapely geometry, then
        Shapely's `mapping()` function to produce a GeoJSON-compatible dict.
        The `__geo_interface__` protocol guarantees this dict follows the
        GeoJSON spec: {"type": "Point", "coordinates": [lon, lat]}.
        """
        if v is None:
            return None
        if isinstance(v, dict):
            return v
        # Attempt WKBElement conversion
        try:
            from geoalchemy2.shape import to_shape
            from shapely.geometry import mapping
            return dict(mapping(to_shape(v)))
        except Exception:
            return None
