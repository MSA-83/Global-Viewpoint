# backend/app/schemas/user.py
"""
User Pydantic schemas for Sentinel-X.

Migrated from Pydantic v1 inner `class Config` to Pydantic v2 `ConfigDict`.
The inner class pattern still works in Pydantic v2 (it's silently converted
internally) but generates deprecation warnings and is unsupported in v3+.

UserRead.id is typed as `str` even though the database PK is UUID because:
  - JSON has no native UUID type, so it must be a string in responses anyway.
  - Keeping it as `str` avoids Pydantic needing to coerce UUID → str on every
    serialisation, and means the frontend receives a consistent plain string.
"""
from __future__ import annotations

import uuid
from typing import Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.models.user import UserRole


class UserBase(BaseModel):
    email: EmailStr
    display_name: Optional[str] = Field(default=None, max_length=128)


class UserCreate(UserBase):
    """Schema for user registration. Password must be ≥ 12 characters."""
    password: str = Field(min_length=12, max_length=128)
    role: UserRole = UserRole.OPERATOR


class UserUpdate(BaseModel):
    """Partial update — only provided fields are written."""
    display_name: Optional[str] = Field(default=None, max_length=128)
    role: Optional[UserRole] = None
    is_active: Optional[bool] = None


class UserRead(UserBase):
    """
    Response schema for user profile endpoints.

    `id` is serialised as a plain string UUID. `tenant_id` is included so
    the frontend can scope API requests to the correct tenant without a
    separate lookup.
    """
    model_config = ConfigDict(from_attributes=True)

    id: str
    role: UserRole
    is_active: bool
    tenant_id: Optional[str] = None
    classification: str = "UNCLASSIFIED"


class Token(BaseModel):
    """Access token response from the login endpoint."""
    access_token: str
    token_type: str = "bearer"
