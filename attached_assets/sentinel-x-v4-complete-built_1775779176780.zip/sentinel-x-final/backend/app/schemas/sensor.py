# backend/app/schemas/sensor.py
"""
Sensor Pydantic schemas for Sentinel-X.

The core challenge here is the `location` column, which is a GeoAlchemy2
`Geometry(Point, srid=4326)` column. When SQLAlchemy loads a row, this column
contains a `WKBElement` — raw Well-Known Binary bytes that represent a PostGIS
geometry object. Pydantic has no serialiser for WKBElement, so if we tried to
pass it directly, every `SensorRead` response would raise a
`PydanticSerializationError`.

The solution is a Pydantic v2 `model_validator(mode='before')` that runs
before the model's field validators. When the input is an ORM instance, it
inspects the `location` WKBElement, extracts the longitude and latitude using
GeoAlchemy2's `to_shape()` helper (which returns a Shapely geometry), and injects
those as plain `longitude` and `latitude` float fields. The raw WKBElement
is never exposed in the output.

Why extract to lat/lon instead of returning a GeoJSON object?
-------------------------------------------------------------
For a sensor — a fixed point — discrete `latitude` and `longitude` fields are
what the frontend actually needs to position the marker on the map. Returning
a GeoJSON `{"type": "Point", "coordinates": [lon, lat]}` object is marginally
more correct, but adds parsing overhead on the client for no practical benefit
compared to plain floats. Events, which can have polygon or line geometries,
return full GeoJSON in `EventRead` — the distinction is intentional.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app.models.sensor import SensorDomain, SensorStatus


class SensorBase(BaseModel):
    name: str = Field(max_length=128)
    domain: SensorDomain
    status: SensorStatus = SensorStatus.OPERATIONAL
    platform: Optional[str] = Field(default=None, max_length=64)
    capabilities: Optional[Dict[str, Any]] = None
    description: Optional[str] = Field(default=None, max_length=512)
    external_id: Optional[str] = Field(default=None, max_length=128)


class SensorCreate(SensorBase):
    """
    Input schema for creating a sensor.

    Latitude and longitude are received as plain floats and converted to a
    PostGIS Point geometry in the CRUD layer. They are named fields here
    rather than a GeoJSON object for simplicity — creating a sensor from the
    UI is just "fill in a form", not "draw a shape on a map".
    """
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)


class SensorUpdate(BaseModel):
    """Partial update — only provided fields are written."""
    name: Optional[str] = Field(default=None, max_length=128)
    status: Optional[SensorStatus] = None
    platform: Optional[str] = Field(default=None, max_length=64)
    capabilities: Optional[Dict[str, Any]] = None
    description: Optional[str] = Field(default=None, max_length=512)
    latitude: Optional[float] = Field(default=None, ge=-90, le=90)
    longitude: Optional[float] = Field(default=None, ge=-180, le=180)


class SensorRead(SensorBase):
    """
    Response schema for sensor endpoints.

    The `location` WKBElement from GeoAlchemy2 is converted to plain
    `latitude` and `longitude` floats by the model_validator before Pydantic
    validates the fields. The raw WKBElement is excluded from the output.
    """
    model_config = ConfigDict(from_attributes=True)

    id: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    classification: str = "UNCLASSIFIED"
    tenant_id: Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def _extract_location(cls, data: Any) -> Any:
        """
        Convert WKBElement → (latitude, longitude) floats before validation.

        This validator runs before any field validators, so it receives the
        raw ORM instance. We detect the presence of a GeoAlchemy2 geometry
        by checking for the `location` attribute and trying to call `to_shape`.
        If conversion fails for any reason, we silently leave the fields as None
        rather than crashing the response for a geometry we can't decode.
        """
        if not hasattr(data, "location"):
            return data                      # dict input, nothing to convert

        location = getattr(data, "location", None)
        if location is None:
            return data

        # Build a plain dict from the ORM instance's column values.
        # We can't mutate the ORM object directly, so we create a new dict
        # that Pydantic can use as its input.
        try:
            row: Dict[str, Any] = {
                col.key: getattr(data, col.key)
                for col in data.__table__.columns    # type: ignore[attr-defined]
            }
        except AttributeError:
            # Fallback for non-SQLAlchemy objects (e.g. test fixtures)
            row = {k: v for k, v in vars(data).items() if not k.startswith("_")}

        # Convert the geometry to (lon, lat) floats.
        try:
            from geoalchemy2.shape import to_shape
            point = to_shape(location)
            row["longitude"] = point.x   # Shapely Point.x is longitude (GeoJSON order)
            row["latitude"] = point.y
        except Exception:
            row["longitude"] = None
            row["latitude"] = None

        # Remove the raw WKBElement — Pydantic should never see it.
        row.pop("location", None)
        return row
