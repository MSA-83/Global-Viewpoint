# backend/app/schemas/workspace.py
"""
MissionWorkspace Pydantic schemas for Sentinel-X.

Two changes from the original:

1. WorkspaceCreate.config now has a default of `{}`.
   The original required callers to explicitly send `"config": {}` in every
   create request. This makes the API unnecessarily rigid — most creation
   requests happen from the frontend "New Workspace" dialog, where the user
   just enters a name and presses save. The config starts empty and is
   populated later through PUT updates. With the default in place, the minimal
   valid create payload is just `{"name": "My Workspace"}`.

2. WorkspaceUpdate is added.
   The update_workspace CRUD function expects a WorkspaceUpdate schema, but the
   original schemas file only defined WorkspaceCreate. Without WorkspaceUpdate,
   the CRUD function had no type annotation for its `workspace_in` parameter,
   which would cause mypy to complain and makes the partial-update semantics
   (`exclude_unset=True`) unenforceable.

3. All schemas migrated from Pydantic v1 `class Config` to v2 `ConfigDict`.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, Field


class WorkspaceBase(BaseModel):
    name: str = Field(max_length=128)
    description: Optional[str] = Field(default=None, max_length=1024)


class WorkspaceCreate(WorkspaceBase):
    """
    Input schema for workspace creation.

    `config` defaults to an empty dict so callers can omit it when creating a
    brand-new workspace that hasn't been configured yet. The config blob grows
    over time as the operator saves layer visibility, filter presets, and map
    viewport state.
    """
    config: Dict[str, Any] = Field(default_factory=dict)


class WorkspaceUpdate(BaseModel):
    """
    Partial update schema. Only fields explicitly set in the request body are written.

    This is intentionally a flat model — callers provide the complete new config
    blob rather than a deep-merge patch, which avoids the ambiguity of "did the
    caller intend to delete a key or just not mention it?"
    """
    name: Optional[str] = Field(default=None, max_length=128)
    description: Optional[str] = Field(default=None, max_length=1024)
    config: Optional[Dict[str, Any]] = None


class WorkspaceRead(WorkspaceBase):
    model_config = ConfigDict(from_attributes=True)

    id: str
    owner_id: str
    config: Dict[str, Any]
