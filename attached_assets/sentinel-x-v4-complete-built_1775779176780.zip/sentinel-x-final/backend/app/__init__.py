# backend/app/__init__.py
"""Sentinel-X core application package."""

__version__ = "1.0.0"
__all__ = ["models", "schemas", "crud", "routers", "deps", "services", "core", "db", "external"]
