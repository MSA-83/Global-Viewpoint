# backend/app/core/config.py
from functools import lru_cache
from typing import List, Optional

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    app_name: str = "Sentinel-X"
    environment: str = "development"
    debug: bool = False

    secret_key: str
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    refresh_token_expire_days: int = 7

    postgres_dsn: str
    redis_url: str
    kafka_bootstrap_servers: str = "localhost:9092"
    kafka_topic_events: str = "sentinel.events"

    cors_origins: List[str] = []

    nasa_api_key: Optional[str] = None
    n2yo_license_key: Optional[str] = None
    openweather_api_key: Optional[str] = None
    space_track_username: Optional[str] = None
    space_track_password: Optional[str] = None
    gfw_api_token: Optional[str] = None
    rapidapi_key: Optional[str] = None
    avwx_api_key: Optional[str] = None
    copernicus_user_id: Optional[str] = None
    copernicus_account_id: Optional[str] = None
    oauth_client_id: Optional[str] = None
    oauth_client_secret: Optional[str] = None
    cesium_ion_token: Optional[str] = None
    planet_account_id: Optional[str] = None
    planet_user_id: Optional[str] = None
    planet_client_id: Optional[str] = None
    planet_client_secret: Optional[str] = None
    zerossl_api_key: Optional[str] = None
    abusech_auth_key: Optional[str] = None
    newsapi_key: Optional[str] = None
    shodan_api_key: Optional[str] = None
    aisstream_token: Optional[str] = None

    otlp_endpoint: Optional[str] = None
    prometheus_enabled: bool = True

    @field_validator("secret_key")
    @classmethod
    def validate_secret_key(cls, value: str) -> str:
        if len(value.strip()) < 32:
            raise ValueError("SECRET_KEY must be at least 32 characters long")
        return value

    @field_validator("postgres_dsn")
    @classmethod
    def validate_postgres_dsn(cls, value: str) -> str:
        if "postgresql+" not in value:
            raise ValueError("POSTGRES_DSN must use an async PostgreSQL driver, e.g. postgresql+asyncpg://...")
        return value

    @field_validator("cors_origins", mode="before")
    @classmethod
    def parse_cors_origins(cls, value):
        if value is None:
            return []
        if isinstance(value, str):
            return [item.strip() for item in value.split(",") if item.strip()]
        if isinstance(value, list):
            return value
        raise ValueError("CORS_ORIGINS must be a comma-separated string or a list of strings")


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
