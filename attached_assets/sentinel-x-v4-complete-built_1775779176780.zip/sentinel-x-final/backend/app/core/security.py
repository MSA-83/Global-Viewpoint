# backend/app/core/security.py
"""
Authentication and cryptographic utilities for Sentinel-X.

Consolidates the previously split security.py (v1) and security_v2.py into a single
authoritative module. Key decisions:
  - Argon2id for password hashing (OWASP 2024 recommendation over bcrypt)
  - PyJWT (not python-jose) for JWT encoding — fewer CVEs, active maintenance
  - Pydantic TokenPayload model for validated JWT claims
  - All settings accessed via lowercase attributes (pydantic-settings normalises case)
"""
from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone
from typing import Union

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel, ValidationError

from app.core.config import settings

# ---------------------------------------------------------------------------
# Password hashing — Argon2id
# ---------------------------------------------------------------------------
_ph = PasswordHasher(
    time_cost=2,
    memory_cost=65_536,  # 64 MiB
    parallelism=4,
    hash_len=32,
    salt_len=16,
)


def hash_password(password: str) -> str:
    """Hash a plain-text password using Argon2id."""
    return _ph.hash(password)


def verify_password(hashed: str, plain: str) -> bool:
    """
    Return True if *plain* matches *hashed*.

    We catch VerifyMismatchError explicitly so the caller never has to handle
    the argon2 exception hierarchy — it gets a clean boolean.
    """
    try:
        return _ph.verify(hashed, plain)
    except VerifyMismatchError:
        return False
    except Exception:
        # Catches VerificationError (malformed hash) and similar edge-cases.
        return False


# ---------------------------------------------------------------------------
# JWT utilities
# ---------------------------------------------------------------------------

class TokenPayload(BaseModel):
    """Validated representation of a Sentinel-X JWT payload."""
    sub: Union[int, str]  # user primary key
    exp: datetime
    iat: datetime
    typ: str              # "access" or "refresh"


def _create_token(
    subject: Union[int, str],
    expires_delta: timedelta,
    token_type: str,
) -> str:
    now = datetime.now(tz=timezone.utc)
    payload = {
        "sub": str(subject),
        "iat": now,
        "exp": now + expires_delta,
        "typ": token_type,
    }
    # settings fields are lowercase — pydantic-settings normalises them.
    return jwt.encode(payload, settings.secret_key, algorithm=settings.jwt_algorithm)


def create_access_token(subject: Union[int, str]) -> str:
    """Return a short-lived JWT access token for the given user identifier."""
    return _create_token(
        subject,
        timedelta(minutes=settings.access_token_expire_minutes),
        token_type="access",
    )


def create_refresh_token(subject: Union[int, str]) -> str:
    """Return a long-lived JWT refresh token."""
    return _create_token(
        subject,
        timedelta(days=settings.refresh_token_expire_days),
        token_type="refresh",
    )


def decode_token(token: str) -> TokenPayload:
    """
    Decode and validate a JWT, returning a typed TokenPayload.

    Raises HTTP 401 for any invalid or expired token so callers can
    propagate the error directly to the client.
    """
    try:
        payload = jwt.decode(
            token,
            settings.secret_key,
            algorithms=[settings.jwt_algorithm],
            options={"require": ["exp", "iat", "sub", "typ"]},
        )
        return TokenPayload(**payload)
    except (jwt.ExpiredSignatureError, jwt.InvalidTokenError, ValidationError) as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired credentials",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc


# ---------------------------------------------------------------------------
# FastAPI dependency
# ---------------------------------------------------------------------------
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


async def get_current_user(token: str = Depends(oauth2_scheme)) -> int:
    """
    FastAPI dependency that validates the bearer token and returns the user ID
    as an integer. Downstream dependencies can use this ID to fetch the full
    user object from the database when needed.
    """
    payload = decode_token(token)
    if payload.typ != "access":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token type mismatch — expected 'access'",
        )
    return int(payload.sub)


# ---------------------------------------------------------------------------
# CSRF helper (used by form-based flows)
# ---------------------------------------------------------------------------

def generate_csrf_token() -> str:
    """Generate a 32-byte URL-safe CSRF token."""
    return secrets.token_urlsafe(32)
