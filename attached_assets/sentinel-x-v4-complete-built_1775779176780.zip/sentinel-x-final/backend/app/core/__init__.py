# backend/app/core/__init__.py
"""
Core application utilities and configuration.

BUG FIXED: The previous version imported `get_password_hash` and
`decode_access_token`, neither of which exists in security.py.
The correct names are `hash_password` and `decode_token`.
Importing non-existent names raises ImportError at startup, before the
server binds to its port — so this was a hard crash on every cold start.
"""

from .config import settings
from .logging import configure_logging, logger
from .security import (
    hash_password,       # was: get_password_hash (does not exist)
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token,        # was: decode_access_token (does not exist)
    get_current_user,
)

__all__ = [
    "settings",
    "configure_logging",
    "logger",
    "hash_password",
    "verify_password",
    "create_access_token",
    "create_refresh_token",
    "decode_token",
    "get_current_user",
]
