# backend/app/main.py
"""
Sentinel-X FastAPI application entry point.

Lifespan context
----------------
FastAPI's lifespan context (introduced in Starlette 0.20) replaces the older
@app.on_event("startup") / @app.on_event("shutdown") decorators.  It gives us
a single, structured place to:

  1. Initialise shared resources (Redis pool, Kafka producer) before the app
     starts accepting requests.  If any initialisation fails, the application
     fails fast with a clear error message rather than crashing on the first
     request.

  2. Tear down those resources cleanly during shutdown, ensuring in-flight Kafka
     messages are flushed and open Redis connections are released before the
     process exits.

OpenTelemetry is wired up inside the lifespan rather than at module level so
that import failures don't prevent the application from starting — the
`OTLP_ENDPOINT` setting is optional, and many deployments (local dev, CI) don't
run a collector.

Middleware
----------
We add a request ID middleware inline here rather than as a separate module to
keep the application wiring visible in one place.  Every request gets a unique
X-Request-ID header, which is injected into all log lines produced during that
request via structlog's context-local binding.
"""
from __future__ import annotations

import uuid
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.core.logging import configure_logging, logger
from app.routers import auth, events, health, intel, sensors, streams, workspaces
from app.services import kafka_producer, redis_pubsub

configure_logging()


# ---------------------------------------------------------------------------
# OpenTelemetry — optional, fail-soft
# ---------------------------------------------------------------------------
def _setup_telemetry() -> None:
    """Wire up OTLP tracing if an endpoint is configured. Never raises."""
    if not settings.otlp_endpoint:
        return
    try:
        from opentelemetry import trace
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor

        provider = TracerProvider()
        provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=settings.otlp_endpoint)))
        trace.set_tracer_provider(provider)
        logger.info("OpenTelemetry tracing initialised", endpoint=settings.otlp_endpoint)
    except Exception as exc:
        logger.warning("OpenTelemetry setup failed — continuing without tracing", error=str(exc))


# ---------------------------------------------------------------------------
# Application lifespan
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Manage the lifecycle of shared application resources.

    Everything before `yield` runs on startup; everything after runs on shutdown.
    Errors in startup propagate and prevent the app from serving traffic — this is
    intentional.  A misconfigured Redis URL or Kafka broker should be a hard failure,
    not a silent degradation that surfaces as cryptic errors at runtime.
    """
    logger.info("Starting Sentinel-X", version="1.0.0", environment=settings.environment)

    _setup_telemetry()

    # Initialise the Redis connection pool. Fails fast if Redis is unreachable.
    await redis_pubsub.startup()

    # Initialise the Kafka producer. Deferred connection with health check.
    await kafka_producer.startup()

    logger.info("Sentinel-X ready to serve requests")
    try:
        yield
    finally:
        logger.info("Sentinel-X shutting down — flushing resources")
        await kafka_producer.shutdown()
        await redis_pubsub.shutdown()
        logger.info("Sentinel-X shutdown complete")


# ---------------------------------------------------------------------------
# Application factory
# ---------------------------------------------------------------------------
def create_app() -> FastAPI:
    """
    Create and configure the FastAPI application.

    Exposed as a factory function so that tests can call create_app() and
    inject dependency overrides before starting the test client.
    """
    application = FastAPI(
        title="Sentinel-X API",
        description=(
            "Multi-domain situational awareness platform — real-time geospatial "
            "intelligence aggregation across aviation, maritime, orbital, seismic, "
            "weather, conflict, and cyber domains."
        ),
        version="1.0.0",
        docs_url="/api/v1/docs",
        redoc_url="/api/v1/redoc",
        openapi_url="/api/v1/openapi.json",
        lifespan=lifespan,
    )

    # CORS — restrict to known frontend origins in production.
    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["*"],
        expose_headers=["X-Request-ID"],
    )

    # Request ID middleware — adds a unique ID to every request for log correlation.
    @application.middleware("http")
    async def add_request_id(request: Request, call_next):
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        with logger.contextualize(request_id=request_id):
            response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response

    # Routers — health/ready have no prefix so Kubernetes can probe them at /health.
    application.include_router(health.router)
    application.include_router(auth.router, prefix="/api/v1")
    application.include_router(sensors.router, prefix="/api/v1")
    application.include_router(streams.router)  # prefix defined in the router itself
    application.include_router(events.router, prefix="/api/v1")
    application.include_router(intel.router, prefix="/api/v1")
    application.include_router(workspaces.router, prefix="/api/v1")

    return application


app = create_app()
