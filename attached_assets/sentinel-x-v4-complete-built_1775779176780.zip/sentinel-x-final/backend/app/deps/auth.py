# backend/app/deps/auth.py
"""
FastAPI dependency factories for authentication and role-based access control.

The key pattern here is the "dependency factory" — a regular function that
*returns* an async dependency function.  This lets callers write:

    user = Depends(require_role(UserRole.ANALYST))

FastAPI calls the returned inner function (_check) at request time, injecting
its own Depends (get_current_user_obj) automatically.  The outer call happens
at import / route-registration time and simply captures `min_role` in a closure.
"""
from __future__ import annotations

from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_user
from app.deps.db import get_db
from app.models.user import User, UserRole
from app.crud.user import get_user_by_id


# ---------------------------------------------------------------------------
# Full user object dependency
# ---------------------------------------------------------------------------

async def get_current_user_obj(
    user_id: int = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
) -> User:
    """
    Resolve the numeric user_id from the JWT into a full SQLAlchemy User row.

    Most endpoints only need the user ID (returned directly by get_current_user),
    but those that need the user's role, tenant, or display name use this
    dependency to hydrate the full object in a single DB call per request.
    """
    user = await get_user_by_id(db, user_id=user_id)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User account not found",
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive",
        )
    return user


# ---------------------------------------------------------------------------
# Role hierarchy
# ---------------------------------------------------------------------------

_ROLE_ORDER: dict[UserRole, int] = {
    UserRole.OPERATOR: 1,
    UserRole.ANALYST: 2,
    UserRole.COMMANDER: 3,
    UserRole.ADMIN: 4,
}


def require_role(min_role: UserRole):
    """
    Dependency factory — returns a FastAPI dependency that enforces a minimum
    role level.

    Usage in a router:

        @router.get("/sensitive")
        async def sensitive_endpoint(user: User = Depends(require_role(UserRole.ANALYST))):
            ...

    The factory pattern (a function that returns a function) is necessary because
    FastAPI Depends() expects a callable with no positional arguments beyond those
    it can inject.  We capture `min_role` in a closure so the inner function
    matches that constraint while still knowing the required role.
    """
    async def _check(user: User = Depends(get_current_user_obj)) -> User:
        if _ROLE_ORDER.get(user.role, 0) < _ROLE_ORDER[min_role]:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=(
                    f"Role '{user.role}' does not meet the minimum required "
                    f"role '{min_role}' for this endpoint."
                ),
            )
        return user

    return _check
