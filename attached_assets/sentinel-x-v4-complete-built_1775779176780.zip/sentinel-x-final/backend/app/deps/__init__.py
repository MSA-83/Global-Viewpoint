# backend/app/deps/__init__.py
"""
FastAPI dependency re-exports.

BUG FIXED: The previous version imported `get_current_user` from `deps.auth`.
That function does not exist in deps/auth.py — it only has `get_current_user_obj`
and `require_role`. The `get_current_user` function lives in `core/security.py`
and returns a bare user ID (int), while `get_current_user_obj` in deps/auth.py
does the extra DB lookup to return a full User row.

Both are exported here so callers can import from a single location without
knowing which sub-module each comes from.
"""

from .db import get_db
from .auth import get_current_user_obj, require_role  # was: get_current_user (not in this module)
from ..core.security import get_current_user           # correct source

__all__ = [
    "get_db",
    "get_current_user",       # from core.security — returns int (user ID from JWT)
    "get_current_user_obj",   # from deps.auth — returns full User ORM row
    "require_role",           # factory: require_role(UserRole.ANALYST) → dependency
]
