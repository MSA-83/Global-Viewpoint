# backend/app/db/__init__.py
"""
Database package exports.

BUG FIXED: The previous version of this file created a second, independent
SQLAlchemy engine at import time and defined its own `get_db` dependency.
This directly conflicted with the canonical implementations in:
  - db/session.py  → defines the engine with proper AsyncAdaptedQueuePool
  - deps/db.py     → defines the canonical get_db FastAPI dependency

Having two engines means two separate connection pools, and the `get_db`
defined here would win for any code that did `from app.db import get_db`
instead of `from app.deps.db import get_db`. The db/__init__.py version also
used no pool class (defaulting to StaticPool or NullPool depending on version),
had no pool pre-ping, and silently bypassed all the session management work
done in session.py.

The fix is to remove all connection/session logic from this file entirely and
only re-export what downstream code legitimately needs to import from the
`app.db` namespace.
"""

from .base import Base
from .session import engine, async_session_maker, get_async_session

__all__ = [
    "Base",
    "engine",
    "async_session_maker",
    "get_async_session",
]
