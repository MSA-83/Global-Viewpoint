"""initial schema with postgis and core sentinel-x entities

Revision ID: 2024_01_01_initial
Revises: 
Create Date: 2024-01-01 00:00:00.000000
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "2024_01_01_initial"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS postgis;")

    op.create_table(
        "user",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("tenant_id", postgresql.UUID(as_uuid=True), nullable=True, index=True),
        sa.Column("classification", sa.String(length=16), nullable=False, server_default="UNCLASSIFIED"),
        sa.Column("email", sa.String(length=255), nullable=False, unique=True, index=True),
        sa.Column("hashed_password", sa.String(length=255), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.text("true")),
        sa.Column("is_superuser", sa.Boolean(), nullable=False, server_default=sa.text("false")),
        sa.Column("role", sa.String(length=32), nullable=False, server_default="operator"),
        sa.Column("display_name", sa.String(length=128), nullable=True),
    )

    op.create_table(
        "sensor",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("tenant_id", postgresql.UUID(as_uuid=True), nullable=True, index=True),
        sa.Column("classification", sa.String(length=16), nullable=False, server_default="UNCLASSIFIED"),
        sa.Column("name", sa.String(length=128), nullable=False, index=True),
        sa.Column("domain", sa.String(length=32), nullable=False, index=True),
        sa.Column("status", sa.String(length=32), nullable=False, server_default="operational"),
        sa.Column("platform", sa.String(length=64), nullable=True, index=True),
        sa.Column("capabilities", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("location", sa.Text(), nullable=False),
        sa.Column("description", sa.String(length=512), nullable=True),
        sa.Column("external_id", sa.String(length=128), nullable=True, index=True),
    )
    op.execute("ALTER TABLE sensor ALTER COLUMN location TYPE geometry(Point,4326) USING ST_SetSRID(ST_GeomFromText(location),4326);")

    op.create_table(
        "event",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("tenant_id", postgresql.UUID(as_uuid=True), nullable=True, index=True),
        sa.Column("classification", sa.String(length=16), nullable=False, server_default="UNCLASSIFIED"),
        sa.Column("sensor_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("sensor.id"), nullable=True, index=True),
        sa.Column("event_type", sa.String(length=32), nullable=False, index=True),
        sa.Column("severity", sa.String(length=16), nullable=False, server_default="info"),
        sa.Column("title", sa.String(length=256), nullable=False),
        sa.Column("description", sa.String(length=2048), nullable=True),
        sa.Column("geometry", sa.Text(), nullable=True),
        sa.Column("payload", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column("correlation_id", postgresql.UUID(as_uuid=True), nullable=True, index=True),
        sa.Column("parent_event_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("event.id"), nullable=True),
        sa.Column("occurred_at", sa.DateTime(timezone=True), nullable=False, index=True),
    )
    op.execute("ALTER TABLE event ALTER COLUMN geometry TYPE geometry(Geometry,4326) USING geometry::geometry;")

    op.create_table(
        "missionworkspace",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("tenant_id", postgresql.UUID(as_uuid=True), nullable=True, index=True),
        sa.Column("classification", sa.String(length=16), nullable=False, server_default="UNCLASSIFIED"),
        sa.Column("name", sa.String(length=128), nullable=False, index=True),
        sa.Column("description", sa.String(length=1024), nullable=True),
        sa.Column("owner_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("user.id"), nullable=False, index=True),
        sa.Column("config", postgresql.JSONB(astext_type=sa.Text()), nullable=False, server_default=sa.text("'{}'::jsonb")),
    )


def downgrade() -> None:
    op.drop_table("missionworkspace")
    op.drop_table("event")
    op.drop_table("sensor")
    op.drop_table("user")
    op.execute("DROP EXTENSION IF EXISTS postgis;")
