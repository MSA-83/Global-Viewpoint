# backend/app/deps/db.py
"""
Database session dependency for FastAPI route handlers.

Using `async with async_session_maker() as session` (the context manager form)
is preferred over a manual try/finally because SQLAlchemy's async session context
manager automatically handles rollback on exception — meaning if your route handler
raises an unhandled exception, the session is cleanly rolled back rather than
potentially leaving a partial transaction open.
"""
from collections.abc import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import async_session_maker


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency that provides a scoped AsyncSession for the duration of a
    single HTTP request.  The session is committed or rolled back and closed
    automatically when the request completes.
    """
    async with async_session_maker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
