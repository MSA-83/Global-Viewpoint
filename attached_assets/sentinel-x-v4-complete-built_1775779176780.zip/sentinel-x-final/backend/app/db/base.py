# backend/app/db/base.py
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


# Import models so metadata is populated for Alembic autogenerate.
from ..models.user import User  # noqa: E402,F401
from ..models.sensor import Sensor  # noqa: E402,F401
from ..models.event import Event  # noqa: E402,F401
from ..models.workspace import MissionWorkspace  # noqa: E402,F401
