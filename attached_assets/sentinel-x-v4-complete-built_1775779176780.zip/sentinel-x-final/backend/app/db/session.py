# backend/app/db/session.py
"""
Async SQLAlchemy session factory for Sentinel-X.

Design notes
------------
NullPool was previously used, which disables connection pooling entirely —
meaning every database operation opens and closes a TCP connection to Postgres.
Under any real load this becomes a bottleneck. We replace it with
AsyncAdaptedQueuePool (the asyncpg-compatible queue pool) with conservative
defaults that suit a medium-traffic deployment. Adjust pool_size and
max_overflow to match your Postgres max_connections budget.

pool_pre_ping=True performs a lightweight "SELECT 1" before handing out a
stale connection from the pool, preventing "connection closed" errors after
Postgres restarts or idle-timeout evictions.
"""
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import AsyncAdaptedQueuePool

from app.core.config import settings
from app.db.base import Base


engine: AsyncEngine = create_async_engine(
    settings.postgres_dsn,
    echo=settings.debug,
    future=True,
    poolclass=AsyncAdaptedQueuePool,
    pool_size=10,         # Baseline pool kept open between requests
    max_overflow=20,      # Additional connections allowed under peak load
    pool_pre_ping=True,   # Detect stale connections before use
    pool_recycle=300,     # Force-recycle connections older than 5 minutes
)

async_session_maker: async_sessionmaker[AsyncSession] = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
    autocommit=False,
)


async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency that yields a database session per request."""
    async with async_session_maker() as session:
        yield session


@asynccontextmanager
async def get_async_session_ctx() -> AsyncGenerator[AsyncSession, None]:
    """Context manager variant for use outside of FastAPI request scope."""
    async with async_session_maker() as session:
        yield session


async def init_models() -> None:
    """Create all tables defined in the ORM metadata. Used in testing only.
    In production, Alembic migrations manage the schema."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
