# backend/app/external/openweather.py
import httpx
from typing import Any, Dict
from ..core.config import settings
from ..core.logging import logger

BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

async def fetch_weather(lat: float, lon: float) -> Dict[str, Any]:
    params = {
        "lat": lat,
        "lon": lon,
        "appid": settings.openweather_api_key,
        "units": "metric",
    }
    timeout = httpx.Timeout(5.0, connect=2.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        try:
            resp = await client.get(BASE_URL, params=params)
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning(f"OpenWeather error: {exc}")
            return {}
    return resp.json()
