# backend/app/external/aisstream.py
"""
AISStream.io WebSocket adapter for real-time maritime vessel tracking.

Protocol overview
-----------------
AISStream provides a persistent WebSocket connection that pushes AIS (Automatic
Identification System) messages from vessels globally.  Unlike a REST poll, the
connection is long-lived: you open it once, send a subscription message with
your API key and optional bounding boxes, and the server pushes vessel position
reports as they arrive from its network of AIS receivers.

The three most useful AIS message types for situational awareness are:
  - PositionReport (class A MMSI transmitters: cargo ships, tankers, passenger)
  - ShipStaticData (vessel name, type, dimensions, flag — sent every 6 min)
  - StandardClassBPositionReport (class B: smaller vessels, fishing boats, yachts)

Integration strategy
--------------------
This module exposes two interfaces:

1. `stream_vessel_positions()` — an async generator that yields normalised
   vessel dicts.  Wire this into your Kafka producer during application startup
   to continuously ingest maritime data into the event stream.

2. `fetch_vessels_in_bbox()` — a short-lived snapshot that opens the WebSocket,
   collects vessels seen within a bounding box for `timeout_seconds`, then closes.
   Useful for the `/intel/overview` endpoint.

Why WebSocket, not REST?
------------------------
The REST alternative (MarineTraffic, VesselFinder) charges per API call and
returns stale cached data.  AISStream's WebSocket gives you raw decoded AIS
frames within seconds of a vessel transmitting, which is the right fidelity
for a live ops platform.
"""
from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncGenerator

import websockets

from app.core.config import settings
from app.core.logging import logger

WS_URL = "wss://stream.aisstream.io/v0/stream"

# Mapping from AIS navigational status codes to human-readable labels.
_NAV_STATUS: dict[int, str] = {
    0: "Under way (engine)",
    1: "At anchor",
    2: "Not under command",
    3: "Restricted manoeuvrability",
    4: "Constrained by draught",
    5: "Moored",
    6: "Aground",
    7: "Engaged in fishing",
    8: "Under way (sailing)",
    15: "Undefined",
}

# AIS ship type codes → category labels (simplified subset).
_SHIP_TYPE: dict[int, str] = {
    0: "Unknown",
    20: "Wing in ground",
    30: "Fishing",
    31: "Towing",
    36: "Sailing",
    37: "Pleasure craft",
    40: "HSC",
    50: "Pilot vessel",
    51: "SAR vessel",
    52: "Tug",
    60: "Passenger",
    70: "Cargo",
    80: "Tanker",
    90: "Other",
}


def _normalise_position_report(msg: dict[str, Any]) -> dict[str, Any] | None:
    """
    Extract a standard dict from a raw AISStream PositionReport message.

    Returns None if the position is invalid (lat/lon outside valid range
    indicates the vessel hasn't transmitted a fix yet).
    """
    meta = msg.get("MetaData", {})
    pr = msg.get("Message", {}).get("PositionReport", {})

    lat = pr.get("Latitude")
    lon = pr.get("Longitude")

    # AIS transmits 91 / 181 as "not available" sentinel values.
    if lat is None or lon is None or abs(lat) > 90 or abs(lon) > 180:
        return None
    if lat == 91.0 or lon == 181.0:
        return None

    return {
        "mmsi": meta.get("MMSI"),
        "name": meta.get("ShipName", "").strip() or "Unknown",
        "lat": lat,
        "lon": lon,
        "cog": pr.get("Cog"),          # Course over ground (degrees)
        "sog": pr.get("Sog"),          # Speed over ground (knots)
        "heading": pr.get("TrueHeading"),
        "nav_status": _NAV_STATUS.get(pr.get("NavigationalStatus", 15), "Undefined"),
        "timestamp": meta.get("time_utc"),
        "source": "aisstream",
    }


def _build_subscription(bounding_boxes: list[list[list[float]]] | None = None) -> str:
    """
    Build the JSON subscription message that AISStream expects on connection.

    bounding_boxes format: [ [[min_lat, min_lon], [max_lat, max_lon]], ... ]
    Pass None (or an empty list) to subscribe to all vessels globally — be
    aware this is a very high-volume stream (~10k msgs/min at peak).
    """
    msg: dict[str, Any] = {
        "APIKey": settings.aisstream_token or "",
        "MessageType": "Subscribe",
        "BoundingBoxes": bounding_boxes or [],
        "FilterMessageTypes": [
            "PositionReport",
            "StandardClassBPositionReport",
        ],
    }
    return json.dumps(msg)


async def stream_vessel_positions(
    bounding_boxes: list[list[list[float]]] | None = None,
    reconnect_delay: float = 5.0,
) -> AsyncGenerator[dict[str, Any], None]:
    """
    Async generator that yields normalised vessel position dicts indefinitely.

    Automatically reconnects with exponential backoff if the WebSocket drops,
    which is common for long-lived connections over the internet.

    Usage:
        async for vessel in stream_vessel_positions():
            await kafka_producer.produce_event(vessel, key=str(vessel["mmsi"]))

    Args:
        bounding_boxes: Optional spatial filter.  If omitted, receives all vessels.
        reconnect_delay: Initial backoff in seconds; doubles on each failure up to 60s.
    """
    if not settings.aisstream_token:
        logger.warning("AISStream: AISSTREAM_TOKEN not configured, skipping maritime stream")
        return

    subscription = _build_subscription(bounding_boxes)
    delay = reconnect_delay

    while True:
        try:
            async with websockets.connect(WS_URL, ping_interval=30) as ws:
                await ws.send(subscription)
                logger.info("AISStream WebSocket connected")
                delay = reconnect_delay  # Reset backoff on successful connect

                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                    except json.JSONDecodeError:
                        continue

                    msg_type = msg.get("MessageType")
                    if msg_type in ("PositionReport", "StandardClassBPositionReport"):
                        vessel = _normalise_position_report(msg)
                        if vessel is not None:
                            yield vessel

        except (websockets.ConnectionClosed, OSError) as exc:
            logger.warning(
                "AISStream WebSocket disconnected, reconnecting",
                error=str(exc),
                retry_in=delay,
            )
            await asyncio.sleep(delay)
            delay = min(delay * 2, 60.0)


async def fetch_vessels_in_bbox(
    min_lat: float,
    min_lon: float,
    max_lat: float,
    max_lon: float,
    timeout_seconds: float = 10.0,
) -> list[dict[str, Any]]:
    """
    Collect a snapshot of vessels seen within a bounding box.

    Opens the WebSocket, accumulates position reports for `timeout_seconds`,
    then returns the deduplicated set of vessels (latest position per MMSI).
    This is used by the `/intel/overview` endpoint for on-demand maritime context.
    """
    if not settings.aisstream_token:
        return []

    bboxes = [[[min_lat, min_lon], [max_lat, max_lon]]]
    subscription = _build_subscription(bboxes)
    vessels: dict[int, dict[str, Any]] = {}

    try:
        async with asyncio.timeout(timeout_seconds):
            async with websockets.connect(WS_URL, ping_interval=30) as ws:
                await ws.send(subscription)
                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    vessel = _normalise_position_report(msg)
                    if vessel and vessel.get("mmsi"):
                        vessels[vessel["mmsi"]] = vessel
    except TimeoutError:
        pass  # Expected — we collected for timeout_seconds, then stopped
    except Exception as exc:
        logger.warning("AISStream snapshot error", error=str(exc))

    return list(vessels.values())
