# backend/app/external/global_fishing_watch.py
import httpx
from typing import Any, Dict, List
from ..core.config import settings
from ..core.logging import logger

BASE_URL = "https://gateway.api.globalfishingwatch.org/v2/vessels"

async def fetch_fishing_activity(lat: float, lon: float, radius_km: float) -> List[Dict[str, Any]]:
    # Real GFW queries are more complex; we approximate a bounding box query.
    radius_deg = radius_km / 111.0
    params = {
        "lat": lat,
        "lon": lon,
        "radius": radius_km,
    }
    headers = {
        "Authorization": f"Bearer {settings.gfw_api_token}",
    }
    timeout = httpx.Timeout(8.0, connect=3.0)
    async with httpx.AsyncClient(timeout=timeout, headers=headers) as client:
        try:
            resp = await client.get(BASE_URL, params=params)
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning(f"GFW error: {exc}")
            return []
    data = resp.json()
    return data.get("vessels", [])
