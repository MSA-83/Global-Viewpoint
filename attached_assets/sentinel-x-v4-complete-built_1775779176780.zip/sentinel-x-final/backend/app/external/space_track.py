# backend/app/external/space_track.py
import httpx
from typing import List, Dict, Any
from ..core.config import settings
from ..core.logging import logger

BASE_URL = "https://www.space-track.org"

async def _login(client: httpx.AsyncClient) -> None:
    resp = await client.post(
        f"{BASE_URL}/ajaxauth/login",
        data={
            "identity": settings.space_track_username,
            "password": settings.space_track_password,
        },
    )
    resp.raise_for_status()

async def fetch_tle_for_norad_ids(norad_ids: List[int]) -> List[Dict[str, Any]]:
    if not norad_ids:
        return []
    timeout = httpx.Timeout(8.0, connect=3.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        try:
            await _login(client)
            norad_str = ",".join(str(n) for n in norad_ids)
            url = f"{BASE_URL}/basicspacedata/query/class/tle_latest/NORAD_CAT_ID/{norad_str}/orderby/NORAD_CAT_ID/format/json"
            resp = await client.get(url)
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning(f"Space-Track error: {exc}")
            return []
    return resp.json()
