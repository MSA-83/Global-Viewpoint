# backend/app/external/avwx.py
"""
AVWX aviation weather adapter for Sentinel-X.

What AVWX provides and why it matters
--------------------------------------
AVWX (Aviation Weather) is a REST API that wraps NOAA and ICAO aviation
weather data into a clean, decoded JSON format. For a global situational
awareness platform, aviation weather data provides two things:

1. Real-time airspace hazards via SIGMETs (Significant Meteorological
   Information). SIGMETs are advisories issued by meteorological watch offices
   describing dangerous conditions: severe turbulence, volcanic ash clouds,
   tropical cyclones, icing, and radioactive releases. Each SIGMET covers a
   defined polygon or corridor with an altitude band and time window.
   Overlaying active SIGMETs on the globe gives operators immediate context
   for why aircraft are deviating from expected routes.

2. Ground-truth atmospheric conditions via METARs (Meteorological Aerodrome
   Reports). These are standardised hourly observations from airport weather
   stations. A METAR gives you pressure, temperature, dew point, wind, cloud
   layers, visibility, and weather phenomena like fog, rain, or snow. When
   a ground sensor reports unusual activity near an airport, the METAR from
   that airport tells you whether poor visibility or adverse winds might be
   affecting the situation.

API notes
---------
AVWX's base URL is https://avwx.rest/api/. The relevant endpoints are:

  /sigmet                 — Active SIGMETs globally, filterable by hazard type
  /metar/{icao_code}      — Latest METAR for a single station
  /station/near/{lat},{lon} — Nearest weather stations to a coordinate

Authentication is via `Token <key>` in the Authorization header.

We cache SIGMET data aggressively (they are valid for hours, not minutes)
using a simple in-memory TTL cache to avoid hammering the API on every
`/intel/overview` call.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any

import httpx

from app.core.config import settings
from app.core.logging import logger

_BASE = "https://avwx.rest/api"
_TIMEOUT = httpx.Timeout(8.0, connect=3.0)

# Simple in-memory TTL cache for SIGMETs (valid for up to 10 minutes).
_sigmet_cache: dict[str, Any] = {}
_SIGMET_CACHE_TTL = 600  # seconds


def _auth_headers() -> dict[str, str]:
    """Return the Authorization header required by AVWX."""
    return {
        "Authorization": f"Token {settings.avwx_api_key or ''}",
        "Accept": "application/json",
    }


async def fetch_active_sigmets(
    hazard: str | None = None,
) -> list[dict[str, Any]]:
    """
    Return all currently active SIGMETs, optionally filtered by hazard type.

    Hazard types include: TURB (turbulence), ICE (icing), VA (volcanic ash),
    TC (tropical cyclone), RDOACT (radioactive cloud), MTW (mountain wave).

    SIGMETs are cached for 10 minutes because they change at most hourly and
    hammering the AVWX API with one call per Intel overview request would
    quickly exhaust the rate limit.

    Returns a list of dicts, each representing one active SIGMET with its
    hazard type, time window, altitude bounds, and a GeoJSON polygon or
    corridor describing the affected area.
    """
    if not settings.avwx_api_key:
        logger.warning("AVWX: AVWX_API_KEY not configured, skipping SIGMETs")
        return []

    cache_key = f"sigmets:{hazard or 'all'}"
    cached = _sigmet_cache.get(cache_key)
    if cached and time.monotonic() - cached["ts"] < _SIGMET_CACHE_TTL:
        return cached["data"]

    params: dict[str, str] = {}
    if hazard:
        params["hazard"] = hazard.upper()

    async with httpx.AsyncClient(timeout=_TIMEOUT, headers=_auth_headers()) as client:
        try:
            resp = await client.get(f"{_BASE}/sigmet", params=params)
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("AVWX SIGMET fetch failed", error=str(exc))
            return []

    raw = resp.json()
    sigmets = _parse_sigmets(raw if isinstance(raw, list) else raw.get("sigmets", []))

    _sigmet_cache[cache_key] = {"data": sigmets, "ts": time.monotonic()}
    return sigmets


def _parse_sigmets(raw_list: list[dict]) -> list[dict[str, Any]]:
    """Normalise AVWX SIGMET records into a consistent Sentinel-X dict shape."""
    results = []
    for s in raw_list:
        # AVWX may return decoded or raw format; handle both gracefully.
        coords = s.get("coords") or s.get("coordinates") or []
        results.append({
            "id": s.get("raw", "")[:32],          # Use start of raw text as ID
            "hazard": s.get("hazard", "UNKNOWN"),
            "qualifier": s.get("qualifier"),       # e.g. "EMBD" (embedded), "SEV"
            "flight_levels": {
                "lower": s.get("altitude", {}).get("min"),
                "upper": s.get("altitude", {}).get("max"),
            },
            "valid_from": s.get("start_time", {}).get("repr") if isinstance(s.get("start_time"), dict) else s.get("start_time"),
            "valid_to": s.get("end_time", {}).get("repr") if isinstance(s.get("end_time"), dict) else s.get("end_time"),
            "issuing_office": s.get("issuing_office"),
            "fir": s.get("fir"),    # Flight Information Region
            "coords": coords,       # List of [lon, lat] pairs for polygon
            "raw": s.get("raw"),    # Original SIGMET text for operators who want it
            "source": "avwx_sigmet",
        })
    return results


async def fetch_metar(icao_code: str) -> dict[str, Any]:
    """
    Return the latest decoded METAR for a given ICAO airport code.

    AVWX decodes the raw METAR string (e.g. "EHAM 091025Z 25015KT 9999 FEW040
    10/04 Q1020 NOSIG") into structured fields — wind speed, visibility, cloud
    layers, and altimeter setting — making it far easier to render in a UI than
    parsing the raw text.

    Args:
        icao_code: Four-letter ICAO identifier (e.g. "EHAM" for Amsterdam
                   Schiphol, "EGLL" for London Heathrow).

    Returns an empty dict if the station is unknown or the API is unavailable.
    """
    if not settings.avwx_api_key:
        return {}

    url = f"{_BASE}/metar/{icao_code.upper()}"
    async with httpx.AsyncClient(timeout=_TIMEOUT, headers=_auth_headers()) as client:
        try:
            resp = await client.get(url, params={"options": "translate"})
            if resp.status_code == 400:
                return {}  # Unknown station
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("AVWX METAR fetch failed", icao=icao_code, error=str(exc))
            return {}

    d = resp.json()
    return {
        "icao": icao_code.upper(),
        "time": d.get("time", {}).get("repr"),
        "wind": {
            "direction": d.get("wind_direction", {}).get("value"),
            "speed_kt": d.get("wind_speed", {}).get("value"),
            "gust_kt": d.get("wind_gust", {}).get("value"),
        },
        "visibility_m": d.get("visibility", {}).get("value"),
        "temperature_c": d.get("temperature", {}).get("value"),
        "dewpoint_c": d.get("dewpoint", {}).get("value"),
        "altimeter_hpa": d.get("altimeter", {}).get("value"),
        "clouds": [
            {
                "cover": c.get("repr"),
                "base_ft": c.get("altitude"),
                "type": c.get("type"),
            }
            for c in d.get("clouds", [])
        ],
        "wx_codes": [w.get("repr") for w in d.get("wx_codes", [])],
        "flight_rules": d.get("flight_rules"),  # VFR / MVFR / IFR / LIFR
        "raw": d.get("raw"),
        "source": "avwx_metar",
    }


async def fetch_nearest_stations(
    lat: float,
    lon: float,
    radius_km: float = 100.0,
    limit: int = 5,
) -> list[dict[str, Any]]:
    """
    Return the nearest airport weather stations to a coordinate.

    Used to drive `fetch_metar()` calls when the operator specifies a lat/lon
    rather than an ICAO code — we first find the nearest stations, then fetch
    their METARs.
    """
    if not settings.avwx_api_key:
        return []

    url = f"{_BASE}/station/near/{lat:.4f},{lon:.4f}"
    params = {"n": str(limit), "maxdist": str(int(radius_km))}

    async with httpx.AsyncClient(timeout=_TIMEOUT, headers=_auth_headers()) as client:
        try:
            resp = await client.get(url, params=params)
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("AVWX station search failed", lat=lat, lon=lon, error=str(exc))
            return []

    return [
        {
            "icao": s.get("station", {}).get("icao"),
            "name": s.get("station", {}).get("name"),
            "lat": s.get("station", {}).get("latitude"),
            "lon": s.get("station", {}).get("longitude"),
            "elevation_m": s.get("station", {}).get("elevation"),
            "distance_km": s.get("distance"),
        }
        for s in resp.json()
        if s.get("station", {}).get("icao")
    ]


async def fetch_metars_near_coordinate(
    lat: float,
    lon: float,
    radius_km: float = 150.0,
    limit: int = 5,
) -> list[dict[str, Any]]:
    """
    Convenience wrapper: find nearby stations and return their METARs concurrently.

    This is the main entry point for the `/intel/overview` endpoint.  It finds
    the nearest airports and fetches all their METARs in parallel using
    asyncio.gather(), so the total time is bounded by the slowest single METAR
    request rather than growing linearly with the number of stations.
    """
    stations = await fetch_nearest_stations(lat, lon, radius_km=radius_km, limit=limit)
    if not stations:
        return []

    icao_codes = [s["icao"] for s in stations if s.get("icao")]
    metars = await asyncio.gather(
        *[fetch_metar(code) for code in icao_codes],
        return_exceptions=True,
    )
    return [m for m in metars if isinstance(m, dict) and m]
