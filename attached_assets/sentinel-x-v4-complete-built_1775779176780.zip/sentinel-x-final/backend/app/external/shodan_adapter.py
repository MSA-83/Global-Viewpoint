# backend/app/external/shodan_adapter.py
"""
Shodan cyber intelligence adapter for Sentinel-X.

What Shodan provides
--------------------
Shodan is a search engine for internet-connected devices. Unlike Google, which
indexes web page content, Shodan indexes the raw banners that devices return
when you connect to them — HTTP headers, TLS certificates, SSH fingerprints,
ICS/SCADA protocol responses, and so on. For a situational awareness platform
this translates to two distinct intelligence use cases:

1. Geospatial cyber presence — "what internet-facing systems exist within a
   given geographic area, and are any of them known-vulnerable?"
   Use fetch_hosts_near_coordinate() for this.

2. IP reputation and exposure — "a sensor has reported traffic from this IP;
   what do we know about it?" Use fetch_host_intel() for this.

API notes
---------
The Shodan REST API returns at most 100 results per request on the free tier.
The `shodan.io/api/v1/shodan/host/search` endpoint supports geographical
filtering via the `geo:lat,lon,radius` search filter, which we use to bound
results to the operator's area of interest.

We use httpx directly (rather than the official `shodan` Python library) to
stay consistent with the rest of the codebase and avoid an additional
dependency for a thin wrapper.

Rate limits: 1 request/second on the developer plan.  Add a token-bucket
rate limiter if you need higher throughput.
"""
from __future__ import annotations

from typing import Any

import httpx

from app.core.config import settings
from app.core.logging import logger

_BASE = "https://api.shodan.io"
_TIMEOUT = httpx.Timeout(10.0, connect=3.0)


def _headers() -> dict[str, str]:
    """Common headers for Shodan API requests.  API key is a query parameter."""
    return {"Accept": "application/json"}


def _params(extra: dict | None = None) -> dict[str, str]:
    """Inject the API key into every request's query parameters."""
    base = {"key": settings.shodan_api_key or ""}
    if extra:
        base.update(extra)
    return base


async def fetch_host_intel(ip_address: str) -> dict[str, Any]:
    """
    Return Shodan's knowledge about a specific IP address.

    The response includes open ports, running services, known CVEs, OS
    fingerprint, autonomous system number, and the last scan timestamp.
    This is useful for enriching an alert: if a sensor flags suspicious
    traffic from 185.220.x.x you can immediately see whether Shodan knows
    it as a Tor exit node or a server running an unpatched CVE.

    Returns an empty dict if the IP is not in Shodan's index or the API
    key is not configured.
    """
    if not settings.shodan_api_key:
        logger.warning("Shodan: SHODAN_API_KEY not configured, skipping")
        return {}

    url = f"{_BASE}/shodan/host/{ip_address}"
    async with httpx.AsyncClient(timeout=_TIMEOUT, headers=_headers()) as client:
        try:
            resp = await client.get(url, params=_params())
            if resp.status_code == 404:
                return {}  # IP not in Shodan's database — not an error
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("Shodan host lookup failed", ip=ip_address, error=str(exc))
            return {}

    data = resp.json()
    # Return a curated subset rather than the full noisy Shodan response.
    return {
        "ip": data.get("ip_str"),
        "org": data.get("org"),
        "country": data.get("country_name"),
        "city": data.get("city"),
        "isp": data.get("isp"),
        "asn": data.get("asn"),
        "os": data.get("os"),
        "open_ports": data.get("ports", []),
        "vulns": list(data.get("vulns", {}).keys()),
        "last_update": data.get("last_update"),
        "hostnames": data.get("hostnames", []),
        "tags": data.get("tags", []),   # e.g. ["tor", "cdn", "vpn"]
        "source": "shodan",
    }


async def fetch_hosts_near_coordinate(
    lat: float,
    lon: float,
    radius_km: float = 50.0,
    query: str = "",
    limit: int = 50,
) -> list[dict[str, Any]]:
    """
    Return internet-facing hosts near a geographic coordinate.

    Shodan supports the `geo:lat,lon,radius_km` filter in its search syntax,
    which lets us find exposed systems in, say, a 50 km radius around a
    point of interest.  Additional query terms can narrow the results — for
    example `query="port:502"` for Modbus-enabled ICS devices, or
    `query="vuln:CVE-2021-44228"` for Log4Shell-vulnerable hosts.

    Args:
        lat:        Centre latitude.
        lon:        Centre longitude.
        radius_km:  Search radius in kilometres (Shodan supports up to 500).
        query:      Optional additional Shodan search filters.
        limit:      Maximum number of hosts to return (capped at 100 by API).
    """
    if not settings.shodan_api_key:
        return []

    geo_filter = f"geo:{lat:.4f},{lon:.4f},{radius_km:.0f}"
    full_query = f"{geo_filter} {query}".strip()

    params = _params({
        "query": full_query,
        "minify": "true",       # Return only summary fields — reduces payload size
        "page": "1",
    })

    async with httpx.AsyncClient(timeout=_TIMEOUT, headers=_headers()) as client:
        try:
            resp = await client.get(f"{_BASE}/shodan/host/search", params=params)
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning(
                "Shodan geo search failed",
                lat=lat,
                lon=lon,
                error=str(exc),
            )
            return []

    data = resp.json()
    matches = data.get("matches", [])[:limit]

    return [
        {
            "ip": m.get("ip_str"),
            "port": m.get("port"),
            "org": m.get("org"),
            "country": m.get("location", {}).get("country_name"),
            "lat": m.get("location", {}).get("latitude"),
            "lon": m.get("location", {}).get("longitude"),
            "product": m.get("product"),
            "version": m.get("version"),
            "cpe": m.get("cpe", []),
            "vulns": list(m.get("vulns", {}).keys()),
            "timestamp": m.get("timestamp"),
            "source": "shodan",
        }
        for m in matches
        if m.get("ip_str")
    ]


async def fetch_exploits(cve_id: str) -> list[dict[str, Any]]:
    """
    Return known exploits for a given CVE from Shodan's exploit database.

    Useful for enriching a vulnerability finding: once you know a host is
    running a vulnerable version, this tells you whether there is a public
    proof-of-concept or weaponised exploit available.
    """
    if not settings.shodan_api_key:
        return []

    async with httpx.AsyncClient(timeout=_TIMEOUT, headers=_headers()) as client:
        try:
            resp = await client.get(
                f"{_BASE}/exploits/search",
                params=_params({"query": cve_id}),
            )
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("Shodan exploit search failed", cve=cve_id, error=str(exc))
            return []

    data = resp.json()
    return [
        {
            "id": e.get("_id"),
            "title": e.get("description", "")[:200],
            "type": e.get("type"),
            "platform": e.get("platform"),
            "cve": e.get("cve", []),
            "source": "shodan_exploits",
        }
        for e in data.get("matches", [])
    ]
