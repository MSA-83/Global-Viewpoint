# backend/app/external/nasa.py
"""
NASA EONET (Earth Observatory Natural Event Tracker) adapter.

The original implementation fetched up to 20 globally-distributed events and
returned all of them regardless of where the operator was looking.  A user
monitoring the North Sea would receive wildfire events in California — not
useful for situational awareness.

The EONET v3 API supports a `bbox` (bounding box) query parameter that filters
results server-side to events whose geometry intersects the requested area.
The format is `bbox=min_lon,min_lat,max_lon,max_lat` (WGS-84 decimal degrees,
longitude first — the GeoJSON/OGC convention, not lat-first).

We compute the bounding box from the same `lat/lon/radius_km` parameters that
every other adapter in the intel router accepts, converting radius to degrees
using the flat-earth approximation (accurate enough for radii < 1000 km).

The function also returns richer event data: category slugs, geometry types,
and the most recent geometry coordinates, so the frontend can place events on
the map rather than just listing their titles.
"""
from __future__ import annotations

import math
from typing import Any

import httpx

from app.core.config import settings
from app.core.logging import logger

_BASE_URL = "https://eonet.gsfc.nasa.gov/api/v3/events"
_TIMEOUT = httpx.Timeout(8.0, connect=3.0)
_KM_PER_DEG = 111.0  # 1 degree latitude ≈ 111 km


def _compute_bbox(
    lat: float, lon: float, radius_km: float
) -> tuple[float, float, float, float]:
    """
    Return (min_lon, min_lat, max_lon, max_lat) in the EONET bbox format.

    Note the order: EONET uses longitude-first (GeoJSON convention), which is
    the opposite of the lat-first convention used elsewhere in the codebase.
    We keep it explicit here to avoid confusion.
    """
    delta_lat = radius_km / _KM_PER_DEG
    # Longitude degrees per km shrinks towards the poles: cos(lat) correction.
    delta_lon = radius_km / (_KM_PER_DEG * math.cos(math.radians(lat)))
    min_lon = max(lon - delta_lon, -180.0)
    min_lat = max(lat - delta_lat, -90.0)
    max_lon = min(lon + delta_lon, 180.0)
    max_lat = min(lat + delta_lat, 90.0)
    return min_lon, min_lat, max_lon, max_lat


async def fetch_natural_events(
    lat: float,
    lon: float,
    radius_km: float,
    limit: int = 50,
    days: int = 30,
) -> list[dict[str, Any]]:
    """
    Return open natural hazard events within a geographic bounding box.

    Uses the EONET v3 `bbox` parameter for server-side spatial filtering, so
    only events whose most recent geometry falls within the requested area are
    returned.  No API key is required — NASA EONET is publicly accessible.

    Args:
        lat:        Centre latitude of the area of interest.
        lon:        Centre longitude of the area of interest.
        radius_km:  Search radius.  Converted to a bounding box internally.
        limit:      Maximum events to return (EONET caps at 1000).
        days:       Only return events with activity in the last N days.
                    Set to None or 0 to include all open events regardless of age.
    """
    min_lon, min_lat, max_lon, max_lat = _compute_bbox(lat, lon, radius_km)
    # EONET bbox format: min_lon,min_lat,max_lon,max_lat
    bbox_str = f"{min_lon:.4f},{min_lat:.4f},{max_lon:.4f},{max_lat:.4f}"

    params: dict[str, Any] = {
        "status": "open",
        "limit": limit,
        "bbox": bbox_str,
    }
    if days:
        params["days"] = days

    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        try:
            resp = await client.get(_BASE_URL, params=params)
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            logger.warning("NASA EONET error", error=str(exc), bbox=bbox_str)
            return []

    data = resp.json()
    events = data.get("events", [])

    return [_normalise_event(e) for e in events]


def _normalise_event(e: dict[str, Any]) -> dict[str, Any]:
    """
    Convert a raw EONET event record into a flat, frontend-friendly dict.

    EONET events carry a list of `geometries` (one per observation, newest
    first).  We extract the most recent geometry's coordinates and type so
    the frontend can immediately place the event on the map without parsing
    the nested EONET structure.
    """
    geometries = e.get("geometries", [])
    latest_geom = geometries[0] if geometries else {}

    # EONET geometry coordinates are [lon, lat] for Point types.
    coords = latest_geom.get("coordinates")
    lon_val: float | None = None
    lat_val: float | None = None
    if coords and latest_geom.get("type") == "Point" and len(coords) >= 2:
        lon_val, lat_val = coords[0], coords[1]

    return {
        "id": e.get("id"),
        "title": e.get("title"),
        "categories": [c.get("title") for c in e.get("categories", [])],
        "category_ids": [c.get("id") for c in e.get("categories", [])],
        "geometry_type": latest_geom.get("type"),
        "lat": lat_val,
        "lon": lon_val,
        "date": latest_geom.get("date"),
        "link": e.get("link"),
        "source": "nasa_eonet",
    }
