# backend/app/external/__init__.py
"""
External intelligence adapter re-exports.

The previous version only registered the original four adapters (nasa,
openweather, space_track, global_fishing_watch). The three new adapters added
in earlier sessions (aisstream, avwx, shodan_adapter) were never added here,
meaning `from app.external import fetch_vessels_in_bbox` and similar imports
would fail with ImportError in any code that used the package-level import path.
"""

from .nasa import fetch_natural_events
from .openweather import fetch_weather
from .space_track import fetch_tle_for_norad_ids
from .global_fishing_watch import fetch_fishing_activity
from .aisstream import fetch_vessels_in_bbox, stream_vessel_positions
from .avwx import fetch_active_sigmets, fetch_metars_near_coordinate, fetch_metar
from .shodan_adapter import fetch_host_intel, fetch_hosts_near_coordinate

__all__ = [
    # Original adapters
    "fetch_natural_events",
    "fetch_weather",
    "fetch_tle_for_norad_ids",
    "fetch_fishing_activity",
    # Maritime (AISStream)
    "fetch_vessels_in_bbox",
    "stream_vessel_positions",
    # Aviation weather (AVWX)
    "fetch_active_sigmets",
    "fetch_metars_near_coordinate",
    "fetch_metar",
    # Cyber intelligence (Shodan)
    "fetch_host_intel",
    "fetch_hosts_near_coordinate",
]
