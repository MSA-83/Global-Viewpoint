# backend/app/routers/events.py
"""
Events router for Sentinel-X.

The original router used `Depends(get_current_user)` (imported from
`deps.auth`), which — after the security consolidation — correctly returns a
plain `int` (the user's numeric ID extracted from the JWT).  The handler then
immediately accessed `user.tenant_id`, but an `int` has no `.tenant_id`
attribute.  Every request to this endpoint raised `AttributeError`.

The fix is to use `Depends(get_current_user_obj)` instead, which resolves the
integer ID into the full SQLAlchemy `User` row via a secondary DB lookup.
That row carries `tenant_id`, `role`, and all other profile fields the handler
needs.

Why the two-step dependency chain?
-----------------------------------
`get_current_user` (in core/security.py) validates the JWT and extracts the
user ID with zero DB I/O — it is fast and used by high-frequency paths like
the WebSocket ticket endpoint.  `get_current_user_obj` (in deps/auth.py) builds
on top of it, adding one `SELECT` to hydrate the full User object.  Endpoints
that only need to know *who* is calling use the cheap version; endpoints that
need the caller's role, tenant, or display name use the expensive one.
"""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.deps.auth import get_current_user_obj   # ← was get_current_user (returns int)
from app.deps.db import get_db
from app.models.user import User
from app.schemas.event import EventRead
from app.crud import event as event_crud

router = APIRouter(prefix="/events", tags=["events"])


@router.get("/", response_model=List[EventRead])
async def list_events(
    from_ts: datetime = Query(..., description="Start time (inclusive, ISO 8601)"),
    to_ts: datetime = Query(..., description="End time (exclusive, ISO 8601)"),
    severity: Optional[str] = Query(None, description="Filter by severity level"),
    event_type: Optional[str] = Query(None, description="Filter by event type"),
    limit: int = Query(500, ge=1, le=5000),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user_obj),  # ← full User object, not int
) -> List:
    """
    Return events within a time window, scoped to the caller's tenant.

    The `from_ts` / `to_ts` pair defines a half-open interval [from_ts, to_ts).
    Both must be ISO 8601 datetimes with timezone information — naive datetimes
    are ambiguous and rejected by the query layer.

    Results are ordered newest-first and capped at `limit` rows (default 500,
    max 5000).  For large playback windows, paginate by advancing `from_ts` to
    the `occurred_at` of the last returned event.
    """
    return await event_crud.list_events(
        db=db,
        tenant_id=user.tenant_id,   # .tenant_id now works — user is a User, not an int
        from_ts=from_ts,
        to_ts=to_ts,
        severity=severity,
    )
