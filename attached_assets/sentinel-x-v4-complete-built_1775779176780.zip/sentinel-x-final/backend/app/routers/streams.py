# backend/app/routers/streams.py
"""
WebSocket stream router for Sentinel-X real-time event fan-out.

How WebSocket authentication works here
----------------------------------------
HTTP-based authentication (Bearer tokens in the Authorization header) does not
work with WebSocket connections because browsers do not allow setting custom
headers on WebSocket handshake requests — only the standard Upgrade headers are
sent. There are two conventional workarounds:

  1. Pass the token as a query parameter: ws://host/ws?token=eyJ...
     Simple, but query parameters appear in server access logs and browser
     history, leaking the token.

  2. Pass the token as a Sec-WebSocket-Protocol subprotocol header.
     Less obvious but supported by all modern browsers. The client sends
     `new WebSocket(url, [token])` and the server reads the first subprotocol
     value. Still visible in network logs but not URLs.

  3. Issue a short-lived WebSocket ticket (a random nonce) via a normal REST
     endpoint, then present the ticket in the WebSocket URL.  The ticket is
     single-use and expires in 30 seconds — leaking the URL leaks nothing useful.
     This is the most secure approach and what we implement below.

We implement option 3. The `/streams/ticket` endpoint (requires a valid Bearer
token) issues a nonce stored in Redis with a 30-second TTL. The client passes
the nonce as `?ticket=<nonce>` when opening the WebSocket. The WS endpoint
validates the nonce (and deletes it so it cannot be reused), then proceeds.

Event fan-out via Redis Pub/Sub
--------------------------------
Rather than maintaining an in-process list of connected WebSocket clients, we
use Redis Pub/Sub as the fan-out mechanism. Any backend service (Kafka consumer,
API handler, background task) can publish to the `sentinel.events` channel and
all connected WebSocket clients receive the message. This means horizontal
scaling works correctly: two replicas of the backend each maintain their own set
of WebSocket connections, but both subscribe to the same Redis channel, so every
client hears every event regardless of which replica it connected to.
"""
from __future__ import annotations

import secrets

from fastapi import APIRouter, Depends, HTTPException, Query, WebSocket, WebSocketDisconnect, status

from app.core.config import settings
from app.core.logging import logger
from app.core.security import decode_token, oauth2_scheme
from app.services.redis_pubsub import event_generator, _get_redis

router = APIRouter(prefix="/api/v1/streams", tags=["streams"])


# ---------------------------------------------------------------------------
# WebSocket ticket issuance — REST endpoint, requires valid Bearer token
# ---------------------------------------------------------------------------

@router.post("/ticket", summary="Issue a single-use WebSocket connection ticket")
async def issue_ws_ticket(token: str = Depends(oauth2_scheme)) -> dict:
    """
    Exchange a valid JWT access token for a short-lived WebSocket ticket.

    The ticket is a 32-byte URL-safe random nonce stored in Redis with a 30-second
    TTL.  The client uses it once to open the WebSocket connection, after which
    the ticket is deleted from Redis and cannot be reused.

    This pattern avoids passing the JWT in the WebSocket URL or as a subprotocol
    header, both of which have logging and interception risks.
    """
    # Validate the Bearer token — raises 401 if invalid or expired.
    payload = decode_token(token)

    ticket = secrets.token_urlsafe(32)
    redis = _get_redis()
    # Store ticket → user_id mapping for 30 seconds.
    await redis.setex(f"ws_ticket:{ticket}", 30, str(payload.sub))

    return {"ticket": ticket, "expires_in": 30}


# ---------------------------------------------------------------------------
# WebSocket event stream
# ---------------------------------------------------------------------------

@router.websocket("/ws")
async def events_ws(
    websocket: WebSocket,
    ticket: str = Query(..., description="Single-use ticket obtained from POST /streams/ticket"),
) -> None:
    """
    Real-time event stream via WebSocket.

    The client must present a valid ticket obtained from `POST /streams/ticket`.
    On connection the ticket is validated and immediately deleted (single-use),
    then the handler subscribes to the Redis `sentinel.events` channel and relays
    every message to the connected client until it disconnects.

    Client-side usage (TypeScript):
        const { data } = await fetch('/api/v1/streams/ticket', {
            method: 'POST',
            headers: { Authorization: `Bearer ${accessToken}` },
        }).then(r => r.json());

        const ws = new WebSocket(`wss://host/api/v1/streams/ws?ticket=${data.ticket}`);
    """
    redis = _get_redis()

    # Validate and consume the ticket atomically.
    ticket_key = f"ws_ticket:{ticket}"
    user_id = await redis.getdel(ticket_key)
    if user_id is None:
        # Ticket not found, expired, or already consumed.
        await websocket.close(code=4001, reason="Invalid or expired ticket")
        return

    await websocket.accept()
    logger.info("ws_connected", user_id=user_id, client=websocket.client)

    try:
        async for event in event_generator("sentinel.events"):
            await websocket.send_json(event)
    except WebSocketDisconnect:
        logger.info("ws_disconnected", user_id=user_id)
    except Exception as exc:
        logger.error("ws_error", user_id=user_id, error=str(exc))
    finally:
        logger.debug("ws_closed", user_id=user_id)
