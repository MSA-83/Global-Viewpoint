# backend/app/routers/auth.py
"""
Authentication router — login, register, token refresh, and user profile.

Token strategy
--------------
On successful login the backend returns two tokens:
  * access_token  — short-lived (default 30 min), sent in the Authorization header
  * refresh_token — long-lived (default 7 days), stored in an httpOnly cookie

The frontend should store the access token in memory (never localStorage) and
use the refresh endpoint to obtain a new access token when the current one expires.
Storing the refresh token in an httpOnly cookie prevents XSS theft.
"""
from __future__ import annotations

from fastapi import APIRouter, Cookie, Depends, HTTPException, Response, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import (
    create_access_token,
    create_refresh_token,
    decode_token,
    verify_password,
)
from app.crud.user import create_user, get_user_by_email, get_user_by_id
from app.deps.auth import get_current_user_obj
from app.deps.db import get_db
from app.models.user import User
from app.schemas.user import UserCreate, UserRead

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/login")
async def login(
    response: Response,
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Authenticate with email + password.

    Returns an access token in the JSON body and sets the refresh token as an
    httpOnly secure cookie.  The access token should be held in memory by the
    frontend and sent as `Authorization: Bearer <token>` on subsequent requests.
    """
    user: User | None = await get_user_by_email(db, email=form_data.username)
    if user is None or not verify_password(user.hashed_password, form_data.password):
        # Intentionally vague error to prevent user enumeration
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is inactive",
        )

    access_token = create_access_token(subject=user.id)
    refresh_token = create_refresh_token(subject=user.id)

    # Set the refresh token as an httpOnly cookie so it is inaccessible to JS.
    response.set_cookie(
        key="refresh_token",
        value=refresh_token,
        httponly=True,
        secure=settings.environment != "development",
        samesite="strict",
        max_age=settings.refresh_token_expire_days * 86_400,
    )

    return {"access_token": access_token, "token_type": "bearer"}


@router.post("/refresh")
async def refresh_token(
    refresh_token: str | None = Cookie(default=None),
    db: AsyncSession = Depends(get_db),
) -> dict:
    """
    Issue a new access token using the refresh token from the httpOnly cookie.

    This endpoint is called by the frontend when a request returns 401, before
    redirecting the user to the login page.
    """
    if refresh_token is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="No refresh token present",
        )

    payload = decode_token(refresh_token)
    if payload.typ != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token type mismatch",
        )

    user: User | None = await get_user_by_id(db, user_id=int(payload.sub))
    if user is None or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
        )

    return {
        "access_token": create_access_token(subject=user.id),
        "token_type": "bearer",
    }


@router.post("/logout")
async def logout(response: Response) -> dict:
    """Clear the refresh token cookie to log the user out server-side."""
    response.delete_cookie("refresh_token")
    return {"detail": "Logged out"}


@router.post("/register", response_model=UserRead, status_code=status.HTTP_201_CREATED)
async def register(
    user_in: UserCreate,
    db: AsyncSession = Depends(get_db),
) -> User:
    """
    Register a new user.

    Disabled in non-development environments — in production, create users via
    an admin CLI command or a protected admin API endpoint.
    """
    if settings.environment != "development":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Open registration is disabled. Contact your administrator.",
        )
    existing = await get_user_by_email(db, email=user_in.email)
    if existing is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="An account with this email already exists",
        )
    return await create_user(db, obj_in=user_in)


@router.get("/me", response_model=UserRead)
async def read_me(current_user: User = Depends(get_current_user_obj)) -> User:
    """Return the profile of the currently authenticated user."""
    return current_user
