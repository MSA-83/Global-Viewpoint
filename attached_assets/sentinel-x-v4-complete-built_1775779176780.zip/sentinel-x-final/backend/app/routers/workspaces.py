# backend/app/routers/workspaces.py
"""
Mission Workspaces router for Sentinel-X.

Same root cause as events.py: `Depends(get_current_user)` returns an `int`,
but the handler passed `user.id` and `owner_id=user.id` to the CRUD layer.
An `int` does have a value — but it is not the UUID the CRUD layer expects.
More importantly, the pattern is semantically wrong: we need the full User
object to future-proof this router for role checks and tenant scoping.

Switched to `Depends(get_current_user_obj)` throughout.
"""
from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.deps.auth import get_current_user_obj   # ← was get_current_user
from app.deps.db import get_db
from app.models.user import User
from app.schemas.workspace import WorkspaceCreate, WorkspaceRead
from app.crud import workspace as workspace_crud

router = APIRouter(prefix="/workspaces", tags=["workspaces"])


@router.get("/", response_model=List[WorkspaceRead])
async def list_my_workspaces(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user_obj),
) -> List:
    """Return all workspaces owned by the authenticated user."""
    return await workspace_crud.list_workspaces(db=db, owner_id=user.id)


@router.post(
    "/",
    response_model=WorkspaceRead,
    status_code=status.HTTP_201_CREATED,
)
async def create_workspace(
    payload: WorkspaceCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user_obj),
) -> object:
    """Create a new mission workspace for the authenticated user."""
    return await workspace_crud.create_workspace(
        db=db, owner_id=user.id, workspace_in=payload
    )


@router.get("/{workspace_id}", response_model=WorkspaceRead)
async def get_workspace(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user_obj),
) -> object:
    """Return a single workspace, enforcing ownership."""
    ws = await workspace_crud.get_workspace(db=db, workspace_id=workspace_id)
    if ws is None or str(ws.owner_id) != str(user.id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Workspace not found",
        )
    return ws


@router.delete("/{workspace_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_workspace(
    workspace_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user_obj),
) -> None:
    """Soft-delete a workspace. Only the owner may delete it."""
    ws = await workspace_crud.get_workspace(db=db, workspace_id=workspace_id)
    if ws is None or str(ws.owner_id) != str(user.id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Workspace not found",
        )
    await workspace_crud.delete_workspace(db=db, workspace=ws)
