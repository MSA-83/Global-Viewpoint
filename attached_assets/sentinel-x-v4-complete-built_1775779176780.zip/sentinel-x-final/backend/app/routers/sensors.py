# backend/app/routers/sensors.py
from typing import List
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from ..deps.db import get_db
from ..deps.auth import require_role
from ..models.user import UserRole
from ..schemas.sensor import SensorCreate, SensorRead
from ..crud import sensor as sensor_crud

router = APIRouter(prefix="/sensors", tags=["sensors"])

@router.get("/", response_model=List[SensorRead])
async def list_sensors(
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    user=Depends(require_role(UserRole.OPERATOR)),
):
    # Tenant scoping is applied inside CRUD
    return await sensor_crud.list_sensors(db=db, tenant_id=user.tenant_id, skip=skip, limit=limit)

@router.post("/", response_model=SensorRead, status_code=status.HTTP_201_CREATED)
async def create_sensor(
    payload: SensorCreate,
    db: AsyncSession = Depends(get_db),
    user=Depends(require_role(UserRole.COMMANDER)),
):
    return await sensor_crud.create_sensor(db=db, tenant_id=user.tenant_id, sensor_in=payload)

@router.get("/{sensor_id}", response_model=SensorRead)
async def get_sensor(
    sensor_id: str,
    db: AsyncSession = Depends(get_db),
    user=Depends(require_role(UserRole.OPERATOR)),
):
    sensor = await sensor_crud.get_sensor(db=db, tenant_id=user.tenant_id, sensor_id=sensor_id)
    if not sensor:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Sensor not found")
    return sensor
