# backend/app/routers/health.py
"""
Health and readiness probes for Sentinel-X.

Why these endpoints must be unauthenticated
-------------------------------------------
Kubernetes liveness and readiness probes send plain GET requests with no
Authorization header. If the health endpoint requires a JWT, every probe
returns 401, Kubernetes marks the pod as unhealthy, and it restarts the
container in an infinite crash loop.

The rule is simple: /health and /ready are operational probes for
infrastructure, not API endpoints for users.  They check real dependencies
(database, Redis) but must never require any authentication credential.

Three-tier probe design
-----------------------
/health   — liveness probe.  Returns 200 if the process is alive and can
            reach its dependencies.  Kubernetes restarts the container if
            this returns 5xx.

/ready    — readiness probe.  Returns 200 only when the app is fully
            initialised and ready to serve traffic.  Kubernetes removes the
            pod from the load-balancer if this fails, without restarting it.

/version  — returns build metadata for observability dashboards.
            Not a Kubernetes probe target — just a convenience endpoint.
"""
from __future__ import annotations

import time

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.deps.db import get_db

router = APIRouter(tags=["observability"])

# Record the time the process started so /version can report uptime.
_START_TIME = time.time()


@router.get("/health", summary="Liveness probe")
async def health_check(db: AsyncSession = Depends(get_db)) -> dict:
    """
    Liveness probe — no authentication required.

    Tests basic database reachability by executing `SELECT 1`.  If the
    database is unreachable this returns 503, which triggers a Kubernetes
    container restart.
    """
    try:
        await db.execute(text("SELECT 1"))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Database unreachable: {exc}",
        )
    return {"status": "healthy", "environment": settings.environment}


@router.get("/ready", summary="Readiness probe")
async def readiness_check(db: AsyncSession = Depends(get_db)) -> dict:
    """
    Readiness probe — no authentication required.

    A pod that is not ready is temporarily removed from the Kubernetes
    Service endpoint list, ensuring it doesn't receive traffic it cannot
    handle (e.g. during startup migrations or rolling deployments).
    """
    try:
        await db.execute(text("SELECT 1"))
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Not ready — database unavailable",
        )
    return {"status": "ready"}


@router.get("/version", summary="Build and version metadata")
async def version_info() -> dict:
    """Return build metadata. Useful for confirming which version is deployed."""
    return {
        "app": settings.app_name,
        "version": "1.0.0",
        "environment": settings.environment,
        "uptime_seconds": round(time.time() - _START_TIME, 1),
    }
