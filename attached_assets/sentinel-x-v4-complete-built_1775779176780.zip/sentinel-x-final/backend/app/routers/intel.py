# backend/app/routers/intel.py
"""
Intelligence aggregation router for Sentinel-X.

This router is the "single pane of glass" endpoint: given a geographic coordinate
and radius, it concurrently fans out to every configured external intelligence
source and returns a unified, multi-domain picture of activity in that area.

Design philosophy
-----------------
The core challenge is latency: each upstream API has its own response time, and
calling them sequentially would mean the endpoint takes N seconds where N is the
sum of all individual timeouts. We use asyncio.gather() with return_exceptions=True
to call all adapters concurrently. Each adapter already handles its own error
conditions and returns an empty list/dict on failure, so a single unavailable
upstream never poisons the entire response. The `return_exceptions=True` flag means
a Python-level exception in one adapter also cannot propagate up to cancel the
others.

Domain coverage
---------------
The endpoint aggregates seven intelligence domains in one call:

  WEATHER     — OpenWeatherMap current conditions
  AVIATION    — AVWX SIGMETs (airspace hazards) + nearest station METARs
  MARITIME    — AISStream vessel snapshot within the bounding box
  NATURAL     — NASA EONET natural events (fires, storms, floods) with spatial filter
  CYBER       — Shodan internet-exposed hosts and known vulnerabilities
  ORBITAL     — Space-Track TLE data for selected NORAD IDs (configurable)
  FISHING     — Global Fishing Watch vessel activity
"""
from __future__ import annotations

import asyncio
import math
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status

from app.deps.auth import require_role
from app.models.user import UserRole
from app.external.nasa import fetch_natural_events
from app.external.openweather import fetch_weather
from app.external.space_track import fetch_tle_for_norad_ids
from app.external.global_fishing_watch import fetch_fishing_activity
from app.external.aisstream import fetch_vessels_in_bbox
from app.external.shodan_adapter import fetch_hosts_near_coordinate
from app.external.avwx import fetch_active_sigmets, fetch_metars_near_coordinate
from app.core.logging import logger

router = APIRouter(prefix="/intel", tags=["intel"])

# Default NORAD IDs to track in the orbital layer. In production, this should
# be driven by the operator's workspace configuration rather than hardcoded.
_DEFAULT_NORAD_IDS: list[int] = [
    25544,   # ISS
    43013,   # NOAA-20
    41866,   # Sentinel-3A
]

# Rough degree-to-km conversion for bounding box calculation.
# 1 degree of latitude ≈ 111 km everywhere.
# 1 degree of longitude ≈ 111 * cos(lat) km — we use the flat-earth approximation
# since our radii are small relative to Earth's curvature.
_KM_PER_DEG = 111.0


def _bbox(lat: float, lon: float, radius_km: float) -> tuple[float, float, float, float]:
    """Return (min_lat, min_lon, max_lat, max_lon) for a circular bounding box approximation."""
    delta_lat = radius_km / _KM_PER_DEG
    delta_lon = radius_km / (_KM_PER_DEG * math.cos(math.radians(lat)))
    return (
        max(lat - delta_lat, -90.0),
        max(lon - delta_lon, -180.0),
        min(lat + delta_lat, 90.0),
        min(lon + delta_lon, 180.0),
    )


@router.get("/overview")
async def intel_overview(
    lat: float = Query(..., ge=-90, le=90, description="Centre latitude of the area of interest"),
    lon: float = Query(..., ge=-180, le=180, description="Centre longitude of the area of interest"),
    radius_km: float = Query(250.0, gt=0, le=2000, description="Radius of the area of interest in kilometres"),
    domains: list[str] = Query(
        default=["weather", "aviation", "maritime", "natural", "cyber", "fishing"],
        description="Which intelligence domains to include in the response",
    ),
    user=Depends(require_role(UserRole.ANALYST)),
) -> dict[str, Any]:
    """
    Return a multi-domain intelligence overview for a geographic area.

    All configured upstream sources are queried concurrently. Sources that are
    unavailable or unconfigured (missing API key) return empty results rather
    than causing the endpoint to fail.

    The `domains` query parameter lets the frontend request only the layers
    it needs, which reduces latency for focused views — for example, a maritime
    operator might request only `domains=maritime,weather` when monitoring a
    specific sea lane.

    Requires at minimum the ANALYST role, since this endpoint aggregates data
    from multiple external intelligence sources.
    """
    domain_set = set(d.lower() for d in domains)
    min_lat, min_lon, max_lat, max_lon = _bbox(lat, lon, radius_km)

    # Build the list of coroutines to run concurrently.
    # We use a dict of named tasks so results are easy to map back.
    tasks: dict[str, asyncio.Task] = {}

    async def _gather_named(**coros) -> dict[str, Any]:
        """Run named coroutines concurrently and return results by name."""
        names = list(coros.keys())
        results = await asyncio.gather(
            *coros.values(), return_exceptions=True
        )
        output: dict[str, Any] = {}
        for name, result in zip(names, results):
            if isinstance(result, BaseException):
                logger.warning(
                    "intel_overview: adapter raised exception",
                    domain=name,
                    error=str(result),
                )
                output[name] = []
            else:
                output[name] = result
        return output

    coros: dict[str, Any] = {}

    if "weather" in domain_set:
        coros["weather"] = fetch_weather(lat=lat, lon=lon)

    if "aviation" in domain_set:
        coros["sigmets"] = fetch_active_sigmets()
        coros["metars"] = fetch_metars_near_coordinate(
            lat=lat, lon=lon, radius_km=min(radius_km, 300)
        )

    if "maritime" in domain_set:
        coros["vessels"] = fetch_vessels_in_bbox(
            min_lat=min_lat,
            min_lon=min_lon,
            max_lat=max_lat,
            max_lon=max_lon,
            timeout_seconds=8.0,
        )

    if "natural" in domain_set:
        coros["natural_events"] = fetch_natural_events(
            lat=lat, lon=lon, radius_km=radius_km
        )

    if "cyber" in domain_set:
        coros["cyber_hosts"] = fetch_hosts_near_coordinate(
            lat=lat, lon=lon, radius_km=min(radius_km, 500)
        )

    if "fishing" in domain_set:
        coros["fishing_vessels"] = fetch_fishing_activity(
            lat=lat, lon=lon, radius_km=radius_km
        )

    # Orbital data is requested globally rather than geospatially — TLE data
    # doesn't filter by ground track in real time.
    if "orbital" in domain_set:
        coros["orbital"] = fetch_tle_for_norad_ids(_DEFAULT_NORAD_IDS)

    gathered = await _gather_named(**coros)

    return {
        "query": {
            "lat": lat,
            "lon": lon,
            "radius_km": radius_km,
            "bbox": {"min_lat": min_lat, "min_lon": min_lon, "max_lat": max_lat, "max_lon": max_lon},
            "domains": sorted(domain_set),
        },
        "weather": gathered.get("weather", {}),
        "aviation": {
            "sigmets": gathered.get("sigmets", []),
            "metars": gathered.get("metars", []),
        },
        "maritime": {
            "vessels": gathered.get("vessels", []),
            "vessel_count": len(gathered.get("vessels", [])),
        },
        "natural_events": gathered.get("natural_events", []),
        "cyber": {
            "exposed_hosts": gathered.get("cyber_hosts", []),
            "host_count": len(gathered.get("cyber_hosts", [])),
        },
        "fishing": gathered.get("fishing_vessels", []),
        "orbital": gathered.get("orbital", []),
    }


@router.get("/sigmet", summary="Active SIGMETs globally")
async def get_active_sigmets(
    hazard: str | None = Query(None, description="Filter by hazard type: TURB, ICE, VA, TC"),
    user=Depends(require_role(UserRole.OPERATOR)),
) -> list[dict[str, Any]]:
    """Return all currently active SIGMETs, optionally filtered by hazard type."""
    return await fetch_active_sigmets(hazard=hazard)


@router.get("/cyber/host/{ip_address}", summary="Shodan intel for a specific IP")
async def get_host_intel(
    ip_address: str,
    user=Depends(require_role(UserRole.ANALYST)),
) -> dict[str, Any]:
    """Return Shodan's intelligence profile for a specific IP address."""
    from app.external.shodan_adapter import fetch_host_intel
    result = await fetch_host_intel(ip_address)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No Shodan data found for {ip_address}",
        )
    return result


@router.get("/maritime/vessels", summary="Vessel snapshot for a bounding box")
async def get_vessels_in_area(
    lat: float = Query(..., ge=-90, le=90),
    lon: float = Query(..., ge=-180, le=180),
    radius_km: float = Query(100.0, gt=0, le=500),
    user=Depends(require_role(UserRole.OPERATOR)),
) -> dict[str, Any]:
    """Return a real-time snapshot of vessels within the specified area."""
    min_lat, min_lon, max_lat, max_lon = _bbox(lat, lon, radius_km)
    vessels = await fetch_vessels_in_bbox(
        min_lat=min_lat,
        min_lon=min_lon,
        max_lat=max_lat,
        max_lon=max_lon,
        timeout_seconds=10.0,
    )
    return {"vessel_count": len(vessels), "vessels": vessels}
