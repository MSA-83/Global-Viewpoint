# backend/app/crud/event.py
"""
Event CRUD operations for Sentinel-X.

Events are the core data type of the platform — every detected anomaly, sensor
reading, intel report, and system notification flows through this table. The
design priorities are:

  Append-only writes: events are never updated after creation. They are
  immutable records of what happened and when. The `parent_event_id` and
  `correlation_id` fields allow relationships between events to be expressed
  without mutating existing rows.

  Temporal queries: the most common access pattern is a sliding time window
  (from_ts → to_ts), so `occurred_at` is indexed and all list queries are
  ordered by it descending (newest first).

  Tenant isolation: every query scopes to `tenant_id` when provided, ensuring
  operators from one organisation never see another's events.

Missing from the original: `create_event` was exported by crud/__init__.py
but never implemented. Any code path that tried to write an event would have
raised ImportError.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.event import Event, EventSeverity, EventType
from app.schemas.event import EventCreate


async def list_events(
    db: AsyncSession,
    from_ts: datetime,
    to_ts: datetime,
    tenant_id: Optional[UUID] = None,
    severity: Optional[str] = None,
    event_type: Optional[str] = None,
    limit: int = 500,
) -> List[Event]:
    """
    Return events within [from_ts, to_ts), newest first.

    Results are capped at `limit` rows (default 500). For large playback
    windows, the caller should paginate by advancing `from_ts` to the
    `occurred_at` of the last returned event.
    """
    stmt = select(Event).where(
        Event.deleted_at.is_(None),
        Event.occurred_at >= from_ts,
        Event.occurred_at < to_ts,
    )
    if tenant_id is not None:
        stmt = stmt.where(Event.tenant_id == tenant_id)
    if severity:
        stmt = stmt.where(Event.severity == EventSeverity(severity))
    if event_type:
        stmt = stmt.where(Event.event_type == EventType(event_type))
    stmt = stmt.order_by(Event.occurred_at.desc()).limit(limit)
    result = await db.execute(stmt)
    return list(result.scalars().all())


# Alias so crud/__init__.py can export both names.
get_events = list_events


async def get_event(db: AsyncSession, event_id: str | UUID) -> Optional[Event]:
    """Return a single event by primary key, or None if not found / soft-deleted."""
    result = await db.execute(
        select(Event).where(
            Event.id == event_id,
            Event.deleted_at.is_(None),
        )
    )
    return result.scalar_one_or_none()


async def create_event(
    db: AsyncSession,
    event_in: EventCreate,
    tenant_id: Optional[UUID] = None,
) -> Event:
    """
    Persist a new operational event.

    The `payload` field accepts an arbitrary dict which is stored as JSONB.
    The `geometry` field accepts a GeoJSON-compatible dict; GeoAlchemy2
    handles the conversion to a PostGIS geometry on the way in.

    Note: geometry is passed as a WKT string or GeoJSON string to avoid
    requiring the caller to construct a WKBElement. SQLAlchemy / GeoAlchemy2
    will convert it during the flush.
    """
    # Serialise the payload dict to JSON string if provided, since the Avro
    # schema stores payload as a nullable string field.
    payload_val = event_in.payload
    if isinstance(payload_val, dict):
        payload_val = json.dumps(payload_val)

    # Handle GeoJSON geometry: accept dict, convert to WKT for GeoAlchemy2
    geometry_val = None
    if event_in.geometry is not None:
        try:
            from shapely.geometry import shape
            from geoalchemy2.shape import from_shape
            geometry_val = from_shape(shape(event_in.geometry), srid=4326)
        except Exception:
            geometry_val = None

    obj = Event(
        sensor_id=event_in.sensor_id,
        event_type=EventType(event_in.event_type),
        severity=EventSeverity(event_in.severity),
        title=event_in.title,
        description=event_in.description,
        geometry=geometry_val,
        payload=payload_val,
        correlation_id=event_in.correlation_id,
        parent_event_id=event_in.parent_event_id,
        occurred_at=event_in.occurred_at,
        tenant_id=tenant_id,
        classification=event_in.classification or "UNCLASSIFIED",
    )
    db.add(obj)
    await db.flush()       # ← flush only; get_db commits when the request succeeds
    await db.refresh(obj)
    return obj
