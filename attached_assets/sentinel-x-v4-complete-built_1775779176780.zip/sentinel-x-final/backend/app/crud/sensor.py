# backend/app/crud/sensor.py
"""
Sensor CRUD operations for Sentinel-X.

Transaction discipline
----------------------
Every write function here uses `await db.flush()` instead of `await db.commit()`.
This is a deliberate architectural choice that aligns with how the `get_db`
FastAPI dependency manages sessions.

The `get_db` dependency opens a session, yields it to the request handler,
and then either commits (on success) or rolls back (on any exception) before
closing the session. If a CRUD function called `db.commit()` directly, it would
end the transaction prematurely — meaning:

  1. A second CRUD call in the same request cannot be part of the same atomic unit.
  2. If the handler raises an exception after the early commit, `get_db`'s rollback
     cannot undo what was already committed. Partial writes reach the database.

`db.flush()` writes the pending SQL to the database server within the open
transaction without issuing a COMMIT. The row becomes visible to subsequent
queries in the same session, `db.refresh(obj)` works correctly, but the write
is not yet durable. Durability comes from `get_db`'s commit when the request
completes successfully.

The original code called `await db.commit()` in create_sensor, which would have
caused these issues in any request that tried to create a sensor and then do
anything else with the database.

Missing functions
-----------------
The crud/__init__.py re-exported `get_sensors`, `update_sensor`, and
`delete_sensor` but none of them were implemented. Any route that imported
those names would have raised an ImportError immediately.
"""
from __future__ import annotations

from typing import List, Optional
from uuid import UUID

from geoalchemy2.shape import from_shape
from shapely.geometry import Point
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.sensor import Sensor, SensorStatus
from app.schemas.sensor import SensorCreate, SensorUpdate


async def list_sensors(
    db: AsyncSession,
    tenant_id: Optional[UUID],
    skip: int = 0,
    limit: int = 50,
) -> List[Sensor]:
    """Return a paginated, tenant-scoped list of active sensors."""
    stmt = select(Sensor).where(Sensor.deleted_at.is_(None))
    if tenant_id is not None:
        stmt = stmt.where(Sensor.tenant_id == tenant_id)
    stmt = stmt.order_by(Sensor.created_at.desc()).offset(skip).limit(limit)
    result = await db.execute(stmt)
    return list(result.scalars().all())


# Alias so crud/__init__.py can export both names without confusion.
get_sensors = list_sensors


async def get_sensor(
    db: AsyncSession,
    sensor_id: str | UUID,
    tenant_id: Optional[UUID] = None,
) -> Optional[Sensor]:
    """Return a single active sensor by ID, optionally enforcing tenant scope."""
    stmt = select(Sensor).where(
        Sensor.id == sensor_id,
        Sensor.deleted_at.is_(None),
    )
    if tenant_id is not None:
        stmt = stmt.where(Sensor.tenant_id == tenant_id)
    result = await db.execute(stmt)
    return result.scalar_one_or_none()


async def create_sensor(
    db: AsyncSession,
    sensor_in: SensorCreate,
    tenant_id: Optional[UUID] = None,
) -> Sensor:
    """
    Persist a new sensor, converting the lat/lon pair to a PostGIS Point geometry.

    `from_shape(Point(lon, lat), srid=4326)` produces the WKBElement that
    GeoAlchemy2 stores as a PostGIS geometry column.  Note the argument order:
    Shapely's Point constructor takes (x, y) = (longitude, latitude), not the
    intuitive (lat, lon) order used by most mapping APIs.
    """
    geom = from_shape(Point(sensor_in.longitude, sensor_in.latitude), srid=4326)
    obj = Sensor(
        name=sensor_in.name,
        domain=sensor_in.domain,
        status=sensor_in.status,
        platform=sensor_in.platform,
        capabilities=sensor_in.capabilities,
        description=sensor_in.description,
        external_id=sensor_in.external_id,
        location=geom,
        tenant_id=tenant_id,
    )
    db.add(obj)
    await db.flush()       # ← was db.commit(); see module docstring
    await db.refresh(obj)
    return obj


async def update_sensor(
    db: AsyncSession,
    sensor: Sensor,
    sensor_in: SensorUpdate,
) -> Sensor:
    """
    Apply a partial update to a sensor row.

    Only fields explicitly provided in the request body (exclude_unset=True) are
    written. If the caller sends `{"status": "offline"}`, only `status` changes;
    every other field retains its current database value.

    If a new lat/lon is provided, the geometry column is regenerated accordingly.
    """
    update_data = sensor_in.model_dump(exclude_unset=True)

    # Handle coordinate update: if either lat or lon is being changed, we need
    # both values to reconstruct the Point geometry.
    new_lat = update_data.pop("latitude", None)
    new_lon = update_data.pop("longitude", None)
    if new_lat is not None or new_lon is not None:
        # Fall back to existing coordinates if only one axis was provided.
        try:
            from geoalchemy2.shape import to_shape
            existing_point = to_shape(sensor.location)
            lat = new_lat if new_lat is not None else existing_point.y
            lon = new_lon if new_lon is not None else existing_point.x
        except Exception:
            lat = new_lat or 0.0
            lon = new_lon or 0.0
        update_data["location"] = from_shape(Point(lon, lat), srid=4326)

    for field, value in update_data.items():
        setattr(sensor, field, value)

    db.add(sensor)
    await db.flush()
    await db.refresh(sensor)
    return sensor


async def delete_sensor(db: AsyncSession, sensor: Sensor) -> Sensor:
    """
    Soft-delete a sensor by setting deleted_at and marking it OFFLINE.

    We set status=OFFLINE as a belt-and-suspenders measure: even if a query
    accidentally omits the `deleted_at IS NULL` filter, it will never show a
    soft-deleted sensor as operational.
    """
    from datetime import datetime, timezone
    sensor.deleted_at = datetime.now(timezone.utc)
    sensor.status = SensorStatus.OFFLINE
    db.add(sensor)
    await db.flush()
    await db.refresh(sensor)
    return sensor
