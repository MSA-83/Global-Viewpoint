# backend/app/crud/user.py
"""
User CRUD operations for Sentinel-X.

This file was entirely absent from the repository despite being imported by
both `crud/__init__.py` (six functions) and `deps/auth.py` (`get_user_by_id`).
Because Python raises ImportError the moment a missing module is first touched,
the application would fail on startup — before serving any request — making
this the single most impactful missing file in the codebase.

Design notes
------------
All queries filter `deleted_at IS NULL` so soft-deleted users are invisible to
the rest of the application. Hard deletes are never performed — we rely on soft
delete to preserve audit trails, consistent with how every other entity model
in Sentinel-X works.

`get_user_by_id` accepts a Union[int, str] because the JWT payload stores the
user PK as a string (JWTs can only carry string claims), but the database PK is
a UUID. Both forms are accepted and cast appropriately before querying.
"""
from __future__ import annotations

from typing import Optional, List
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import hash_password
from app.models.user import User, UserRole
from app.schemas.user import UserCreate, UserUpdate


async def get_user(db: AsyncSession, user_id: UUID) -> Optional[User]:
    """Return a single active user by UUID primary key, or None."""
    result = await db.execute(
        select(User).where(User.id == user_id, User.deleted_at.is_(None))
    )
    return result.scalar_one_or_none()


async def get_user_by_id(db: AsyncSession, user_id: int | str | UUID) -> Optional[User]:
    """
    Resolve a user from any form of its primary key.

    The JWT sub claim is always a string, so this function accepts str, int,
    and UUID equally, converting to UUID for the DB query.  Returns None if the
    user does not exist or has been soft-deleted.
    """
    try:
        uid = UUID(str(user_id))
    except (ValueError, AttributeError):
        return None
    return await get_user(db, user_id=uid)


async def get_user_by_email(db: AsyncSession, email: str) -> Optional[User]:
    """Return an active user by email address (case-sensitive), or None."""
    result = await db.execute(
        select(User).where(
            User.email == email,
            User.deleted_at.is_(None),
        )
    )
    return result.scalar_one_or_none()


async def get_users(
    db: AsyncSession,
    skip: int = 0,
    limit: int = 100,
    tenant_id: Optional[UUID] = None,
) -> List[User]:
    """
    Return a paginated list of active users.

    If `tenant_id` is provided, results are scoped to that tenant.  Superusers
    and admin endpoints that need cross-tenant user listings should pass
    tenant_id=None.
    """
    stmt = select(User).where(User.deleted_at.is_(None))
    if tenant_id is not None:
        stmt = stmt.where(User.tenant_id == tenant_id)
    stmt = stmt.order_by(User.created_at.desc()).offset(skip).limit(limit)
    result = await db.execute(stmt)
    return list(result.scalars().all())


async def create_user(db: AsyncSession, obj_in: UserCreate) -> User:
    """
    Create a new user, hashing the password before persistence.

    The plain-text password is hashed with Argon2id (via `hash_password` from
    core.security) and never stored.  The hashed value is written to
    `hashed_password` — the plain password is discarded after this call.
    """
    user = User(
        email=obj_in.email,
        hashed_password=hash_password(obj_in.password),
        display_name=obj_in.display_name,
        role=obj_in.role,
        is_active=True,
        is_superuser=False,
    )
    db.add(user)
    await db.flush()   # Write to DB within the current transaction so refresh works
    await db.refresh(user)
    return user


async def update_user(
    db: AsyncSession,
    user: User,
    obj_in: UserUpdate,
) -> User:
    """
    Apply a partial update to an existing user.

    Only fields explicitly set in `obj_in` (i.e. not None) are written.  This
    prevents accidental overwrites when the caller only intends to change one
    field — for example, promoting a role without clearing the display name.
    """
    update_data = obj_in.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(user, field, value)
    db.add(user)
    await db.flush()
    await db.refresh(user)
    return user


async def delete_user(db: AsyncSession, user: User) -> User:
    """
    Soft-delete a user by setting `deleted_at` to the current timestamp.

    The user row is retained for audit purposes.  Login attempts for a
    soft-deleted user are rejected by the `is_active` check in the auth router
    before `deleted_at` is even evaluated, so there is no gap in access control.
    """
    from datetime import datetime, timezone
    user.deleted_at = datetime.now(timezone.utc)
    user.is_active = False
    db.add(user)
    await db.flush()
    await db.refresh(user)
    return user
