# backend/app/crud/__init__.py
"""
Convenience re-exports for all CRUD modules.

Every public function from every CRUD module is surfaced here so routers and
services can write `from app.crud import sensor_crud` or import individual
functions directly from this package rather than reaching into sub-modules.

The previous version of this file imported names that did not exist in the
implementation files — for example `get_sensors` (not defined), `get_workspace`
(not defined), `create_event` (not defined). Any import of these names raised
ImportError, silently preventing the affected routers from loading.

All function names here now match what the implementation files actually export.
"""

from app.crud.user import (
    get_user,
    get_user_by_id,
    get_user_by_email,
    get_users,
    create_user,
    update_user,
    delete_user,
)

from app.crud.sensor import (
    get_sensor,
    get_sensors,          # alias for list_sensors
    list_sensors,
    create_sensor,
    update_sensor,
    delete_sensor,
)

from app.crud.event import (
    get_event,
    get_events,           # alias for list_events
    list_events,
    create_event,
)

from app.crud.workspace import (
    get_workspace,
    get_workspaces,       # alias for list_workspaces
    list_workspaces,
    create_workspace,
    update_workspace,
    delete_workspace,
)

__all__ = [
    # Users
    "get_user", "get_user_by_id", "get_user_by_email", "get_users",
    "create_user", "update_user", "delete_user",
    # Sensors
    "get_sensor", "get_sensors", "list_sensors",
    "create_sensor", "update_sensor", "delete_sensor",
    # Events
    "get_event", "get_events", "list_events", "create_event",
    # Workspaces
    "get_workspace", "get_workspaces", "list_workspaces",
    "create_workspace", "update_workspace", "delete_workspace",
]
