# backend/app/crud/workspace.py
"""
Mission Workspace CRUD operations for Sentinel-X.

A MissionWorkspace is a saved view configuration: a named snapshot of which
map layers are active, what filters are applied, and which sensors are being
watched. Operators create workspaces for recurring missions (e.g. "North Sea
Maritime Patrol") so they don't have to reconfigure the UI every shift.

The original implementation was missing `get_workspace`, `get_workspaces`,
`update_workspace`, and `delete_workspace` — all of which were exported by
crud/__init__.py and referenced by the workspaces router. The router I rewrote
in the previous session calls `workspace_crud.get_workspace(...)` and
`workspace_crud.delete_workspace(...)`, so this file must define both.

Transaction discipline: `await db.flush()` not `await db.commit()`. See the
sensor.py module docstring for the full explanation.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.workspace import MissionWorkspace
from app.schemas.workspace import WorkspaceCreate, WorkspaceUpdate


async def list_workspaces(
    db: AsyncSession,
    owner_id: UUID | str,
) -> List[MissionWorkspace]:
    """Return all non-deleted workspaces owned by the given user."""
    stmt = select(MissionWorkspace).where(
        MissionWorkspace.owner_id == owner_id,
        MissionWorkspace.deleted_at.is_(None),
    ).order_by(MissionWorkspace.created_at.desc())
    result = await db.execute(stmt)
    return list(result.scalars().all())


# Export alias matching crud/__init__.py
get_workspaces = list_workspaces


async def get_workspace(
    db: AsyncSession,
    workspace_id: str | UUID,
) -> Optional[MissionWorkspace]:
    """Return a single workspace by ID, or None if not found / soft-deleted."""
    result = await db.execute(
        select(MissionWorkspace).where(
            MissionWorkspace.id == workspace_id,
            MissionWorkspace.deleted_at.is_(None),
        )
    )
    return result.scalar_one_or_none()


async def create_workspace(
    db: AsyncSession,
    workspace_in: WorkspaceCreate,
    owner_id: UUID | str,
) -> MissionWorkspace:
    """Persist a new workspace with the given owner."""
    obj = MissionWorkspace(
        name=workspace_in.name,
        description=workspace_in.description,
        config=workspace_in.config,
        owner_id=owner_id,
    )
    db.add(obj)
    await db.flush()       # ← was db.commit()
    await db.refresh(obj)
    return obj


async def update_workspace(
    db: AsyncSession,
    workspace: MissionWorkspace,
    workspace_in: WorkspaceUpdate,
) -> MissionWorkspace:
    """
    Apply a partial update to an existing workspace.

    This is the primary way operators save changes to their view configuration.
    The `config` field is a free-form JSONB blob, so the entire config dict is
    replaced on update — no deep-merging is performed server-side.
    """
    update_data = workspace_in.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(workspace, field, value)
    db.add(workspace)
    await db.flush()
    await db.refresh(workspace)
    return workspace


async def delete_workspace(
    db: AsyncSession,
    workspace: MissionWorkspace,
) -> MissionWorkspace:
    """Soft-delete a workspace by stamping deleted_at."""
    workspace.deleted_at = datetime.now(timezone.utc)
    db.add(workspace)
    await db.flush()
    await db.refresh(workspace)
    return workspace
