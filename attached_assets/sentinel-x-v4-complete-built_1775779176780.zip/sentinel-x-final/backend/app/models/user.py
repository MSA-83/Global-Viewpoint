# backend/app/models/user.py
from enum import Enum

from sqlalchemy import Boolean, Column, Enum as SAEnum, String
from sqlalchemy.dialects.postgresql import UUID

from .base import BaseMixin


class UserRole(str, Enum):
    OPERATOR = "operator"
    ANALYST = "analyst"
    COMMANDER = "commander"
    ADMIN = "admin"


class User(BaseMixin):
    """User account with RBAC for Sentinel-X."""

    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)

    is_active = Column(Boolean, nullable=False, default=True, server_default="true")
    is_superuser = Column(Boolean, nullable=False, default=False, server_default="false")

    role = Column(
        SAEnum(UserRole, name="user_role"),
        nullable=False,
        default=UserRole.OPERATOR,
        server_default=UserRole.OPERATOR.value,
    )

    display_name = Column(String(128), nullable=True)
