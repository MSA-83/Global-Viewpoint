# backend/app/models/event.py
from enum import Enum

from geoalchemy2 import Geometry
from sqlalchemy import Column, DateTime, Enum as SAEnum, ForeignKey, JSON, String
from sqlalchemy.dialects.postgresql import UUID

from .base import BaseMixin


class EventType(str, Enum):
    DETECTION = "detection"
    ALERT = "alert"
    TRACK_UPDATE = "track_update"
    INTEL_REPORT = "intel_report"
    SYSTEM = "system"


class EventSeverity(str, Enum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Event(BaseMixin):
    """Operational event emitted by sensors or external systems."""

    sensor_id = Column(UUID(as_uuid=True), ForeignKey("sensor.id"), nullable=True, index=True)
    event_type = Column(SAEnum(EventType, name="event_type"), nullable=False, index=True)
    severity = Column(
        SAEnum(EventSeverity, name="event_severity"),
        nullable=False,
        default=EventSeverity.INFO,
        server_default=EventSeverity.INFO.value,
    )

    title = Column(String(256), nullable=False)
    description = Column(String(2048), nullable=True)

    geometry = Column(Geometry(geometry_type="GEOMETRY", srid=4326), nullable=True)
    payload = Column(JSON, nullable=True)

    correlation_id = Column(UUID(as_uuid=True), nullable=True, index=True)
    parent_event_id = Column(UUID(as_uuid=True), ForeignKey("event.id"), nullable=True)

    occurred_at = Column(DateTime(timezone=True), nullable=False, index=True)
