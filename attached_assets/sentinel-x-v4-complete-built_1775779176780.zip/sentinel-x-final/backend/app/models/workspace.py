# backend/app/models/workspace.py
from sqlalchemy import Column, ForeignKey, JSON, String
from sqlalchemy.dialects.postgresql import UUID

from .base import BaseMixin


class MissionWorkspace(BaseMixin):
    """Saved mission / operational view configuration."""

    name = Column(String(128), nullable=False, index=True)
    description = Column(String(1024), nullable=True)

    owner_id = Column(UUID(as_uuid=True), ForeignKey("user.id"), nullable=False, index=True)
    config = Column(JSON, nullable=False, server_default="{}")
