# backend/app/models/sensor.py
from enum import Enum

from geoalchemy2 import Geometry
from sqlalchemy import Column, Enum as SAEnum, JSON, String
from sqlalchemy.dialects.postgresql import UUID

from .base import BaseMixin


class SensorDomain(str, Enum):
    LAND = "land"
    MARITIME = "maritime"
    AIR = "air"
    SPACE = "space"
    CYBER = "cyber"


class SensorStatus(str, Enum):
    OPERATIONAL = "operational"
    DEGRADED = "degraded"
    OFFLINE = "offline"


class Sensor(BaseMixin):
    """Sensor/platform representation with domain, status, and location."""

    name = Column(String(128), nullable=False, index=True)
    domain = Column(SAEnum(SensorDomain, name="sensor_domain"), nullable=False, index=True)
    status = Column(
        SAEnum(SensorStatus, name="sensor_status"),
        nullable=False,
        default=SensorStatus.OPERATIONAL,
        server_default=SensorStatus.OPERATIONAL.value,
    )
    platform = Column(String(64), nullable=True, index=True)
    capabilities = Column(JSON, nullable=True)
    location = Column(Geometry(geometry_type="POINT", srid=4326), nullable=False)
    description = Column(String(512), nullable=True)
    external_id = Column(String(128), nullable=True, index=True)
