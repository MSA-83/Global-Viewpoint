# backend/app/models/base.py
"""
Base mixin providing audit columns, soft-delete, multi-tenancy, and
classification labelling for every Sentinel-X entity.

The mixin must be used alongside the SQLAlchemy DeclarativeBase defined in
db/base.py.  Every concrete model should inherit from BOTH:

    class Sensor(Base, BaseMixin):
        ...

This two-parent pattern keeps the ORM metadata registration (Base) separate
from the column definitions (BaseMixin), which is the correct SQLAlchemy 2.x
approach for shared column sets.

Why classification at the row level?
    Multi-tenant OSINT platforms often need to mark individual records as
    UNCLASSIFIED / CONFIDENTIAL / SECRET so that RBAC checks can be applied
    at query time rather than relying solely on endpoint-level guards.  This
    is far easier to retrofit at the model layer now than to add later.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

import sqlalchemy as sa
from sqlalchemy import Column, DateTime, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeMixin, declared_attr


class BaseMixin(DeclarativeMixin):
    """Column mixin applied to every Sentinel-X ORM model."""

    @declared_attr.directive
    def __tablename__(cls) -> str:  # type: ignore[override]
        # Derive the table name automatically from the class name (lowercase).
        # Override in the concrete model if a different name is needed.
        return cls.__name__.lower()

    id: sa.orm.Mapped[uuid.UUID] = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid.uuid4,
        nullable=False,
    )

    created_at: sa.orm.Mapped[datetime] = Column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        server_default=sa.func.now(),
    )

    updated_at: sa.orm.Mapped[datetime] = Column(
        DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
        onupdate=lambda: datetime.now(timezone.utc),
        server_default=sa.func.now(),
    )

    # Soft-delete: set deleted_at instead of issuing DELETE statements.
    # Queries should filter `WHERE deleted_at IS NULL` unless history is needed.
    deleted_at: sa.orm.Mapped[datetime | None] = Column(
        DateTime(timezone=True), nullable=True, default=None
    )

    # Multi-tenancy: every row is scoped to a tenant UUID.
    # NULL means "global / system record" (e.g. seeded reference data).
    tenant_id: sa.orm.Mapped[uuid.UUID | None] = Column(
        UUID(as_uuid=True),
        nullable=True,
        index=True,
    )

    # Information classification — used for display-level access control.
    # Possible values: UNCLASSIFIED, CUI, CONFIDENTIAL, SECRET, TOP_SECRET.
    classification: sa.orm.Mapped[str] = Column(
        String(16),
        nullable=False,
        default="UNCLASSIFIED",
        server_default="UNCLASSIFIED",
        index=True,
    )
