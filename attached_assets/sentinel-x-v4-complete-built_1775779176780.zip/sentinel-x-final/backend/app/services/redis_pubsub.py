# backend/app/services/redis_pubsub.py
"""
Redis Pub/Sub service for Sentinel-X real-time event fan-out.

The core problem with the original implementation
-------------------------------------------------
The original code called `aioredis.from_url(...)` inside every function call,
which means a brand-new TCP connection to Redis was opened — and eventually
closed — on each invocation.  Under any meaningful load (dozens of WebSocket
clients each receiving hundreds of events per minute), this created a
continuous stream of connection setup/teardown overhead and risked exhausting
the Redis `maxclients` limit.

The fix: a module-level connection pool
---------------------------------------
We maintain a single `redis.asyncio.ConnectionPool` that is initialised once
during application startup (via the lifespan context in main.py) and torn down
cleanly on shutdown.  All `publish_event` calls share this pool, meaning they
each borrow and return a connection rather than creating one from scratch.

For Pub/Sub subscriber connections we use a dedicated `Redis` client per
WebSocket.  This is intentional: a Pub/Sub connection is in "subscriber mode"
and cannot be shared safely with regular command traffic.  Creating one per
WebSocket is the correct pattern; the pool is for the publisher side only.

How to wire this into main.py
------------------------------
In your lifespan context:

    from app.services import redis_pubsub

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await redis_pubsub.startup()
        try:
            yield
        finally:
            await redis_pubsub.shutdown()
"""
from __future__ import annotations

import json
from typing import Any, AsyncGenerator

import redis.asyncio as aioredis
from redis.asyncio.client import PubSub

from app.core.config import settings
from app.core.logging import logger

# ---------------------------------------------------------------------------
# Module-level pool — initialised by startup(), torn down by shutdown()
# ---------------------------------------------------------------------------
_pool: aioredis.ConnectionPool | None = None
_redis: aioredis.Redis | None = None


async def startup() -> None:
    """
    Initialise the Redis connection pool.  Call once from the FastAPI lifespan
    context before the application starts serving requests.
    """
    global _pool, _redis
    _pool = aioredis.ConnectionPool.from_url(
        settings.redis_url,
        encoding="utf-8",
        decode_responses=True,
        max_connections=50,  # tune to your Redis server's maxclients setting
    )
    _redis = aioredis.Redis(connection_pool=_pool)
    # Verify the connection is reachable at startup rather than discovering
    # the problem on the first publish attempt.
    await _redis.ping()
    logger.info("Redis connection pool initialised", url=settings.redis_url)


async def shutdown() -> None:
    """Drain and close the connection pool gracefully on application shutdown."""
    global _pool, _redis
    if _redis is not None:
        await _redis.aclose()
    if _pool is not None:
        await _pool.aclose()
    _redis = None
    _pool = None
    logger.info("Redis connection pool closed")


def _get_redis() -> aioredis.Redis:
    """Return the shared Redis client.  Raises if startup() was not called."""
    if _redis is None:
        raise RuntimeError(
            "Redis is not initialised.  "
            "Ensure redis_pubsub.startup() is called in the FastAPI lifespan."
        )
    return _redis


# ---------------------------------------------------------------------------
# Publisher — borrows a connection from the shared pool
# ---------------------------------------------------------------------------

async def publish_event(channel: str, event: dict[str, Any]) -> None:
    """
    Publish a JSON-serialised event to a Redis channel.

    Subscribers (typically WebSocket handlers) will receive the message on the
    next iteration of their listen() loop.
    """
    redis = _get_redis()
    payload = json.dumps(event, default=str)
    subscribers = await redis.publish(channel, payload)
    logger.debug(
        "redis.publish",
        channel=channel,
        event_id=event.get("id"),
        subscribers=subscribers,
    )


# ---------------------------------------------------------------------------
# Subscriber — creates a dedicated PubSub connection per WebSocket
# ---------------------------------------------------------------------------

async def subscribe_to_channel(channel: str) -> PubSub:
    """
    Return a PubSub object already subscribed to the given channel.

    Each WebSocket handler should call this once, hold the returned PubSub
    object for the duration of the connection, then call:

        await pubsub.unsubscribe(channel)
        await pubsub.aclose()

    when the WebSocket disconnects.  This is safe: Pub/Sub connections are
    independent of the shared pool and carry no state that would affect other
    clients.
    """
    # We create a fresh Redis client for each subscriber so that the PubSub
    # connection is isolated from the shared command pool.
    subscriber = aioredis.Redis.from_url(
        settings.redis_url,
        encoding="utf-8",
        decode_responses=True,
    )
    pubsub: PubSub = subscriber.pubsub()
    await pubsub.subscribe(channel)
    return pubsub


async def event_generator(
    channel: str,
) -> AsyncGenerator[dict[str, Any], None]:
    """
    Async generator that yields decoded event dicts from a Redis channel.

    Usage in a WebSocket handler:

        async for event in event_generator("sentinel.events"):
            await websocket.send_json(event)
    """
    pubsub = await subscribe_to_channel(channel)
    try:
        async for message in pubsub.listen():
            if message["type"] != "message":
                continue
            try:
                yield json.loads(message["data"])
            except json.JSONDecodeError:
                logger.warning("redis.pubsub: malformed JSON in message", channel=channel)
    finally:
        await pubsub.unsubscribe(channel)
        await pubsub.aclose()
