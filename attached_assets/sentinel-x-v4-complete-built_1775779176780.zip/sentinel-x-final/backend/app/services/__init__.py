# backend/app/services/__init__.py
"""
Service layer re-exports.

BUG FIXED: The previous version imported `KafkaEventProducer`, a class that
does not exist anywhere in kafka_producer.py. The module uses an internal
`_ProducerSingleton` (private, not for import) and exposes its public API as
module-level functions: `produce_event`, `startup`, and `shutdown`.

Similarly, `redis_pubsub.py` exposes `publish_event`, `subscribe_to_channel`,
`event_generator`, `startup`, and `shutdown` as module-level functions.
"""

from .kafka_producer import produce_event, startup as kafka_startup, shutdown as kafka_shutdown
from .redis_pubsub import (
    publish_event,
    subscribe_to_channel,
    event_generator,
    startup as redis_startup,
    shutdown as redis_shutdown,
)

__all__ = [
    # Kafka
    "produce_event",
    "kafka_startup",
    "kafka_shutdown",
    # Redis
    "publish_event",
    "subscribe_to_channel",
    "event_generator",
    "redis_startup",
    "redis_shutdown",
]
