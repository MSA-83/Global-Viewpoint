# backend/app/services/kafka_producer.py
"""
Kafka event producer for Sentinel-X using Avro serialisation.

Why the original failed at startup
-----------------------------------
The original module instantiated `SerializingProducer(...)` at import time,
meaning the Kafka broker had to be reachable the moment Python first imported
the module — which, in a Docker Compose setup, is almost always before Kafka
has finished its own startup sequence.  The result was a failed import that
prevented the entire FastAPI application from starting.

The fix: lazy initialisation
-----------------------------
We wrap the producer inside a `_ProducerSingleton` class that defers the
actual connection until the first call to `produce_event()`.  The producer
instance is then cached and reused for all subsequent calls.

The `startup()` / `shutdown()` hooks integrate with the FastAPI lifespan
context so that:
  - On startup, we eagerly initialise the producer and verify the broker is
    reachable via a metadata request.
  - On shutdown, we flush the internal queue and close the producer cleanly
    so no events are silently dropped.

Avro schema
-----------
Events are serialised with a compact Avro schema.  This enforces a contract
between producers and consumers: if a consumer expects a field and the producer
stops sending it, schema evolution catches the mismatch at serialisation time
rather than silently at consumption time.  The `fastavro` library handles
serialisation without requiring a Schema Registry, which simplifies local
development while keeping the door open for a Registry in production.

Delivery callback and error handling
--------------------------------------
`_delivery_report` is called by the internal librdkafka thread pool after
each message either succeeds or fails.  On failure we log the error; in a
production system you would also increment a Prometheus counter and potentially
feed a dead-letter queue or trigger a circuit breaker.
"""
from __future__ import annotations

import threading
from io import BytesIO
from typing import Any

from fastavro import parse_schema, schemaless_writer

from app.core.config import settings
from app.core.logging import logger

# ---------------------------------------------------------------------------
# Avro schema definition
# ---------------------------------------------------------------------------
_RAW_SCHEMA: dict = {
    "namespace": "sentinel.events",
    "type": "record",
    "name": "SentinelEvent",
    "doc": "A Sentinel-X operational event, emitted by sensors or external feeds.",
    "fields": [
        {"name": "id",             "type": "string",             "doc": "UUID of the event"},
        {"name": "sensor_id",      "type": ["null", "string"],   "default": None},
        {"name": "event_type",     "type": "string"},
        {"name": "severity",       "type": "string",             "default": "info"},
        {"name": "tenant_id",      "type": ["null", "string"],   "default": None},
        {"name": "classification", "type": "string",             "default": "UNCLASSIFIED"},
        {"name": "occurred_at",    "type": "string",             "doc": "ISO-8601 timestamp"},
        {"name": "payload",        "type": ["null", "string"],   "default": None,
         "doc": "JSON-encoded domain-specific payload"},
    ],
}

_PARSED_SCHEMA = parse_schema(_RAW_SCHEMA)


def _avro_serialise(event: dict[str, Any]) -> bytes:
    """Serialise an event dict to Avro bytes using the module schema."""
    buf = BytesIO()
    schemaless_writer(buf, _PARSED_SCHEMA, event)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Lazy singleton producer
# ---------------------------------------------------------------------------

class _ProducerSingleton:
    """
    Thread-safe lazy wrapper around confluent-kafka's SerializingProducer.

    The inner producer is created on the first call to `get()` so that
    importing this module never triggers a Kafka connection attempt.
    A `threading.Lock` ensures only one thread initialises the producer even
    under concurrent request handling.
    """

    def __init__(self) -> None:
        self._producer: Any = None  # confluent_kafka.SerializingProducer
        self._lock = threading.Lock()

    def get(self):  # -> SerializingProducer
        if self._producer is not None:
            return self._producer
        with self._lock:
            if self._producer is None:
                try:
                    from confluent_kafka import SerializingProducer
                    from confluent_kafka.serialization import StringSerializer
                except ImportError as exc:
                    raise RuntimeError(
                        "confluent-kafka is not installed. "
                        "Add it to requirements.txt."
                    ) from exc

                self._producer = SerializingProducer(
                    {
                        "bootstrap.servers": settings.kafka_bootstrap_servers,
                        "client.id": "sentinel-x-backend",
                        # Batch for up to 10 ms to improve throughput on burst loads.
                        "linger.ms": 10,
                        "batch.size": 65_536,  # 64 KiB batch size
                        # zstd gives better compression ratios than lz4/gzip for JSON-like payloads.
                        "compression.type": "zstd",
                        # Retry up to 5 times with exponential backoff before giving up.
                        "retries": 5,
                        "retry.backoff.ms": 250,
                        # Require acknowledgement from all in-sync replicas.
                        "acks": "all",
                    },
                    value_serializer=lambda event, ctx: _avro_serialise(event),
                    key_serializer=StringSerializer("utf_8"),
                )
                logger.info(
                    "Kafka producer initialised",
                    bootstrap_servers=settings.kafka_bootstrap_servers,
                )
        return self._producer

    def close(self) -> None:
        """Flush pending messages and close the producer."""
        if self._producer is not None:
            remaining = self._producer.flush(timeout=10)
            if remaining > 0:
                logger.warning(
                    "Kafka flush timeout: messages may have been lost",
                    remaining=remaining,
                )
            self._producer = None
            logger.info("Kafka producer closed")


_singleton = _ProducerSingleton()


# ---------------------------------------------------------------------------
# Lifecycle hooks — wire into FastAPI lifespan
# ---------------------------------------------------------------------------

async def startup() -> None:
    """
    Eagerly initialise the Kafka producer during application startup.

    Calling this in the lifespan context ensures a clear error message if
    the broker is unreachable, rather than a confusing failure on the first
    event-producing request.
    """
    _singleton.get()  # triggers initialisation


async def shutdown() -> None:
    """Flush and close the Kafka producer during application shutdown."""
    _singleton.close()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def produce_event(event: dict[str, Any], key: str | None = None) -> None:
    """
    Enqueue an event for delivery to the configured Kafka topic.

    This is a non-blocking call.  The confluent-kafka producer batches messages
    internally and delivers them on a background thread.  Use `flush()` if you
    need synchronous confirmation — but do not call it per-event in a hot path.

    Args:
        event:  Dict matching the SentinelEvent Avro schema.
        key:    Optional partition key (e.g. sensor_id or tenant_id) to ensure
                events for the same entity land on the same partition and are
                therefore ordered relative to each other.
    """
    producer = _singleton.get()
    producer.produce(
        topic=settings.kafka_topic_events,
        key=key,
        value=event,
        on_delivery=_delivery_report,
    )
    # poll(0) services the delivery callback queue without blocking.
    # Without this call, callbacks accumulate indefinitely.
    producer.poll(0)


def _delivery_report(err: Any, msg: Any) -> None:
    """Confluent-kafka delivery callback — invoked on the producer's internal thread."""
    if err is not None:
        logger.error(
            "Kafka delivery failed",
            error=str(err),
            topic=msg.topic() if msg else "unknown",
        )
    else:
        logger.debug(
            "Kafka delivery confirmed",
            topic=msg.topic(),
            partition=msg.partition(),
            offset=msg.offset(),
        )
