# Sentinel-X Backend

FastAPI-based backend for the Sentinel-X situational awareness platform.

## Features

- Async FastAPI API with JWT-based authentication and RBAC
- PostgreSQL/PostGIS for multi-domain geospatial data
- Kafka + Redis topology for real-time streaming
- External integrations (NASA, OpenWeather, Space-Track, GFW, etc.)
- Mission workspaces, historical event playback, and Intel fusion

## Local development

```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Ensure PostgreSQL and Redis are running (see docker-compose.yml)
export POSTGRES_DSN=postgresql+asyncpg://sentinel:sentinel@localhost:5432/sentinel
export REDIS_URL=redis://localhost:6379/0
export SECRET_KEY=change-me-long-random

uvicorn app.main:app --reload --port 8000
