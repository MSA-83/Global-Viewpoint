# backend/tests/test_auth.py
"""
Authentication endpoint tests.

The original test referenced `async_client` which was not defined in conftest —
the fixture was named `client`.  Fixed to use `async_client` which is the
correct name after the conftest rewrite.  Also added a positive login test so
the suite verifies both happy and unhappy paths.
"""
import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_unauthorized_me(async_client: AsyncClient):
    """Calling /me without a token must return 401."""
    response = await async_client.get("/api/v1/auth/me")
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_register_and_login(async_client: AsyncClient):
    """A newly registered user can log in and retrieve their own profile."""
    email = "auth_test@sentinel-x.local"
    password = "Auth!T3st_P@ssw0rd"

    reg = await async_client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "display_name": "Auth Tester"},
    )
    assert reg.status_code == 201, reg.text

    login = await async_client.post(
        "/api/v1/auth/login",
        data={"username": email, "password": password},
    )
    assert login.status_code == 200
    token = login.json()["access_token"]
    assert token

    me = await async_client.get(
        "/api/v1/auth/me",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert me.status_code == 200
    assert me.json()["email"] == email


@pytest.mark.asyncio
async def test_login_wrong_password(async_client: AsyncClient):
    """Login with an incorrect password returns 401."""
    response = await async_client.post(
        "/api/v1/auth/login",
        data={"username": "nobody@example.com", "password": "wrong"},
    )
    assert response.status_code == 401
