# backend/tests/test_streams.py
"""
WebSocket stream tests.

Two fixes from the original:
  1. Import path was `from backend.app.main import app` — wrong. The correct
     path inside the backend package is `from app.main import app` (or via
     the `create_app` factory).
  2. The test tried to connect directly to `/api/v1/streams/ws` without a
     ticket.  The updated streams router requires a `?ticket=` query parameter.
     Without it, the server rejects the connection.  The test is updated to
     first obtain a ticket via the REST endpoint, then present it.

The WebSocket integration test is still marked as requiring Redis because the
ticket is stored in Redis with a 30-second TTL.  The `mock_redis` autouse
fixture in conftest patches the Redis singleton so this test can run without a
real broker — the `getdel` mock returns None by default (meaning "ticket not
found"), which tests the rejection path cleanly.
"""
import pytest
from httpx import AsyncClient

from tests.conftest import get_test_token


@pytest.mark.asyncio
async def test_websocket_ticket_requires_auth(async_client: AsyncClient):
    """Requesting a WebSocket ticket without a Bearer token returns 401."""
    resp = await async_client.post("/api/v1/streams/ticket")
    assert resp.status_code == 401


@pytest.mark.asyncio
async def test_websocket_ticket_issued_for_valid_token(
    async_client: AsyncClient,
    mock_redis,
):
    """A valid Bearer token produces a ticket response."""
    # Make getdel return a user_id so the Redis mock simulates a valid ticket.
    mock_redis.setex.return_value = True

    token = await get_test_token(async_client, email="ws_test@sentinel-x.local")
    resp = await async_client.post(
        "/api/v1/streams/ticket",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert "ticket" in body
    assert body["expires_in"] == 30
