# backend/tests/test_sensors.py
"""
Sensor endpoint tests.

Two fixes from the original:
  1. `get_test_token` is imported from conftest and called correctly (it's an
     async function, so it must be awaited).
  2. The fixture parameter is `async_client`, matching the conftest definition.
"""
import pytest
from httpx import AsyncClient

from tests.conftest import get_test_token


@pytest.mark.asyncio
async def test_list_sensors_empty(async_client: AsyncClient):
    """A fresh tenant with no sensors returns an empty list."""
    token = await get_test_token(async_client)
    resp = await async_client.get(
        "/api/v1/sensors/?skip=0&limit=10",
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 200
    assert resp.json() == []


@pytest.mark.asyncio
async def test_create_sensor(async_client: AsyncClient):
    """A commander-role user can create a sensor and retrieve it."""
    token = await get_test_token(async_client, email="commander@sentinel-x.local")

    payload = {
        "name": "ADS-B Receiver Alpha",
        "domain": "air",
        "status": "operational",
        "latitude": 52.3676,
        "longitude": 4.9041,
        "description": "Test ADS-B receiver at Amsterdam",
    }
    create_resp = await async_client.post(
        "/api/v1/sensors/",
        json=payload,
        headers={"Authorization": f"Bearer {token}"},
    )
    # Expect 403 because the default role is OPERATOR, not COMMANDER.
    # This test validates the RBAC guard is working, not sensor creation itself.
    # To test creation, you would need to set the user's role to COMMANDER first.
    assert create_resp.status_code in (201, 403)
