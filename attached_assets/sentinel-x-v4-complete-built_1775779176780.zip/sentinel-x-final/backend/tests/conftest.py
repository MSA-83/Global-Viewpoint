# backend/tests/conftest.py
"""
Pytest fixtures for the Sentinel-X backend test suite.

Why the original conftest.py broke the entire test suite
---------------------------------------------------------
The original file constructed Settings with uppercase keyword arguments:

    Settings(APP_ENV="testing", SECRET_KEY="test-secret-key", ...)

Pydantic-settings v2 normalises all field names to lowercase internally.
Passing `SECRET_KEY=` as a keyword argument does not set the `secret_key`
field — it is treated as an extra key and silently ignored (because the model
uses `extra="ignore"`).  The actual `secret_key` field is then left unset,
causing Pydantic to raise a ValidationError before the first test runs.

There was a second problem: even if the name had been correct, the value
"test-secret-key" is only 15 characters long.  The `validate_secret_key`
validator requires at least 32 characters, so validation fails again.

Both problems are fixed here by using the correct lowercase field names and a
sufficiently long test key.

Fixture architecture
--------------------
The fixture tree is designed so that:

  1. The database engine is created once per test SESSION (expensive: creates
     all tables in SQLite memory).

  2. Each test gets a fresh TRANSACTION that is rolled back at teardown, so
     tests never see each other's writes — even if they both commit.

  3. The FastAPI `client` fixture overrides the `get_db` dependency to inject
     the test session, so handlers run against the same in-memory database as
     the test assertions without any real PostgreSQL required.

  4. `mock_redis` and `mock_kafka` patch the module-level singletons so tests
     that exercise routes touching Redis or Kafka never need running brokers.

get_test_token helper
----------------------
Several tests (test_sensors.py, test_events.py) import `get_test_token` from
this module.  We define it here as an async function that calls the `/register`
endpoint (available in the `testing` environment) and then `/login`, returning
the resulting access token string.
"""
from __future__ import annotations

import asyncio
from collections.abc import AsyncGenerator
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

from app.core.config import Settings
from app.db.base import Base
from app.deps.db import get_db
from app.main import create_app

# ---------------------------------------------------------------------------
# In-memory SQLite database URL for fast, hermetic tests
# ---------------------------------------------------------------------------
_TEST_DB_URL = "sqlite+aiosqlite:///:memory:"


# ---------------------------------------------------------------------------
# Settings override — lowercase field names, long-enough SECRET_KEY
# ---------------------------------------------------------------------------
# We cannot monkey-patch the module-level `settings` singleton directly because
# it is already constructed at import time.  Instead we pass overrides through
# environment variables that pydantic-settings reads before the validators run.
# For tests, the simplest approach is to construct a fresh Settings object with
# the correct values and pass it to any fixture that needs it.  Fixtures that
# call `create_app()` will use the real singleton, so we also patch the DB
# dependency (see `client` fixture below).

TEST_SETTINGS_KWARGS = dict(
    app_name="Sentinel-X-Test",
    environment="testing",
    debug=True,
    # ↓ lowercase  ↓ at least 32 chars (validator requires it)
    secret_key="test-sentinel-x-secret-key-32ch!",
    jwt_algorithm="HS256",
    access_token_expire_minutes=5,
    refresh_token_expire_days=1,
    postgres_dsn="sqlite+aiosqlite:///:memory:",
    redis_url="redis://localhost:6379/0",
    kafka_bootstrap_servers="localhost:9092",
    kafka_topic_events="test.events",
    cors_origins=["http://localhost:3000"],
)


# ---------------------------------------------------------------------------
# Event loop (session-scoped so all async fixtures share one loop)
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def event_loop():
    policy = asyncio.get_event_loop_policy()
    loop = policy.new_event_loop()
    yield loop
    loop.close()


# ---------------------------------------------------------------------------
# Database engine — created once per session, schema set up at creation time
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture(scope="session")
async def async_engine() -> AsyncGenerator[AsyncEngine, None]:
    """
    Create an in-memory SQLite engine and initialise the full schema.

    Session-scoped so table creation happens only once.  Individual tests get
    transaction-isolated sessions via the `db_session` fixture below.
    """
    engine = create_async_engine(
        _TEST_DB_URL,
        echo=False,
        future=True,
        connect_args={"check_same_thread": False},
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


# ---------------------------------------------------------------------------
# Per-test database session — wrapped in a SAVEPOINT for automatic rollback
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture
async def db_session(async_engine: AsyncEngine) -> AsyncGenerator[AsyncSession, None]:
    """
    Yield a function-scoped session that is always rolled back at teardown.

    Using SAVEPOINT (nested transaction) means each test can freely call
    `commit()` inside its session — the outer transaction rollback undoes all
    of it, leaving the in-memory database in a pristine state for the next test.
    """
    session_factory = sessionmaker(
        async_engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )
    async with session_factory() as session:
        async with session.begin():
            yield session
            await session.rollback()


# ---------------------------------------------------------------------------
# FastAPI async test client with DB dependency override
# ---------------------------------------------------------------------------

@pytest_asyncio.fixture
async def async_client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """
    Provide an async HTTP client wired to the in-memory test database.

    We override the `get_db` FastAPI dependency so that every request handler
    receives the same `db_session` instance that the test is using — meaning
    test assertions and handler writes see the same data.

    Note: services that contact Redis or Kafka are also mocked out here via
    the `mock_redis` and `mock_kafka` fixtures below so tests run without
    running brokers.
    """
    app = create_app()

    async def _override_get_db() -> AsyncGenerator[AsyncSession, None]:
        yield db_session

    app.dependency_overrides[get_db] = _override_get_db

    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://testserver",
    ) as client:
        yield client


# ---------------------------------------------------------------------------
# Mock external services (Redis, Kafka)
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def mock_redis(monkeypatch):
    """
    Patch the Redis singleton so tests never need a running Redis instance.

    `autouse=True` means this fixture is applied to every test in the suite
    automatically — no test accidentally makes a real Redis call.
    """
    mock = AsyncMock()
    mock.ping = AsyncMock(return_value=True)
    mock.publish = AsyncMock(return_value=1)
    mock.setex = AsyncMock(return_value=True)
    mock.getdel = AsyncMock(return_value=None)
    monkeypatch.setattr("app.services.redis_pubsub._redis", mock)
    monkeypatch.setattr("app.services.redis_pubsub._pool", MagicMock())
    return mock


@pytest.fixture(autouse=True)
def mock_kafka(monkeypatch):
    """
    Patch the Kafka producer singleton so tests never need a running broker.
    """
    mock_producer = MagicMock()
    mock_producer.produce = MagicMock()
    mock_producer.poll = MagicMock(return_value=0)
    mock_producer.flush = MagicMock(return_value=0)
    monkeypatch.setattr("app.services.kafka_producer._singleton._producer", mock_producer)
    return mock_producer


# ---------------------------------------------------------------------------
# Helper: obtain an access token for a freshly-registered test user
# ---------------------------------------------------------------------------

async def get_test_token(client: AsyncClient, email: str = "test@sentinel-x.local") -> str:
    """
    Register a test user (if not already present) and return a valid JWT.

    Several test modules import this function directly from conftest.py.
    It relies on the `/register` endpoint being open in `testing` environment,
    which the auth router allows when `settings.environment == "testing"`.
    """
    password = "T3st!Passw0rd_Sentinel"

    # Attempt registration — ignore 409 Conflict (user already exists).
    await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": password, "display_name": "Test User"},
    )

    # Login to obtain a token.
    login_resp = await client.post(
        "/api/v1/auth/login",
        data={"username": email, "password": password},
    )
    assert login_resp.status_code == 200, f"Login failed: {login_resp.text}"
    return login_resp.json()["access_token"]
