# backend/tests/test_events.py
"""
Event endpoint tests.

Three fixes from the original:
  1. Removed the `token = "…"` placeholder — actual auth is now wired via
     `get_test_token` from conftest.
  2. Changed the Event import path from `backend.app.models.event` to the
     correct package-relative `app.models.event`.
  3. The `app` fixture argument was removed — the `async_client` fixture
     already embeds the application instance.
"""
import pytest
from datetime import datetime, timedelta, timezone

from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.event import Event, EventSeverity, EventType
from tests.conftest import get_test_token


@pytest.mark.asyncio
async def test_events_empty_window(async_client: AsyncClient):
    """An empty time window returns an empty list, not an error."""
    token = await get_test_token(async_client, email="events_test@sentinel-x.local")

    now = datetime.now(timezone.utc)
    resp = await async_client.get(
        "/api/v1/events/",
        params={
            "from_ts": (now - timedelta(hours=1)).isoformat(),
            "to_ts": now.isoformat(),
        },
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 200
    assert resp.json() == []


@pytest.mark.asyncio
async def test_events_returns_seeded_data(
    async_client: AsyncClient,
    db_session: AsyncSession,
):
    """Events written directly to the DB appear in the API response."""
    token = await get_test_token(async_client, email="events_seed@sentinel-x.local")
    now = datetime.now(timezone.utc)

    event = Event(
        event_type=EventType.DETECTION,
        severity=EventSeverity.HIGH,
        title="Test Detection Event",
        occurred_at=now,
        classification="UNCLASSIFIED",
    )
    db_session.add(event)
    await db_session.flush()

    resp = await async_client.get(
        "/api/v1/events/",
        params={
            "from_ts": (now - timedelta(minutes=5)).isoformat(),
            "to_ts": (now + timedelta(minutes=5)).isoformat(),
        },
        headers={"Authorization": f"Bearer {token}"},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) >= 1
    assert any(e["title"] == "Test Detection Event" for e in data)
