{{/*
  helm/sentinel-x/_helpers.tpl

  Named template helpers shared across all Sentinel-X Helm templates.
  These follow the standard Helm "named template" pattern: each helper is
  defined with {{- define "name" -}} and called with {{- include "name" . -}}.

  The trailing dashes ({{- and -}}) trim surrounding whitespace, which prevents
  accidental blank lines from appearing in the rendered YAML — a common source
  of "invalid YAML" errors in multi-line template blocks.
*/}}

{{/*
  sentinel-x.fullname
  Returns the fully-qualified release name, capped at 63 characters
  (the Kubernetes label value limit).
*/}}
{{- define "sentinel-x.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end }}

{{/*
  sentinel-x.chart
  Returns "chart-name-chart-version" — used as an annotation value so you
  can trace which chart version deployed a given resource.
*/}}
{{- define "sentinel-x.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
  sentinel-x.labels
  Standard set of recommended Kubernetes labels applied to every resource.
  These power `kubectl get -l app.kubernetes.io/instance=...` queries and
  are indexed by most Kubernetes dashboard tools.
*/}}
{{- define "sentinel-x.labels" -}}
helm.sh/chart: {{ include "sentinel-x.chart" . }}
app.kubernetes.io/name: {{ include "sentinel-x.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
  sentinel-x.selectorLabels
  Minimal label set used for pod selectors and Service selectors.
  These must be IMMUTABLE after first deploy — Kubernetes rejects updates to
  Deployment selectors. Do NOT add chart version or any other changing value here.
  The `component` label is injected by callers to distinguish backend from frontend.
*/}}
{{- define "sentinel-x.selectorLabels" -}}
app.kubernetes.io/name: {{ include "sentinel-x.fullname" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
  sentinel-x.secretName
  Returns the name of the Kubernetes Secret that holds all sensitive env vars.
  Centralised here so every template references the same name without risk of typos.
*/}}
{{- define "sentinel-x.secretName" -}}
{{- printf "%s-secrets" (include "sentinel-x.fullname" .) -}}
{{- end }}

{{/*
  sentinel-x.backendServiceName / sentinel-x.frontendServiceName
  Stable service names used by the Ingress to route traffic. Keeping these in
  helpers prevents the ingress and service templates from getting out of sync.
*/}}
{{- define "sentinel-x.backendServiceName" -}}
{{- printf "%s-backend" (include "sentinel-x.fullname" .) -}}
{{- end }}

{{- define "sentinel-x.frontendServiceName" -}}
{{- printf "%s-frontend" (include "sentinel-x.fullname" .) -}}
{{- end }}
