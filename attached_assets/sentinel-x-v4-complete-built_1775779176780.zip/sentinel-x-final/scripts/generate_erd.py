#!/usr/bin/env python
# scripts/generate_erd.py
#
# Generates a PNG entity-relationship diagram of the Sentinel-X database schema.
#
# BUG FIXED: The original imported `from backend.app.db.base import Base` and
# `from backend.app.core.config import settings`. This path assumes the script
# is run from a directory where `backend` is an importable package, which
# requires a `backend/__init__.py` file (none exists) AND that the repo root
# is on sys.path.
#
# The correct pattern for a script in `scripts/` that needs to import from
# `backend/app/` is to manipulate sys.path to include the backend directory
# directly, then import using the `app.*` prefix — the same prefix the backend
# application itself uses at runtime.
#
# Usage:
#   From the repository root:
#     pip install sqlalchemy-schemadisplay psycopg2-binary
#     POSTGRES_DSN="postgresql://sentinel:pw@localhost:5432/sentinel" \
#       python scripts/generate_erd.py
#
# The script will write docs/schema-erd.png.

import os
import sys

# Add backend/ to sys.path so `from app.xxx import ...` resolves correctly,
# matching the import convention used throughout the backend application.
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND_DIR = os.path.join(REPO_ROOT, "backend")
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

# These imports must come after the sys.path manipulation above.
from app.db.base import Base       # noqa: E402
from app.core.config import settings  # noqa: E402

# Import all models so their tables are registered in Base.metadata.
import app.models  # noqa: E402, F401


def main() -> None:
    try:
        from sqlalchemy_schemadisplay import create_schema_graph
        from sqlalchemy import create_engine
    except ImportError:
        print(
            "ERROR: sqlalchemy-schemadisplay is not installed.\n"
            "Install it with: pip install sqlalchemy-schemadisplay"
        )
        sys.exit(1)

    # Strip the async driver prefix — synchronous psycopg2 is needed for the
    # schema inspection query that sqlalchemy-schemadisplay performs.
    dsn = os.getenv(
        "POSTGRES_DSN",
        settings.postgres_dsn.replace("+asyncpg", ""),
    )

    engine = create_engine(dsn)
    graph = create_schema_graph(
        metadata=Base.metadata,
        show_datatypes=True,
        show_indexes=False,
        rankdir="LR",        # Left-to-right layout is more readable for wide schemas
        concentrate=False,
    )

    output_dir = os.path.join(REPO_ROOT, "docs")
    os.makedirs(output_dir, exist_ok=True)
    path = os.path.join(output_dir, "schema-erd.png")
    graph.write_png(path)
    print(f"Schema ERD written to {path}")


if __name__ == "__main__":
    main()
