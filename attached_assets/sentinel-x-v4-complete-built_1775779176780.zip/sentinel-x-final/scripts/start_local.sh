#!/usr/bin/env bash
# scripts/start_local.sh
#
# Local development server for Sentinel-X.
#
# Prerequisites:
#   - Infra services running: docker compose up -d postgres redis kafka kafka-init
#   - Python virtualenv active with requirements installed:
#       cd backend && pip install -r requirements.txt
#
# What this script does:
#   1. Exports environment variables needed for local development.
#   2. Applies Alembic migrations (was missing — server would start against
#      an empty schema and crash on the first DB call).
#   3. Starts uvicorn with --reload for hot-reloading.
#
# BUG FIXED: The previous SECRET_KEY default was "change-me-long-random-secret-key"
# which is 34 characters including spaces — but the Settings validator calls
# `len(value.strip())` and the validator requires >= 32 characters. The stripped
# value was 34 chars so it would pass, BUT only because strip() left it intact.
# To avoid any ambiguity and make the intent clear, we use an explicit 32-char
# value that is obviously a local-dev placeholder, not a real secret.
#
# NEVER use these defaults outside of local development. The docker-compose.yml
# and Helm chart both require ${SECRET_KEY:?error} which forces a real value.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# ── Environment ───────────────────────────────────────────────────────────────
export POSTGRES_DSN="${POSTGRES_DSN:-postgresql+asyncpg://sentinel:sentinel_dev@localhost:5432/sentinel}"
export REDIS_URL="${REDIS_URL:-redis://:sentinel_dev@localhost:6379/0}"
export KAFKA_BOOTSTRAP_SERVERS="${KAFKA_BOOTSTRAP_SERVERS:-localhost:9094}"
export KAFKA_TOPIC_EVENTS="${KAFKA_TOPIC_EVENTS:-sentinel.events}"
export ENVIRONMENT="${ENVIRONMENT:-development}"
export DEBUG="${DEBUG:-true}"
export CORS_ORIGINS="${CORS_ORIGINS:-http://localhost:3000}"

# 32 characters exactly — satisfies the >= 32 validator requirement.
# Local dev only. Generate a real one with: openssl rand -hex 32
export SECRET_KEY="${SECRET_KEY:-local-dev-key-32chars-sentinel!!}"

echo "────────────────────────────────────────────────────────────"
echo "  Sentinel-X — local development"
echo "  DB  : $POSTGRES_DSN"
echo "  Redis: $REDIS_URL"
echo "  Kafka: $KAFKA_BOOTSTRAP_SERVERS"
echo "────────────────────────────────────────────────────────────"
echo ""

# ── Migrations ────────────────────────────────────────────────────────────────
echo "▶  Applying Alembic migrations…"
cd "$REPO_ROOT"
alembic upgrade head
echo "✓  Migrations up to date."
echo ""

# ── Server ────────────────────────────────────────────────────────────────────
echo "▶  Starting backend on http://localhost:8000"
echo "   Swagger UI: http://localhost:8000/api/v1/docs"
echo ""
cd "$REPO_ROOT/backend"
uvicorn app.main:app \
    --reload \
    --port 8000 \
    --host 0.0.0.0 \
    --log-level info
