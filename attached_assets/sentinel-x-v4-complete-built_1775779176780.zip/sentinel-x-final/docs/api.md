# Sentinel-X API Reference

Base URL: `/api/v1`  
Interactive docs: `http://localhost:8000/api/v1/docs` (Swagger UI)  
OpenAPI schema: `http://localhost:8000/api/v1/openapi.json`

---

## Authentication

All endpoints except `/health`, `/ready`, and `/version` require a valid
JWT access token in the `Authorization: Bearer <token>` header.

### `POST /api/v1/auth/login`

Authenticate with email and password. Returns an access token in the JSON
body and sets a refresh token as an httpOnly Secure cookie.

**Request body** (form-encoded):
```
username=user@example.com&password=your_password
```

**Response:**
```json
{ "access_token": "eyJ...", "token_type": "bearer" }
```

### `POST /api/v1/auth/refresh`

Exchange the refresh token cookie for a new access token. No request body
needed — the browser sends the cookie automatically.

### `POST /api/v1/auth/logout`

Clears the refresh token cookie server-side.

### `POST /api/v1/auth/register`

Create a new user. **Only available in `development` environment.**

### `GET /api/v1/auth/me`

Return the authenticated user's profile.

---

## Health / Observability

These endpoints are **unauthenticated** — required for Kubernetes probes.

| Endpoint | Purpose | K8s probe type |
|---|---|---|
| `GET /health` | Liveness — checks DB connectivity | livenessProbe |
| `GET /ready` | Readiness — checks DB connectivity | readinessProbe |
| `GET /version` | Build metadata and uptime | — |

---

## Sensors

Minimum role: **OPERATOR** (read), **COMMANDER** (write).

### `GET /api/v1/sensors/`

List sensors, optionally filtered by domain. Supports `skip` and `limit`
pagination. Returns a list of `SensorRead` objects.

### `POST /api/v1/sensors/`

Create a new sensor. Requires COMMANDER role.

**Request body:**
```json
{
  "name": "ADS-B Alpha",
  "domain": "air",
  "latitude": 52.3676,
  "longitude": 4.9041,
  "platform": "OpenSky",
  "status": "operational"
}
```

### `GET /api/v1/sensors/{sensor_id}`

Return a single sensor by UUID.

---

## Events

Minimum role: **OPERATOR**.

### `GET /api/v1/events/`

Query events within a time window. Results are tenant-scoped, ordered newest
first, capped at `limit` rows (default 500, max 5000).

**Query parameters:**
- `from_ts` — ISO 8601 datetime (inclusive, required)
- `to_ts` — ISO 8601 datetime (exclusive, required)
- `severity` — filter: `info` | `low` | `medium` | `high` | `critical`
- `event_type` — filter: `detection` | `alert` | `track_update` | etc.
- `limit` — max rows (default 500)

---

## Streams (WebSocket)

### `POST /api/v1/streams/ticket`

Exchange a valid Bearer token for a single-use WebSocket connection ticket.
The ticket is a 32-byte URL-safe nonce stored in Redis with a 30-second TTL.

**Response:** `{ "ticket": "abc123...", "expires_in": 30 }`

### `WS /api/v1/streams/ws?ticket=<nonce>`

Open a real-time WebSocket event stream. The ticket from `/streams/ticket`
must be passed as the `ticket` query parameter. Tickets are single-use;
fetch a new one for each reconnect. Close code `4001` means the ticket was
invalid or expired — do not retry without obtaining a fresh ticket.

Each message is a JSON-encoded `StreamEvent` object:
```json
{
  "id": "uuid",
  "event_type": "detection",
  "severity": "high",
  "title": "Vessel off expected route",
  "occurred_at": "2026-04-09T12:34:56Z",
  "geometry": { "type": "Point", "coordinates": [4.9, 52.3] },
  "classification": "UNCLASSIFIED"
}
```

---

## Intelligence

Minimum role: **ANALYST** (overview), **OPERATOR** (individual domain endpoints).

### `GET /api/v1/intel/overview`

Return fused multi-domain intelligence for a geographic area. All domains
are queried concurrently. A missing API key or unreachable upstream returns
an empty result for that domain without failing the entire response.

**Query parameters:**
- `lat` — centre latitude (required)
- `lon` — centre longitude (required)
- `radius_km` — search radius in km (default 250, max 2000)
- `domains` — repeated param: `weather`, `aviation`, `maritime`, `natural`, `cyber`, `fishing`, `orbital`

**Response shape:**
```json
{
  "query": { "lat": 52.37, "lon": 4.90, "radius_km": 250, "domains": [...] },
  "weather": { ... },
  "aviation": { "sigmets": [...], "metars": [...] },
  "maritime": { "vessels": [...], "vessel_count": 12 },
  "natural_events": [...],
  "cyber": { "exposed_hosts": [...], "host_count": 5 },
  "fishing": [...],
  "orbital": [...]
}
```

### `GET /api/v1/intel/sigmet`

Return all active SIGMETs globally, optionally filtered by `hazard` type
(`TURB`, `ICE`, `VA`, `TC`).

### `GET /api/v1/intel/cyber/host/{ip_address}`

Return Shodan intelligence for a specific IP: open ports, OS, ASN, CVEs.

### `GET /api/v1/intel/maritime/vessels`

Snapshot of vessels within a radius. Params: `lat`, `lon`, `radius_km`.

---

## Workspaces

Minimum role: **OPERATOR**.

### `GET /api/v1/workspaces/`

List all workspaces owned by the authenticated user.

### `POST /api/v1/workspaces/`

Create a new workspace.

**Request body:**
```json
{
  "name": "North Sea Patrol",
  "description": "Maritime surveillance — watch zone Alpha",
  "config": {}
}
```
`config` is optional and defaults to `{}`.

### `GET /api/v1/workspaces/{workspace_id}`

Return a single workspace. Enforces ownership — returns 404 if the workspace
belongs to a different user.

### `DELETE /api/v1/workspaces/{workspace_id}`

Soft-delete a workspace. Ownership enforced.

---

## Role reference

| Role | Level | Can do |
|---|---|---|
| `operator` | 1 | Read sensors, events, workspaces; open WebSocket |
| `analyst` | 2 | Above + intel overview |
| `commander` | 3 | Above + create/update sensors |
| `admin` | 4 | All operations including user management |
