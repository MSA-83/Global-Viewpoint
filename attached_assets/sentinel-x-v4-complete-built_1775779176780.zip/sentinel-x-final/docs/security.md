# Security Hardening Checklist

| Area | Controls Implemented | Recommended Enhancements |
|------|----------------------|--------------------------|
| **Authentication** | Argon2 password hashing, JWT access + refresh, httpOnly Secure SameSite‑Strict cookies | Enforce MFA for privileged users, rotate JWT signing keys quarterly |
| **Transport** | All endpoints served over HTTPS (Ingress terminates TLS) | Enable HTTP/2, enforce HSTS header |
| **Secrets** | Loaded from environment variables / Kubernetes Secrets | Integrate with HashiCorp Vault or GCP Secret Manager for automatic rotation |
| **Rate Limiting** | FastAPI‑Limiting middleware (future integration) | Deploy API‑gateway (e.g., Kong) with per‑IP limits |
| **Input Validation** | Pydantic v2 strict models, GeoJSON validators | Add JSON schema validation for external API payloads |
| **CORS** | Whitelisted frontend origins only | Dynamically generate allowed origins per environment |
| **Audit Logging** | Loguru JSON logs, include user ID, request ID | Ship logs to centralized SIEM (e.g., Elastic Stack) |
| **Dependency Scanning** | Trivy scan in CI, Dependabot PRs | Add Snyk or GitHub Advanced Security for deeper analysis |
