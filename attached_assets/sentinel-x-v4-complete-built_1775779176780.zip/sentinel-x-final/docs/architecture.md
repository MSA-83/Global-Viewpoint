# Architecture Overview — Sentinel-X

Sentinel-X is a multi-domain situational awareness platform that aggregates
real-time intelligence feeds across aviation, maritime, orbital, seismic,
weather, conflict, and cyber domains into a unified geospatial dashboard.

---

## System Diagram

```mermaid
graph TB
  subgraph Browser["Browser (Operator)"]
    FE["Next.js 14 App Router\nReact · TypeScript · Deck.gl · Mapbox"]
  end

  subgraph API["FastAPI Backend (GKE — 2–8 replicas)"]
    direction TB
    AUTH["Auth Router\nArgon2id · JWT · httpOnly cookies"]
    SENSORS["Sensors Router\nCRUD · PostGIS Point"]
    EVENTS["Events Router\nPlayback · tenant-scoped"]
    INTEL["Intel Router\nasyncio.gather() fan-out"]
    STREAMS["Streams Router\nWebSocket ticket pattern"]
    HEALTH["Health / Ready probes\n(unauthenticated)"]
  end

  subgraph Data["Persistent Data Layer"]
    PG[("PostgreSQL 15\n+ PostGIS 3.4\nSensors · Events · Users · Workspaces")]
    REDIS[("Redis 7\nPub/Sub fan-out\nWS ticket cache")]
    KAFKA[("Kafka 3.7 KRaft\nAvro-serialised events\n6-partition sentinel.events")]
  end

  subgraph External["External Intelligence Sources"]
    EONET["NASA EONET\nNatural events (bbox filter)"]
    OWM["OpenWeatherMap\nCurrent conditions"]
    AVWX["AVWX\nSIGMETs · METARs"]
    AIS["AISStream.io\nWebSocket · live AIS"]
    SHODAN["Shodan\nCyber host intelligence"]
    ST["Space-Track\nTLE / orbital data"]
    GFW["Global Fishing Watch\nVessel activity"]
  end

  subgraph Infra["Infrastructure (GKE + Helm)"]
    INGRESS["nginx-ingress\n/api/* → backend\n/ → frontend"]
    HPA["HorizontalPodAutoscaler\n2–8 backend replicas\n2–6 frontend replicas"]
    SEALED["Sealed Secrets / ESO\nGCP Secret Manager"]
  end

  subgraph Observability["Observability"]
    PROM["Prometheus"]
    GRAFANA["Grafana"]
    OTEL["OpenTelemetry\nOTLP traces"]
  end

  FE -- "HTTPS REST" --> INGRESS
  FE -- "WSS ticket flow" --> INGRESS
  INGRESS --> AUTH & SENSORS & EVENTS & INTEL & STREAMS & HEALTH

  AUTH --> PG
  SENSORS --> PG
  EVENTS --> PG
  STREAMS -- "GETDEL ticket" --> REDIS
  STREAMS -- "subscribe sentinel.events" --> REDIS
  INTEL --> EONET & OWM & AVWX & AIS & SHODAN & ST & GFW

  API -- "Avro produce" --> KAFKA
  KAFKA -- "consumer → publish" --> REDIS

  SEALED --> API
  HPA --> API
  API --> PROM & OTEL
  PROM --> GRAFANA
```

---

## Data Flow: Real-time Event Streaming

1. An external adapter (e.g. AISStream WebSocket consumer) or a sensor
   pushes a new event to the backend.
2. The backend serialises it as an Avro record and produces it to the
   `sentinel.events` Kafka topic (6 partitions for parallelism).
3. A Kafka consumer (co-located in the backend or a separate worker pod)
   reads from the topic and publishes the JSON-decoded event to the
   `sentinel.events` Redis Pub/Sub channel.
4. Every connected WebSocket client has a goroutine subscribing to that
   channel. The message is immediately relayed to the browser.
5. The browser's `useEventStream` hook receives the JSON, deserialises it,
   and appends it to the event ring buffer (capped at 1 000 events).
6. Deck.gl re-renders only the affected layer using React's reconciler.

## Data Flow: Historical Playback

1. The operator selects a time window in the PlaybackControls panel.
2. The frontend calls `GET /api/v1/events/?from_ts=…&to_ts=…`.
3. The events router queries PostgreSQL with a half-open interval filter
   on `occurred_at`, scoped to the operator's `tenant_id`.
4. Results are returned newest-first and rendered in the EventTimeline.

## Data Flow: Intelligence Overview

1. The operator navigates to `/intel` and sets lat/lon/radius.
2. The frontend calls `GET /api/v1/intel/overview?domains=…`.
3. The intel router fans out to all selected domain adapters concurrently
   using `asyncio.gather(return_exceptions=True)`.
4. Each adapter has its own timeout. A slow or failing upstream returns an
   empty list; it never blocks or poisons other domains.
5. The aggregated response is returned in < 10 seconds even when all seven
   domains are active.

---

## Security Model

| Layer | Mechanism |
|---|---|
| Passwords | Argon2id (64 MiB, 2 iterations, 4 parallel) |
| Access tokens | HS256 JWT, 30-minute TTL, held in React state (never localStorage) |
| Refresh tokens | HS256 JWT, 7-day TTL, httpOnly + Secure + SameSite=Strict cookie |
| WebSocket auth | Single-use Redis ticket (30s TTL), never a JWT in the URL |
| Transport | TLS terminated at nginx-ingress; HSTS recommended |
| Container security | Non-root user (appuser), `readOnlyRootFilesystem: true`, all capabilities dropped |
| Secrets | Kubernetes Secrets (Sealed Secrets or ESO for GitOps) |
| RBAC | Four roles: OPERATOR < ANALYST < COMMANDER < ADMIN |
| Multi-tenancy | `tenant_id` on every row; queries always scoped to caller's tenant |

---

## Component Inventory

| Component | Technology | Purpose |
|---|---|---|
| FastAPI backend | Python 3.12, uvicorn | REST API + WebSocket broker |
| PostgreSQL | 15 + PostGIS 3.4 | Primary datastore with geospatial support |
| Redis | 7 | WebSocket fan-out (Pub/Sub) + WS ticket cache |
| Kafka | 3.7, KRaft mode | Durable event ingestion, Avro schema |
| Next.js frontend | 14, App Router | Operator dashboard |
| Deck.gl | 8.9 | WebGL geospatial visualisation |
| GKE | Kubernetes 1.25+ | Container orchestration |
| Helm | 3.x | Kubernetes manifest templating |
| Terraform | 1.6+ | GKE cluster provisioning |
| Alembic | 1.13 | Database schema migrations |
| OpenTelemetry | SDK 1.27 | Distributed tracing (optional) |
