# Sentinel‑X

Sentinel‑X is an open‑source, production‑grade **global situational awareness platform** built for defense‑grade, NATO‑style command‑and‑control use‑cases.

- **Real‑time geospatial streams** via WebSocket + Redis Pub/Sub
- **Secure authentication** (Google OAuth 2.0, JWT access/refresh, Argon2 password hashing)
- **Scalable ingestion** with Apache Kafka and Avro schema
- **Rich map visualisation** powered by Mapbox GL + Deck.gl
- **Observability** via OpenTelemetry, Prometheus, Grafana
- **Infrastructure‑as‑code**: Helm + Terraform for Kubernetes deployments

> **All secrets are injected via environment variables or Kubernetes Secrets; never checked into source control.**
